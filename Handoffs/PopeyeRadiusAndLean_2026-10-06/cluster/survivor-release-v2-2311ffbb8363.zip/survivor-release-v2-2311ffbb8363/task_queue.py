"""Durable, bounded continuation tasks for finalized survivor forests.

This module deliberately is *not* named queue.py: workers import the standard
library queue through multiprocessing.  Original L/S tokens remain source
leaves.  A new C token needs its own input-bound method evidence and fresh
numerical replay; it is never reinterpreted as an old L/S certificate.

There is no Slurm operation here and no physical Lean admission.  Sources are
streamed one bounded record at a time, and only a DONE-pinned complete packet
can publish an import commit.  A task lease holds flock for its whole lifetime,
in addition to a durable expiring token, so an expired live worker is not stolen.
"""
from __future__ import annotations

from contextlib import contextmanager
from fractions import Fraction as Q
from pathlib import Path
import argparse
import fcntl
import gzip
import hashlib
import json
import os
import resource
import shutil
import sqlite3
import sys
import time
import uuid

if __package__:
    from . import dispatch_hold
else:
    import dispatch_hold

SCHEMA = 1
MAX_DEPTH = 48
MAX_TREE_NODES = 262143
MAX_TASK_NODES = 4095
MAX_JSON_BYTES = 16 * 2**20
MAX_SOURCE_RECORD_BYTES = 2 * 2**20
MAX_INPUT_BYTES = 8 * 2**20
MAX_EVIDENCE_BYTES = 12 * 2**20
SHARDS = "0123456789abcdef"
HARD_GUARDS = {"depth_guard", "forest_size_guard", "task_forest_size_guard",
               "worker_peak_rss_512MiB", "disk_reserve_8GiB", "memory_guard",
               "phase_guard", "stop_requested"}


class EvidenceLimit(Exception):
    """A hard per-chunk memory/disk bound, never permission for a larger task."""


class ResourceStop(Exception):
    """Inherited disk/RSS guard: fatal to this import or worker campaign."""


def resource_guard(area):
    if shutil.disk_usage(area).free < 8 * 2**30:
        raise ResourceStop("disk_reserve_8GiB")
    rss = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    if sys.platform != "darwin":
        rss *= 1024
    if rss > 512 * 2**20:
        raise ResourceStop("worker_peak_rss_512MiB")


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def digest(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def tree_sha(tree):
    return hashlib.sha256(tree.encode("ascii")).hexdigest()


def sha_file(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda: f.read(2**20), b""):
            h.update(block)
    return h.hexdigest()


def _fsync_dir(path):
    fd = os.open(path, os.O_RDONLY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def durable_json(path, value):
    """A interrupted write cannot replace the last complete checkpoint."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    raw = canonical(value) + b"\n"
    if len(raw) > MAX_JSON_BYTES:
        raise ValueError("Bounded JSON record is too large")
    tmp = path.with_name(path.name + "." + uuid.uuid4().hex + ".tmp")
    try:
        with tmp.open("xb") as f:
            if path.suffix == ".gz":
                with gzip.GzipFile(fileobj=f, mode="wb", compresslevel=3, mtime=0) as gz:
                    gz.write(raw)
            else:
                f.write(raw)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
        _fsync_dir(path.parent)
    finally:
        tmp.unlink(missing_ok=True)


def read_json(path, limit=MAX_JSON_BYTES):
    path = Path(path)
    opener = gzip.open if path.suffix == ".gz" else open
    with opener(path, "rb") as f:
        raw = f.read(limit + 1)
    if len(raw) > limit:
        raise ValueError("Bounded JSON record is too large")
    return json.loads(raw)


def immutable_json(path, value):
    path = Path(path)
    if path.exists():
        if read_json(path) != value:
            raise ValueError("Immutable queue record changed: " + str(path))
    else:
        durable_json(path, value)


def inventory_lines(path):
    with Path(path).open("rb") as f:
        while True:
            line = f.readline(65537)
            if not line:
                return
            if len(line) > 65536 or not line.endswith(b"\n"):
                raise ValueError("Interrupted or oversized task inventory")
            yield line


@contextmanager
def locked(path):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a") as f:
        fcntl.flock(f, fcntl.LOCK_EX)
        yield


def exact_box(row):
    if type(row.get("id")) is not int or row["id"] < 0:
        raise ValueError("Invalid original ID")
    cc, rr = list(map(Q, row["centers"])), list(map(Q, row["radii"]))
    if len(cc) != 4 or len(rr) != 4 or not all(abs(c) < 4 for c in cc) or not all(0 < r <= 1 for r in rr):
        raise ValueError("Outside the original guarded radians domain")
    return cc, rr


def bisect(cc, rr, axis, bit):
    if type(axis) is not int or not 0 <= axis < 4 or bit not in "01":
        raise ValueError("Invalid exact split")
    cc, rr = list(cc), list(rr)
    rr[axis] /= 2
    cc[axis] += (1 if bit == "1" else -1) * rr[axis]
    return cc, rr


def walk_tree(tree, cc, rr, prefix="", new=False, max_nodes=MAX_TREE_NODES):
    """Independent preorder reader; geometry stack is bounded by depth 48."""
    if not isinstance(tree, str) or not 0 < len(tree) <= max_nodes:
        raise ValueError("Invalid bounded forest length")
    if any(bit not in "01" for bit in prefix) or len(prefix) > MAX_DEPTH:
        raise ValueError("Invalid subtree prefix")
    stack = [(prefix, list(cc), list(rr))]
    terminals = "PC" if new else "PLS"
    for token in tree:
        if not stack:
            raise ValueError("Trailing forest tokens")
        path, centers, radii = stack.pop()
        if token in "0123":
            if len(path) >= MAX_DEPTH:
                raise ValueError("Split exceeds the original depth guard")
            axis = int(token)
            right = bisect(centers, radii, axis, "1")
            left = bisect(centers, radii, axis, "0")
            stack.append((path + "1", *right))
            stack.append((path + "0", *left))
        elif token in terminals:
            yield path, token, centers, radii
        else:
            raise ValueError("Unknown forest token")
    if stack:
        raise ValueError("Truncated forest")


class _JsonStream:
    """Small standard-library reader for the fixed packet object/records array."""
    def __init__(self, stream):
        self.stream, self.buffer, self.eof = stream, "", False
        self.decoder = json.JSONDecoder()

    def _more(self):
        data = self.stream.read(65536)
        self.buffer += data
        self.eof = not data
        if len(self.buffer.encode()) > MAX_SOURCE_RECORD_BYTES + 65536:
            raise ValueError("Source JSON value exceeds the record bound")

    def _space(self):
        while True:
            self.buffer = self.buffer.lstrip()
            if self.buffer or self.eof:
                return
            self._more()

    def peek(self):
        self._space()
        return self.buffer[:1]

    def take(self, token):
        if self.peek() != token:
            raise ValueError("Malformed streaming packet")
        self.buffer = self.buffer[1:]

    def value(self):
        self._space()
        while True:
            try:
                obj, end = self.decoder.raw_decode(self.buffer)
                # A scalar at a block boundary may continue in the next block.
                if end == len(self.buffer) and not self.eof:
                    self._more()
                    continue
                if end < len(self.buffer) and self.buffer[end] not in ",]} \t\r\n:":
                    raise ValueError("Invalid JSON value delimiter")
                self.buffer = self.buffer[end:]
                return obj
            except json.JSONDecodeError as error:
                if self.eof:
                    raise ValueError("Truncated streaming packet") from error
                self._more()


def stream_packet(path):
    """Yield (metadata_key,value) and ('record',record), without a batch list."""
    with gzip.open(path, "rt", encoding="utf-8") as f:
        reader = _JsonStream(f)
        reader.take("{")
        keys = set()
        first = True
        while reader.peek() != "}":
            if not first:
                reader.take(",")
            first = False
            key = reader.value()
            if not isinstance(key, str) or key in keys or len(keys) >= 32:
                raise ValueError("Invalid or duplicate packet key")
            keys.add(key)
            reader.take(":")
            if key != "records":
                yield key, reader.value()
                continue
            reader.take("[")
            first_record = True
            while reader.peek() != "]":
                if not first_record:
                    reader.take(",")
                first_record = False
                record = reader.value()
                if not isinstance(record, dict):
                    raise ValueError("Source record is not an object")
                yield "record", record
            reader.take("]")
        reader.take("}")
        if reader.peek():
            raise ValueError("Trailing JSON after source packet")
        if "records" not in keys:
            raise ValueError("Packet has no records")


def _done_paths(root):
    area = Path(root) / "elastic-run/batches"
    if not area.is_dir():
        return
    with os.scandir(area) as shards:
        for shard in shards:
            if not shard.is_dir(follow_symlinks=False) or not shard.name.isdigit():
                continue
            with os.scandir(shard.path) as batches:
                for batch in batches:
                    if batch.is_dir(follow_symlinks=False) and batch.name.isdigit():
                        path = Path(batch.path) / "DONE.json"
                        if path.is_file():
                            yield int(batch.name), path


def _load_inputs(db, batch):
    item = db.execute("SELECT first_id,n,raw_sha,payload FROM batches WHERE id=?", (batch,)).fetchone()
    if item is None:
        raise ValueError("DONE names an unknown input batch")
    first, n, expected, compressed = item
    if type(n) is not int or not 0 < n <= 256 or len(compressed) > MAX_INPUT_BYTES:
        raise ValueError("Input batch exceeds the frozen bound")
    # Decompression is bounded as well as the compressed SQLite field.
    import io
    with gzip.GzipFile(fileobj=io.BytesIO(compressed)) as f:
        raw = f.read(MAX_INPUT_BYTES + 1)
    if len(raw) > MAX_INPUT_BYTES or hashlib.sha256(raw).hexdigest() != expected:
        raise ValueError("Input batch checksum or size bound failed")
    rows = [json.loads(line) for line in raw.splitlines()]
    if len(rows) != n or [r["id"] for r in rows] != list(range(first, first + n)):
        raise ValueError("Input ID census differs")
    for row in rows:
        exact_box(row)
    return rows, expected


def _parked_reason(reason):
    return reason in HARD_GUARDS or "guard" in reason or reason.startswith("stop_")


class TaskQueue:
    def __init__(self, area):
        self.area = Path(area).resolve()
        self.area.mkdir(parents=True, exist_ok=True)

    def task_dir(self, ident):
        if not isinstance(ident, str) or len(ident) != 64 or any(c not in SHARDS for c in ident):
            raise ValueError("Invalid task ID")
        return self.area / "tasks" / ident[0] / ident

    def parent_dir(self, key):
        if not isinstance(key, str) or len(key) > 100 or any(c not in SHARDS + "-" for c in key):
            raise ValueError("Invalid parent key")
        return self.area / "parents" / key[-2:] / key

    def marker(self, ident):
        self.task_dir(ident)
        return self.area / "ready" / ident[0] / ident

    def _task_dispatch_runnable(self, ident):
        """Fail closed before publishing a descendant-work hint."""
        task = read_json(self.task_dir(ident) / "TASK.json")
        place = self.parent_dir(task["parent_key"])
        parent = read_json(place / "SOURCE.json.gz")
        record = self.parent_dispatch(parent)
        if self.dispatch_runnable(record):
            return True
        self.suppress_held_parent(parent, record)
        return False

    def _make_ready(self, ident):
        if not self._task_dispatch_runnable(ident):
            return False
        path = self.marker(ident)
        path.parent.mkdir(parents=True, exist_ok=True)
        try:
            with path.open("xb") as f:
                f.flush()
                os.fsync(f.fileno())
            _fsync_dir(path.parent)
        except FileExistsError:
            pass
        return True

    def parent_marker(self, kind, key):
        if kind not in ("root_ready", "replay_ready"):
            raise ValueError("Unknown parent dispatch marker")
        self.parent_dir(key)
        return self.area / kind / key[-2:] / key

    def make_parent_marker(self, kind, key):
        place = self.parent_dir(key)
        parent = read_json(place / "SOURCE.json.gz")
        record = self.parent_dispatch(parent)
        if not self.dispatch_runnable(record):
            self.suppress_held_parent(parent, record)
            return False
        path = self.parent_marker(kind, key)
        path.parent.mkdir(parents=True, exist_ok=True)
        try:
            with path.open("xb") as f:
                f.flush()
                os.fsync(f.fileno())
            _fsync_dir(path.parent)
        except FileExistsError:
            pass
        return True

    def iter_parent_markers(self, kind, owner=None):
        if kind not in ("root_ready", "replay_ready"):
            raise ValueError("Unknown parent dispatch marker")
        base = self.area / kind
        if not base.is_dir():
            return
        shards = [a+b for a in SHARDS for b in SHARDS]
        if owner is not None:
            offset = int(hashlib.sha256(owner.encode()).hexdigest()[:2], 16)
            shards = shards[offset:] + shards[:offset]
        for shard in shards:
            path = base / shard
            if not path.is_dir():
                continue
            with os.scandir(path) as entries:
                for entry in entries:
                    if entry.is_file(follow_symlinks=False):
                        self.parent_dir(entry.name)
                        yield entry.name

    def claim_root(self, owner, lease_seconds=180, schedule_sha256=None):
        if __package__:
            from .parent_roots import claim_root
        else:
            from parent_roots import claim_root
        return claim_root(self, owner, lease_seconds, schedule_sha256)

    def parent_dispatch(self, parent):
        """Bind one exact scheduling decision to an immutable source parent."""
        if (parent.get("schema") != SCHEMA or parent.get("physical_lean_admissions") != 0
                or parent.get("input_sha256") != digest(parent.get("input"))):
            raise ValueError("Dispatch parent source binding changed")
        decision = dispatch_hold.classify(parent["input"])
        expected_scope = dispatch_hold.CONFIG["campaign_scope"]
        source = parent.get("source", {})
        queue_binding = read_json(self.area / "CONFIG.json")
        scope_match = (source.get("campaign_sha256") == expected_scope["campaign_sha256"]
                       and queue_binding.get("campaign_sha256") == expected_scope["campaign_sha256"]
                       and queue_binding.get("source_archive_sha256") == expected_scope["source_archive_sha256"])
        # Older source records pin the archive through the immutable queue
        # CONFIG rather than duplicating it in each parent.
        decision["campaign_scope_match"] = scope_match
        if not scope_match:
            decision["reviewed_numerical_theorem"]["status"] = "SOURCE_SCOPE_NOT_BOUND"
            decision["reviewed_numerical_theorem"]["covered_seeds"] = []
            decision["reviewed_numerical_theorem"]["whole_box_interface_accepts"] = False
            decision["reviewed_numerical_theorem"]["punctured_ball_statement"] = False
            decision["reviewed_numerical_theorem"]["seed_point_R_zero_separate"] = False
        record = {"schema": "survivor-parent-dispatch-v1",
                  "parent_key": parent["parent_key"], "original_id": parent["id"],
                  "input_sha256": parent["input_sha256"],
                  "source_record_sha256": parent["source_record_sha256"],
                  "source_tree_sha256": parent["source_tree_sha256"],
                  "classifier_sha256": dispatch_hold.SOURCE_SHA256,
                  "hold_config_sha256": dispatch_hold.CONFIG_SHA256,
                  "decision": decision, "unresolved_obligation_preserved": True,
                  "physical_lean_admissions": 0}
        immutable_json(self.parent_dir(parent["parent_key"]) / "DISPATCH.json", record)
        return record

    @staticmethod
    def dispatch_runnable(record):
        return record["decision"]["dispatch"] == "RUN_WHOLE_PARENT_STRICTLY_OUTSIDE_HOLD"

    def suppress_held_parent(self, parent, record=None):
        """Remove dispatch hints only; task checkpoints and evidence stay byte-for-byte."""
        record = self.parent_dispatch(parent) if record is None else record
        if self.dispatch_runnable(record):
            return False
        place = self.parent_dir(parent["parent_key"])
        ledger = place / "TASKS.jsonl"
        if ledger.exists():
            for line in inventory_lines(ledger):
                item = json.loads(line)
                self.marker(item["task_id"]).unlink(missing_ok=True)
        for kind in ("root_ready", "replay_ready"):
            self.parent_marker(kind, parent["parent_key"]).unlink(missing_ok=True)
        return True

    def reconcile_dispatch_hold(self):
        """Idempotently filter existing markers while preserving every obligation.

        The caller must keep the production stop held until this complete census
        returns.  Each parent is protected by its existing exclusive parent gate;
        the immutable decision is written before any advisory marker is removed.
        Claims independently repeat the same exact test, so a stale marker cannot
        authorize numerical work.
        """
        counts = {"schema": "survivor-dispatch-hold-census-v1", "parents": 0,
                  "runnable_parents": 0, "held_parents": 0,
                  "held_tasks": 0, "held_pending_roots": 0,
                  "reviewed_1_100_numerically_covered_parents": 0,
                  "outside_fragments_in_held_parents": "PRESERVED_UNSPLIT",
                  "hold_config_sha256": dispatch_hold.CONFIG_SHA256,
                  "classifier_sha256": dispatch_hold.SOURCE_SHA256,
                  "closure_credit": False, "physical_lean_admissions": 0}
        chain = hashlib.sha256()
        included_batches = set()
        for key in sorted(self.iter_parent_keys()):
            place = self.parent_dir(key)
            with (place / "PARENT_RUN.lock").open("a") as gate:
                fcntl.flock(gate, fcntl.LOCK_EX)
                parent = read_json(place / "SOURCE.json.gz")
                commit_path = self.area / "batches" / f"{parent['source']['batch']:06d}.json"
                if not commit_path.exists():
                    raise ValueError("Dispatch census encountered an uncommitted import parent")
                commit = read_json(commit_path)
                if commit["packet_sha256"] != parent["source"]["packet_sha256"]:
                    raise ValueError("Dispatch census source commit differs")
                included_batches.add(parent["source"]["batch"])
                record = self.parent_dispatch(parent)
                counts["parents"] += 1
                covered = record["decision"]["reviewed_numerical_theorem"]["status"] == "REVIEWED_NUMERICAL_EVIDENCE_ONLY"
                counts["reviewed_1_100_numerically_covered_parents"] += covered
                if self.dispatch_runnable(record):
                    counts["runnable_parents"] += 1
                else:
                    counts["held_parents"] += 1
                    ready = read_json(place / "READY.json")
                    counts["held_tasks"] += ready["tasks"]
                    counts["held_pending_roots"] += ready["pending_roots"]
                    self.suppress_held_parent(parent, record)
                chain.update(canonical({"parent_key": key, "dispatch_sha256": digest(record)}))
        counts["decision_chain_sha256"] = chain.hexdigest()
        counts["included_batches"] = sorted(included_batches)
        counts["ready_markers_after"] = self.readiness_count()
        counts["root_ready_markers_after"] = sum(1 for _ in self.iter_parent_markers("root_ready"))
        counts["replay_ready_markers_after"] = sum(1 for _ in self.iter_parent_markers("replay_ready"))
        durable_json(self.area / "DISPATCH_HOLD_CENSUS.json", counts)
        return counts

    def _initial_state(self, task):
        guard = task.get("source_guard")
        return {"schema": SCHEMA, "task_id": task["task_id"], "task_sha256": digest(task),
                "status": "parked" if guard else "queued", "reason": guard or "unattempted",
                "roots": [{"prefix": r["prefix"], "tree": "P"} for r in task["roots"]],
                "proofs": {}, "proof_records": {}, "evidence_bytes": 0,
                "added_nodes": 0, "attempts": 0, "cpu_seconds": 0.0,
                "replay_cpu_seconds": 0.0, "schedule_sha256": None, "cursor": None,
                "physical_lean_admissions": 0}

    def _publish_parent(self, row, record, source, chunk_leaves):
        resource_guard(self.area)
        cc, rr = exact_box(row)
        if record.get("id") != row["id"] or record.get("input_sha256") != digest(row):
            raise ValueError("Source record belongs to a different input")
        if type(record.get("closed")) is not bool or record["closed"]:
            raise ValueError("Only open records belong in the survivor queue")
        tree = record["tree"]
        key = f"{row['id']:012d}-{tree_sha(tree)[:24]}"
        place = self.parent_dir(key)
        guard = record.get("reason", "")
        guard = guard if _parked_reason(guard) else None
        parent = {"schema": SCHEMA, "parent_key": key, "id": row["id"], "input": row,
                  "input_sha256": digest(row), "source_record": record,
                  "source_record_sha256": digest(record), "source_tree_sha256": tree_sha(tree),
                  "source_nodes": len(tree), "source": source, "source_guard": guard,
                  "physical_lean_admissions": 0}
        immutable_json(place / "SOURCE.json.gz", parent)
        dispatch = self.parent_dispatch(parent)
        runnable = self.dispatch_runnable(dispatch)
        ledger = place / "TASKS.jsonl"
        tmp = ledger.with_name("TASKS." + uuid.uuid4().hex + ".tmp")
        chain = hashlib.sha256()
        task_count = pending_count = 0
        chunk = []
        try:
            with tmp.open("xb") as index:
                def emit(roots):
                    nonlocal task_count
                    identity = {"parent_key": key, "chunk": task_count,
                                "prefixes": [r["prefix"] for r in roots]}
                    ident = digest(identity)
                    task = {"schema": SCHEMA, "task_id": ident, "parent_key": key,
                            "original_id": row["id"], "input_sha256": digest(row),
                            "source_tree_sha256": parent["source_tree_sha256"],
                            "source_record_sha256": parent["source_record_sha256"],
                            "source_packet_sha256": source["packet_sha256"],
                            "source_batch": source["batch"], "chunk": task_count,
                            "root_geometry": {"centers": list(map(str, cc)), "radii": list(map(str, rr))},
                            "roots": roots, "source_guard": guard,
                            "limits": {"max_depth": MAX_DEPTH, "max_tree_nodes": MAX_TREE_NODES,
                                       "max_task_nodes": MAX_TASK_NODES},
                            "physical_lean_admissions": 0}
                    directory = self.task_dir(ident)
                    immutable_json(directory / "TASK.json", task)
                    if not (directory / "STATE.json.gz").exists():
                        durable_json(directory / "STATE.json.gz", self._initial_state(task))
                    entry = {"task_id": ident, "task_sha256": digest(task),
                             "prefixes": identity["prefixes"]}
                    raw = canonical(entry) + b"\n"
                    index.write(raw)
                    chain.update(raw)
                    task_count += 1
                    if not guard and runnable:
                        self._make_ready(ident)

                for path, token, centers, radii in walk_tree(tree, cc, rr):
                    if token != "P":
                        continue
                    pending_count += 1
                    chunk.append({"prefix": path, "pending_subtree": "P",
                                  "centers": list(map(str, centers)), "radii": list(map(str, radii))})
                    if len(chunk) == chunk_leaves:
                        emit(chunk)
                        chunk = []
                if chunk:
                    emit(chunk)
                if not pending_count:
                    raise ValueError("A finalized open native record has no pending obligation")
                index.flush()
                os.fsync(index.fileno())
            if ledger.exists():
                if sha_file(ledger) != chain.hexdigest():
                    raise ValueError("Parent task partition changed")
            else:
                os.replace(tmp, ledger)
                _fsync_dir(place)
            with locked(place / "BUDGET.lock"):
                budget = place / "BUDGET.json"
                if not budget.exists():
                    durable_json(budget, {"schema": SCHEMA, "source_nodes": len(tree),
                                         "max_nodes": MAX_TREE_NODES, "reservations": {}})
                else:
                    value = read_json(budget)
                    if value["source_nodes"] != len(tree) or value["max_nodes"] != MAX_TREE_NODES:
                        raise ValueError("Parent forest guard changed")
            immutable_json(place / "READY.json", {"schema": SCHEMA, "parent_key": key,
                           "source_sha256": digest(parent), "inventory_sha256": chain.hexdigest(),
                           "tasks": task_count, "pending_roots": pending_count,
                           "source_batch": source["batch"], "physical_lean_admissions": 0})
            if not guard and runnable and not (place / "ROOT_STATE.json").exists():
                self.make_parent_marker("root_ready", key)
        finally:
            tmp.unlink(missing_ok=True)
        return task_count, pending_count, not runnable

    def import_finalized(self, root, chunk_leaves=32, batch_limit=None):
        """Import only finalized native pending roots; reimports are idempotent."""
        if type(chunk_leaves) is not int or not 16 <= chunk_leaves <= 64:
            raise ValueError("Use a bounded chunk of 16 through 64 pending leaves")
        if batch_limit is not None and (type(batch_limit) is not int or batch_limit < 1):
            raise ValueError("Invalid import batch limit")
        root = Path(root).resolve()
        config_path = root / "production/CONFIG.json"
        config = read_json(config_path)
        config_sha = sha_file(config_path)
        counts = dict(done_seen=0, imported_batches=0, imported_parents=0, imported_tasks=0,
                      pending_roots=0, held_parents=0, held_tasks=0, held_pending_roots=0,
                      skipped_non_native=0, physical_lean_admissions=0)
        with locked(self.area / "IMPORT.lock"):
            resource_guard(self.area)
            binding = {"schema": SCHEMA, "campaign_sha256": config["campaign_sha256"],
                       "config_sha256": config_sha, "source_archive_sha256": config["source_archive_sha256"],
                       "chunk_leaves": chunk_leaves, "max_depth": MAX_DEPTH,
                       "max_tree_nodes": MAX_TREE_NODES, "max_task_nodes": MAX_TASK_NODES,
                       "physical_lean_admissions": 0}
            immutable_json(self.area / "CONFIG.json", binding)
            db_path = root / "campaign/full_ring.sqlite"
            db = sqlite3.connect(db_path.resolve().as_uri() + "?mode=ro&immutable=1", uri=True)
            db.execute("PRAGMA cache_size=-4096")
            try:
                meta = {k: json.loads(v) for k, v in db.execute("SELECT key,value FROM metadata")}
                if meta["source_archive_sha256"] != config["source_archive_sha256"]:
                    raise ValueError("Queue input database belongs to another source archive")
                for batch, done_path in _done_paths(root):
                    resource_guard(self.area)
                    counts["done_seen"] += 1
                    done = read_json(done_path, limit=65536)
                    done_sha = sha_file(done_path)
                    if done.get("batch") != batch or done.get("physical_lean_admissions", 0) != 0:
                        raise ValueError("Invalid source DONE receipt")
                    packet_path = root / "production/batches" / f"{batch // 1000:03d}/{batch:06d}.json.gz"
                    commit_path = self.area / "batches" / f"{batch:06d}.json"
                    if commit_path.exists():
                        commit = read_json(commit_path)
                        if commit["packet_sha256"] != done["sha256"] or commit["done_sha256"] != done_sha:
                            raise ValueError("Imported source receipt changed")
                        continue
                    if done.get("sha256") != sha_file(packet_path):
                        raise ValueError("Finalized source packet changed")
                    rows, input_sha = _load_inputs(db, batch)
                    header = {}
                    seen = 0
                    imported = tasks = pending = held = held_tasks = held_pending = skipped = accepted = settled = 0
                    for name, value in stream_packet(packet_path):
                        if name != "record":
                            header[name] = value
                            continue
                        if header.get("batch") != batch or header.get("campaign_sha256") != config["campaign_sha256"] or header.get("input_batch_sha256") != input_sha:
                            raise ValueError("Source packet lacks its pinned input/campaign header")
                        if seen >= len(rows) or value.get("id") != rows[seen]["id"]:
                            raise ValueError("Source record ID census differs")
                        row = rows[seen]
                        seen += 1
                        if value.get("input_sha256") != digest(row) or type(value.get("closed")) is not bool:
                            raise ValueError("Source input or acceptance flag changed")
                        accepted += value["closed"]
                        settled += bool(value["closed"] or "transport" in value or "external_claim_sha256" in value)
                        if value["closed"]:
                            continue
                        if "transport" in value or "external_claim_sha256" in value:
                            skipped += 1
                            continue
                        source = {"batch": batch, "packet_sha256": done["sha256"],
                                  "done_sha256": done_sha, "done": done,
                                  "input_batch_sha256": input_sha, "config_sha256": config_sha,
                                  "campaign_sha256": config["campaign_sha256"]}
                        n_tasks, n_pending, is_held = self._publish_parent(row, value, source, chunk_leaves)
                        imported += 1
                        tasks += n_tasks
                        pending += n_pending
                        held += is_held
                        held_tasks += n_tasks if is_held else 0
                        held_pending += n_pending if is_held else 0
                    if seen != len(rows) or header.get("count") != seen or done.get("n") != seen:
                        raise ValueError("Source batch count differs")
                    if header.get("closed") != accepted or done.get("closed") != accepted or header.get("settled_work") != settled or done.get("settled") != settled:
                        raise ValueError("Source completed census differs")
                    if sha_file(packet_path) != done["sha256"] or sha_file(done_path) != done_sha or sha_file(config_path) != config_sha:
                        raise ValueError("Source changed while importing")
                    commit = {"schema": SCHEMA, "batch": batch, "packet_sha256": done["sha256"],
                              "done_sha256": done_sha, "input_batch_sha256": input_sha,
                              "parents": imported, "tasks": tasks, "pending_roots": pending,
                              "held_parents": held, "held_tasks": held_tasks,
                              "held_pending_roots": held_pending,
                              "skipped_non_native": skipped, "records": seen,
                              "physical_lean_admissions": 0}
                    immutable_json(commit_path, commit)
                    counts["imported_batches"] += 1
                    counts["imported_parents"] += imported
                    counts["imported_tasks"] += tasks
                    counts["pending_roots"] += pending
                    counts["held_parents"] += held
                    counts["held_tasks"] += held_tasks
                    counts["held_pending_roots"] += held_pending
                    counts["skipped_non_native"] += skipped
                    if batch_limit is not None and counts["imported_batches"] >= batch_limit:
                        break
            finally:
                db.close()
        return counts

    def iter_task_dirs(self):
        base = self.area / "tasks"
        for shard in SHARDS:
            place = base / shard
            if not place.is_dir():
                continue
            with os.scandir(place) as entries:
                for entry in entries:
                    if entry.is_dir(follow_symlinks=False) and len(entry.name) == 64:
                        yield Path(entry.path)

    def iter_parent_keys(self):
        base = self.area / "parents"
        if not base.is_dir():
            return
        with os.scandir(base) as shards:
            for shard in shards:
                if not shard.is_dir(follow_symlinks=False):
                    continue
                with os.scandir(shard.path) as parents:
                    for entry in parents:
                        if entry.is_dir(follow_symlinks=False) and (Path(entry.path) / "READY.json").is_file():
                            yield entry.name

    def claim(self, owner, lease_seconds=180, schedule_sha256=None):
        if not isinstance(owner, str) or not owner or len(owner) > 200 or not 1 <= lease_seconds <= 3600:
            raise ValueError("Invalid bounded lease")
        offset = int(hashlib.sha256(owner.encode()).hexdigest()[:2], 16) % len(SHARDS)
        order = SHARDS[offset:] + SHARDS[:offset]
        now = time.time()
        for shard in order:
            place = self.area / "ready" / shard
            if not place.is_dir():
                continue
            with os.scandir(place) as entries:
                for entry in entries:
                    if not entry.is_file(follow_symlinks=False):
                        continue
                    directory = self.task_dir(entry.name)
                    lock = (directory / "RUN.lock").open("a")
                    parent_gate = None
                    try:
                        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
                    except BlockingIOError:
                        lock.close()
                        continue
                    try:
                        task = read_json(directory / "TASK.json")
                        parent = self.parent_dir(task["parent_key"])
                        parent_gate = (parent / "PARENT_RUN.lock").open("a")
                        try:
                            fcntl.flock(parent_gate, fcntl.LOCK_SH | fcntl.LOCK_NB)
                        except BlockingIOError:
                            continue
                        source_parent = read_json(parent / "SOURCE.json.gz")
                        dispatch = self.parent_dispatch(source_parent)
                        if not self.dispatch_runnable(dispatch):
                            self.suppress_held_parent(source_parent, dispatch)
                            continue
                        root_state_path = parent / "ROOT_STATE.json"
                        if root_state_path.exists() and read_json(root_state_path).get("status") in ("candidate", "accepted"):
                            continue
                        commit_path = self.area / "batches" / f"{task['source_batch']:06d}.json"
                        if not (parent / "READY.json").exists() or not commit_path.exists():
                            continue
                        commit = read_json(commit_path)
                        if commit["packet_sha256"] != task["source_packet_sha256"]:
                            raise ValueError("Task source commit differs")
                        state = read_json(directory / "STATE.json.gz")
                        validate_state(task, state)
                        if state["status"] in ("done", "parked"):
                            self.marker(entry.name).unlink(missing_ok=True)
                            continue
                        lease_path = directory / "LEASE.json"
                        old = read_json(lease_path) if lease_path.exists() else None
                        if old and old.get("expires_unix", 0) > now:
                            continue
                        if schedule_sha256 and state.get("schedule_sha256") not in (None, schedule_sha256):
                            raise ValueError("Cannot change a checkpoint's method schedule")
                        token = uuid.uuid4().hex
                        lease = {"schema": SCHEMA, "task_id": entry.name, "owner": owner,
                                 "token": token, "claimed_unix": now, "expires_unix": now + lease_seconds,
                                 "pid": os.getpid(), "physical_lean_admissions": 0}
                        durable_json(lease_path, lease)
                        state["status"] = "running"
                        state["schedule_sha256"] = schedule_sha256 or state.get("schedule_sha256")
                        durable_json(directory / "STATE.json.gz", state)
                        result = Lease(self, task, state, lock, lease, lease_seconds, parent_gate)
                        lock = None
                        parent_gate = None
                        return result
                    finally:
                        if lock is not None:
                            lock.close()
                        if parent_gate is not None:
                            parent_gate.close()
        return None

    def readiness_count(self):
        """Cheap marker census; claims still validate commits and durable leases."""
        count = 0
        for shard in SHARDS:
            path = self.area / "ready" / shard
            if not path.is_dir():
                continue
            with os.scandir(path) as entries:
                count += sum(entry.is_file(follow_symlinks=False) and len(entry.name) == 64
                             and all(c in SHARDS for c in entry.name) for entry in entries)
        return count

    def dispatch_status(self):
        """Counts from small committed import receipts, without proof/geometry IO.

        Ready markers include live leases and rare pre-commit/import-crash
        leftovers.  They are dispatch hints only and confer no proof credit.
        """
        result = dict(batches=0, parents=0, tasks=0, pending_roots=0,
                      held_parents=0, held_tasks=0, held_pending_roots=0,
                      ready_markers=self.readiness_count(), physical_lean_admissions=0)
        result["root_ready_markers"] = sum(1 for _ in self.iter_parent_markers("root_ready"))
        result["replay_ready_markers"] = sum(1 for _ in self.iter_parent_markers("replay_ready"))
        census_path = self.area / "DISPATCH_HOLD_CENSUS.json"
        census = read_json(census_path) if census_path.exists() else None
        included = set(census["included_batches"]) if census else set()
        if census:
            if (census.get("schema") != "survivor-dispatch-hold-census-v1"
                    or census.get("hold_config_sha256") != dispatch_hold.CONFIG_SHA256
                    or census.get("classifier_sha256") != dispatch_hold.SOURCE_SHA256
                    or census.get("closure_credit") is not False
                    or census.get("physical_lean_admissions") != 0):
                raise ValueError("Dispatch hold census belongs to another policy")
            for name in ("held_parents", "held_tasks", "held_pending_roots"):
                result[name] = census[name]
            result["dispatch_hold_census_sha256"] = sha_file(census_path)
        base = self.area / "batches"
        if base.is_dir():
            with os.scandir(base) as entries:
                for entry in entries:
                    if entry.is_file(follow_symlinks=False) and entry.name.endswith(".json"):
                        value = read_json(entry.path, limit=65536)
                        result["batches"] += 1
                        for name in ("parents", "tasks", "pending_roots"):
                            result[name] += value[name]
                        if value["batch"] not in included:
                            for name in ("held_parents", "held_tasks", "held_pending_roots"):
                                result[name] += value.get(name, 0)
        result["runnable_parent_upper_count"] = result["parents"] - result["held_parents"]
        result["dispatch_hold_radius_radians"] = str(dispatch_hold.HOLD_RADIUS)
        result["held_obligations_preserved"] = True
        return result

    def status(self, verify=True):
        if not verify:
            return self.dispatch_status()
        counts = dict(tasks=0, queued=0, running=0, done=0, parked=0, new_closed_leaves=0,
                      pending_leaves=0, added_nodes=0, physical_lean_admissions=0)
        for place in self.iter_task_dirs():
            task = read_json(place / "TASK.json")
            if not (self.area / "batches" / f"{task['source_batch']:06d}.json").exists():
                continue
            state = read_json(place / "STATE.json.gz")
            validate_state(task, state)
            counts["tasks"] += 1
            counts[state["status"]] += 1
            counts["new_closed_leaves"] += len(state["proofs"])
            counts["pending_leaves"] += sum(root["tree"].count("P") for root in state["roots"])
            counts["added_nodes"] += state["added_nodes"]
        return counts


def validate_state(task, state):
    if state.get("schema") != SCHEMA or state.get("task_id") != task["task_id"] or state.get("task_sha256") != digest(task):
        raise ValueError("Checkpoint is bound to a different task")
    if task.get("physical_lean_admissions") != 0 or state.get("physical_lean_admissions") != 0:
        raise ValueError("Numerical continuation cannot admit physical Lean claims")
    if state.get("status") not in ("queued", "running", "parked", "done"):
        raise ValueError("Invalid task state")
    if task.get("source_guard") and state["status"] != "parked":
        raise ValueError("A source guard cannot be overridden")
    if len(state["roots"]) != len(task["roots"]):
        raise ValueError("Checkpoint lost or duplicated a source pending root")
    initial_prefixes = {r["prefix"] for r in task["roots"]}
    if len(initial_prefixes) != len(task["roots"]) or any(p[:j] in initial_prefixes for p in initial_prefixes for j in range(len(p))):
        raise ValueError("Initial task roots are not a distinct prefix-free subset")
    closed = set()
    nodes = pending = 0
    for initial, current in zip(task["roots"], state["roots"]):
        if current["prefix"] != initial["prefix"] or initial["pending_subtree"] != "P":
            raise ValueError("Checkpoint changed the original pending prefix")
        nodes += len(current["tree"])
        for path, token, _, _ in walk_tree(current["tree"], list(map(Q, initial["centers"])),
                                           list(map(Q, initial["radii"])), initial["prefix"], new=True,
                                           max_nodes=task["limits"]["max_task_nodes"]):
            if token == "C":
                if path in closed:
                    raise ValueError("Duplicate closed leaf")
                closed.add(path)
            else:
                pending += 1
    if nodes > task["limits"]["max_task_nodes"] or state.get("added_nodes") != nodes - len(task["roots"]):
        raise ValueError("Checkpoint violates its bounded node ledger")
    if set(state["proofs"]) != closed:
        raise ValueError("Missing or duplicate closed-leaf evidence")
    if {v["sha256"] for v in state["proofs"].values()} != set(state["proof_records"]):
        raise ValueError("Missing or extraneous grouped proof records")
    if type(state.get("evidence_bytes")) is not int or not 0 <= state["evidence_bytes"] <= MAX_EVIDENCE_BYTES:
        raise ValueError("Grouped evidence exceeds its hard bound")
    if state["status"] == "done" and pending:
        raise ValueError("Completed task still has pending leaves")
    cursor = state.get("cursor")
    if cursor is not None:
        if not isinstance(cursor, dict) or type(cursor.get("method_index")) is not int or cursor["method_index"] < 0:
            raise ValueError("Invalid resumable method cursor")
        prefix, path = cursor.get("prefix"), cursor.get("path")
        if prefix not in {r["prefix"] for r in task["roots"]} or not isinstance(path, str) or not path.startswith(prefix):
            raise ValueError("Cursor points outside its original subtree")


class Lease:
    def __init__(self, queue, task, state, lock, lease, seconds, parent_gate=None):
        self.queue, self.task, self.state = queue, task, state
        self.lock, self.lease, self.seconds = lock, lease, seconds
        self.parent_gate = parent_gate
        self.directory = queue.task_dir(task["task_id"])

    def _check(self):
        if self.lock is None or read_json(self.directory / "LEASE.json").get("token") != self.lease["token"]:
            raise ValueError("Stale or released task lease")

    def renew(self):
        self._check()
        self.lease["expires_unix"] = time.time() + self.seconds
        durable_json(self.directory / "LEASE.json", self.lease)

    def checkpoint(self, state=None):
        self._check()
        state = self.state if state is None else state
        validate_state(self.task, state)
        parent = self.queue.parent_dir(self.task["parent_key"])
        budget = read_json(parent / "BUDGET.json")
        if budget["reservations"].get(self.task["task_id"], 0) < state["added_nodes"]:
            raise ValueError("Checkpoint split lacks a durable parent reservation")
        durable_json(self.directory / "STATE.json.gz", state)
        self.state = state
        self.renew()

    def reserve_split(self, block_nodes=32):
        """Reserve a small node block; uncheckpointed work may be recomputed.

        The durable total never exceeds the original parent limit.  A crashed
        task may reuse its conservative unused reservation after reacquiring
        flock.  Release/finish trims unused nodes only after saving its frontier.
        """
        self._check()
        if type(block_nodes) is not int or not 2 <= block_nodes <= 128 or block_nodes % 2:
            raise ValueError("Invalid bounded forest reservation block")
        parent = self.queue.parent_dir(self.task["parent_key"])
        wanted = self.state["added_nodes"] + 2
        with locked(parent / "BUDGET.lock"):
            path = parent / "BUDGET.json"
            value = read_json(path)
            old = value["reservations"].get(self.task["task_id"], 0)
            total = value["source_nodes"] + sum(value["reservations"].values())
            extra = max(0, wanted - old)
            if total + extra > value["max_nodes"]:
                return False
            if extra:
                remaining = value["max_nodes"] - total
                grant = min(max(extra, block_nodes), remaining - remaining % 2)
                value["reservations"][self.task["task_id"]] = old + grant
                durable_json(path, value)
            return True

    def _trim_reservation(self):
        self._check()
        parent = self.queue.parent_dir(self.task["parent_key"])
        with locked(parent / "BUDGET.lock"):
            path = parent / "BUDGET.json"
            value = read_json(path)
            ident = self.task["task_id"]
            saved = read_json(self.directory / "STATE.json.gz")
            wanted = saved["added_nodes"]
            old = value["reservations"].get(ident, 0)
            if old < wanted:
                raise ValueError("Durable state exceeds its parent reservation")
            if old != wanted:
                if wanted:
                    value["reservations"][ident] = wanted
                else:
                    value["reservations"].pop(ident, None)
                durable_json(path, value)

    def install_proof(self, path, centers, radii, evaluation, replay, recipe=None):
        self._check()
        geometry = {"centers": list(map(str, centers)), "radii": list(map(str, radii)), "units": "radians"}
        value = build_proof(self.task, path, centers, radii, evaluation, replay, recipe)
        checksum = digest(value)
        size = len(canonical(value))
        if size > 65536 or self.state["evidence_bytes"] + size > MAX_EVIDENCE_BYTES:
            raise EvidenceLimit("task_evidence_size_guard")
        if checksum not in self.state["proof_records"]:
            self.state["proof_records"][checksum] = value
            self.state["evidence_bytes"] += size
        return {"sha256": checksum, "method": evaluation["method"],
                "evidence_sha256": evaluation["replay"]["evidence_sha256"]}

    def release(self, state=None, reason="cpu_budget", parked=False):
        self._check()
        state = self.state if state is None else state
        state["status"] = "parked" if parked else "queued"
        state["reason"] = reason
        self.checkpoint(state)
        self._trim_reservation()
        self.lease["expires_unix"] = 0
        durable_json(self.directory / "LEASE.json", self.lease)
        if parked:
            self.queue.marker(self.task["task_id"]).unlink(missing_ok=True)
        self.lock.close()
        self.lock = None
        if self.parent_gate is not None:
            self.parent_gate.close()
            self.parent_gate = None

    def finish(self, state=None):
        self._check()
        state = self.state if state is None else state
        state["status"] = "done"
        state["reason"] = "complete_subtrees_freshly_replayed"
        validate_state(self.task, state)
        # Commit the receipt first.  A crash can then leave an extra receipt
        # beside a running state, but can never publish DONE without its receipt.
        # Such an extra receipt may be replaced by the recovered lease.
        durable_json(self.directory / "RESULT.json", {"schema": SCHEMA,
                       "task_id": self.task["task_id"], "state_sha256": digest(state),
                       "task_sha256": digest(self.task), "new_closed_leaves": len(state["proofs"]),
                       "physical_lean_admissions": 0})
        self.checkpoint(state)
        self._trim_reservation()
        self.queue.marker(self.task["task_id"]).unlink(missing_ok=True)
        self.lease["expires_unix"] = 0
        durable_json(self.directory / "LEASE.json", self.lease)
        if __package__:
            from .completion import note_done
        else:
            from completion import note_done
        note_done(self.queue, self.task["parent_key"], self.task["task_id"], digest(state))
        self.lock.close()
        self.lock = None
        if self.parent_gate is not None:
            self.parent_gate.close()
            self.parent_gate = None

    def close(self):
        """Drop flock after a fatal failure; never disguise it as a retry budget."""
        if self.lock is not None:
            self.lock.close()
            self.lock = None
        if self.parent_gate is not None:
            self.parent_gate.close()
            self.parent_gate = None


def build_proof(task, path, centers, radii, evaluation, replay, recipe=None):
    geometry = {"centers": list(map(str, centers)), "radii": list(map(str, radii)), "units": "radians"}
    validate_evaluation(evaluation, replay, evaluation.get("input"))
    if not box_contains(evaluation["input"], geometry):
        raise ValueError("Evaluated box does not exactly contain the certified leaf")
    expected = {"schema": "survivor-leaf-recipe-v1", "ok": True,
                "reason": evaluation["reason"], "method": evaluation["method"],
                "input": evaluation["input"], "provider_hashes": evaluation["provider_hashes"],
                "witness_sha256": digest(evaluation["witness"]), "replay": evaluation["replay"],
                "physical_lean_admissions": 0}
    recipe = expected if recipe is None else dict(recipe)
    if recipe.get("source_ok", True) is not True:
        raise ValueError("Unsuccessful provider recipe cannot close a leaf")
    recipe.setdefault("ok", True)
    recipe.setdefault("physical_lean_admissions", 0)
    if any(recipe.get(k) != value for k, value in expected.items()):
        raise ValueError("Provider recipe differs from its full evaluated witness")
    replay = dict(replay, recipe_sha256=digest(recipe))
    value = {"schema": SCHEMA, "task_id": task["task_id"], "original_id": task["original_id"],
             "path": path, "input_sha256": task["input_sha256"],
             "source_tree_sha256": task["source_tree_sha256"],
             "geometry": geometry, "evaluation": recipe, "replay": replay,
             "physical_lean_admissions": 0}
    if evaluation["input"] != geometry:
        value["containment"] = {"schema": "exact-rational-containment-v1",
                                "evaluated_input_sha256": digest(evaluation["input"]),
                                "target_input_sha256": digest(geometry), "algebraic_transport": False}
    validate_proof(task, path, centers, radii, value)
    return value


def box_contains(outer, inner):
    if __package__:
        from .reuse_store import contains
    else:
        from reuse_store import contains
    return contains(outer, inner)


def recipe_identities(recipe):
    """Bounded recursive provider dependency inventory, including legacy pools."""
    result, stack, visited = {}, [(recipe, 0)], 0
    while stack:
        current, depth = stack.pop()
        visited += 1
        if depth > 8 or visited > 256:
            raise ValueError("Unbounded pooled recipe dependency graph")
        method, pins = current["method"], current["provider_hashes"]
        identity = method + "@" + digest(pins)
        result[identity] = {"method": method, "provider_hashes": pins}
        children = current.get("contributors", [])
        if not isinstance(children, list) or len(children) > 32:
            raise ValueError("Invalid pooled recipe contributor index")
        stack.extend((child, depth + 1) for child in children)
    return result


def validate_evaluation(evaluation, replay, geometry):
    """Full witness validation happens before storing a compact replay recipe."""
    if evaluation.get("schema") != "survivor-leaf-v1" or evaluation.get("ok") is not True or evaluation.get("input") != geometry:
        raise ValueError("Proof lacks a successful input-bound whole-leaf evaluation")
    keys = ("schema", "ok", "reason", "method", "input", "provider_hashes", "witness")
    evidence_sha = digest({k: evaluation[k] for k in keys})
    receipt = evaluation.get("replay", {})
    if receipt.get("evidence_sha256") != evidence_sha or receipt.get("input_sha256") != digest(geometry) or receipt.get("method") != evaluation["method"]:
        raise ValueError("Evaluation evidence or input digest differs")
    if not evaluation.get("provider_hashes") or replay.get("status") != "PASS" or replay.get("method") != evaluation["method"] or replay.get("evidence_sha256") != evidence_sha or replay.get("provider_hashes") != evaluation["provider_hashes"]:
        raise ValueError("Proof lacks a matching fresh provider replay")
    if any(value.get("physical_lean_admissions") != 0 for value in (evaluation, replay)):
        raise ValueError("Numerical evidence cannot admit a physical Lean theorem")


def validate_proof(task, path, centers, radii, proof):
    geometry = {"centers": list(map(str, centers)), "radii": list(map(str, radii)), "units": "radians"}
    if proof.get("schema") != SCHEMA or proof.get("task_id") != task["task_id"] or proof.get("original_id") != task["original_id"] or proof.get("path") != path:
        raise ValueError("Proof belongs to a different leaf")
    if proof.get("input_sha256") != task["input_sha256"] or proof.get("source_tree_sha256") != task["source_tree_sha256"] or proof.get("geometry") != geometry:
        raise ValueError("Proof altered its original input or exact geometry")
    recipe, replay = proof["evaluation"], proof["replay"]
    if recipe.get("schema") != "survivor-leaf-recipe-v1" or recipe.get("ok") is not True or not box_contains(recipe.get("input", {}), geometry):
        raise ValueError("Missing exact method reconstruction recipe")
    if recipe["input"] != geometry and proof.get("containment") != {
            "schema": "exact-rational-containment-v1", "evaluated_input_sha256": digest(recipe["input"]),
            "target_input_sha256": digest(geometry), "algebraic_transport": False}:
        raise ValueError("Missing independently checkable exact containment binding")
    receipt = recipe.get("replay", {})
    for field in ("witness_sha256",):
        value = recipe.get(field)
        if not isinstance(value, str) or len(value) != 64 or any(c not in SHARDS for c in value):
            raise ValueError("Invalid compact witness digest")
    if receipt.get("input_sha256") != digest(recipe["input"]) or receipt.get("method") != recipe["method"]:
        raise ValueError("Compact recipe input or method digest differs")
    if not recipe.get("provider_hashes") or replay.get("status") != "PASS" or replay.get("method") != recipe["method"] or replay.get("evidence_sha256") != receipt.get("evidence_sha256") or replay.get("provider_hashes") != recipe["provider_hashes"] or replay.get("recipe_sha256") != digest(recipe):
        raise ValueError("Compact recipe lacks its matching full-witness replay")
    if any(value.get("physical_lean_admissions") != 0 for value in (proof, recipe, replay)):
        raise ValueError("Numerical evidence cannot admit a physical Lean theorem")


def audit_history(area, parent_key, source_root=None, require_final=False, replay_fn=None, old_replay_fn=None):
    """Read-only independent audit of source pins, coverage, and leaf receipts.

    replay_fn must independently regenerate compact new-method recipes.
    old_replay_fn(token,centers,radii) must replay the frozen L/S provider.  A
    partial source forest's inherited L/S tokens have not yet been independently
    replayed, so parent closure needs both callbacks, even with no pending leaf.
    """
    queue = area if isinstance(area, TaskQueue) else TaskQueue(area)
    place = queue.parent_dir(parent_key)
    parent = read_json(place / "SOURCE.json.gz")
    ready = read_json(place / "READY.json")
    if ready["source_sha256"] != digest(parent) or ready["inventory_sha256"] != sha_file(place / "TASKS.jsonl"):
        raise ValueError("Source or original pending partition changed")
    row, record = parent["input"], parent["source_record"]
    cc, rr = exact_box(row)
    if parent["input_sha256"] != digest(row) or record["input_sha256"] != digest(row) or parent["source_record_sha256"] != digest(record) or parent["source_tree_sha256"] != tree_sha(record["tree"]):
        raise ValueError("Original input/tree pins differ")
    commit = read_json(queue.area / "batches" / f"{parent['source']['batch']:06d}.json")
    if commit["packet_sha256"] != parent["source"]["packet_sha256"] or commit["done_sha256"] != parent["source"]["done_sha256"]:
        raise ValueError("Parent source has no finalized import commit")
    if source_root is not None:
        source_root = Path(source_root)
        batch = parent["source"]["batch"]
        packet = source_root / "production/batches" / f"{batch // 1000:03d}/{batch:06d}.json.gz"
        done = source_root / "elastic-run/batches" / f"{batch // 1000:03d}/{batch:06d}/DONE.json"
        if sha_file(packet) != parent["source"]["packet_sha256"] or sha_file(done) != parent["source"]["done_sha256"] or sha_file(source_root / "production/CONFIG.json") != parent["source"]["config_sha256"]:
            raise ValueError("External finalized source changed")
        found = False
        packet_records = stream_packet(packet)
        try:
            for name, value in packet_records:
                if name == "record" and value.get("id") == row["id"]:
                    if value != record:
                        raise ValueError("Archived original forest differs from its finalized source record")
                    found = True
                    break
        finally:
            packet_records.close()
        if not found:
            raise ValueError("Archived original record is missing from its pinned source packet")
        db = sqlite3.connect((source_root / "campaign/full_ring.sqlite").resolve().as_uri() + "?mode=ro&immutable=1", uri=True)
        try:
            rows, checksum = _load_inputs(db, batch)
            if checksum != parent["source"]["input_batch_sha256"] or next((r for r in rows if r["id"] == row["id"]), None) != row:
                raise ValueError("External original input changed")
        finally:
            db.close()
    expected = {}
    old_closed = 0
    old_replayed = 0
    for path, token, centers, radii in walk_tree(record["tree"], cc, rr):
        if token == "P":
            expected[path] = (centers, radii)
        else:
            old_closed += 1
            if old_replay_fn is not None:
                fresh = old_replay_fn(token, centers, radii)
                if not isinstance(fresh, dict) or fresh.get("status") != "PASS":
                    raise ValueError("Inherited original-provider leaf replay failed")
                old_replayed += 1
    replacements = {}
    proofs = {}
    tasks = added = new_closed = pending = 0
    task_ids = set()
    task_added = {}
    state_chain = hashlib.sha256()
    for line in inventory_lines(place / "TASKS.jsonl"):
        item = json.loads(line)
        ident = item["task_id"]
        if ident in task_ids:
            raise ValueError("Duplicate task in original pending partition")
        task_ids.add(ident)
        directory = queue.task_dir(ident)
        task, state = read_json(directory / "TASK.json"), read_json(directory / "STATE.json.gz")
        if item["task_sha256"] != digest(task) or task["parent_key"] != parent_key or task["original_id"] != row["id"] or task["input_sha256"] != parent["input_sha256"] or task["source_tree_sha256"] != parent["source_tree_sha256"] or task["source_record_sha256"] != parent["source_record_sha256"] or task["source_packet_sha256"] != parent["source"]["packet_sha256"]:
            raise ValueError("Task source/input pins differ")
        if item["prefixes"] != [root["prefix"] for root in task["roots"]]:
            raise ValueError("Task inventory altered a prefix")
        if task.get("root_geometry") != {"centers": list(map(str, cc)), "radii": list(map(str, rr))}:
            raise ValueError("Task altered its original parent geometry")
        validate_state(task, state)
        if sum(len(canonical(proof)) for proof in state["proof_records"].values()) != state["evidence_bytes"]:
            raise ValueError("Grouped proof evidence size ledger differs")
        state_chain.update(bytes.fromhex(ident) + bytes.fromhex(digest(state)))
        if require_final and state["status"] not in ("done", "parked"):
            raise ValueError("Parent has an active or runnable task")
        if state["status"] == "done":
            result = read_json(directory / "RESULT.json")
            if result["state_sha256"] != digest(state) or result["task_sha256"] != digest(task):
                raise ValueError("Completed checkpoint changed")
        for initial, current in zip(task["roots"], state["roots"]):
            prefix = initial["prefix"]
            if prefix not in expected or prefix in replacements:
                raise ValueError("Missing, duplicated, or non-source subtree prefix")
            centers, radii = expected[prefix]
            if initial["centers"] != list(map(str, centers)) or initial["radii"] != list(map(str, radii)):
                raise ValueError("Inherited path geometry changed")
            replacements[prefix] = current["tree"]
            for path, token, lc, lr in walk_tree(current["tree"], centers, radii, prefix, new=True,
                                                  max_nodes=MAX_TASK_NODES):
                if token == "P":
                    pending += 1
                    continue
                receipt = state["proofs"][path]
                proof = state["proof_records"][receipt["sha256"]]
                if digest(proof) != receipt["sha256"] or receipt["method"] != proof["evaluation"]["method"] or receipt["evidence_sha256"] != proof["evaluation"]["replay"]["evidence_sha256"]:
                    raise ValueError("Closed-leaf proof content changed")
                validate_proof(task, path, lc, lr, proof)
                if replay_fn is not None:
                    fresh = replay_fn(proof["evaluation"])
                    if fresh.get("status") != "PASS" or fresh.get("evidence_sha256") != receipt["evidence_sha256"]:
                        raise ValueError("Independent fresh leaf replay failed")
                if path in proofs:
                    raise ValueError("Duplicate new leaf evidence")
                proofs[path] = {"task_id": ident, **receipt,
                                "provider_hashes": proof["evaluation"]["provider_hashes"],
                                "provider_dependencies": recipe_identities(proof["evaluation"]),
                                "provider_identity": proof["evaluation"]["method"] + "@" + digest(proof["evaluation"]["provider_hashes"])}
                new_closed += 1
        tasks += 1
        added += state["added_nodes"]
        task_added[ident] = state["added_nodes"]
    if set(replacements) != set(expected) or tasks != ready["tasks"] or len(expected) != ready["pending_roots"]:
        raise ValueError("Original parent has missing or duplicate pending subtrees")
    budget = read_json(place / "BUDGET.json")
    if set(budget["reservations"]) - task_ids or any(type(v) is not int or v < 0 or v % 2 for v in budget["reservations"].values()):
        raise ValueError("Invalid global forest reservations")
    if any(budget["reservations"].get(ident, 0) < nodes for ident, nodes in task_added.items()):
        raise ValueError("A task expanded without its parent forest reservation")
    if budget["source_nodes"] != len(record["tree"]) or budget["max_nodes"] != MAX_TREE_NODES or len(record["tree"]) + sum(budget["reservations"].values()) > MAX_TREE_NODES or len(record["tree"]) + added > MAX_TREE_NODES:
        raise ValueError("Original parent forest guard was overridden")
    # Replace only original P terminals.  The preorder split recipe and old
    # accepted leaves are retained verbatim; new C leaves refer to their methods.
    stack = [""]
    merged = []
    for token in record["tree"]:
        path = stack.pop()
        if token in "0123":
            stack.extend((path + "1", path + "0"))
            merged.append(token)
        elif token == "P":
            merged.append(replacements[path])
        else:
            merged.append(token)
    merged_tree = "".join(merged)
    result = {"schema": "survivor-parent-v1", "id": row["id"], "parent_key": parent_key,
            "input_sha256": parent["input_sha256"], "source_tree_sha256": parent["source_tree_sha256"],
            "source_record_sha256": parent["source_record_sha256"], "tree": merged_tree,
            "source_packet_sha256": parent["source"]["packet_sha256"],
            "source_done_sha256": parent["source"]["done_sha256"],
            "source_config_sha256": parent["source"]["config_sha256"],
            "task_states_sha256": state_chain.hexdigest(),
            "new_leaf_proofs": proofs, "old_closed_leaves": old_closed,
            "new_closed_leaves": new_closed, "pending_leaves": pending, "tasks": tasks,
            "nodes": len(merged_tree), "candidate_complete": pending == 0,
            "closed": pending == 0 and replay_fn is not None and old_replayed == old_closed,
            "old_replayed_leaves": old_replayed,
            "audit": ("FRESH_ALL_LEAVES_PASS" if replay_fn is not None and old_replayed == old_closed
                      else "FRESH_NEW_LEAVES_ONLY" if replay_fn is not None
                      else "TOPOLOGY_AND_RECEIPTS_PASS"),
            "physical_lean_admissions": 0}
    result["certificate_sha256"] = digest(result)
    return result


def audit_parent(area, parent_key, source_root=None, require_final=False, replay_fn=None, old_replay_fn=None):
    queue = area if isinstance(area, TaskQueue) else TaskQueue(area)
    if __package__:
        from .parent_roots import root_cover
    else:
        from parent_roots import root_cover
    cover = root_cover(queue, parent_key, source_root, replay_fn)
    if cover is not None:
        return cover
    return audit_history(queue, parent_key, source_root, require_final, replay_fn, old_replay_fn)


def audit_queue(area, source_root=None, require_final=False, replay_fn=None, old_replay_fn=None):
    queue = area if isinstance(area, TaskQueue) else TaskQueue(area)
    result = dict(parents=0, closed_parents=0, old_closed_leaves=0, new_closed_leaves=0,
                  pending_leaves=0, physical_lean_admissions=0)
    # A disk-backed temporary uniqueness index keeps a large campaign audit
    # from accumulating all original IDs in a Python set.
    db = sqlite3.connect("")
    db.execute("PRAGMA cache_size=-4096")
    db.execute("CREATE TABLE seen (id INTEGER PRIMARY KEY)")
    try:
        for key in queue.iter_parent_keys():
            value = audit_parent(queue, key, source_root, require_final, replay_fn, old_replay_fn)
            try:
                db.execute("INSERT INTO seen VALUES (?)", (value["id"],))
            except sqlite3.IntegrityError as error:
                raise ValueError("Duplicate original parent input") from error
            result["parents"] += 1
            result["closed_parents"] += value["closed"]
            for name in ("old_closed_leaves", "new_closed_leaves", "pending_leaves"):
                result[name] += value[name]
    finally:
        db.close()
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("import", "status", "audit", "mask"))
    parser.add_argument("--queue", required=True)
    parser.add_argument("--root")
    parser.add_argument("--chunk-leaves", type=int, default=32)
    parser.add_argument("--batch-limit", type=int)
    parser.add_argument("--require-final", action="store_true")
    args = parser.parse_args()
    queue = TaskQueue(args.queue)
    if args.command == "import":
        if not args.root:
            parser.error("import requires --root")
        result = queue.import_finalized(args.root, args.chunk_leaves, args.batch_limit)
    elif args.command == "audit":
        result = audit_queue(queue, args.root, args.require_final)
    elif args.command == "mask":
        result = queue.reconcile_dispatch_hold()
    else:
        result = queue.status()
    print(json.dumps(result, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
