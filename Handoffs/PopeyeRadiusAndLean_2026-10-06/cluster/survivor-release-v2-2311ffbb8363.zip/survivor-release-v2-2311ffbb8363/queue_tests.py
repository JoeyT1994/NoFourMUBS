"""Synthetic-only crash, lease, source pin and exact parent-coverage tests.

No production data import, numerical theorem admission, or Slurm operation.
Run: python3 survivor/queue_tests.py
"""
from fractions import Fraction as Q
from pathlib import Path
import gzip
import json
import os
import sqlite3
import tempfile
import unittest
from unittest.mock import patch

if __package__:
    from . import task_queue as tq
    from . import worker
else:
    import task_queue as tq
    import worker


def full_tree(depth, leaf="P"):
    if not depth:
        return leaf
    child = full_tree(depth - 1, leaf)
    return "0" + child + child


def fixture(root, tree="0LP", reason="cpu_budget", done=True, wrong_count=False):
    root = Path(root)
    row = {"id": 0, "centers": ["1", "1", "1", "1"], "radii": ["1/8"] * 4}
    raw = tq.canonical(row) + b"\n"
    input_sha = __import__("hashlib").sha256(raw).hexdigest()
    (root / "campaign").mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(root / "campaign/full_ring.sqlite")
    db.executescript("CREATE TABLE batches(id INTEGER PRIMARY KEY,first_id INTEGER,n INTEGER,raw_sha TEXT,payload BLOB);"
                     "CREATE TABLE metadata(key TEXT PRIMARY KEY,value TEXT);")
    db.execute("INSERT INTO batches VALUES(0,0,1,?,?)", (input_sha, gzip.compress(raw)))
    db.execute("INSERT INTO metadata VALUES('source_archive_sha256',?)", (json.dumps("a" * 64),))
    db.commit()
    db.close()
    tq.durable_json(root / "production/CONFIG.json", {"campaign_sha256": "b" * 64,
                    "source_archive_sha256": "a" * 64})
    record = {"id": 0, "input_sha256": tq.digest(row), "tree": tree, "stage": 4,
              "closed": False, "reason": reason, "search_cpu_seconds": 1.0,
              "replay_cpu_seconds": 0.0, "physical_lean_admissions": 0}
    # Keep the frozen producer's insertion order: pinned header precedes records.
    packet = {"schema": 1, "campaign_sha256": "b" * 64, "input_batch_sha256": input_sha,
              "batch": 0, "stage": 4, "closed": 0, "settled_work": 0,
              "count": 2 if wrong_count else 1, "physical_lean_admissions": 0, "records": [record]}
    path = root / "production/batches/000/000000.json.gz"
    path.parent.mkdir(parents=True, exist_ok=True)
    with gzip.open(path, "wt") as f:
        json.dump(packet, f, separators=(",", ":"))
    if done:
        tq.durable_json(root / "elastic-run/batches/000/000000/DONE.json",
                        {"batch": 0, "sha256": tq.sha_file(path), "n": 1, "closed": 0,
                         "settled": 0, "owner": "synthetic", "physical_lean_admissions": 0})
    return row


class GoodProvider:
    @staticmethod
    def evaluate(cc, rr, method, seconds):
        box = {"centers": list(map(str, cc)), "radii": list(map(str, rr)), "units": "radians"}
        result = {"schema": "survivor-leaf-v1", "ok": True, "reason": "synthetic_whole_box",
                  "method": method, "input": box, "provider_hashes": {"binary_sha256": "c" * 64},
                  "witness": {"synthetic": True, "exact_radii": list(map(str, rr))},
                  "cpu_seconds": 0.0, "physical_lean_admissions": 0}
        result["replay"] = {"schema": result["schema"], "method": method, "input_sha256": tq.digest(box),
                            "evidence_sha256": tq.digest({k: result[k] for k in
                            ("schema", "ok", "reason", "method", "input", "provider_hashes", "witness")})}
        return result

    @staticmethod
    def replay(record, seconds=10):
        return {"status": "PASS", "ok": True, "method": record["method"],
                "provider_hashes": record["provider_hashes"],
                "evidence_sha256": record["replay"]["evidence_sha256"],
                "cpu_seconds": 0.0, "physical_lean_admissions": 0}

    @staticmethod
    def replay_recipe(recipe):
        record = GoodProvider.evaluate(list(map(Q, recipe["input"]["centers"])),
                                       list(map(Q, recipe["input"]["radii"])), recipe["method"], 10)
        if tq.digest(record["witness"]) != recipe["witness_sha256"] or record["replay"] != recipe["replay"]:
            raise ValueError("Synthetic recipe changed")
        return GoodProvider.replay(record)


class UnresolvedProvider:
    @staticmethod
    def evaluate(cc, rr, method, seconds):
        return {"ok": False, "reason": "unresolved_mean", "axis": 0}


def schedule(methods=None, attempts=2, points=None):
    return {"methods": methods or [{"method": "order3", "cpu_seconds": 1}],
            "task_cpu_seconds": 60, "replay_cpu_seconds": 1,
            "max_task_attempts": attempts, "protected_points": points or []}


class QueueTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="mub6-queue-test-")
        self.base = Path(self.temp.name)
        self.root, self.area = self.base / "source", self.base / "queue"

    def tearDown(self):
        self.temp.cleanup()

    def make(self, tree="0LP", **kwargs):
        fixture(self.root, tree, **kwargs)
        queue = tq.TaskQueue(self.area)
        counts = queue.import_finalized(self.root, 16)
        return queue, counts

    def key(self, queue):
        return next(queue.iter_parent_keys())

    def expire(self, lease):
        path = lease.directory / "LEASE.json"
        value = tq.read_json(path)
        value["expires_unix"] = 0
        tq.durable_json(path, value)

    def rewrite_inventory(self, queue, lines):
        place = queue.parent_dir(self.key(queue))
        raw = b"".join(tq.canonical(x) + b"\n" for x in lines)
        (place / "TASKS.jsonl").write_bytes(raw)
        ready = tq.read_json(place / "READY.json")
        ready["inventory_sha256"] = __import__("hashlib").sha256(raw).hexdigest()
        ready["tasks"] = len(lines)
        tq.durable_json(place / "READY.json", ready)

    def test_only_done_sources_publish_and_reimport_is_idempotent(self):
        fixture(self.root, "0L" + full_tree(6), done=False)
        queue = tq.TaskQueue(self.area)
        self.assertEqual(queue.import_finalized(self.root, 16)["imported_batches"], 0)
        self.assertIsNone(queue.claim("worker-a"))
        packet = self.root / "production/batches/000/000000.json.gz"
        tq.durable_json(self.root / "elastic-run/batches/000/000000/DONE.json",
                        {"batch": 0, "sha256": tq.sha_file(packet), "n": 1, "closed": 0,
                         "settled": 0, "physical_lean_admissions": 0})
        counts = queue.import_finalized(self.root, 16)
        self.assertEqual((counts["imported_tasks"], counts["pending_roots"]), (4, 64))
        self.assertEqual(queue.import_finalized(self.root, 16)["imported_batches"], 0)
        self.assertEqual(queue.status()["tasks"], 4)
        self.assertEqual(queue.status(verify=False)["ready_markers"], 4)
        audit = tq.audit_parent(queue, self.key(queue), self.root)
        self.assertEqual((audit["old_closed_leaves"], audit["pending_leaves"]), (1, 64))
        self.assertFalse(audit["closed"])

    def test_multiple_workers_cooperate_without_changing_old_leaf(self):
        queue, _ = self.make("0L" + full_tree(6))
        a, b = queue.claim("a"), queue.claim("b")
        self.assertNotEqual(a.task["task_id"], b.task["task_id"])
        worker.process_lease(a, schedule(), self.root, provider=GoodProvider)
        worker.process_lease(b, schedule(), self.root, provider=GoodProvider)
        while (lease := queue.claim("next")) is not None:
            worker.process_lease(lease, schedule(), self.root, provider=GoodProvider)
        audit = tq.audit_parent(queue, self.key(queue), self.root, require_final=True)
        self.assertTrue(audit["tree"].startswith("0L"))
        self.assertEqual((audit["new_closed_leaves"], audit["pending_leaves"]), (64, 0))
        self.assertTrue(audit["candidate_complete"])
        self.assertFalse(audit["closed"])
        audit = tq.audit_parent(queue, self.key(queue), self.root, True, GoodProvider.replay_recipe,
                                lambda token, cc, rr: {"status": "PASS"})
        self.assertTrue(audit["closed"])
        self.assertEqual(audit["audit"], "FRESH_ALL_LEAVES_PASS")
        self.assertEqual(audit["physical_lean_admissions"], 0)
        # Evidence is grouped in compressed task checkpoints, not leaf files.
        self.assertFalse(any(p.name == "proofs" for p in self.area.rglob("*")))

    def test_expired_live_flock_is_never_stolen_and_stale_lease_cannot_write(self):
        queue, _ = self.make()
        a = queue.claim("a")
        self.expire(a)
        self.assertIsNone(queue.claim("b"))
        a.release(reason="cpu_budget")
        b = queue.claim("b")
        self.assertNotEqual(a.lease["token"], b.lease["token"])
        with self.assertRaises(ValueError):
            a.checkpoint()
        b.release(reason="cpu_budget")

    def test_crash_reservation_is_reused_and_atomic_write_preserves_state(self):
        queue, _ = self.make()
        a = queue.claim("a")
        self.assertTrue(a.reserve_split())
        saved = (a.directory / "STATE.json.gz").read_bytes()
        with patch.object(tq.os, "replace", side_effect=OSError("synthetic interrupted replace")):
            with self.assertRaises(OSError):
                a.checkpoint()
        self.assertEqual((a.directory / "STATE.json.gz").read_bytes(), saved)
        self.assertFalse(list(a.directory.glob("*.tmp")))
        self.expire(a)
        a.close()
        b = queue.claim("b")
        self.assertTrue(b.reserve_split())
        budget = tq.read_json(queue.parent_dir(b.task["parent_key"]) / "BUDGET.json")
        self.assertEqual(sum(budget["reservations"].values()), 32)
        b.state["roots"][0]["tree"] = "0PP"
        b.state["added_nodes"] = 2
        b.checkpoint()
        b.release(reason="cpu_budget")
        budget = tq.read_json(queue.parent_dir(b.task["parent_key"]) / "BUDGET.json")
        self.assertEqual(sum(budget["reservations"].values()), 2)
        self.assertEqual(tq.audit_parent(queue, self.key(queue))["pending_leaves"], 2)

    def test_interrupted_final_receipt_recovers_without_false_done(self):
        queue, _ = self.make()
        a = queue.claim("a")
        initial = a.task["roots"][0]
        cc, rr = list(map(Q, initial["centers"])), list(map(Q, initial["radii"]))
        verdict = GoodProvider.evaluate(cc, rr, "order3", 1)
        reference = a.install_proof(initial["prefix"], cc, rr, verdict, GoodProvider.replay(verdict))
        a.state["proofs"][initial["prefix"]] = reference
        a.state["roots"][0]["tree"] = "C"
        a.checkpoint()
        write = tq.durable_json

        def interrupt(path, value):
            if Path(path).name == "STATE.json.gz" and value.get("status") == "done":
                raise OSError("synthetic killed final checkpoint")
            return write(path, value)

        with patch.object(tq, "durable_json", side_effect=interrupt):
            with self.assertRaises(OSError):
                a.finish()
        self.assertEqual(tq.read_json(a.directory / "STATE.json.gz")["status"], "running")
        self.expire(a)
        a.close()
        b = queue.claim("recovered")
        worker.process_lease(b, schedule(), self.root, provider=GoodProvider)
        self.assertEqual(queue.status()["done"], 1)
        self.assertTrue(tq.audit_parent(queue, self.key(queue), require_final=True)["candidate_complete"])

    def test_partial_import_cannot_be_claimed(self):
        fixture(self.root, wrong_count=True)
        queue = tq.TaskQueue(self.area)
        with self.assertRaises(ValueError):
            queue.import_finalized(self.root, 16)
        self.assertIsNone(queue.claim("worker"))
        self.assertEqual(queue.status()["tasks"], 0)
        self.assertFalse((self.area / "batches/000000.json").exists())

    def test_independent_reader_rejects_missing_and_duplicate_parent_subtrees(self):
        queue, _ = self.make("0L" + full_tree(5))
        place = queue.parent_dir(self.key(queue))
        lines = [json.loads(line) for line in (place / "TASKS.jsonl").read_bytes().splitlines()]
        self.rewrite_inventory(queue, lines[:-1])
        with self.assertRaisesRegex(ValueError, "missing or duplicate"):
            tq.audit_parent(queue, self.key(queue))
        self.rewrite_inventory(queue, lines + [lines[0]])
        with self.assertRaisesRegex(ValueError, "Duplicate task"):
            tq.audit_parent(queue, self.key(queue))

    def test_independent_reader_rejects_changed_input_and_inherited_geometry(self):
        queue, _ = self.make()
        directory = next(queue.iter_task_dirs())
        task = tq.read_json(directory / "TASK.json")
        task["root_geometry"]["centers"][0] = "2"
        tq.durable_json(directory / "TASK.json", task)
        state = tq.read_json(directory / "STATE.json.gz")
        state["task_sha256"] = tq.digest(task)
        tq.durable_json(directory / "STATE.json.gz", state)
        place = queue.parent_dir(self.key(queue))
        lines = [json.loads(line) for line in (place / "TASKS.jsonl").read_bytes().splitlines()]
        lines[0]["task_sha256"] = tq.digest(task)
        self.rewrite_inventory(queue, lines)
        with self.assertRaisesRegex(ValueError, "parent geometry"):
            tq.audit_parent(queue, self.key(queue))

    def test_final_audit_rehashes_committed_external_source(self):
        queue, _ = self.make()
        packet = self.root / "production/batches/000/000000.json.gz"
        packet.write_bytes(packet.read_bytes() + b"changed")
        # Efficient dispatch import does not reread immutable committed packets.
        self.assertEqual(queue.import_finalized(self.root, 16)["imported_batches"], 0)
        with self.assertRaisesRegex(ValueError, "External finalized source"):
            tq.audit_parent(queue, self.key(queue), source_root=self.root)

    def test_source_record_membership_rejects_rehashed_local_history(self):
        queue, _ = self.make()
        place = queue.parent_dir(self.key(queue))
        parent = tq.read_json(place / "SOURCE.json.gz")
        parent["source_record"]["reason"] = "invented_source_history"
        parent["source_record_sha256"] = tq.digest(parent["source_record"])
        tq.durable_json(place / "SOURCE.json.gz", parent)
        ready = tq.read_json(place / "READY.json")
        ready["source_sha256"] = tq.digest(parent)
        tq.durable_json(place / "READY.json", ready)
        with self.assertRaisesRegex(ValueError, "finalized source record"):
            tq.audit_parent(queue, self.key(queue), source_root=self.root)

    def test_checkpoint_throttle_saves_atomic_group_on_stop(self):
        queue, _ = self.make(full_tree(1))
        lease = queue.claim("worker")
        calls, writes = [0], []
        write = tq.durable_json

        class Provider(GoodProvider):
            @staticmethod
            def replay(record, seconds=10):
                calls[0] += 1
                self.assertEqual(len(tq.read_json(lease.directory / "STATE.json.gz")["proofs"]), 0)
                return GoodProvider.replay(record, seconds)

        def tracked(path, value):
            if Path(path).name == "STATE.json.gz":
                writes.append(len(value["proofs"]))
            return write(path, value)

        with patch.object(tq, "durable_json", side_effect=tracked):
            result = worker.process_lease(lease, schedule(), self.root, stop_fn=lambda: calls[0] >= 1,
                                         provider=Provider)
        self.assertEqual(result["reason"], "stop_requested")
        self.assertEqual(writes, [0, 1])
        audit = tq.audit_parent(queue, self.key(queue), require_final=True)
        self.assertEqual((audit["new_closed_leaves"], audit["pending_leaves"]), (1, 1))

    def test_source_depth_and_global_forest_guards_stay_parked(self):
        queue, _ = self.make("0LP", reason="depth_guard")
        self.assertIsNone(queue.claim("worker"))
        self.assertEqual(queue.status()["parked"], 1)

    def test_absolute_depth48_guard_cannot_be_split(self):
        queue, _ = self.make("0L" * 48 + "P")
        lease = queue.claim("worker")
        result = worker.process_lease(lease, schedule(), self.root, provider=UnresolvedProvider)
        self.assertEqual(result["reason"], "depth_guard")
        self.assertEqual(tq.audit_parent(queue, self.key(queue))["nodes"], 97)

    def test_original262143_node_guard_applies_across_chunk_work(self):
        tree = full_tree(17, "L")
        queue, _ = self.make(tree[:-1] + "P")
        lease = queue.claim("worker")
        result = worker.process_lease(lease, schedule(), self.root, provider=UnresolvedProvider)
        self.assertEqual(result["reason"], "forest_size_guard")
        self.assertEqual(tq.audit_parent(queue, self.key(queue))["nodes"], tq.MAX_TREE_NODES)

    def test_protected_seed_is_parked_without_calling_provider(self):
        queue, _ = self.make("P")
        lease = queue.claim("worker")
        with patch.object(GoodProvider, "evaluate", side_effect=AssertionError("seed evaluated")):
            result = worker.process_lease(lease, schedule(points=[["1"] * 4]), self.root, provider=GoodProvider)
        self.assertEqual(result["reason"], "protected_seed_guard")
        self.assertIsNone(queue.claim("worker2"))

    def test_budget_resume_preserves_method_cursor_and_exhaustion_does_not_loop(self):
        queue, _ = self.make()
        elapsed, calls = [0.0], []

        class Provider(GoodProvider):
            @staticmethod
            def evaluate(cc, rr, method, seconds):
                calls.append(method)
                if method == "order3":
                    elapsed[0] += 2
                    return {"ok": False, "reason": "cpu_budget", "axis": 1}
                return GoodProvider.evaluate(cc, rr, method, seconds)

        config = schedule([{"method": "order3", "cpu_seconds": 1}, {"method": "order4", "cpu_seconds": 1}])
        config["task_cpu_seconds"] = 1
        with patch.object(worker.time, "process_time", side_effect=lambda: elapsed[0]):
            a = queue.claim("a", schedule_sha256=tq.digest(config))
            self.assertEqual(worker.process_lease(a, config, self.root, provider=Provider)["status"], "queued")
            b = queue.claim("b", schedule_sha256=tq.digest(config))
            self.assertEqual(worker.process_lease(b, config, self.root, provider=Provider)["status"], "done")
        self.assertEqual(calls, ["order3", "order4"])
        self.assertIsNone(queue.claim("c"))

    def test_schedule_gates_are_absolute_and_skips_never_close(self):
        self.assertTrue(worker._eligible({"min_depth": 36, "max_depth": 48, "every_depth": 4}, "1" * 40, "1" * 36))
        self.assertFalse(worker._eligible({"min_depth": 36, "max_depth": 48, "every_depth": 4}, "1" * 41, "1" * 36))
        self.assertFalse(worker._eligible({"initial_frontier_only": True}, "10", "1"))
        queue, _ = self.make("0L" * 48 + "P")
        methods = [{"method": "order3", "cpu_seconds": 1, "max_depth": 47}]
        with patch.object(GoodProvider, "evaluate", side_effect=AssertionError("gated method evaluated")):
            result = worker.process_lease(queue.claim("worker"), schedule(methods), self.root, provider=GoodProvider)
        self.assertEqual(result["reason"], "depth_guard")
        self.assertEqual(queue.status()["new_closed_leaves"], 0)

    def test_arithmetic_failure_and_replay_disagreement_are_fatal(self):
        queue, _ = self.make()
        lease = queue.claim("worker")
        with patch.object(GoodProvider, "evaluate", side_effect=ArithmeticError("bad interval")):
            with self.assertRaises(ArithmeticError):
                worker.process_lease(lease, schedule(), self.root, provider=GoodProvider)
        self.assertFalse(lease.state["proofs"])
        self.expire(lease)
        lease.close()
        recovered = queue.claim("recovered")
        with patch.object(GoodProvider, "replay", return_value={"status": "UNRESOLVED", "reason": "changed_witness"}):
            with self.assertRaisesRegex(ValueError, "Fresh survivor replay failed"):
                worker.process_lease(recovered, schedule(), self.root, provider=GoodProvider)
        self.assertFalse(recovered.state["proofs"])
        recovered.close()

    def test_resource_guard_is_a_hard_stop(self):
        queue, _ = self.make()
        lease = queue.claim("worker")
        with patch.object(GoodProvider, "evaluate", return_value={"ok": False, "reason": "disk_reserve_8GiB"}):
            result = worker.process_lease(lease, schedule(), self.root, provider=GoodProvider)
        self.assertEqual((result["status"], result["reason"]), ("parked", "disk_reserve_8GiB"))
        self.assertIsNone(queue.claim("restarted"))
        with patch.object(tq.shutil, "disk_usage", return_value=type("Disk", (), {"free": 1})()):
            with self.assertRaises(tq.ResourceStop):
                queue.import_finalized(self.root, 16)

    def test_schedule_binding_cannot_change_on_resume(self):
        queue, _ = self.make()
        lease = queue.claim("worker", schedule_sha256="a" * 64)
        lease.release(reason="cpu_budget")
        with self.assertRaisesRegex(ValueError, "method schedule"):
            queue.claim("changed", schedule_sha256="b" * 64)


if __name__ == "__main__":
    unittest.main(verbosity=2)
