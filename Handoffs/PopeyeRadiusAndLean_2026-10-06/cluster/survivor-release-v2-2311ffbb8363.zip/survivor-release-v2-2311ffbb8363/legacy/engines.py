"""Bounded, source-pinned whole-leaf numerical evaluators.

Each Taylor order has a separate native handle.  This module never calls
certify_leaves.init or swaps that module's current library.  Use one evaluator
at a time, in the main thread of a worker process.  These are numerical
strict-D0 certificates relative to the upstream physical interface, not Lean
admissions and not a proof of the four-MUB conjecture.
"""
from __future__ import annotations

from contextlib import contextmanager
from fractions import Fraction
from pathlib import Path
import ctypes
import fcntl
import hashlib
import importlib.util
import json
import math
import os
import resource
import signal
import subprocess
import sys
import threading
import time

_STATE = None
_BUSY = False
SCHEMA = "survivor-leaf-v1"
METHODS = ("order3", "order4", "order5", "paired_psd",
           "normalized_order3", "normalized_order4", "normalized_order5",
           "exact_psd", "exact_psd192", "exact_psd256", "exact_psd384")


class CpuBudget(Exception):
    pass


def _sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _digest(obj):
    return hashlib.sha256(json.dumps(obj, sort_keys=True, separators=(",", ":"),
                                     allow_nan=False).encode()).hexdigest()


def _load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _atomic(path, value):
    tmp = path.with_name(path.name + "." + str(os.getpid()) + ".tmp")
    tmp.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n")
    os.replace(tmp, path)


def _compile_psd(root, cache):
    source = root / "engine/upstream/ProvenResults/SignedCornerPSDPrune/engine.cpp"
    terms = source.with_name("determinant_terms.hpp")
    pins = {"native_source_sha256": _sha(source), "determinant_terms_sha256": _sha(terms)}
    directory = cache / ("psd-" + _digest(pins)[:24])
    directory.mkdir(parents=True, exist_ok=True)
    target = directory / "paired_psd.so"
    receipt = target.with_suffix(".build.json")
    with (directory / "BUILD.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        if not target.exists():
            tmp = target.with_name("paired_psd." + str(os.getpid()) + ".tmp.so")
            command = ["c++", "-std=c++17", "-O3", "-fno-fast-math", "-ffp-contract=off",
                       "-fPIC", "-shared", str(source), "-o", str(tmp)]
            try:
                subprocess.run(command, check=True, capture_output=True, text=True, timeout=60)
                info = dict(pins, binary_sha256=_sha(tmp), command=command,
                            compiler=subprocess.check_output(["c++", "--version"], text=True).splitlines()[0])
                os.replace(tmp, target)
                _atomic(receipt, info)
            finally:
                tmp.unlink(missing_ok=True)
        info = json.loads(receipt.read_text())
        if any(info.get(k) != v for k, v in pins.items()) or info.get("binary_sha256") != _sha(target):
            raise ValueError("Paired PSD build receipt mismatch")
    return target, info


def initialize(root: Path, cache: Path) -> dict:
    """Build/load isolated libraries; cache must be outside frozen engine paths.

    Call in each worker process, before evaluate.  Unknown/unavailable methods
    are reported explicitly.  Build receipts include source and binary hashes.
    """
    global _STATE
    if threading.current_thread() is not threading.main_thread() or _BUSY:
        raise RuntimeError("Initialize only in an idle worker's main thread")
    root, cache = Path(root).resolve(), Path(cache).resolve()
    if cache == root / "engine" or root / "engine" in cache.parents:
        raise ValueError("Survivor cache must not alter the frozen engine")
    cache.mkdir(parents=True, exist_ok=True)
    c = _load("survivor_frozen_certify", root / "engine/certify_leaves.py")
    c.check_sources()
    c.guard()
    native = {}
    pins = {}
    dp = ctypes.POINTER(ctypes.c_double)
    for order in (3, 4, 5):
        with (cache / ("ORDER" + str(order) + ".lock")).open("a") as lock:
            fcntl.flock(lock, fcntl.LOCK_EX)
            binary = c.build(order, "linear", build_root=cache / "linear")
        lib = ctypes.CDLL(str(binary))
        lib.linear_region.argtypes = [dp, dp]
        lib.linear_region.restype = ctypes.c_int
        lib.set_budget.argtypes = [ctypes.c_double]
        lib.set_budget.restype = None
        info = json.loads(binary.with_suffix(".build.json").read_text())
        native[order] = lib
        pins["order" + str(order)] = {k: v for k, v in info.items() if k.endswith("sha256")}
        pins["order" + str(order)]["frozen_driver_sha256"] = _sha(c.__file__)
    psd_path, psd_info = _compile_psd(root, cache)
    psd = _load("survivor_frozen_psd", root / "engine/upstream/ProvenResults/SignedCornerPSDPrune/predicate.py")
    psd_lib = ctypes.CDLL(str(psd_path))
    psd_lib.compute.argtypes = [dp, dp, ctypes.c_int]
    psd_lib.compute.restype = ctypes.c_int
    psd_lib.certify.argtypes = [dp, ctypes.c_int, ctypes.c_int, dp]
    psd_lib.certify.restype = ctypes.c_int
    psd_lib.test_arithmetic.argtypes = [ctypes.c_int, dp, dp]
    psd_lib.test_arithmetic.restype = ctypes.c_int
    psd._LIB = psd_lib
    pins["paired_psd"] = {k: v for k, v in psd_info.items() if k.endswith("sha256")}
    pins["paired_psd"]["predicate_sha256"] = _sha(psd.__file__)
    normalized_module = _load("survivor_normalized_provider", Path(__file__).with_name("normalized_provider.py"))
    normalized = normalized_module.Provider(root, cache, c)
    exact_module = _load("survivor_normalized_exact", Path(__file__).with_name("normalized_exact.py"))
    exact = exact_module.Provider(root, normalized_module)
    pins.update(normalized.pins)
    pins.update(exact.pins)
    _STATE = dict(root=root, cache=cache, c=c, native=native, psd=psd,
                  pins=pins, pid=os.getpid(), normalized=normalized, exact=exact)
    for method in pins:
        pins[method]["survivor_driver_sha256"] = _sha(__file__)
    availability = {m: {"available": m in pins,
                        "reason": "ready" if m in pins else "provider_not_installed"}
                    for m in METHODS}
    _STATE["availability"] = availability
    return {"schema": SCHEMA, "methods": availability, "provider_hashes": pins,
            "physical_lean_admissions": 0}


def _alarm(signum, frame):
    raise CpuBudget("cpu_budget")


@contextmanager
def _cpu_limit(seconds):
    if threading.current_thread() is not threading.main_thread():
        raise RuntimeError("Evaluation requires the worker's main thread")
    prior_timer = signal.getitimer(signal.ITIMER_PROF)
    if prior_timer[0] or prior_timer[1]:
        raise RuntimeError("An enclosing CPU timer is already active")
    prior_handler = signal.getsignal(signal.SIGPROF)
    signal.signal(signal.SIGPROF, _alarm)
    try:
        signal.setitimer(signal.ITIMER_PROF, seconds)
        yield
    finally:
        signal.setitimer(signal.ITIMER_PROF, 0)
        signal.signal(signal.SIGPROF, prior_handler)


def _validate_box(centers, radii):
    if len(centers) != 4 or len(radii) != 4:
        raise ValueError("Exactly four centers/radii are required")
    if any(isinstance(x, bool) or not isinstance(x, (int, Fraction)) for x in (*centers, *radii)):
        raise ValueError("Exact Fraction/integer geometry is required")
    cc, rr = list(map(Fraction, centers)), list(map(Fraction, radii))
    if not all(abs(x) < 4 for x in cc) or not all(0 < x <= 1 for x in rr):
        raise ValueError("Outside the guarded radians domain")
    return cc, rr


def _finite(value):
    if isinstance(value, float) and not math.isfinite(value):
        raise ArithmeticError("Nonfinite provider witness")
    if isinstance(value, dict):
        for item in value.values():
            _finite(item)
    elif isinstance(value, (list, tuple)):
        for item in value:
            _finite(item)


def _linear(cc, rr, order, deadline):
    c, lib = _STATE["c"], _STATE["native"][order]
    providers, seen, scores = [], set(), [0.0] * 4
    for transpose in (False, True):
        perm = (0, 2, 1, 3) if transpose else (0, 1, 2, 3)
        data = sum((c.phase(cc[k]) for k in perm), []) + [c.up(rr[k]) for k in perm]
        remaining = deadline - time.process_time()
        if remaining <= 0:
            raise CpuBudget("cpu_budget")
        lib.set_budget(remaining)
        out = (ctypes.c_double * 38)()
        code = lib.linear_region((ctypes.c_double * 20)(*data), out)
        if code == -2:
            raise CpuBudget("native_cpu_budget")
        if code != 38:
            raise ArithmeticError("Native arithmetic status " + str(code))
        co = list(out)
        _finite(co)
        if any(co[i] > co[i + 1] for i in range(0, 34, 2)):
            raise ArithmeticError("Malformed native interval")
        signs, reason = c.linear_signs(co)
        providers.append(dict(transpose=transpose, coefficients=co[:34],
                              signs=sorted(signs), reason=reason))
        if len(signs) == 2:
            return dict(ok=True, reason=reason, providers=providers, order=order)
        if co[1] < 243:
            seen.update(-s if transpose else s for s in signs)
        if seen == {-1, 1}:
            return dict(ok=True, reason="coupled_signed_means_non_Tao", providers=providers, order=order)
        for i, k in enumerate(perm):
            scores[k] += co[34 + i]
    return dict(ok=False, reason="unresolved_mean", providers=providers,
                axis=max(range(4), key=lambda k: (scores[k], rr[k])), order=order)


def _evidence(result):
    return {k: result[k] for k in ("schema", "ok", "reason", "method", "input",
                                  "provider_hashes", "witness")}


def evaluate(centers: list[Fraction], radii: list[Fraction], method: str,
             cpu_seconds: float) -> dict:
    """Evaluate an entire exact angular box, with no sample-based acceptance.

    Arithmetic/malformed-source errors and inherited resource guards raise.
    CPU exhaustion returns unresolved.  Witnesses bind exact input strings and pinned
    providers, with a digest suitable for fresh replay in another process.
    """
    global _BUSY
    if _STATE is None or _STATE["pid"] != os.getpid():
        raise RuntimeError("Call initialize in this process first")
    if _BUSY:
        raise RuntimeError("Concurrent evaluator calls are forbidden")
    if isinstance(cpu_seconds, bool) or not isinstance(cpu_seconds, (int, float)) or not math.isfinite(cpu_seconds) or not 0 < cpu_seconds <= 600:
        raise ValueError("CPU budget must be finite and in (0,600]")
    cc, rr = _validate_box(centers, radii)
    if method not in METHODS:
        raise ValueError("Unknown method " + str(method))
    input_box = {"centers": list(map(str, cc)), "radii": list(map(str, rr)), "units": "radians"}
    pins = _STATE["pins"].get(method, {})
    started = time.process_time()
    deadline = started + cpu_seconds
    witness = {}
    verdict = dict(ok=False, reason="method_unavailable", axis=max(range(4), key=lambda k: rr[k]))
    _BUSY = True
    try:
        _STATE["c"].guard()
        if _STATE["availability"][method]["available"]:
            with _cpu_limit(cpu_seconds):
                if method.startswith("order"):
                    witness = _linear(cc, rr, int(method[-1]), deadline)
                    verdict = witness
                elif method == "paired_psd":
                    cert = _STATE["psd"].coupled_leaf(cc, rr, extra=True, q_depth=8, q_nodes=511)
                    if cert is None:
                        verdict = dict(ok=False, reason="unresolved_paired_psd", axis=max(range(4), key=lambda k: rr[k]))
                    else:
                        _finite(cert)
                        witness = {"extra": True, "q_depth": 8, "q_nodes": 511, "certificate": cert}
                        verdict = dict(ok=True, reason=cert["reason"])
                elif method.startswith("normalized_order"):
                    witness = _STATE["normalized"].evaluate(cc, rr, int(method[-1]), deadline, CpuBudget)
                    _finite(witness)
                    verdict = witness
                elif method.startswith("exact_psd"):
                    precision = 256 if method == "exact_psd" else int(method.removeprefix("exact_psd"))
                    witness = _STATE["exact"].evaluate(cc, rr, precision)
                    verdict = witness
                    if not verdict["ok"]:
                        verdict["axis"] = max(range(4), key=lambda k: rr[k])
                else:
                    raise RuntimeError("Available provider has no evaluator")
                if time.process_time() > deadline:
                    raise CpuBudget("cpu_budget")
        _STATE["c"].guard()
    except CpuBudget as error:
        verdict = dict(ok=False, reason=str(error), axis=max(range(4), key=lambda k: rr[k]))
        witness = {}
    finally:
        _BUSY = False
    result = {"schema": SCHEMA, "ok": verdict["ok"] is True,
              "reason": verdict["reason"], "method": method, "input": input_box,
              "provider_hashes": dict(pins), "witness": witness,
              "cpu_seconds": time.process_time() - started, "physical_lean_admissions": 0}
    if "axis" in verdict:
        result["axis"] = verdict["axis"]
    result["replay"] = {"schema": SCHEMA, "evidence_sha256": _digest(_evidence(result)),
                        "input_sha256": _digest(input_box), "method": method}
    return result


def replay(record: dict, cpu_seconds: float = 30) -> dict:
    """Freshly recompute a successful leaf and reject changed inputs/providers.

    This is a numerical replay receipt, never a Lean admission.  Replay is
    intentionally performed under exactly the original method and source pins.
    """
    if record.get("schema") != SCHEMA or record.get("ok") is not True:
        raise ValueError("Only an accepted survivor leaf can be replayed")
    receipt = record.get("replay", {})
    if receipt.get("evidence_sha256") != _digest(_evidence(record)) or receipt.get("input_sha256") != _digest(record["input"]):
        raise ValueError("Leaf evidence/input digest mismatch")
    method = record["method"]
    if _STATE is None or record["provider_hashes"] != _STATE["pins"].get(method):
        raise ValueError("Replay provider pins differ")
    if record["input"].get("units") != "radians":
        raise ValueError("Unsupported replay geometry units")
    fresh = evaluate(list(map(Fraction, record["input"]["centers"])),
                     list(map(Fraction, record["input"]["radii"])), method, cpu_seconds)
    if not fresh["ok"]:
        return {"ok": False, "status": "UNRESOLVED", "reason": fresh["reason"], "method": method,
                "cpu_seconds": fresh["cpu_seconds"], "physical_lean_admissions": 0}
    if fresh["replay"]["evidence_sha256"] != receipt["evidence_sha256"]:
        raise ValueError("Fresh provider evidence differs")
    return {"ok": True, "status": "PASS", "method": method, "evidence_sha256": receipt["evidence_sha256"],
            "provider_hashes": fresh["provider_hashes"], "cpu_seconds": fresh["cpu_seconds"],
            "physical_lean_admissions": 0}


def replay_recipe(recipe: dict, cpu_seconds: float = 30) -> dict:
    """Recompute a compact leaf recipe without trusting any stored PASS flag."""
    if recipe.get("schema") != "survivor-leaf-recipe-v1":
        raise ValueError("Unsupported compact leaf recipe")
    method, geometry = recipe["method"], recipe["input"]
    if _STATE is None or recipe["provider_hashes"] != _STATE["pins"].get(method):
        raise ValueError("Compact replay provider pins differ")
    receipt = recipe["replay"]
    if receipt.get("schema") != SCHEMA or receipt.get("method") != method or receipt.get("input_sha256") != _digest(geometry):
        raise ValueError("Compact replay geometry binding differs")
    if geometry.get("units") != "radians":
        raise ValueError("Unsupported compact replay geometry units")
    fresh = evaluate(list(map(Fraction, geometry["centers"])),
                     list(map(Fraction, geometry["radii"])), method, cpu_seconds)
    if not fresh["ok"]:
        return {"ok": False, "status": "UNRESOLVED", "method": method,
                "reason": fresh["reason"], "cpu_seconds": fresh["cpu_seconds"],
                "physical_lean_admissions": 0}
    if (fresh["reason"] != recipe["reason"] or _digest(fresh["witness"]) != recipe["witness_sha256"]
            or fresh["replay"]["evidence_sha256"] != receipt["evidence_sha256"]):
        raise ValueError("Compact replay regenerated different evidence")
    return {"ok": True, "status": "PASS", "method": method,
            "evidence_sha256": receipt["evidence_sha256"], "provider_hashes": fresh["provider_hashes"],
            "cpu_seconds": fresh["cpu_seconds"], "physical_lean_admissions": 0}
