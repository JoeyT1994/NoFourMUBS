"""Exact radial chart data and native Taylor evaluation near cube-root seeds.

This provider divides seed displacements before the polynomial circuit, using
the exact factorizations R=rho^4 Rbar, Delta=rho^12 Dbar, A=rho^12 Abar,
B=rho^10 Bbar. It does not divide already-enclosed output intervals.
The physical implications remain the upstream numerical assumptions.
"""
from fractions import Fraction as Q
from functools import lru_cache
from pathlib import Path
import ctypes
import fcntl
import hashlib
import json
import math
import os
import subprocess
import time

HERE = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


@lru_cache(maxsize=2048)
def trig_bounds(q):
    """Rational Taylor bounds, retaining tiny exp(i*q)-root differences."""
    q = Q(q)
    if abs(q) >= 4:
        raise ValueError("Phase outside supported range")
    co, si, power, fact = Q(0), Q(0), Q(1), 1
    for k in range(160):
        if k % 2:
            si += (-1) ** ((k - 1) // 2) * power / fact
        else:
            co += (-1) ** (k // 2) * power / fact
        power *= q
        fact *= k + 1
    error = abs(power) / fact
    return co - error, co + error, si - error, si + error


@lru_cache(maxsize=1)
def constants():
    def atan(x):
        v = sum(((-1) ** k * x ** (2*k + 1) / Q(2*k + 1) for k in range(160)), Q(0))
        e = x ** 321 / 321
        return v - e, v + e
    a, b = atan(Q(1, 5)), atan(Q(1, 239))
    pi = (16*a[0] - 4*b[1], 16*a[1] - 4*b[0])
    scale = 1 << 512
    lo = math.isqrt(3 * scale * scale)
    sqrt3 = Q(lo, scale), Q(lo + 1, scale)
    return pi, sqrt3


def chart(centers, radii):
    pi, sqrt3 = constants()
    midpoint = sum(pi) / 2
    candidates = []
    for signs in ((1, -1, -1, 1), (-1, 1, 1, -1)):
        distance = max(abs(c - s * 2 * midpoint / 3) + r + (pi[1] - pi[0])
                       for c, r, s in zip(centers, radii, signs))
        candidates.append((distance, signs))
    distance, signs = min(candidates)
    if distance > Q(1, 2):
        return None
    rho = Q(1)
    while rho / 2 >= distance:
        rho /= 2
    roots = []
    deltas = []
    for center, sign in zip(centers, signs):
        imag = (sqrt3[0]/2, sqrt3[1]/2) if sign > 0 else (-sqrt3[1]/2, -sqrt3[0]/2)
        root = (-Q(1, 2), -Q(1, 2), *imag)
        ph = trig_bounds(center)
        delta = ((ph[0]-root[1])/rho, (ph[1]-root[0])/rho,
                 (ph[2]-root[3])/rho, (ph[3]-root[2])/rho)
        roots.append(root)
        deltas.append(delta)
    return dict(rho=rho, roots=roots, deltas=deltas, signs=signs,
                angular_distance_bound=distance)


class Provider:
    def __init__(self, root, cache, frozen):
        self.root, self.cache, self.c = Path(root), Path(cache), frozen
        self.libs, self.pins = {}, {}
        source = HERE / "normalized_engine.cpp"
        common = {"normalized_native_source_sha256": sha(source),
                  "normalized_provider_sha256": sha(__file__),
                  "frozen_driver_sha256": sha(frozen.__file__),
                  "taylor_source_sha256": sha(frozen.MODULE / "taylor.hpp"),
                  "interval_source_sha256": sha(frozen.MODULE.parent / "SignedCornerPSDPrune/engine.cpp"),
                  "determinant_terms_sha256": sha(frozen.MODULE.parent / "SignedCornerPSDPrune/determinant_terms.hpp")}
        key = hashlib.sha256(json.dumps(common, sort_keys=True).encode()).hexdigest()[:24]
        directory = self.cache / ("normalized-" + key)
        directory.mkdir(parents=True, exist_ok=True)
        for order in (3, 4, 5):
            target = directory / ("normalized_order" + str(order) + ".so")
            receipt = target.with_suffix(".build.json")
            with target.with_suffix(".lock").open("a") as lock:
                fcntl.flock(lock, fcntl.LOCK_EX)
                if not target.exists():
                    tmp = target.with_name(target.name + "." + str(os.getpid()) + ".tmp.so")
                    cmd = ["c++", "-std=c++17", "-O3", "-fno-fast-math", "-ffp-contract=off",
                           "-fPIC", "-shared", "-DTM_ORDER=" + str(order), str(source), "-o", str(tmp)]
                    try:
                        subprocess.run(cmd, check=True, capture_output=True, text=True, timeout=60)
                        info = dict(common, order=order, binary_sha256=sha(tmp), command=cmd)
                        os.replace(tmp, target)
                        receipt.write_text(json.dumps(info, indent=2) + "\n")
                    finally:
                        tmp.unlink(missing_ok=True)
                info = json.loads(receipt.read_text())
                if info.get("order") != order or any(info.get(k) != v for k, v in common.items()) or info.get("binary_sha256") != sha(target):
                    raise ValueError("Normalized build receipt mismatch")
            lib = ctypes.CDLL(str(target))
            dp = ctypes.POINTER(ctypes.c_double)
            lib.normalized_region.argtypes = [dp, dp]
            lib.normalized_region.restype = ctypes.c_int
            lib.set_budget.argtypes = [ctypes.c_double]
            lib.set_budget.restype = None
            self.libs[order] = lib
            self.pins["normalized_order" + str(order)] = {k:v for k,v in info.items() if k.endswith("sha256")}

    def evaluate(self, centers, radii, order, deadline, budget_error):
        info = chart(centers, radii)
        if info is None:
            return dict(ok=False, reason="normalized_chart_outside_neighborhood",
                        axis=max(range(4), key=lambda k:radii[k]))
        lib, c = self.libs[order], self.c
        rho = info["rho"]
        providers, seen, scores = [], set(), [0.0]*4
        for tr in (False, True):
            perm = (0, 2, 1, 3) if tr else (0, 1, 2, 3)
            pairs = lambda values: [c.down(values[0]), c.up(values[1]), c.down(values[2]), c.up(values[3])]
            data = sum((c.phase(centers[k]) for k in perm), []) + [c.up(radii[k]) for k in perm]
            data += sum((pairs(info["deltas"][k]) for k in perm), [])
            data += sum((pairs(info["roots"][k]) for k in perm), []) + [float(rho)]
            remaining = deadline - time.process_time()
            if remaining <= 0:
                raise budget_error("cpu_budget")
            lib.set_budget(remaining)
            out = (ctypes.c_double*38)()
            status = lib.normalized_region((ctypes.c_double*53)(*data), out)
            if status == -2:
                raise budget_error("native_cpu_budget")
            if status != 38:
                raise ArithmeticError("Normalized arithmetic status " + str(status))
            co = list(out)
            if not all(math.isfinite(x) for x in co) or any(co[k] > co[k+1] for k in range(0,34,2)):
                raise ArithmeticError("Malformed normalized native intervals")
            signs, why = c.linear_signs(co)
            providers.append(dict(transpose=tr, coefficients=co[:34], signs=sorted(signs), reason=why))
            if len(signs) == 2:
                verdict = dict(ok=True, reason=why)
                break
            # co[0:2] encloses Rbar, not physical R.  Retain the exact rho^4.
            if Q(co[1]) * rho**4 < 243:
                seen.update(-s if tr else s for s in signs)
            if seen == {-1, 1}:
                verdict = dict(ok=True, reason="coupled_normalized_means_non_Tao")
                break
            for i,k in enumerate(perm):
                scores[k] += co[34+i]
        else:
            verdict = dict(ok=False, reason="unresolved_normalized_mean",
                           axis=max(range(4), key=lambda k:(scores[k],radii[k])))
        verdict.update(providers=providers, order=order,
                       normalization={"rho":str(rho), "seed_imaginary_signs":list(info["signs"]),
                                      "angular_distance_bound":str(info["angular_distance_bound"]),
                                      "coefficient_scaling":{"R":4,"Delta":12,"A":12,"B":10},
                                      "coefficient_domain":"Rbar,Dbar,Abar,Bbar+-3rho^2Dbar,Hbar"})
        return verdict
