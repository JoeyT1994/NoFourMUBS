// Radial Taylor circuit at the two cube-root strict-corner seeds.
// Seed displacements and exact cancellations occur before enclosure arithmetic.
#include "../engine/upstream/ProvenResults/SignedCornerPSDPrune/engine.cpp"
#include "../engine/upstream/ProvenResults/Patch2442Region_v3/taylor.hpp"

static array<T,6> ncoeffs(T A,T B){T ai=cj(A),bi=cj(B);return {
 -sq(A-B)*(A+B)*sq(ai)*sq(bi),
 (A-B)*(A+B)*(A*B-T(1))*sq(ai)*bi,
 sq(B-T(1))*(B+T(1))*ai*bi,
 -(sq(A)-B)*(B-T(1))*(B+T(1))*ai*sq(bi),
 sq(A-T(1))*(A+T(1))*ai*bi,
 (A-T(1))*(A+T(1))*(A-sq(B))*sq(ai)*bi};}

// Layout: phase centers[16], angular radii[4], (phase-anchor)/rho[16],
// exact root enclosures[16], positive dyadic rho[1].
static array<T,4> displacement_seed(const double*input){
 array<T,4>out;I rho(input[52]);
 for(int i=0;i<4;i++){
  C centre(I(input[4*i],input[4*i+1]),I(input[4*i+2],input[4*i+3]));
  const double*p=input+20+4*i;
  T z(C(I(p[0],p[1]),I(p[2],p[3])));C co=centre*(I(1)/rho);
  for(int k=1;k<=TM_ORDER;k++){
   co=co*ii*(I(input[16+i])/I(k));array<int,4>e={0,0,0,0};e[i]=k;
   int n=0;while(basis.e[n]!=e)n++;z.a[n]=co;
  }
  I rem(1);for(int k=1;k<=TM_ORDER+1;k++)rem=rem*I(input[16+i])/I(k);
  rem=rem/rho;z.error=C(I(-rem.u,rem.u),I(-rem.u,rem.u));out[i]=z;
 }
 return out;
}

extern "C" int normalized_region(const double*input,double*output){try{
 if(!std::numeric_limits<double>::is_iec559||std::fegetround()!=FE_TONEAREST)return -9;
 if(!(input[52]>0 && input[52]<=1))return -8;
 auto ds0=displacement_seed(input);array<C,4>z;
 for(int i=0;i<4;i++){const double*p=input+36+4*i;z[i]=C(I(p[0],p[1]),I(p[2],p[3]));}
 C h(input[52]),h2=h*h,h3=h2*h,h4=h2*h2,h5=h4*h,h6=h3*h3;
 T a=T(z[0])+ds0[0]*h,b=T(z[1])+ds0[1]*h,c=T(z[2])+ds0[2]*h,d=T(z[3])+ds0[3]*h;
 // -1-z0-z1=-1-z2-z3=-1-z2*conj(z0)-z3*conj(z1)=0 exactly.
 T S=-ds0[0]-ds0[1],V=-ds0[2]-ds0[3];
 T U=-(cj(ds0[0])*z[2]+ds0[2]*cj(z[0])+ds0[2]*cj(ds0[0])*h
       +cj(ds0[1])*z[3]+ds0[3]*cj(z[1])+ds0[3]*cj(ds0[1])*h);
 T x=abs2(S),y=abs2(V),zz=abs2(U),p=x+y+zz;
 T j=real(S*U*cj(V))*C(2),w=x*y+x*zz+y*zz-x*y*zz*h2;
 T pp=sq(p),jj=sq(j);
 T R=w*C(324)-pp*C(81)+p*j*h*C(54)
   +(jj*C(27)+pp*p*C(18)-p*w*C(54))*h2
   +j*(w*C(30)-pp*C(24))*h3
   +(pp*w*C(2)-sq(pp)-sq(w)+p*jj*C(2))*h4
   +(jj*j*C(4)+pp*p*j*C(2)-p*w*j*C(2))*h5-pp*jj*h6;
 auto E=[&](const T&v){return p*C(9)-v*C(18)+j*h*C(3)
                            +(w-pp+v*p*C(2))*h2+(p-v*C(2))*j*h3;};
 array<T,3>P={S*V*C(3)+(U*sq(S)+cj(U)*sq(V))*h-zz*S*V*h2,
              U*cj(S)*C(3)+(V*sq(cj(S))+sq(U)*cj(V))*h-y*U*cj(S)*h2,
              cj(U)*cj(V)*C(3)+(S*sq(cj(V))+sq(cj(U))*cj(S))*h-x*cj(U)*cj(V)*h2};
 array<T,3>n={abs2(P[0]),abs2(P[1]),abs2(P[2])};T delta=n[0]*n[1]*n[2],D=delta*h2*C(3);
 T f0=P[0]*n[1]*n[2]*C(0.5),f1=cj(P[1])*n[0]*n[2]*C(0.5),f2=cj(P[2])*n[0]*n[1]*C(0.5);
 array<T,6>M={delta*S*V*h2-E(zz)*f0,delta*cj(U)*h,
              delta*S*cj(U)*h2-E(y)*f1,delta*V*h,
              delta*V*U*h2-E(x)*f2,delta*S*h};
 array<T,6>B={f0*(-ii),T(0),f1*ii,T(0),f2*ii,T(0)};
 array<T,3>xx={T(1),a,b},yy={T(1),c,d};
 int pq[6][2]={{1,1},{1,-1},{2,-1},{0,1},{-1,2},{1,0}},pairs[3][2]={{0,1},{0,2},{1,2}};
 double*q=output;put(R.range().re,q);put(delta.range().re,q);double best=INF;array<double,4>scores={1,1,1,1};
 for(int k=0;k<3;k++){
  int u=pairs[k][0],v=pairs[k][1];auto ds=ncoeffs(xx[v]*cj(xx[u]),yy[v]*cj(yy[u]));T sa,sb;
  for(int m=0;m<6;m++){T co=ds[m]*powu(xx[u],-pq[m][0])*powu(yy[u],-pq[m][1]);sa=sa+co*M[m];sb=sb+co*B[m];}
  T A=real((sa-cj(sa))*ii),beta=real((sb-cj(sb))*ii);
  T Km=beta-D,Kp=beta+D,Hm=sq(A)-sq(Km)*R,Hp=sq(A)-sq(Kp)*R;
  put(A.range().re,q);put(Km.range().re,q);put(Kp.range().re,q);
  I hm=Hm.range().re,hp=Hp.range().re;
  if(hm.l<=0 && hm.u>=0)hm=intersect(hm,bernstein_real(Hm));
  if(hp.l<=0 && hp.u>=0)hp=intersect(hp,bernstein_real(Hp));
  put(hm,q);put(hp,q);
  double ma=mag(A.a[0].re),mh=std::max(mag(Hm.a[0].re),mag(Hp.a[0].re));
  if(ma>0 && mh>0){double rate=std::min((hm.u-hm.l)/mh,(hp.u-hp.l)/mh);
   if(rate<best){best=rate;scores={0,0,0,0};
    for(int m=1;m<basis.n;m++)for(int i=0;i<4;i++)if(basis.e[m][i])
     scores[i]+=mag(A.a[m].re)/ma+std::min(mag(Hm.a[m].re),mag(Hp.a[m].re))/mh;
   }
  }
 }
 for(double v:scores)*q++=v;return int(q-output);
 }catch(const NativeBudget&){return -2;}catch(...){return -1;}}
