"""Selective integer-arithmetic PSD fallback with certified chart conversion.

Each precision owns an isolated exact_core module, including its constants.
Angular boxes are enclosed in rational-unit-anchor Cayley boxes using the
upstream arc_radius inequality.  Angles are never used as Cayley coordinates.
Acceptance is by whole-box coefficient bounds and complete radical covers;
center evaluations only enter a Taylor enclosure with a whole-box Hessian.
"""
from fractions import Fraction as Q
from pathlib import Path
import hashlib
import math
import types


class Provider:
    def __init__(self, root, normalized):
        self.path = Path(root) / "engine/upstream/ProvenResults/ExactPSDRegionCertificates/exact_core.py"
        self.source = self.path.read_text()
        self.normalized = normalized
        self.contexts = {}
        self.pins = {}
        if self.source.count("P=80\n") != 1 or self.source.count("c=F(c);N=36") != 1:
            raise ValueError("Exact provider precision injection point changed")
        for precision in (192, 256, 384):
            # The module's ZERO/IM constants must be created at this precision.
            # Reassigning P/S after import would silently corrupt those values.
            source = self.source.replace("P=80\n", "P=" + str(precision) + "\n")
            source = source.replace("c=F(c);N=36", "c=F(c);N=128")
            module = types.ModuleType("survivor_exact_core_" + str(precision))
            module.__file__ = str(self.path)
            exec(compile(source, str(self.path), "exec"), module.__dict__)
            self.contexts[precision] = module
            self.pins["exact_psd" + str(precision)] = {
                "exact_core_source_sha256": hashlib.sha256(self.source.encode()).hexdigest(),
                "exact_instantiated_source_sha256": hashlib.sha256(source.encode()).hexdigest(),
                "exact_provider_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                "phase_provider_sha256": hashlib.sha256(Path(normalized.__file__).read_bytes()).hexdigest()}
        self.pins["exact_psd"] = dict(self.pins["exact_psd256"])

    def _anchors(self, centers):
        result = []
        # First rotate into a Cayley chart at one of the four exact axial units.
        for center in centers:
            bounds = self.normalized.trig_bounds(center)
            x, y = (bounds[0] + bounds[1])/2, (bounds[2] + bounds[3])/2
            axes = ((Q(1),Q(0)), (Q(0),Q(1)), (-Q(1),Q(0)), (Q(0),-Q(1)))
            ax, ay = max(axes, key=lambda v:x*v[0]+y*v[1])
            re, im = x*ax+y*ay, y*ax-x*ay
            tangent = im / (1+re)
            denominator = 1 << 64
            numerator = (tangent.numerator*denominator)//tangent.denominator
            t = Q(numerator, denominator)
            rx, ry = (1-t*t)/(1+t*t), 2*t/(1+t*t)
            anchor = (ax*rx-ay*ry, ay*rx+ax*ry)
            if anchor[0]**2 + anchor[1]**2 != 1:
                raise ArithmeticError("Nonunit exact Cayley anchor")
            result.append(anchor)
        return result

    @staticmethod
    def _sqrt_bounds(value, bits):
        if value < 0:
            raise ValueError("Negative radical endpoint")
        scale = 1 << bits
        n = (value.numerator*scale*scale)//value.denominator
        low = math.isqrt(n)
        lo = Q(low, scale)
        hi = lo if lo*lo == value else Q(low+1, scale)
        if not lo*lo <= value <= hi*hi:
            raise ArithmeticError("Exact radical enclosure failure")
        return lo, hi

    @staticmethod
    def _serialize_coefficients(ex):
        def complex_endpoints(x):
            return {"re":x.re.endpoints(), "im":x.im.endpoints()}
        return dict(scale=complex_endpoints(ex["scale"]),
                    G=[complex_endpoints(x) for x in ex["G"]],
                    nf=[[[complex_endpoints(a),complex_endpoints(b)] for a,b in row] for row in ex["nf"]])

    @staticmethod
    def _exclusion(core, provider, sigma, lo, hi):
        ex = provider["bounds"]
        for j, row in enumerate(ex["nf"]):
            for eps in (-1, 1):
                da = row[0][0].re*eps
                db = 3*ex["scale"].re+row[0][1].re*(eps*sigma)
                d0, d1 = da+db*lo, da+db*hi
                if max(d0.hi,d1.hi) < 0:
                    return dict(kind="negative_diagonal", j=j, eps=eps,
                                endpoint_bounds=[d0.endpoints(),d1.endpoints()])
                for k in range(3):
                    za = row[k+1][0]*eps
                    zb = ex["G"][k]+row[k+1][1]*(eps*sigma)
                    z0, z1 = za+zb*lo, za+zb*hi
                    bernstein = (d0.sq()-z0.norm(),
                                 d0*d1-(z0*z1.conj()).re,
                                 d1.sq()-z1.norm())
                    if all(value.hi < 0 for value in bernstein):
                        return dict(kind="negative_minor_bernstein", j=j, eps=eps, k=k,
                                    bernstein=[value.endpoints() for value in bernstein])
        return None

    def evaluate(self, centers, radii, precision=256):
        core = self.contexts[precision]
        anchors = self._anchors(centers)
        # arc_radius proves containment for all points of each angular interval.
        try:
            cayley = [core.arc_radius(c,r,a) for c,r,a in zip(centers,radii,anchors)]
        except ValueError as error:
            if str(error) in ("wrong Cayley chart", "Cayley pole not separated"):
                return dict(ok=False, reason="exact_chart_conversion_unavailable",
                            precision_bits=precision, conversion_reason=str(error))
            raise
        providers, records, rbounds = [], [], []
        for tr in (False, True):
            perm = (0,2,1,3) if tr else (0,1,2,3)
            aa, rr = [anchors[k] for k in perm], [cayley[k] for k in perm]
            center = core.phase_jets(aa, rr, center=True)
            box = core.phase_jets(aa, rr, center=False)
            # Cleared arithmetic has no branch depending on interval separation
            # of P. The unscaled mode is a selective additional provider.
            for cleared in (True, False):
                try:
                    ec, eb = core.expressions(center, cleared), core.expressions(box, cleared)
                except ValueError as error:
                    if not cleared and str(error) == "zero denominator":
                        records.append(dict(transpose=tr, cleared=False, available=False,
                                            reason="interval_denominator_not_separated"))
                        continue
                    raise
                rb = core.taylor(ec["R"], eb["R"], rr)
                rbounds.append(rb)
                bounds = core.coefficient_bounds(ec, eb, rr)
                providers.append(dict(transpose=tr, cleared=cleared, bounds=bounds))
                records.append(dict(provider=len(providers)-1, transpose=tr, cleared=cleared, available=True,
                                    R=rb.endpoints(), coefficients=self._serialize_coefficients(bounds)))
                if rb.hi <= 0:
                    return dict(ok=True, reason="R_nonpositive", precision_bits=precision,
                                chart=self._chart_record(anchors,cayley), providers=records,
                                q_cover=[])
        low = max(Q(0), *(Q(r.lo,core.S) for r in rbounds))
        high = min(Q(r.hi,core.S) for r in rbounds)
        if low > high:
            raise ArithmeticError("Exact R providers have disjoint enclosures")
        qlo = self._sqrt_bounds(low, precision)[0]
        qhi = self._sqrt_bounds(high, precision)[1]
        # Use all four orientation/sign combinations; no matching/Tao shortcut.
        stack, cover, nodes = [(qlo,qhi,0)], [], 0
        while stack:
            lo, hi, depth = stack.pop()
            nodes += 1
            if nodes > 511:
                return dict(ok=False, reason="exact_q_node_budget", precision_bits=precision,
                            chart=self._chart_record(anchors,cayley), providers=records,
                            R=[str(low),str(high)], q_nodes=nodes-1)
            excluded = {False:{}, True:{}}
            for index, provider in enumerate(providers):
                for sign in (-1,1):
                    if sign in excluded[provider["transpose"]]:
                        continue
                    witness = self._exclusion(core, provider, sign, lo, hi)
                    if witness is not None:
                        excluded[provider["transpose"]][sign] = dict(provider=index, sigma=sign, **witness)
            if any(len(side)==2 for side in excluded.values()):
                side = next(side for side in excluded.values() if len(side)==2)
                cover.append(dict(interval=[str(lo),str(hi)], exclusions=[side[-1],side[1]]))
                continue
            if depth >= 8:
                return dict(ok=False, reason="unresolved_exact_psd", precision_bits=precision,
                            chart=self._chart_record(anchors,cayley), providers=records,
                            R=[str(low),str(high)], q_nodes=nodes)
            mid = (lo+hi)/2
            stack.extend(((mid,hi,depth+1),(lo,mid,depth+1)))
        return dict(ok=True, reason="exact_signed_corner_PSD", precision_bits=precision,
                    chart=self._chart_record(anchors,cayley), providers=records,
                    R=[str(low),str(high)], q_cover=cover, q_nodes=nodes)

    @staticmethod
    def _chart_record(anchors,radii):
        return {"kind":"rational_unit_anchor_Cayley", "anchors":[list(map(str,a)) for a in anchors],
                "radii":list(map(str,radii)), "conversion":"exact_core.arc_radius",
                "angle_units":"radians", "cayley_units":"dimensionless"}
