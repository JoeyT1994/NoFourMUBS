"""Admit a pristine v2 validation queue; never replace a historical v1 stage."""
from pathlib import Path
import argparse
import json

if __package__:
    from . import task_queue as tq, worker
    from .runtime import release_pins
    from .migrate import free_lock, _node_locks
    from .parent_roots import seed_root
else:
    import task_queue as tq
    import worker
    from runtime import release_pins
    from migrate import free_lock, _node_locks
    from parent_roots import seed_root


def bootstrap(queue, release, schedule_path):
    queue = queue if isinstance(queue, tq.TaskQueue) else tq.TaskQueue(queue)
    release = Path(release).resolve()
    pins = release_pins(release)
    schedule = worker.load_schedule(schedule_path)
    config = tq.read_json(queue.area / "CONFIG.json")
    with free_lock(queue.area / "RUNTIME.lock"), free_lock(queue.area / "COORDINATOR.lock"), free_lock(queue.area / "IMPORT.lock"):
        tq.resource_guard(queue.area)
        _node_locks(queue)
        if any((queue.area / name).exists() for name in ("LAUNCH.json", "FAILURE.json", "STOP_REQUESTED.json")):
            raise ValueError("Pristine bootstrap cannot replace an existing runtime/launch/guard")
        if (queue.area / "RUNTIME.json").exists():
            runtime = tq.read_json(queue.area / "RUNTIME.json")
            receipt = tq.read_json(queue.area / "MIGRATION.json")
            if (receipt.get("schema") != "survivor-bootstrap-receipt-v2" or not receipt.get("pristine_queue")
                    or runtime.get("new_release_sha256") != tq.digest(pins)
                    or runtime.get("schedule_sha256") != tq.digest(schedule)
                    or runtime.get("queue_config_sha256") != tq.digest(config)
                    or runtime.get("migration_receipt_sha256") != receipt.get("receipt_sha256")
                    or runtime.get("receipt_sha256") != tq.digest({k:v for k,v in runtime.items() if k != "receipt_sha256"})
                    or receipt.get("receipt_sha256") != tq.digest({k:v for k,v in receipt.items() if k != "receipt_sha256"})):
                raise ValueError("Existing runtime is not this pristine bootstrap")
            return receipt
        count = 0
        for directory in queue.iter_task_dirs():
            with free_lock(directory / "RUN.lock"):
                task, state = tq.read_json(directory / "TASK.json"), tq.read_json(directory / "STATE.json.gz")
                tq.validate_state(task, state)
                if (state["attempts"] or state["proofs"] or state["added_nodes"] or state.get("cursor")
                        or state.get("schedule_sha256") is not None or state["cpu_seconds"]
                        or state["status"] not in ("queued", "parked")
                        or any(r["tree"] != "P" for r in state["roots"])
                        or state["status"] == "parked" and not task.get("source_guard")):
                    raise ValueError("Historical queue requires explicit stopped-checkpoint migration")
                count += 1
        body = {"schema": "survivor-bootstrap-receipt-v2", "status": "COMMITTED", "tasks": count,
                "new_release": str(release), "new_release_sha256": tq.digest(pins),
                "schedule_sha256": tq.digest(schedule), "queue_config_sha256": tq.digest(config),
                "pristine_queue": True, "physical_lean_admissions": 0}
        ident = tq.digest(body)
        receipt = dict(body, migration_id=ident)
        receipt["receipt_sha256"] = tq.digest(receipt)
        tq.immutable_json(queue.area / "MIGRATION.json", receipt)
        runtime = {"schema": "survivor-runtime-v2", "migration_id": ident,
                   "migration_receipt_sha256": receipt["receipt_sha256"],
                   "new_release": str(release), "new_release_sha256": tq.digest(pins),
                   "legacy_source": None, "legacy_release_sha256": None, "legacy_pins": {},
                   "queue_config_sha256": tq.digest(config), "schedule_sha256": tq.digest(schedule),
                   "physical_lean_admissions": 0}
        runtime["receipt_sha256"] = tq.digest(runtime)
        tq.immutable_json(queue.area / "RUNTIME.json", runtime)
        for key in queue.iter_parent_keys():
            if schedule["whole_root"]:
                seed_root(queue, key)
            else:
                queue.parent_marker("root_ready", key).unlink(missing_ok=True)
        return receipt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--queue", required=True)
    parser.add_argument("--release", required=True)
    parser.add_argument("--schedule", required=True)
    args = parser.parse_args()
    worker._memory_limit()
    print(json.dumps(bootstrap(args.queue, args.release, args.schedule), sort_keys=True), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
