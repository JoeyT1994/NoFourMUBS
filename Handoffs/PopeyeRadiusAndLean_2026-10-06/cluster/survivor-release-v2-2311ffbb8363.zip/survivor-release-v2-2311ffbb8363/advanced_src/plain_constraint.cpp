#include "../../engine/upstream/ProvenResults/SignedCornerPSDPrune/engine.cpp"
#include "../../engine/upstream/ProvenResults/Patch2442Region_v3/taylor.hpp"
static T stableR2(const T&p,const T&j,const T&w){T pp=sq(p),jj=sq(j);return jj*j*C(4)+jj*(-pp+p*C(2)+T(27))+j*(pp*p*C(2)-pp*C(24)-p*w*C(2)+p*C(54)+w*C(30))-sq(pp)+pp*p*C(18)+pp*w*C(2)-pp*C(81)-p*w*C(54)-sq(w)+w*C(324);}
static T stableA2(const T&p,const T&j,const T&w,const T&z){return w-sq(p)+p*C(9)-z*C(18)+z*p*C(2)+(p+T(3)-z*C(2))*j;}
static array<T,6> tc2(T A,T B){T ai=cj(A),bi=cj(B);return {
 -sq(A-B)*(A+B)*sq(ai)*sq(bi),
 (A-B)*(A+B)*(A*B-T(1))*sq(ai)*bi,
 sq(B-T(1))*(B+T(1))*ai*bi,
 -(sq(A)-B)*(B-T(1))*(B+T(1))*ai*sq(bi),
 sq(A-T(1))*(A+T(1))*ai*bi,
 (A-T(1))*(A+T(1))*(A-sq(B))*sq(ai)*bi};}
struct MeanPack {T R,Delta,p,j,w;array<T,3>A,B;};
static MeanPack means(array<T,4>seed){
 T a=seed[0],b=seed[1],c=seed[2],d=seed[3];
 T s=-T(1)-a-b,t=-T(1)-c-d,r=-T(1)-c*cj(a)-d*cj(b);
 T X=abs2(s),Y=abs2(t),Z=abs2(r),p=X+Y+Z,j=real(s*r*cj(t))*C(2),w=X*Y+X*Z+Y*Z-X*Y*Z;
 MeanPack out;out.R=stableR2(p,j,w);out.p=p;out.j=j;out.w=w;
 array<T,3>P={r*sq(s)+cj(r)*sq(t)+(T(3)-Z)*s*t,t*sq(cj(s))+sq(r)*cj(t)+(T(3)-Y)*r*cj(s),s*sq(cj(t))+sq(cj(r))*cj(s)+(T(3)-X)*cj(r)*cj(t)};
 array<T,3>n={abs2(P[0]),abs2(P[1]),abs2(P[2])};T delta=n[0]*n[1]*n[2];out.Delta=delta;
 T u0=P[0]*n[1]*n[2]*C(.5),u1=cj(P[1])*n[0]*n[2]*C(.5),u2=cj(P[2])*n[0]*n[1]*C(.5);
 array<T,6>M={delta*s*t-stableA2(p,j,w,Z)*u0,delta*cj(r),delta*s*cj(r)-stableA2(p,j,w,Y)*u1,delta*t,delta*t*r-stableA2(p,j,w,X)*u2,delta*s};
 array<T,6>B={u0*(-ii),T(0),u1*ii,T(0),u2*ii,T(0)};
 array<T,3>xx={T(1),a,b},yy={T(1),c,d};int pq[6][2]={{1,1},{1,-1},{2,-1},{0,1},{-1,2},{1,0}},pairs[3][2]={{0,1},{0,2},{1,2}};
 for(int k=0;k<3;k++){
  int u=pairs[k][0],v=pairs[k][1];auto ds=tc2(xx[v]*cj(xx[u]),yy[v]*cj(yy[u]));T sa,sb;
  for(int z=0;z<6;z++){T co=ds[z]*powu(xx[u],-pq[z][0])*powu(yy[u],-pq[z][1]);sa=sa+co*M[z];sb=sb+co*B[z];}
  out.A[k]=real((sa-cj(sa))*ii);out.B[k]=real((sb-cj(sb))*ii);
 }
 return out;
}
static I plain_bound(const T&a){I x=a.range().re;return x.l>0?x:intersect(x,bernstein_real(a));}


static I fullbound(const T&a){return intersect(a.range().re,bernstein_real(a));}
// Dh*|Av|+Dv*|Ah| is nonnegative (Dh,Dv are 3*Delta).
// Generic outward products round their exact zero lower endpoints below zero.
// Intersect that enclosure with the proved nonnegative range for the witness;
// the upper endpoint, and therefore every accepting comparison, is unchanged.
static I elimination_rhs(I dh,I dv,I ah,I av){
 I rhs=I(0,std::max(0.,dh.u))*I(0,mag(av))+I(0,std::max(0.,dv.u))*I(0,mag(ah));
 return I(0,rhs.u);
}
static T domain_J,domain_R;static bool use_J=false,use_R=false;
static I domain_bound(const T&f){
 return plain_bound(f); // v2 plain fallback: constraints deliberately disabled.

 I base=plain_bound(f);if(base.l>0)return base;
 struct Choice{double j,r,score;};std::vector<Choice>choices;
 array<I,4>fv,jv,rv;
 for(int m=1;m<basis.n;m++)if(basis.degree[m]==1){int ax=0;while(!basis.e[m][ax])ax++;
  // Any exact dyadic proposal is legitimate. Lower coefficient endpoints
  // are chosen only to propose multipliers, never as accepting estimates.
  fv[ax]=I(f.a[m].re.l);jv[ax]=I(use_J?domain_J.a[m].re.l:0);rv[ax]=I(use_R?domain_R.a[m].re.l:0);
 }
 auto add=[&](I ji,I ri){
  double jd=std::max(0.,ji.l),rd=std::max(0.,ri.l);
  if(!(std::isfinite(jd)&&std::isfinite(rd)&&(jd>0||rd>0)))return;
  I score;
  for(int k=0;k<4;k++)score=score+I(mag(fv[k]-I(jd)*jv[k]-I(rd)*rv[k]));
  choices.push_back({jd,rd,score.u});
 };
 I jj,rr,jr,fj,fr;
 for(int k=0;k<4;k++){
  if(jv[k].l!=0)add(fv[k]/jv[k],I(0));if(rv[k].l!=0)add(I(0),fv[k]/rv[k]);
  jj=jj+sq(jv[k]);rr=rr+sq(rv[k]);jr=jr+jv[k]*rv[k];fj=fj+fv[k]*jv[k];fr=fr+fv[k]*rv[k];
 }
 if(jj.l>0)add(fj/jj,I(0));if(rr.l>0)add(I(0),fr/rr);
 I determinant=jj*rr-sq(jr);
 if(determinant.l>0)add((fj*rr-fr*jr)/determinant,(fr*jj-fj*jr)/determinant);
 std::stable_sort(choices.begin(),choices.end(),[](const Choice&a,const Choice&b){return a.score<b.score;});
 for(int k=0;k<std::min(3,(int)choices.size());k++){
  const auto&c=choices[k];T shifted=f-domain_J*C(c.j)-domain_R*C(c.r);I v=plain_bound(shifted);
  // If constrained lower exceeds an unconstrained upper, the constrained
  // set is empty. Capping is conservative and never adds an acceptance.
  if(v.l>base.l)base=I(std::min(v.l,base.u),base.u);if(base.l>0)return base;
 }
 return base;
}

static bool positive_linear(const T&a,const T&b,const T&R,double*rec){
 I ar=domain_bound(a),br=domain_bound(b);I margin;int kind=0;
 if(ar.l>=0&&br.l>=0&&(ar.l>0||br.l>0)){kind=1;margin=I(0);}
 if(!kind && ar.l>0){
  T d=sq(a)-sq(b)*R; margin=domain_bound(d);if(margin.l>0)kind=2;
 }
 if(!kind && br.l>0){
  T d=sq(b)*R-sq(a);margin=domain_bound(d);if(margin.l>0)kind=3;
 }
 if(!kind)return false;
 rec[0]=kind;rec[1]=ar.l;rec[2]=ar.u;rec[3]=br.l;rec[4]=br.u;rec[5]=margin.l;rec[6]=margin.u;return true;
}
static int signs_excluded(const MeanPack&m,double*records){
 int mask=0;
 for(int sg=0;sg<2;sg++){
  int sigma=sg==0?1:-1;
  for(int k=0;k<3 && !(mask&(1<<sg));k++)for(int es=0;es<2;es++){
   int eps=es==0?1:-1;T a=m.A[k]*C(eps),b=m.B[k]*C(eps*sigma)-m.Delta*C(3);
   double rec[7];if(positive_linear(a,b,m.R,rec)){
    double*out=records+sg*9;out[0]=k;out[1]=eps;for(int j=0;j<7;j++)out[j+2]=rec[j];mask|=1<<sg;break;
   }
  }
 }
 return mask;
}

// Coherent-sign product test. All decisions below use outward intervals.
extern "C" int local_region(const double*input,double*output){try{
 if(!std::numeric_limits<double>::is_iec559||std::fegetround()!=FE_TONEAREST)return -9;
 volatile double normal=std::numeric_limits<double>::min(), half=.5;
 volatile double subnormal=std::numeric_limits<double>::denorm_min();
 if(!(normal*half>0) || !(subnormal+subnormal>subnormal))return -9;
 auto seed=tseed(input,input+16);MeanPack h=means(seed);I rr=h.R.range().re;
 output[0]=rr.l;output[1]=rr.u;
 use_J=false;use_R=false;output[52]=h.p.range().re.u;output[53]=0;
 if(rr.u<=0)return 1;
 use_R=true;domain_R=h.R-T(std::max(0.,rr.l));
 use_J=output[52]<1;output[53]=use_J?1:0;
 domain_J=use_J?h.j-T(std::max(0.,h.j.range().re.l)):T(0);
 
 // The same-row complementary corner requires R(p,J,W)>=R(p,-J,W).
 T bracket=sq(h.j)*C(4)+sq(h.p)*h.p*C(2)-sq(h.p)*C(24)-h.p*h.w*C(2)+h.p*C(54)+h.w*C(30);
 I comparison=fullbound(h.j*bracket*C(2));
 if(comparison.u<0){output[2]=comparison.l;output[3]=comparison.u;return 5;}
 int hm=signs_excluded(h,output+16);output[2]=hm;
 if(hm==3){output[3]=0;return 3;}
 std::swap(seed[1],seed[2]);MeanPack v=means(seed);
 int vm=signs_excluded(v,output+34);output[3]=vm;
 if(vm==3 || (rr.u<243 && ((hm&1)||(vm&2)) && ((hm&2)||(vm&1))))return 3;
 if(!(rr.u<243))return 0;
 // Eliminate the shared radical by multiplying by the two A coefficients.
 I dh=fullbound(h.Delta*C(3)),dv=fullbound(v.Delta*C(3));
 for(int i=0;i<3;i++)for(int j=0;j<3;j++){
  T H=v.A[j]*h.B[i]+h.A[i]*v.B[j];I hr=fullbound(H);
  I ah=fullbound(h.A[i]),av=fullbound(v.A[j]);
  I rhs=elimination_rhs(dh,dv,ah,av);
  if(hr.l>rhs.u || -hr.u>rhs.u){
   output[2]=i;output[3]=j;output[4]=0;output[5]=hr.l;output[6]=hr.u;output[7]=rhs.l;output[8]=rhs.u;return 4;
  }
  int sh=ah.l>0?1:ah.u<0?-1:0,sv=av.l>0?1:av.u<0?-1:0;
  if(sh && sv){
   int eh=H.a[0].re.l>=0?1:-1;
   T gap=H*C(eh)-h.Delta*v.A[j]*C(3*sv)-v.Delta*h.A[i]*C(3*sh);I gapr=domain_bound(gap);
   if(gapr.l>0){output[2]=i;output[3]=j;output[4]=1;output[5]=sh;output[6]=sv;output[7]=eh;output[8]=gapr.l;output[9]=gapr.u;return 4;}
  }
 }

 array<T,3>hh,vv;array<int,3>hs,vs;
 for(int i=0;i<3;i++){
  hs[i]=(h.B[i].a[0].re.l>=0)?1:-1;
  vs[i]=(v.B[i].a[0].re.l>=0)?1:-1;
  hh[i]=h.B[i]*C(hs[i])-h.Delta*C(3);
  vv[i]=v.B[i]*C(vs[i])-v.Delta*C(3);
 }
 double best=INF;array<I,4>scores={I(0),I(0),I(0),I(0)};
 for(int i=0;i<3;i++)for(int j=0;j<3;j++){
  I hr=domain_bound(hh[i]),vr=domain_bound(vv[j]);
  T ap=h.A[i]*v.A[j]*C(hs[i]*vs[j]);
  T G=ap+hh[i]*vv[j]*h.R;I gr=domain_bound(G);
  if(hr.l>0 && vr.l>0){
   I apr=domain_bound(ap),clippedR(std::max(0.,rr.l),rr.u);
   gr=intersect(gr,apr+hr*vr*clippedR);
  }
  if(hr.l>0 && vr.l>0 && gr.l>0){
   output[2]=i;output[3]=j;output[4]=hs[i];output[5]=vs[j];
   double *o=output+6;put(hr,o);put(vr,o);put(gr,o);return 2;
  }
  // Proposal only; even these scores are built with outward interval operations.
  double cent=G.a[0].re.l;
  if(cent>0){double relative=((I(gr.u)-I(gr.l))/I(cent)).u;if(relative<best){
   best=relative;scores={I(0),I(0),I(0),I(0)};
   for(int m=1;m<basis.n;m++)for(int a=0;a<4;a++)
    if(basis.e[m][a])scores[a]=scores[a]+I(mag(G.a[m].re))/I(cent);
  }}
 }
 for(int i=0;i<4;i++)output[12+i]=scores[i].u;return 0;
 }catch(const NativeBudget&){return -2;}catch(...){return -1;}}

// Independent exact-point implementation controls inspect these enclosures.
extern "C" int local_coefficients(const double*input,double*output){try{
 set_budget(0);auto seed=tseed(input,input+16);double*q=output;
 for(int tr=0;tr<2;tr++){
  MeanPack h=means(seed);put(h.R.range().re,q);put(h.Delta.range().re,q);
  for(int j=0;j<3;j++){put(h.A[j].range().re,q);put(h.B[j].range().re,q);}
  std::swap(seed[1],seed[2]);
 }
 return int(q-output);
 }catch(...){return -1;}}

extern "C" int control_exponents(int*out){int*q=out;for(int i=0;i<basis.n;i++)for(int x:basis.e[i])*q++=x;return basis.n;}
extern "C" int control_weights(double*out){double*q=out;for(const auto&row:bernstein_weights.weights)for(I x:row)put(x,q);return int(q-out);}
extern "C" int control_polynomial(int mode,double*out){set_budget(0);array<T,4>x;for(int i=0;i<4;i++){array<int,4>e={0,0,0,0};e[i]=1;int k=0;while(basis.e[k]!=e)k++;x[i].a[k]=C(1);}
 T v;if(mode==0)v=powu(T(1)+x[0],6);else if(mode==1)v=powu(x[0]+x[1],5);else if(mode==2){T z=x[0]+x[1]*ii;v=z*cj(z);}else if(mode==3)v=(T(1)+x[0])*(T(1)-x[0])*powu(T(1)+x[1],4);else {T a=powu(T(1)+x[0]-x[1],4),b=powu(T(1)+x[2]+x[3],3);v=a*b-b*a;}
 double*q=out;for(const C&a:v.a)put(a,q);put(v.error,q);return int(q-out);}
