# Exact 1/40 parent dispatch hold

This release adds a scheduling hold around the two stationary ring seeds.  It
does not add a numerical closure method, a new tree token, or a physical Lean
admission.  The supplied radius-1/40 claim is not used to close any box.

## Exact decision

`dispatch_hold.py` reads only four exact rational centers and radii.  It encloses
pi with the 64-term alternating Machin identity

```
pi = 16 atan(1/5) - 4 atan(1/239)
```

using `fractions.Fraction`.  For every coordinate and every relevant `2*pi`
lift it obtains a lower bound for the distance from the whole closed interval
to the lifted seed coordinate.  The source guard `|center| < 4`, `0 < radius <=
1` makes lifts -3 through 3 exhaustive; the two end lifts are checked to lie
strictly beyond the interval and every omitted lift is farther away.

A parent is runnable only when, for each of seeds 2442 and 4224, at least one
coordinate interval has lower distance strictly greater than `1/40`.  This is
equivalent to a rigorous lower bound greater than `1/40` for the circular sup
distance of every point in the parent.  Equality, overlap, malformed input, or
uncertainty returns `HOLD_PARENT_UNRESOLVED`.

The decision is made once for the original parent.  Every descendant is a
subset of that parent, so descendants of a runnable parent remain outside the
hold.  A held boundary-crossing parent is not split in this release.  Its
outside fragment remains transparently deferred together with its inside
fragment.

## Queue behavior

Every imported parent receives an immutable `DISPATCH.json` bound to its input,
source record, source tree, classifier source, and hold configuration.  A held
parent receives no descendant, whole-root, or replay-ready marker.  Its task
states, forests, evidence, attempt counters, source pins, and pending leaves are
unchanged.

Claims repeat the exact parent test under the existing task/parent locks.  A
stale marker therefore cannot start numerical evaluation.  Every descendant,
whole-root, and replay marker publisher also repeats the gate, and the final
replay entry point rejects held parents before initializing a numerical replay.
The idempotent

```
python -B task_queue.py mask --queue QUEUE
```

command writes all immutable parent ledgers first and removes only advisory
ready markers.  It must run to completion while the production failure/stop
guard remains held.  It writes `DISPATCH_HOLD_CENSUS.json` with the exact held
parent/task/pending-root census and a deterministic decision-chain digest.
The coordinator allocates from post-filter ready markers, not from the total
pending count, so held obligations do not create worker arrays.

Future finalized imports apply the same classifier before publishing markers.
Their immutable batch receipts separately count held parents, tasks, and
pending roots.  `dispatch_status()` combines the migration-time census with
later batch receipts without double counting.

## Reviewed 1/100 evidence ledger

The classifier also records whether the whole box lies in the reviewed
radius-1/100 numerical theorem at either seed.  This ledger matches the ring's
strict-D0 scope only when the pinned campaign hash matches.  The punctured
theorem and the seed fact `R=0` are separate fields.  The ledger never changes
the numerical forest and has `physical_lean_admissions = 0`.

The corrected theorem module, its whole-box geometry, independent replay/audit,
and analytic review are hash-pinned in `DISPATCH_HOLD.json`.  Under the project
Lean policy they remain reviewed numerical/analytic evidence until the physical
statement, cover, arithmetic, and source binding are kernel checked.

## Runtime upgrade boundary

`runtime.py`, numerical engines, worker search logic, schedule, budgets, cache
repair, checkpoints, and formal sources are unchanged from source
`2214dacc43cc`.  Production admission therefore needs a new explicitly scoped
metadata upgrade receipt that:

1. preserves the original runtime/migration bytes and exact failure guard in a
   recovery archive;
2. admits this release's full `PINS.json` digest and a passing validation receipt;
3. runs the exact mask under exclusive runtime/coordinator/import locks while
   the guard remains held;
4. verifies the census, zero held ready markers, unchanged checkpoint hashes,
   unchanged schedule/legacy replay pins, and runtime admission;
5. clears only the already authorized guard after metadata and mask receipts
   commit; and
6. leaves any later stop or failure guard in place.

The earlier cache-only helper is not valid for this larger source delta and
must not be relabeled or reused unchanged.

## Controls

Full cluster validation inherits the hash-pinned 2214 validation receipt only
for byte-identical engines, providers, worker, cache, schedule, runtime, and
formal sources.  It reruns the queue and safety suites, then uses the real
worker and replay paths only on parents whose entire exact box is strictly
outside both hold balls.  Current and legacy checkpoint replay samples skip
held parents before provider initialization.  The saved benchmark applies the
same exact filter before evaluation and reports the held rows; it no longer
claims that all 48 historical rows were replayed.

`dispatch_hold_tests.py` covers rational pi bounds, both seeds, periodic lifts,
closed boundary, crossing faces, whole-box outside witnesses, descendant
containment, the seed, the separate `R=0` ledger component, exact-input
rejection, future imports, stale ready markers, all marker publishers, the final
replay entry point, census reporting, campaign scope, and byte preservation of
task checkpoints and parent sources.
The inherited queue, v2 queue, migration, supervisor, cutover, cache, safety,
audit, and combine suites remain part of full release validation.
