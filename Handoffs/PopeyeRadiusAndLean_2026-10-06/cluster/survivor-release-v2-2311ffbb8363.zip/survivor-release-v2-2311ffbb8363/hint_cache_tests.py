"""Optional cache corruption/contention cannot accept evidence or stop search."""
from fractions import Fraction as Q
from pathlib import Path
import fcntl
import multiprocessing
import tempfile
import unittest
from unittest.mock import patch

import reuse_store as reuse
import task_queue as tq


def recipe(n=0):
    return {"method": "order3", "input": {
        "centers": [str(Q(1) + Q(n, 8192))] * 4,
        "radii": ["1/16"] * 4, "units": "radians"},
        "provider_hashes": {"fixture": "a" * 64}}


def concurrent_cache(area, writer, rounds):
    hints = reuse.CertificateHints(area)
    for n in range(rounds):
        if writer:
            hints.last_write = float("-inf")
            hints.add(recipe(n))
        else:
            hints.last_read.clear()
            target = recipe(n)["input"]
            proposals = hints.candidates(target, {"order3"}, 2)
            if any(not reuse.contains(p["input"], target) for p in proposals):
                raise AssertionError("Cache returned a noncontaining proposal")


class HintCacheTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.area = Path(self.temp.name)

    def tearDown(self):
        self.temp.cleanup()

    def directory(self, hints):
        return hints._directory(reuse._bucket(recipe()["input"]), create=True)

    def test_legacy_malformed_database_is_preserved_and_ignored(self):
        hints = reuse.CertificateHints(self.area)
        hints.place.mkdir()
        old = hints.place / ("%02x.sqlite" % reuse._bucket(recipe()["input"]))
        old.write_bytes(b"not a SQLite database\x00")
        self.assertEqual(hints.candidates(recipe()["input"], {"order3"}), [])
        hints.add(recipe())
        reader = reuse.CertificateHints(self.area)
        self.assertTrue(reader.candidates(recipe()["input"], {"order3"}))
        self.assertEqual(old.read_bytes(), b"not a SQLite database\x00")

    def test_truncated_oversized_wrong_digest_and_temporary_records_are_misses(self):
        hints = reuse.CertificateHints(self.area)
        directory = self.directory(hints)
        (directory / ("0" * 64 + ".json")).write_text('{"input":')
        (directory / ("1" * 64 + ".json")).write_bytes(b"x" * (reuse.MAX_HINT_BYTES + 2))
        (directory / ("2" * 64 + ".json")).write_text('{}')
        (directory / ("3" * 64 + ".json.dead.tmp")).write_text('incomplete')
        self.assertEqual(hints.candidates(recipe()["input"], {"order3"}), [])
        self.assertFalse(hints.local)

    def test_content_digest_is_checked_before_proposing(self):
        hints = reuse.CertificateHints(self.area)
        directory = self.directory(hints)
        value = {**recipe(), "recipe_sha256": tq.digest(recipe())}
        tq.durable_json(directory / ("f" * 64 + ".json"), value)
        self.assertEqual(hints.candidates(recipe()["input"], {"order3"}), [])
        hints.last_read.clear()
        tq.durable_json(directory / (tq.digest(value) + ".json"), value)
        self.assertTrue(hints.candidates(recipe()["input"], {"order3"}))

    def test_busy_writer_keeps_local_hint_without_blocking(self):
        hints = reuse.CertificateHints(self.area)
        directory = self.directory(hints)
        with (directory / "WRITE.lock").open("a") as lock:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            hints.add(recipe())
            self.assertTrue(hints.candidates(recipe()["input"], {"order3"}))
            self.assertEqual(list(directory.glob("*.json")), [])

    def test_optional_storage_failure_keeps_local_hint(self):
        hints = reuse.CertificateHints(self.area)
        with patch.object(reuse.tq, "durable_json", side_effect=OSError("cache IO")):
            hints.add(recipe())
        self.assertTrue(hints.candidates(recipe()["input"], {"order3"}))

    def test_resource_stop_is_never_caught_by_cache(self):
        hints = reuse.CertificateHints(self.area)
        with patch.object(reuse.tq, "durable_json", side_effect=tq.ResourceStop("disk_reserve_8GiB")):
            with self.assertRaises(tq.ResourceStop):
                hints.add(recipe())

    def test_method_filter_and_containment_are_preserved(self):
        writer = reuse.CertificateHints(self.area)
        writer.add(recipe())
        reader = reuse.CertificateHints(self.area)
        self.assertEqual(reader.candidates(recipe()["input"], {"unknown"}), [])
        target = {**recipe()["input"], "centers": ["3"] * 4}
        self.assertEqual(reader.candidates(target, {"order3"}), [])

    def test_shared_storage_and_process_local_rows_are_bounded(self):
        hints = reuse.CertificateHints(self.area)
        for n in range(reuse.CACHE_ROWS + 4):
            hints.last_write = float("-inf")
            hints.add(recipe(n))
        directory = self.directory(hints)
        self.assertEqual(len(list(directory.glob("*.json"))), reuse.CACHE_ROWS)
        self.assertEqual(len(hints.local), 128)

    def test_concurrent_atomic_readers_and_writers(self):
        ctx = multiprocessing.get_context("spawn")
        children = [ctx.Process(target=concurrent_cache, args=(str(self.area), write, 48))
                    for write in (True, True, False, False)]
        try:
            for child in children:
                child.start()
            for child in children:
                child.join(timeout=60)
                self.assertEqual(child.exitcode, 0)
        finally:
            for child in children:
                if child.is_alive():
                    child.terminate()
                    child.join(timeout=10)


if __name__ == "__main__":
    unittest.main()
