"""Synthetic-only final replay/cache/summary protocol regressions.

These tests perform no numerical acceptance and do not bypass a numerical
resource guard. They use the queue's synthetic provider and tiny source fixture.
"""
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import collections
import gzip
import hashlib
import json
import os
import sqlite3
import tempfile
import time
import unittest

import audit_worker as audit
import queue_tests as fixtures
import task_queue as tq
import worker


class FakeRuntime(audit.ReplayRuntime):
    def __init__(self, root, *args):
        self.root = Path(root)
        self.config_path = self.root / "production/CONFIG.json"
        self.config = tq.read_json(self.config_path)
        self.config_sha = tq.sha_file(self.config_path)
        self.frozen_pins = {"production_config_sha256":self.config_sha}
        self.new_manifest = {"provider_hashes":{"order3":{"binary_sha256":"c"*64}}}
        self.old = SimpleNamespace(guard=lambda:None)
        self.leaf_seconds = 30
        self.batch_cache = collections.OrderedDict()
        self.source_db = sqlite3.connect((self.root / "campaign/full_ring.sqlite").resolve().as_uri()+"?mode=ro&immutable=1",uri=True)
        self.fail_budget = False
        self.old_calls = self.new_calls = 0
        self.reset(time.process_time()+600)

    def old_leaf(self, token, centers, radii):
        self.old_calls += 1
        if self.fail_budget:
            raise audit.AuditBudget("parent_cpu_budget")
        self.counts[token] += 1
        self.chain.update(token.encode())
        return {"status":"PASS","physical_lean_admissions":0}

    def new_leaf(self, recipe):
        self.new_calls += 1
        if recipe["provider_hashes"]!=self.new_manifest["provider_hashes"][recipe["method"]]:
            raise ValueError("Synthetic dependent provider pins differ")
        result = fixtures.GoodProvider.replay_recipe(recipe)
        self.counts[recipe["method"]] += 1
        self.new_provider_pins[recipe["method"]] = result["provider_hashes"]
        self.chain.update(result["evidence_sha256"].encode())
        return result


class AuditTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="mub6-final-audit-test-")
        self.base = Path(self.temp.name)
        self.root, self.area = self.base / "source",self.base / "queue"
        fixtures.fixture(self.root,"0LP")
        tq.durable_json(self.root / "elastic-run/PLAN.json",{"batches":[{"batch":0}]})
        self.queue = tq.TaskQueue(self.area)
        self.queue.import_finalized(self.root,16)
        lease = self.queue.claim("synthetic-worker")
        worker.process_lease(lease,fixtures.schedule(),self.root,provider=fixtures.GoodProvider)
        self.key = next(self.queue.iter_parent_keys())
        self.runtime = FakeRuntime(self.root)

    def tearDown(self):
        self.runtime.source_db.close()
        self.temp.cleanup()

    def test_both_old_and_new_leaves_replay_then_matching_receipt_reuses(self):
        result = audit.audit_one(self.queue,self.key,self.runtime,600)
        self.assertEqual((result["status"],result["closed"]),("PASS",True))
        self.assertEqual((self.runtime.old_calls,self.runtime.new_calls),(1,1))
        reused = audit.audit_one(self.queue,self.key,self.runtime,600)
        self.assertTrue(reused["reused_unchanged_receipt"])
        self.assertEqual((self.runtime.old_calls,self.runtime.new_calls),(1,1))
        self.assertEqual(result["replayed_leaves"],{"L":1,"order3":1})

    def test_changed_dependent_provider_cannot_reuse_a_previous_pass(self):
        first = audit.audit_one(self.queue,self.key,self.runtime,600)
        self.runtime.new_manifest["provider_hashes"]["order3"]["binary_sha256"]="d"*64
        with self.assertRaisesRegex(ValueError,"dependent provider"):
            audit.audit_one(self.queue,self.key,self.runtime,600)
        current = tq.read_json(self.queue.parent_dir(self.key) / "FINAL_REPLAY.json")
        self.assertEqual((current["status"],current["closed"]),("FAIL",False))
        self.assertTrue((self.queue.parent_dir(self.key) / "final_replays" / (first["receipt_sha256"]+".json")).exists())

    def test_budget_failure_reuses_only_same_or_smaller_attempt_budget(self):
        self.runtime.fail_budget = True
        result = audit.audit_one(self.queue,self.key,self.runtime,600)
        self.assertEqual((result["status"],result["closed"]),("UNRESOLVED",False))
        again = audit.audit_one(self.queue,self.key,self.runtime,600)
        self.assertTrue(again["reused_unchanged_budget_result"])
        self.assertEqual(self.runtime.old_calls,1)
        larger = audit.audit_one(self.queue,self.key,self.runtime,3600)
        self.assertEqual(larger["attempted_parent_cpu_seconds"],3600)
        self.assertEqual(self.runtime.old_calls,2)

    def test_source_cache_rejects_changed_packet_identity(self):
        self.runtime.verify_parent_source(self.queue,self.key)
        path = self.root / "production/batches/000/000000.json.gz"
        stat = path.stat()
        os.utime(path,ns=(stat.st_atime_ns,stat.st_mtime_ns+1000000))
        with self.assertRaisesRegex(ValueError,"identity"):
            self.runtime.verify_parent_source(self.queue,self.key)

    def test_source_cache_rejects_rehashed_nonmember_source_record(self):
        self.runtime.verify_parent_source(self.queue,self.key)
        path = self.queue.parent_dir(self.key) / "SOURCE.json.gz"
        parent = tq.read_json(path)
        parent["source_record"]["reason"]="altered_history"
        parent["source_record_sha256"]=tq.digest(parent["source_record"])
        tq.durable_json(path,parent)
        with self.assertRaisesRegex(ValueError,"packet member"):
            self.runtime.verify_parent_source(self.queue,self.key)

    def test_summary_streams_only_current_fresh_pass_ids(self):
        receipt = audit.audit_one(self.queue,self.key,self.runtime,600)
        with patch.object(audit,"ReplayRuntime",return_value=self.runtime):
            result = audit.summarize(self.queue,self.root,self.base / "unused-cache")
        self.assertEqual(result["original_roots_closed"],1)
        self.assertEqual(result["original_roots_incomplete"],0)
        ledger = self.area / result["closed_native_ids"]["path"]
        self.assertEqual(tq.sha_file(ledger),result["closed_native_ids"]["sha256"])
        with gzip.open(ledger,"rt") as stream:
            rows = [json.loads(line) for line in stream]
        self.assertEqual(rows,[{"id":0,"parent_key":self.key,"receipt_sha256":receipt["receipt_sha256"]}])
        self.runtime.new_manifest["provider_hashes"]["order3"]["binary_sha256"]="d"*64
        with patch.object(audit,"ReplayRuntime",return_value=self.runtime):
            changed = audit.summarize(self.queue,self.root,self.base / "unused-cache")
        self.assertEqual(changed["original_roots_closed"],0)
        self.assertEqual(changed["candidate_roots_without_replay"],1)
        self.assertEqual(changed["closed_native_ids"]["count"],0)


if __name__=="__main__":
    unittest.main()
