"""Exact parent-level dispatch hold for the two stationary ring seeds.

This module changes scheduling only.  A HOLD result preserves the original
parent, forests, certificates, attempts, and formal obligation.  It never emits
an accepted tree token and never supplies mathematical or Lean proof credit.
"""
from __future__ import annotations

from fractions import Fraction as Q
from pathlib import Path
import hashlib
import json


CONFIG_PATH = Path(__file__).with_name("DISPATCH_HOLD.json")
CONFIG_RAW = CONFIG_PATH.read_bytes()
CONFIG_SHA256 = hashlib.sha256(CONFIG_RAW).hexdigest()
SOURCE_SHA256 = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
CONFIG = json.loads(CONFIG_RAW)


def _require_config():
    if (CONFIG.get("schema") != "popeye-ring-dispatch-hold-v1"
            or CONFIG.get("status") != "SCHEDULING_HOLD_ONLY"
            or CONFIG.get("hold_radius_radians") != "1/40"
            or CONFIG.get("boundary_policy") != "HOLD"
            or CONFIG.get("closure_credit") is not False
            or CONFIG.get("changes_tree_tokens") is not False
            or CONFIG.get("changes_task_states") is not False
            or CONFIG.get("class_0024_pruning") is not False
            or CONFIG.get("physical_lean_admissions") != 0):
        raise ValueError("Dispatch-hold policy changed")
    expected = {"2442": ["2/3", "-2/3", "-2/3", "2/3"],
                "4224": ["-2/3", "2/3", "2/3", "-2/3"]}
    if CONFIG.get("stationary_seeds_pi_coefficients") != expected:
        raise ValueError("Dispatch-hold seeds changed")
    enclosure = CONFIG.get("pi_enclosure", {})
    if enclosure.get("identity") != "pi = 16*atan(1/5) - 4*atan(1/239)" or enclosure.get("alternating_terms") != 64:
        raise ValueError("Dispatch-hold pi enclosure changed")
    theorem = CONFIG.get("reviewed_numerical_theorem", {})
    if (theorem.get("radius_radians") != "1/100"
            or theorem.get("admission") != "REVIEWED_NUMERICAL_EVIDENCE_ONLY"):
        raise ValueError("Reviewed numerical theorem metadata changed")


_require_config()
HOLD_RADIUS = Q(CONFIG["hold_radius_radians"])
THEOREM_RADIUS = Q(CONFIG["reviewed_numerical_theorem"]["radius_radians"])
SEEDS = {name: tuple(map(Q, values))
         for name, values in CONFIG["stationary_seeds_pi_coefficients"].items()}


def _atan_inverse_bounds(denominator, terms):
    """Alternating-series enclosure of atan(1/denominator)."""
    if type(denominator) is not int or denominator <= 1 or type(terms) is not int or terms < 1:
        raise ValueError("Invalid rational atan enclosure")
    partial = sum((Q((-1) ** k, (2 * k + 1) * denominator ** (2 * k + 1))
                   for k in range(terms)), Q(0))
    next_term = Q((-1) ** terms, (2 * terms + 1) * denominator ** (2 * terms + 1))
    return min(partial, partial + next_term), max(partial, partial + next_term)


def pi_bounds():
    terms = CONFIG["pi_enclosure"]["alternating_terms"]
    a_lo, a_hi = _atan_inverse_bounds(5, terms)
    b_lo, b_hi = _atan_inverse_bounds(239, terms)
    return 16 * a_lo - 4 * b_hi, 16 * a_hi - 4 * b_lo


PI_LO, PI_HI = pi_bounds()
if not Q(314159, 100000) < PI_LO < PI_HI < Q(314160, 100000):
    raise ValueError("Rational pi enclosure failed its exact control")


def _rational_vector(row):
    if type(row) is not dict:
        raise ValueError("Parent box must be an object")
    centers, radii = row.get("centers"), row.get("radii")
    if (type(centers) is not list or type(radii) is not list
            or len(centers) != 4 or len(radii) != 4
            or any(type(x) is not str for x in centers + radii)):
        raise ValueError("Parent coordinates require four exact rational strings")
    centers, radii = list(map(Q, centers)), list(map(Q, radii))
    if any(abs(x) >= 4 for x in centers) or any(not (0 < x <= 1) for x in radii):
        raise ValueError("Parent is outside the frozen ring source domain")
    return centers, radii


def _scale_pi(coefficient):
    values = coefficient * PI_LO, coefficient * PI_HI
    return min(values), max(values)


def _alias(seed_coefficient, lift):
    if type(lift) is not int:
        raise ValueError("Circular lift must be integral")
    return _scale_pi(seed_coefficient + 2 * lift)


def _gap(interval, target):
    lo, hi = interval
    target_lo, target_hi = target
    if hi < target_lo:
        return target_lo - hi
    if lo > target_hi:
        return lo - target_hi
    return Q(0)


def _coordinate_metrics(lo, hi, seed_coefficient):
    """Safe lower/upper circular distances for one exact interval.

    The frozen source guard gives -5 <= lo <= hi <= 5.  The lift -3 lies
    strictly to its left and lift +3 strictly to its right.  All omitted lifts
    are still farther away because 2*pi is positive.  Thus lifts -3..3 give a
    complete circular lower-distance check, not a center-only heuristic.
    """
    if not Q(-5) <= lo <= hi <= Q(5):
        raise ValueError("Box interval exceeds the frozen guarded domain")
    left_tail, right_tail = _alias(seed_coefficient, -3), _alias(seed_coefficient, 3)
    if not left_tail[1] < lo or not right_tail[0] > hi:
        raise ValueError("Finite circular-lift guard is insufficient")
    aliases = [_alias(seed_coefficient, k) for k in range(-3, 4)]
    lower = min(_gap((lo, hi), target) for target in aliases)
    upper_candidates = []
    for target_lo, target_hi in aliases:
        upper_candidates.append(max(abs(lo - target_lo), abs(lo - target_hi),
                                    abs(hi - target_lo), abs(hi - target_hi)))
    upper = min(upper_candidates)
    contains_seed = any(lo <= target_lo and target_hi <= hi for target_lo, target_hi in aliases)
    return {"lower": lower, "upper": upper, "contains_seed_for_all_pi_in_enclosure": contains_seed}


def _seed_metrics(centers, radii, label, coefficients):
    coordinates = [_coordinate_metrics(c - r, c + r, coefficient)
                   for c, r, coefficient in zip(centers, radii, coefficients)]
    lower_sup = max(item["lower"] for item in coordinates)
    upper_sup = max(item["upper"] for item in coordinates)
    witness = max(range(4), key=lambda j: coordinates[j]["lower"])
    seed_contained = all(item["contains_seed_for_all_pi_in_enclosure"] for item in coordinates)
    return {
        "seed": label,
        "lower_circular_sup_distance": str(lower_sup),
        "upper_circular_sup_distance": str(upper_sup),
        "strictly_outside_closed_hold": lower_sup > HOLD_RADIUS,
        "outside_witness_coordinate": witness,
        "whole_box_inside_reviewed_1_100_ball": upper_sup <= THEOREM_RADIUS,
        "puncture_separated": lower_sup > 0,
        "seed_point_guaranteed_in_box": seed_contained,
    }


def classify(row):
    """Return a deterministic exact dispatch and numerical-evidence ledger."""
    centers, radii = _rational_vector(row)
    metrics = [_seed_metrics(centers, radii, label, coefficients)
               for label, coefficients in SEEDS.items()]
    runnable = all(item["strictly_outside_closed_hold"] for item in metrics)
    covered = [item for item in metrics if item["whole_box_inside_reviewed_1_100_ball"]]
    theorem = {
        "status": "REVIEWED_NUMERICAL_EVIDENCE_ONLY" if covered else "NOT_WHOLE_BOX_COVERED",
        "radius_radians": str(THEOREM_RADIUS),
        "covered_seeds": [item["seed"] for item in covered],
        "whole_box_interface_accepts": any(item["puncture_separated"] for item in covered),
        "punctured_ball_statement": bool(covered),
        "seed_point_R_zero_separate": bool(covered),
        "changes_numerical_tree": False,
        "physical_lean_admissions": 0,
    }
    return {
        "schema": "exact-parent-dispatch-classification-v1",
        "dispatch": "RUN_WHOLE_PARENT_STRICTLY_OUTSIDE_HOLD" if runnable else "HOLD_PARENT_UNRESOLVED",
        "reason": ("whole_closed_parent_strictly_outside_both_closed_1_40_balls" if runnable
                   else "intersects_touches_or_is_not_certified_outside_a_closed_1_40_ball"),
        "hold_radius_radians": str(HOLD_RADIUS),
        "boundary_policy": "HOLD",
        "whole_parent_policy": True,
        "seed_relations": metrics,
        "reviewed_numerical_theorem": theorem,
        "hold_config_sha256": CONFIG_SHA256,
        "closure_credit": False,
        "changes_tree_tokens": False,
        "changes_task_states": False,
        "class_0024_pruning": False,
        "physical_lean_admissions": 0,
    }


def is_runnable(row):
    return classify(row)["dispatch"] == "RUN_WHOLE_PARENT_STRICTLY_OUTSIDE_HOLD"
