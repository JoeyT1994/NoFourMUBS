"""Synthetic stopped-checkpoint migration and pristine bootstrap controls."""
from pathlib import Path
from fractions import Fraction as Q
import fcntl
import json
import sqlite3
import tempfile
import unittest
from unittest.mock import patch

import bootstrap
import migrate
import queue_tests as fixtures
import runtime
import task_queue as tq
import worker


class MigrationTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix="mub6-migration-test-")
        self.base=Path(self.temp.name)
        self.root,self.area=self.base/"source",self.base/"queue"
        fixtures.fixture(self.root,"0L"+fixtures.full_tree(5))
        self.queue=tq.TaskQueue(self.area)
        self.queue.import_finalized(self.root,16)
        self.old,self.new=self.base/"old",self.base/"new"
        self.old.mkdir();self.new.mkdir()
        for folder, text in ((self.old,"old synthetic source"),(self.new,"new synthetic source")):
            (folder/"engines.py").write_text(text)
            tq.durable_json(folder/"SCHEDULE.json",{"methods":[{"method":"order3","cpu_seconds":1}],"max_task_attempts":3})
            tq.durable_json(folder/"PINS.json",{name:tq.sha_file(folder/name) for name in ("engines.py","SCHEDULE.json")})
        self.old_sha=tq.digest(tq.read_json(self.old/"PINS.json"))
        self.new_sha=tq.digest(tq.read_json(self.new/"PINS.json"))
        self.schedule_path=self.new/"SCHEDULE.json"
        self.schedule_sha=tq.digest(worker.load_schedule(self.schedule_path))
        self.stop={"schema":"survivor-cutover-stop-v2","old_release_sha256":self.old_sha,
                   "coordinator_stopped":True,"workers_stopped":True,"source_workers_untouched":True,
                   "obsolete_jobs":[{"job_id":"123","state":"ABSENT"},{"job_id":"124","state":"CANCELLED"}]}
        tq.durable_json(self.area/"LAUNCH.json",{"source":str(self.old),"source_sha256":self.old_sha})
        tq.durable_json(self.area/"VALIDATION_PASS.json",{"source_sha256":self.old_sha,"status":"PASS"})
        tq.durable_json(self.area/"submissions/node-0.json",{"source":str(self.old),"job_id":"124","token":"synthetic"})

    def tearDown(self):
        self.temp.cleanup()

    def run_migration(self,fault=None):
        return migrate.migrate(self.queue,self.old,self.new,self.schedule_path,self.stop,fault)

    def partial_running(self):
        lease=self.queue.claim("old-worker",schedule_sha256="e"*64)
        initial=lease.task["roots"][0]
        cc,rr=list(map(Q,initial["centers"])),list(map(Q,initial["radii"]))
        record=fixtures.GoodProvider.evaluate(cc,rr,"order3",1)
        proof=lease.install_proof(initial["prefix"],cc,rr,record,fixtures.GoodProvider.replay(record))
        lease.state["roots"][0]["tree"]="C"
        lease.state["proofs"][initial["prefix"]]=proof
        other=lease.task["roots"][1]
        lease.state["attempts"]=2
        lease.state["cursor"]={"prefix":other["prefix"],"path":other["prefix"],"method_index":1,"axis":2,"available_seen":True}
        lease.checkpoint()
        before=tq.read_json(lease.directory/"STATE.json.gz")
        lease.close()  # Simulates vanished old process; durable token is stale.
        return lease.directory,before

    def test_migration_preserves_c_and_exact_cursor_forest_while_changing_explicit_stage(self):
        directory,before=self.partial_running()
        receipt=self.run_migration()
        after=tq.read_json(directory/"STATE.json.gz")
        self.assertEqual(migrate._preserved(before),migrate._preserved(after))
        self.assertEqual((after["status"],after["attempts"],after["schedule_sha256"]),("queued",0,self.schedule_sha))
        self.assertEqual(after["cursor"]["path"],before["cursor"]["path"])
        self.assertEqual(after["cursor"]["method_index"],0)
        self.assertEqual(after["stage_history"][0]["cursor"],before["cursor"])
        self.assertEqual(tq.read_json(directory/"LEASE.json")["expires_unix"],0)
        self.assertEqual(receipt["status"],"COMMITTED")
        self.assertFalse((self.area/"LAUNCH.json").exists())
        self.assertTrue((Path(receipt["operational_archive"])/"LAUNCH.json").exists())
        with runtime.RuntimeLease(self.queue,self.new,self.schedule_sha) as active:
            self.assertEqual(active.engine_kwargs()["legacy_source"],self.old.resolve())
            self.assertEqual(active.engine_kwargs()["legacy_pins"],tq.read_json(self.old/"PINS.json"))
        journal=sqlite3.connect(self.area/"migrations"/receipt["migration_id"]/"TASK_JOURNAL.sqlite")
        try:
            payload=journal.execute("SELECT after_payload FROM tasks WHERE task_id=?",(directory.name,)).fetchone()[0]
            self.assertNotIn("proof_records",payload)
            self.assertLess(len(payload),65536)
        finally:
            journal.close()

    def test_done_and_parked_states_and_leases_stay_byte_unchanged(self):
        done=self.queue.claim("done")
        worker.process_lease(done,fixtures.schedule(),self.root,provider=fixtures.GoodProvider)
        parked=self.queue.claim("guarded")
        parked.release(reason="task_evidence_size_guard",parked=True)
        before={p.name:(tq.sha_file(p/"STATE.json.gz"),tq.sha_file(p/"LEASE.json")) for p in self.queue.iter_task_dirs()}
        receipt=self.run_migration()
        self.assertEqual(before,{p.name:(tq.sha_file(p/"STATE.json.gz"),tq.sha_file(p/"LEASE.json")) for p in self.queue.iter_task_dirs()})
        self.assertEqual(receipt["old_status_counts"],{"done":1,"parked":1})
        self.assertIsNone(self.queue.claim("retry-parked",schedule_sha256=self.schedule_sha))
        self.assertEqual(list(self.queue.iter_parent_markers("root_ready")),[])

    def test_live_task_node_or_runtime_lock_blocks_without_mutation(self):
        directory,before=self.partial_running()
        for path in (directory/"RUN.lock",self.area/"nodes/node/RUN.lock",self.area/"COORDINATOR.lock",self.area/"RUNTIME.lock"):
            path.parent.mkdir(parents=True,exist_ok=True)
            with path.open("a") as lock:
                fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
                with self.assertRaisesRegex(ValueError,"live lock"):
                    self.run_migration()
            self.assertEqual(before,tq.read_json(directory/"STATE.json.gz"))
        self.assertFalse((self.area/"RUNTIME.json").exists())

    def test_running_job_omitted_submission_or_ambiguous_receipt_is_rejected(self):
        bad=dict(self.stop,obsolete_jobs=[{"job_id":"123","state":"RUNNING"}])
        with self.assertRaisesRegex(ValueError,"live"):
            migrate.migrate(self.queue,self.old,self.new,self.schedule_path,bad)
        bad=dict(self.stop,obsolete_jobs=[{"job_id":"123","state":"ABSENT"}])
        with self.assertRaisesRegex(ValueError,"omitted"):
            migrate.migrate(self.queue,self.old,self.new,self.schedule_path,bad)
        tq.durable_json(self.area/"submissions/node-0.json",{"token":"unknown","source":str(self.old)})
        with self.assertRaisesRegex(ValueError,"Ambiguous"):
            self.run_migration()

    def test_existing_stop_failure_and_changed_release_pins_are_never_overridden(self):
        for name in ("FAILURE.json","STOP_REQUESTED.json"):
            tq.durable_json(self.area/name,{"reason":"do_not_override"})
            with self.assertRaisesRegex(ValueError,"override"):
                self.run_migration()
            (self.area/name).unlink()
        (self.old/"engines.py").write_text("altered")
        with self.assertRaisesRegex(ValueError,"Pinned release changed"):
            self.run_migration()

    def test_interrupted_intent_and_state_recover_exactly_once(self):
        directory,before=self.partial_running()
        for phase in ("intent","state"):
            fired=[]
            def fault(where,ident):
                if where==phase and not fired:
                    fired.append(True)
                    raise RuntimeError("synthetic interrupted "+phase)
            with self.assertRaisesRegex(RuntimeError,"interrupted"):
                self.run_migration(fault)
            self.assertFalse((self.area/"RUNTIME.json").exists())
        receipt=self.run_migration()
        after=tq.read_json(directory/"STATE.json.gz")
        self.assertEqual(migrate._preserved(before),migrate._preserved(after))
        self.assertEqual(len(after["stage_history"]),1)
        again=self.run_migration()
        self.assertEqual(again,receipt)
        self.assertEqual(after,tq.read_json(directory/"STATE.json.gz"))

    def test_interruption_after_operational_archive_recovers_submissions(self):
        original=migrate._archive_operations
        def fail_after(queue,archive):
            original(queue,archive)
            raise RuntimeError("after archive")
        with patch.object(migrate,"_archive_operations",side_effect=fail_after):
            with self.assertRaisesRegex(RuntimeError,"after archive"):
                self.run_migration()
        self.assertFalse((self.area/"submissions").exists())
        receipt=self.run_migration()
        self.assertTrue((Path(receipt["operational_archive"])/"submissions/node-0.json").exists())
        self.assertEqual(self.run_migration(),receipt)

    def test_committed_receipt_without_runtime_recovers_without_journal_rewrite(self):
        with patch.object(migrate,"publish_runtime",side_effect=RuntimeError("before runtime")):
            with self.assertRaisesRegex(RuntimeError,"before runtime"):
                self.run_migration()
        receipt=tq.read_json(self.area/"MIGRATION.json")
        journal=self.area/"migrations"/receipt["migration_id"]/"TASK_JOURNAL.sqlite"
        journal_sha=tq.sha_file(journal)
        self.assertFalse((self.area/"RUNTIME.json").exists())
        self.assertEqual(self.run_migration(),receipt)
        self.assertEqual(tq.sha_file(journal),journal_sha)
        self.assertTrue((self.area/"RUNTIME.json").exists())

    def test_completed_old_parents_seed_incremental_fresh_audit(self):
        while (lease:=self.queue.claim("old-done")) is not None:
            worker.process_lease(lease,fixtures.schedule(),self.root,provider=fixtures.GoodProvider)
        key=next(self.queue.iter_parent_keys())
        self.queue.parent_marker("replay_ready",key).unlink()
        (self.queue.parent_dir(key)/"COMPLETION.sqlite").unlink()
        self.run_migration()
        self.assertEqual(list(self.queue.iter_parent_markers("replay_ready")),[key])

    def test_pristine_bootstrap_cannot_admit_existing_v1_launch_or_attempted_state(self):
        with self.assertRaisesRegex(ValueError,"bootstrap"):
            bootstrap.bootstrap(self.queue,self.new,self.schedule_path)
        (self.area/"LAUNCH.json").unlink()
        directory,before=self.partial_running()
        with self.assertRaisesRegex(ValueError,"Historical queue"):
            bootstrap.bootstrap(self.queue,self.new,self.schedule_path)
        self.assertFalse((self.area/"RUNTIME.json").exists())

    def test_pristine_bootstrap_idempotence_and_runtime_schedule_pin(self):
        (self.area/"LAUNCH.json").unlink()
        receipt=bootstrap.bootstrap(self.queue,self.new,self.schedule_path)
        self.assertEqual(bootstrap.bootstrap(self.queue,self.new,self.schedule_path),receipt)
        with runtime.RuntimeLease(self.queue,self.new,self.schedule_sha) as active:
            self.assertEqual(active.engine_kwargs(),{})
        with self.assertRaisesRegex(ValueError,"schedule"):
            runtime.RuntimeLease(self.queue,self.new,"f"*64)
        with self.assertRaisesRegex(ValueError,"release differs"):
            runtime.RuntimeLease(self.queue,self.old,self.schedule_sha)

    def test_partial_bootstrap_receipt_without_runtime_can_recover(self):
        (self.area/"LAUNCH.json").unlink()
        original=tq.immutable_json
        def fail_runtime(path,value):
            if Path(path).name=="RUNTIME.json":
                raise RuntimeError("bootstrap interrupted")
            return original(path,value)
        with patch.object(tq,"immutable_json",side_effect=fail_runtime):
            with self.assertRaisesRegex(RuntimeError,"bootstrap interrupted"):
                bootstrap.bootstrap(self.queue,self.new,self.schedule_path)
        self.assertTrue((self.area/"MIGRATION.json").exists())
        self.assertFalse((self.area/"RUNTIME.json").exists())
        receipt=bootstrap.bootstrap(self.queue,self.new,self.schedule_path)
        self.assertEqual(receipt,tq.read_json(self.area/"MIGRATION.json"))


if __name__=="__main__":
    unittest.main(verbosity=2)
