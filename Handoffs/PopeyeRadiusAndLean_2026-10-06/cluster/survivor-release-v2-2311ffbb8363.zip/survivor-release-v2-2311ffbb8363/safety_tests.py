"""Synthetic safety enumeration, polling freshness, and stop policy controls."""
from collections import Counter
from contextlib import contextmanager
from pathlib import Path
from types import SimpleNamespace
import errno
import hashlib
import json
import os
import shutil
import stat
import subprocess
import sys
import tempfile
import time
import unittest
import uuid
from unittest.mock import patch

import audit_worker as audit
import node_safety_cache as cache
import safety_paths as safety
import worker


class Clock:
    def __init__(self):
        self.now = 0.0

    def __call__(self):
        return self.now


class Entries:
    def __init__(self, names):
        self.names = names

    def __enter__(self):
        return (SimpleNamespace(name=name) for name in self.names)

    def __exit__(self, *args):
        pass


class SafetyTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="mub6-safety-test-")
        self.base = Path(self.temp.name)
        self.root, self.area = self.base / "source", self.base / "queue"
        (self.root / "production").mkdir(parents=True)
        (self.root / "elastic-run").mkdir()
        self.area.mkdir()
        self.queue = SimpleNamespace(area=self.area)
        self.clock = Clock()
        self.calls = []

        def scanner(path):
            self.calls.append(Path(path))
            return os.scandir(path)
        self.checker = safety.SafetyPaths(clock=self.clock, scanner=scanner)
        self.worker_patch = patch.object(worker, "SAFETY_PATHS", self.checker)
        self.signal_patch = patch.object(worker, "STOP", False)
        self.audit_patch = patch.object(audit, "SAFETY_PATHS", safety.SafetyPaths(clock=self.clock))
        self.worker_patch.start()
        self.signal_patch.start()
        self.audit_patch.start()

    def tearDown(self):
        self.audit_patch.stop()
        self.signal_patch.stop()
        self.worker_patch.stop()
        self.temp.cleanup()

    @staticmethod
    def write(path, value=None):
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(value or {"reason": "synthetic_stop"}))

    def test_shared_parents_are_listed_once_and_missing_intermediates_never_opened(self):
        output = self.root / "elastic-run/output"
        output.mkdir()
        guards = (self.root / "production/STOP_REQUESTED.json", self.root / "production/FAILURE.json",
                  self.root / "elastic-run/STOP_REQUESTED.json", self.root / "elastic-run/FAILURE.json",
                  output / "STOP_REQUESTED.json", self.area / "FAILURE.json",
                  self.root / "missing/deep/FAILURE.json")
        self.write(guards[0])
        self.write(guards[4])
        result = self.checker.present(guards, (self.root, self.area))
        self.assertEqual(result, {safety.absolute(guards[0]), safety.absolute(guards[4])})
        counts = Counter(self.calls)
        self.assertTrue(all(count == 1 for count in counts.values()))
        self.assertEqual(set(counts), {self.root, self.root / "production", self.root / "elastic-run", output, self.area})
        self.assertFalse(any("missing" in path.parts for path in self.calls))

    def test_helper_and_worker_never_stat_exists_or_resolve_guard_paths(self):
        self.write(self.root / "production/STOP_REQUESTED.json", {"reason": "authorized_elastic_handover"})
        checks = (patch.object(Path, "exists", side_effect=AssertionError("exists forbidden")),
                  patch.object(Path, "stat", side_effect=AssertionError("stat forbidden")),
                  patch.object(Path, "lstat", side_effect=AssertionError("lstat forbidden")),
                  patch.object(Path, "resolve", side_effect=AssertionError("resolve forbidden")),
                  patch.object(os, "stat", side_effect=AssertionError("os.stat forbidden")),
                  patch.object(os, "lstat", side_effect=AssertionError("os.lstat forbidden")))
        for check in checks:
            check.start()
        try:
            self.assertFalse(worker.stop_requested(self.root, self.queue))
            self.assertFalse(audit.queue_failure_detected(self.root, self.queue))
        finally:
            for check in reversed(checks):
                check.stop()

    def test_verified_direct_parents_avoid_campaign_root_scan_and_open_once(self):
        output = self.root / "elastic-run/output"
        output.mkdir()
        self.write(self.root / "production/STOP_REQUESTED.json", {"reason": "authorized_elastic_handover"})
        with patch.object(safety.os, "open", wraps=os.open) as opened:
            self.assertFalse(worker.stop_requested(self.root, self.queue))
            self.clock.now = 0.25
            self.assertFalse(worker.stop_requested(self.root, self.queue))
            expected = {self.root / "production", self.root / "elastic-run", output, self.area}
            self.assertEqual(Counter(Path(call.args[0]) for call in opened.call_args_list),
                             Counter({path: 1 for path in expected}))
            self.assertTrue(all(call.args[1] & os.O_DIRECTORY for call in opened.call_args_list))
        self.assertNotIn(self.root, self.calls)
        self.assertEqual(Counter(self.calls), Counter({path: 2 for path in expected}))

    def test_missing_optional_output_is_detected_after_creation_without_root_scan(self):
        output = self.root / "elastic-run/output"
        self.assertFalse(worker.stop_requested(self.root, self.queue))
        anchors = self.checker.verified_anchors(self.root, self.area)
        self.assertNotIn(output, anchors)
        self.assertNotIn(output, self.calls)
        self.write(output / "STOP_REQUESTED.json")
        self.clock.now = 0.249
        self.assertFalse(worker.stop_requested(self.root, self.queue))
        self.clock.now = 0.25
        self.assertTrue(worker.stop_requested(self.root, self.queue))
        self.assertIn(output, self.calls)
        self.assertNotIn(self.root, self.calls)

    def test_missing_top_parent_retains_campaign_fallback_and_later_stop(self):
        production = self.root / "production"
        production.rmdir()
        self.assertFalse(worker.stop_requested(self.root, self.queue))
        self.assertNotIn(production, self.checker.verified_anchors(self.root, self.area))
        self.assertIn(self.root, self.calls)
        self.write(production / "FAILURE.json")
        self.clock.now = 0.25
        self.assertTrue(worker.stop_requested(self.root, self.queue))

    def test_verified_parent_removal_raises_instead_of_becoming_absence(self):
        output = self.root / "elastic-run/output"
        output.mkdir()
        self.assertFalse(worker.stop_requested(self.root, self.queue))
        output.rmdir()
        self.clock.now = 0.25
        for _ in range(2):
            with self.assertRaises(FileNotFoundError):
                worker.stop_requested(self.root, self.queue)
        self.assertIn(output, self.checker.verified_anchors(self.root, self.area))

    def test_anchor_verification_errors_propagate_without_partial_cache(self):
        real_open = os.open
        output = self.root / "elastic-run/output"
        for code in (errno.EACCES, errno.EIO, errno.EMFILE):
            with self.subTest(errno=code):
                def fail_output(path, flags):
                    if Path(path) == output:
                        raise OSError(code, "synthetic verification failure")
                    return real_open(path, flags)
                with patch.object(safety.os, "open", side_effect=fail_output) as opened:
                    for _ in range(2):
                        with self.assertRaises(OSError) as raised:
                            self.checker.verified_anchors(self.root, self.area)
                        self.assertEqual(raised.exception.errno, code)
                    self.assertEqual(sum(Path(call.args[0]) == output for call in opened.call_args_list), 2)
                self.assertEqual(self.checker.anchor_sets, {})

    def test_nondirectory_optional_anchor_retains_original_scan_error(self):
        production = self.root / "production"
        production.rmdir()
        production.write_text("regular file")
        with self.assertRaises(NotADirectoryError):
            worker.stop_requested(self.root, self.queue)
        self.assertNotIn(production, self.checker.verified_anchors(self.root, self.area))

    def test_verified_anchor_cache_is_scoped_bounded_and_never_evicts(self):
        checker = safety.SafetyPaths(clock=self.clock)
        with patch.object(safety.os, "open", return_value=123) as opened, patch.object(safety.os, "close") as closed:
            for index in range(safety.MAX_ANCHOR_SETS):
                root, area = self.base / ("root-" + str(index)), self.base / ("area-" + str(index))
                anchors = checker.verified_anchors(root, area)
                self.assertEqual(checker.verified_anchors(root, area), anchors)
                self.assertIn(root / "production", anchors)
                self.assertIn(area, anchors)
            self.assertEqual(len(checker.anchor_sets), safety.MAX_ANCHOR_SETS)
            self.assertEqual(opened.call_count, 4 * safety.MAX_ANCHOR_SETS)
            self.assertEqual(closed.call_count, opened.call_count)
            with self.assertRaisesRegex(safety.SafetyPathLimit, "anchor bound"):
                checker.verified_anchors(self.root, self.area)
            self.assertEqual(opened.call_count, 4 * safety.MAX_ANCHOR_SETS)

    def test_negative_snapshots_refresh_at_quarter_second_and_not_later(self):
        target = self.area / "FAILURE.json"
        self.assertEqual(self.checker.present((target,), (self.area,)), set())
        self.write(target)
        self.clock.now = 0.249
        self.assertEqual(self.checker.present((target,), (self.area,)), set())
        self.assertEqual(len(self.calls), 1)
        self.clock.now = 0.25
        self.assertEqual(self.checker.present((target,), (self.area,)), {target})
        self.assertEqual(len(self.calls), 2)
        with self.assertRaises(ValueError):
            safety.SafetyPaths(ttl=0.251)

    def test_slow_enumeration_does_not_extend_negative_deadline(self):
        target = self.area / "FAILURE.json"
        calls = []

        def scanner(path):
            calls.append(path)
            self.clock.now += 1
            return os.scandir(path)
        checker = safety.SafetyPaths(clock=self.clock, scanner=scanner)
        self.assertEqual(checker.present((target,), (self.area,)), set())
        self.assertEqual(checker.directories[self.area][0], 0.25)
        self.write(target)
        self.assertEqual(checker.present((target,), (self.area,)), {target})
        self.assertEqual(len(calls), 2)

    def test_listing_errors_retry_and_never_commit_a_negative_snapshot(self):
        target = self.root / "elastic-run/FAILURE.json"
        bad = self.root / "elastic-run"
        calls = Counter()

        def scanner(path):
            calls[path] += 1
            if path == bad:
                raise OSError("synthetic stale directory handle")
            return os.scandir(path)
        checker = safety.SafetyPaths(clock=self.clock, scanner=scanner)
        for _ in range(2):
            with self.assertRaisesRegex(OSError, "stale directory"):
                checker.present((target,), (self.root,))
        self.assertEqual(calls[bad], 2)
        self.assertNotIn(bad, checker.directories)

    def test_permission_missing_anchor_and_nondirectory_errors_fail_closed(self):
        with patch.object(self.checker, "scanner", side_effect=PermissionError("permission denied")):
            with self.assertRaises(PermissionError):
                self.checker.present((self.area / "FAILURE.json",), (self.area,))
        missing = self.root / "not_a_verified_anchor"
        with self.assertRaises(FileNotFoundError):
            self.checker.present((missing / "FAILURE.json",), (missing,))
        not_dir = self.root / "not_a_directory"
        not_dir.write_text("regular file")
        with self.assertRaises(NotADirectoryError):
            self.checker.present((not_dir / "FAILURE.json",), (self.root,))

    def test_overflow_is_bounded_and_does_not_cache_guard_absence(self):
        checker = safety.SafetyPaths(clock=self.clock,
            scanner=lambda path: Entries(("entry-" + str(n) for n in range(safety.MAX_ENTRIES + 1))))
        with self.assertRaisesRegex(safety.SafetyPathLimit, "4096"):
            checker.present((self.area / "FAILURE.json",), (self.area,))
        self.assertEqual(checker.directories, {})
        checker.scanner = os.scandir
        self.assertEqual(checker.present((self.area / "FAILURE.json",), (self.area,)), set())

    def test_exact_directory_bound_and_global_cache_bound(self):
        checker = safety.SafetyPaths(clock=self.clock,
            scanner=lambda path: Entries(("entry-" + str(n) for n in range(safety.MAX_ENTRIES))))
        self.assertEqual(checker.present((self.area / "FAILURE.json",), (self.area,)), set())
        self.assertEqual(len(checker.directories[self.area][1]), safety.MAX_ENTRIES)
        checker.scanner = os.scandir
        for n in range(safety.MAX_DIRECTORIES + 2):
            anchor = self.base / ("anchor-" + str(n))
            anchor.mkdir()
            checker.present((anchor / "FAILURE.json",), (anchor,))
        self.assertEqual(len(checker.directories), safety.MAX_DIRECTORIES)

    def test_outside_anchor_and_oversized_requests_fail_closed(self):
        with self.assertRaisesRegex(ValueError, "outside verified"):
            self.checker.present((self.area / "FAILURE.json",), (self.root,))
        with self.assertRaises(safety.SafetyPathLimit):
            self.checker.present([self.area / (str(n) + ".json") for n in range(65)], (self.area,))

    def test_fresh_membership_for_failure_write_does_not_overwrite_first_failure(self):
        target = self.area / "FAILURE.json"
        self.assertEqual(self.checker.present((target,), (self.area,)), set())
        self.write(target, {"reason": "first_failure"})
        self.assertEqual(self.checker.present((target,), (self.area,), fresh=True), {target})
        self.assertEqual(json.loads(target.read_text())["reason"], "first_failure")

    def test_failed_forced_refresh_invalidates_an_unexpired_negative(self):
        target = self.area / "FAILURE.json"
        self.assertEqual(self.checker.present((target,), (self.area,)), set())
        with patch.object(self.checker, "scanner", side_effect=PermissionError("refresh failed")) as scan:
            with self.assertRaises(PermissionError):
                self.checker.present((target,), (self.area,), fresh=True)
            with self.assertRaises(PermissionError):
                self.checker.present((target,), (self.area,))
            self.assertEqual(scan.call_count, 2)
        self.assertNotIn(self.area, self.checker.directories)
        self.write(target)
        self.assertEqual(self.checker.present((target,), (self.area,)), {target})

    def test_worker_all_original_stops_latch_and_are_scoped_to_root_and_area(self):
        relative = (("queue", "STOP_REQUESTED.json"), ("queue", "FAILURE.json"),
                    ("source", "production/FAILURE.json"), ("source", "elastic-run/FAILURE.json"),
                    ("source", "elastic-run/STOP_REQUESTED.json"), ("source", "elastic-run/output/STOP_REQUESTED.json"))
        for index, (kind, name) in enumerate(relative):
            with self.subTest(name=name):
                root, area = self.base / ("source-" + str(index)), self.base / ("queue-" + str(index))
                root.mkdir(); area.mkdir()
                target = (root if kind == "source" else area) / name
                self.write(target)
                self.assertTrue(worker.stop_requested(root, SimpleNamespace(area=area)))
                target.unlink()
                self.assertTrue(worker.stop_requested(root, SimpleNamespace(area=area)))
        self.assertFalse(worker.stop_requested(self.root, self.queue))
        self.write(self.area / "FAILURE.json")
        self.clock.now = 0.25
        self.assertTrue(worker.stop_requested(self.root, self.queue))
        other_area = self.base / "other-queue"
        other_area.mkdir()
        self.assertFalse(worker.stop_requested(self.root, SimpleNamespace(area=other_area)))

    def test_authorized_handover_is_read_live_and_other_reason_latches(self):
        receipt = self.root / "production/STOP_REQUESTED.json"
        self.write(receipt, {"reason": "authorized_elastic_handover"})
        self.assertFalse(worker.stop_requested(self.root, self.queue))
        self.assertFalse(worker.stop_requested(self.root, self.queue))
        self.write(receipt, {"reason": "new_safety_stop"})
        self.assertTrue(worker.stop_requested(self.root, self.queue))
        self.write(receipt, {"reason": "authorized_elastic_handover"})
        self.assertTrue(worker.stop_requested(self.root, self.queue))

    def test_malformed_handover_retries_instead_of_caching_false(self):
        receipt = self.root / "production/STOP_REQUESTED.json"
        receipt.write_text("{malformed")
        for _ in range(2):
            with self.assertRaises(json.JSONDecodeError):
                worker.stop_requested(self.root, self.queue)
        self.write(receipt, {"reason": "authorized_elastic_handover"})
        self.assertFalse(worker.stop_requested(self.root, self.queue))

    def test_handover_read_error_propagates_on_every_call(self):
        receipt = self.root / "production/STOP_REQUESTED.json"
        self.write(receipt, {"reason": "authorized_elastic_handover"})
        with patch.object(worker.tq, "read_json", side_effect=OSError("synthetic guard read failure")) as read:
            for _ in range(2):
                with self.assertRaisesRegex(OSError, "guard read"):
                    worker.stop_requested(self.root, self.queue)
            self.assertEqual(read.call_count, 2)

    def test_audit_failure_poll_latches_and_isolated_areas_do_not_cross_contaminate(self):
        self.assertFalse(audit.queue_failure_detected(self.root, self.queue))
        self.write(self.area / "FAILURE.json")
        self.clock.now = 0.25
        self.assertTrue(audit.queue_failure_detected(self.root, self.queue))
        (self.area / "FAILURE.json").unlink()
        self.assertTrue(audit.queue_failure_detected(self.root, self.queue))
        other = self.base / "audit-other"
        other.mkdir()
        self.assertFalse(audit.queue_failure_detected(self.root, SimpleNamespace(area=other)))
        self.assertEqual(audit.audit_provider_hashes()["safety_paths_sha256"],
                         worker.tq.sha_file(safety.__file__))


class SharedCacheTests(unittest.TestCase):
    def setUp(self):
        self.env = patch.dict(os.environ)
        self.env.start()
        for name in (cache.DIRECTORY_ENV, cache.SOURCE_ENV, cache.JOB_ENV):
            os.environ.pop(name, None)
        self.temp = tempfile.TemporaryDirectory(prefix="mub6-node-cache-test-", dir=str(cache._temp_root()))
        self.base = Path(self.temp.name)
        self.area = self.base / "guards"
        self.area.mkdir()
        self.target = self.area / "FAILURE.json"
        self.source = hashlib.sha256(uuid.uuid4().bytes).hexdigest()
        self.job = os.environ.get("SLURM_JOB_ID", "1")
        self.place = cache.prepare_node_cache(self.source, self.job)
        self.backends = []
        self.clock = Clock()
        self.count = 0

    def tearDown(self):
        for backend in self.backends:
            backend.close()
        shutil.rmtree(self.place)
        self.temp.cleanup()
        self.env.stop()

    def backend(self):
        value = cache.NodeDirectoryCache(self.place, self.source, self.job, Path(safety.__file__).parent)
        self.backends.append(value)
        return value

    def checker(self, backend=None, scanner=None, ttl=0.25):
        def counted(path):
            self.count += 1
            return os.scandir(path)
        return safety.SafetyPaths(clock=self.clock, scanner=scanner or counted,
                                  ttl=ttl, node_cache=backend or self.backend())

    def snapshot(self, backend):
        key, identity = backend._key(self.area)
        return self.place / (key + ".json"), identity

    @contextmanager
    def replace_during_read(self, reader, path, replacement, stage="open"):
        """Publish through the real cache API after the reader holds its FD."""
        writer = self.backend()
        old_inode = path.stat().st_ino
        real_open, real_fdopen = os.open, os.fdopen
        observed = {}

        def publish(descriptor):
            if observed:
                return
            observed["inode"] = os.fstat(descriptor).st_ino
            writer._write(path.name, replacement)
            observed["links"] = os.fstat(descriptor).st_nlink
            observed["bytes"] = os.pread(descriptor, cache.MAX_BYTES + 1, 0)
            observed["new_inode"] = path.stat().st_ino

        def opened(name, flags, *args, **kwargs):
            descriptor = real_open(name, flags, *args, **kwargs)
            if stage == "open" and name == path.name and kwargs.get("dir_fd") == reader.descriptor:
                publish(descriptor)
            return descriptor

        def fdopened(descriptor, mode, *args, **kwargs):
            if stage == "read" and mode == "rb" and os.fstat(descriptor).st_ino == old_inode:
                publish(descriptor)
            return real_fdopen(descriptor, mode, *args, **kwargs)

        with patch.object(cache.os, "open", side_effect=opened), patch.object(cache.os, "fdopen", side_effect=fdopened):
            yield observed
        self.assertEqual(observed["inode"], old_inode)
        self.assertEqual(observed["links"], 0)
        self.assertNotEqual(observed["new_inode"], old_inode)

    def test_detached_completed_snapshot_survives_replacement_before_fstat_or_read(self):
        for stage in ("open", "read"):
            with self.subTest(stage=stage):
                self.target.unlink(missing_ok=True)
                a, b = self.checker(), self.checker()
                a.present((self.target,), (self.area,), fresh=True)
                path, _ = self.snapshot(a.node_cache)
                old = json.loads(path.read_text())
                self.target.write_text("synthetic_stop")
                self.clock.now += 0.1
                replacement = dict(old, names=[self.target.name], scan_start=self.clock.now,
                                   deadline=self.clock.now + 0.25)
                with self.replace_during_read(b.node_cache, path, replacement, stage) as observed:
                    self.assertEqual(b.present((self.target,), (self.area,)), set())
                self.assertEqual(json.loads(observed["bytes"]), old)
                self.assertEqual(b.present((self.target,), (self.area,)), {self.target})

    def test_detached_negative_replaced_by_error_keeps_original_deadline(self):
        for now in (0.1, 0.25):
            with self.subTest(now=now):
                a, b = self.checker(), self.checker()
                self.clock.now = 0
                a.present((self.target,), (self.area,), fresh=True)
                path, identity = self.snapshot(a.node_cache)
                error = {"identity": identity, "status": "error",
                         "error": {"errno": errno.EIO, "message": "replacement scan failed"}}
                self.clock.now = now
                with self.replace_during_read(b.node_cache, path, error):
                    if now < 0.25:
                        self.assertEqual(b.present((self.target,), (self.area,)), set())
                    else:
                        with self.assertRaisesRegex(OSError, "replacement scan failed"):
                            b.present((self.target,), (self.area,))
                with self.assertRaisesRegex(OSError, "replacement scan failed"):
                    b.present((self.target,), (self.area,))

    def test_detached_expired_negative_reads_current_stop_snapshot(self):
        a, b = self.checker(), self.checker()
        a.present((self.target,), (self.area,))
        path, _ = self.snapshot(a.node_cache)
        self.target.write_text("synthetic_stop")
        self.clock.now = 0.25
        replacement = dict(json.loads(path.read_text()), names=[self.target.name], scan_start=0.25, deadline=0.5)
        with self.replace_during_read(b.node_cache, path, replacement, "read"):
            self.assertEqual(b.present((self.target,), (self.area,)), {self.target})
        self.assertEqual(self.count, 1)

    def test_detached_error_replaced_by_success_remains_fatal_to_open_reader(self):
        a, b = self.checker(), self.checker()
        a.present((self.target,), (self.area,))
        path, identity = self.snapshot(a.node_cache)
        complete = json.loads(path.read_text())
        a.node_cache._write(path.name, {"identity": identity, "status": "error",
                           "error": {"errno": errno.EACCES, "message": "prior scan denied"}})
        with self.replace_during_read(b.node_cache, path, complete):
            with self.assertRaisesRegex(OSError, "prior scan denied"):
                b.present((self.target,), (self.area,))
        self.assertEqual(b.present((self.target,), (self.area,)), set())

    def test_registry_locks_pending_and_writable_files_reject_detached_inodes(self):
        backend = self.backend()
        key, _ = backend._key(self.area)
        for name in ("REGISTRY.lock", "REGISTRY.json", key + ".lock", key + ".json.pending", key + ".json"):
            for options in ({}, {"writable": True}, {"create": True}):
                with self.subTest(name=name, options=options):
                    path = self.place / name
                    backend._write(name, {"generation": "old"})
                    with self.replace_during_read(backend, path, {"generation": "new"}):
                        with self.assertRaises(cache.CacheSecurityError):
                            backend._file(name, **options)
        for name, options in (("REGISTRY.json", {}), (key + ".lock", {}),
                              (key + ".json.pending", {}), (key + ".json", {"writable": True}),
                              (key + ".json", {"create": True})):
            with self.subTest(name=name, options=options):
                with self.assertRaisesRegex(cache.CacheSecurityError, "read-only keyed snapshots"):
                    backend._file(name, detached_snapshot=True, **options)

    def test_snapshot_hardlink_added_after_open_or_first_fstat_remains_fatal(self):
        a = self.checker()
        a.present((self.target,), (self.area,))
        path, _ = self.snapshot(a.node_cache)
        alias = self.base / "concurrent-hardlink"
        inode = path.stat().st_ino
        real_open, real_fstat = os.open, os.fstat
        for stage in ("open", "fstat"):
            linked = []

            def opened(name, flags, *args, **kwargs):
                descriptor = real_open(name, flags, *args, **kwargs)
                if stage == "open" and name == path.name:
                    os.link(path, alias)
                    linked.append(True)
                return descriptor

            def stated(descriptor):
                info = real_fstat(descriptor)
                if stage == "fstat" and info.st_ino == inode and not linked:
                    os.link(path, alias)
                    linked.append(True)
                return info

            try:
                with self.subTest(stage=stage), patch.object(cache.os, "open", side_effect=opened), \
                        patch.object(cache.os, "fstat", side_effect=stated):
                    with self.assertRaises(cache.CacheSecurityError):
                        a.present((self.target,), (self.area,))
                    self.assertTrue(linked)
            finally:
                alias.unlink(missing_ok=True)

    def test_shared_hit_retains_original_expiry_and_detects_late_guard(self):
        a, b = self.checker(), self.checker()
        self.assertEqual(a.present((self.target,), (self.area,)), set())
        self.clock.now = 0.2
        self.assertEqual(b.present((self.target,), (self.area,)), set())
        self.assertEqual(self.count, 1)
        self.target.write_text("synthetic_stop")
        self.clock.now = 0.249
        self.assertEqual(b.present((self.target,), (self.area,)), set())
        self.clock.now = 0.25
        self.assertEqual(b.present((self.target,), (self.area,)), {self.target})
        self.assertEqual(self.count, 2)
        self.assertTrue(b.statistics()["shared_enabled"])
        self.assertEqual(b.statistics()["shared_hits"], 2)

    def test_shorter_reader_ttl_never_extends_shared_freshness(self):
        a, b = self.checker(), self.checker(ttl=0.1)
        self.assertEqual(a.present((self.target,), (self.area,)), set())
        self.target.write_text("synthetic_stop")
        self.clock.now = 0.099
        self.assertEqual(b.present((self.target,), (self.area,)), set())
        self.clock.now = 0.1
        self.assertEqual(b.present((self.target,), (self.area,)), {self.target})
        self.assertEqual(self.count, 2)

    def test_shared_hit_does_not_rewrite_snapshot_or_registry(self):
        a, b = self.checker(), self.checker()
        a.present((self.target,), (self.area,))
        path, _ = self.snapshot(a.node_cache)
        before = path.read_bytes()
        b.present((self.target,), (self.area,))
        with patch.object(b.node_cache, "_write", side_effect=AssertionError("cached hit wrote")):
            self.assertEqual(b.present((self.target,), (self.area,)), set())
        self.assertEqual(path.read_bytes(), before)

    def test_shared_freshness_is_checked_after_name_validation(self):
        a, b = self.checker(), self.checker()
        a.present((self.target,), (self.area,))
        self.target.write_text("synthetic_stop")
        self.clock.now = 0.2
        actual = b.node_cache._names
        def slow_names(value):
            result = actual(value)
            self.clock.now = 0.3
            return result
        with patch.object(b.node_cache, "_names", side_effect=slow_names):
            self.assertEqual(b.present((self.target,), (self.area,)), {self.target})
        self.assertEqual(self.count, 2)
        self.assertEqual(b.statistics()["shared_hits"], 0)

    def test_exclusive_first_creation_only_reopens_eexist_and_never_retries_enoent(self):
        backend = self.backend()
        real_open = os.open
        with patch.object(cache.os, "open", wraps=real_open) as opened:
            first = backend._file("creation-probe.lock", create=True)
            os.close(first)
            second = backend._file("creation-probe.lock", create=True)
            os.close(second)
            calls = opened.call_args_list
        self.assertEqual(len(calls), 3)
        self.assertTrue(calls[0].args[1] & os.O_CREAT and calls[0].args[1] & os.O_EXCL)
        self.assertTrue(calls[1].args[1] & os.O_CREAT and calls[1].args[1] & os.O_EXCL)
        self.assertFalse(calls[2].args[1] & (os.O_CREAT | os.O_EXCL))
        with patch.object(cache.os, "open", side_effect=FileNotFoundError(errno.ENOENT, "synthetic missing cache parent")) as opened:
            with self.assertRaises(FileNotFoundError):
                backend._file("missing-parent.lock", create=True)
            self.assertEqual(opened.call_count, 1)
        link = self.place / "symlink-probe.lock"
        link.symlink_to(self.base / "outside")
        with self.assertRaises(OSError):
            backend._file(link.name, create=True)
        link.unlink()
        os.mkfifo(link, 0o600)
        with self.assertRaises(cache.CacheSecurityError):
            backend._file(link.name, create=True)

    def test_failed_forced_refresh_invalidates_other_reader_until_explicit_revalidation(self):
        a, b = self.checker(), self.checker()
        a.present((self.target,), (self.area,))
        b.present((self.target,), (self.area,))
        with patch.object(a, "scanner", side_effect=OSError(errno.EIO, "forced scan failed")):
            with self.assertRaises(OSError):
                a.present((self.target,), (self.area,), fresh=True)
        with self.assertRaisesRegex(OSError, "forced scan failed"):
            b.present((self.target,), (self.area,))
        self.assertEqual(self.count, 1)
        self.assertEqual(b.present((self.target,), (self.area,), fresh=True), set())
        self.assertEqual(b.present((self.target,), (self.area,)), set())
        self.assertEqual(self.count, 2)

    def test_slow_scanner_owns_result_but_another_reader_cannot_reuse_it(self):
        def slow(path):
            self.count += 1
            self.clock.now += 0.3
            return os.scandir(path)
        a, b = self.checker(scanner=slow), self.checker()
        self.assertEqual(a.present((self.target,), (self.area,)), set())
        self.assertEqual(a.statistics()["slow_refreshes"], 1)
        path, _ = self.snapshot(a.node_cache)
        self.assertEqual(json.loads(path.read_text())["deadline"], 0.25)
        self.target.write_text("synthetic_stop")
        self.assertEqual(b.present((self.target,), (self.area,)), {self.target})
        self.assertEqual(self.count, 2)

    def test_bad_future_identity_and_partial_snapshots_fail_closed(self):
        a, b = self.checker(), self.checker()
        a.present((self.target,), (self.area,))
        path, identity = self.snapshot(a.node_cache)
        original = json.loads(path.read_text())
        for change in ({"scan_start": 1, "deadline": 1.25}, {"deadline": 0.251},
                       {"scan_start": float("nan")}, {"status": "partial"},
                       {"identity": dict(identity, boot="different_boot")},
                       {"names": ["duplicate", "duplicate"]}):
            with self.subTest(change=change):
                path.write_text(json.dumps(dict(original, **change)))
                with self.assertRaises(cache.CacheSecurityError):
                    b.present((self.target,), (self.area,))
        path.write_text("{truncated")
        with self.assertRaises(json.JSONDecodeError):
            b.present((self.target,), (self.area,))
        self.assertEqual(self.count, 1)

    def test_cache_read_and_publish_errors_are_never_suppressed(self):
        a = self.checker()
        a.present((self.target,), (self.area,))
        with patch.object(a.node_cache, "_read", side_effect=PermissionError(errno.EACCES, "cache read")):
            with self.assertRaises(PermissionError):
                a.present((self.target,), (self.area,))
        with patch.object(a.node_cache, "_write", side_effect=OSError(errno.EIO, "cache publication")):
            with self.assertRaises(OSError):
                a.present((self.target,), (self.area,), fresh=True)

    def test_private_path_symlinks_modes_and_source_configuration_are_checked(self):
        os.chmod(self.place, 0o755)
        with self.assertRaises(cache.CacheSecurityError):
            self.backend()
        os.chmod(self.place, 0o700)
        other = self.base / "foreign-cache"
        other.mkdir()
        with self.assertRaises(cache.CacheSecurityError):
            cache.NodeDirectoryCache(other, self.source, self.job, Path(safety.__file__).parent)
        cache.environment_config()
        os.environ[cache.DIRECTORY_ENV] = str(self.place)
        with self.assertRaisesRegex(ValueError, "Incomplete"):
            cache.environment_config()
        os.environ[cache.SOURCE_ENV] = self.source
        os.environ[cache.JOB_ENV] = "not_a_job"
        with self.assertRaises(ValueError):
            cache.environment_config()
        with patch.object(cache, "_require_local_filesystem", side_effect=cache.CacheSecurityError("remote filesystem")):
            with self.assertRaisesRegex(cache.CacheSecurityError, "remote filesystem"):
                self.backend()

    def test_symlink_hardlink_and_nonregular_cache_files_fail_closed(self):
        a = self.checker()
        a.present((self.target,), (self.area,))
        path, _ = self.snapshot(a.node_cache)
        original = path.read_bytes()
        path.unlink()
        path.symlink_to(self.base / "outside")
        with self.assertRaises(OSError):
            a.present((self.target,), (self.area,))
        path.unlink()
        path.write_bytes(original)
        os.chmod(path, 0o600)
        alias = self.base / "hardlink"
        os.link(path, alias)
        with self.assertRaises(cache.CacheSecurityError):
            a.present((self.target,), (self.area,))
        alias.unlink()
        path.unlink()
        os.mkfifo(path, 0o600)
        with self.assertRaises(cache.CacheSecurityError):
            a.present((self.target,), (self.area,))

    def test_direct_cache_namespace_symlink_is_rejected(self):
        moved = self.place.with_name(self.place.name + "-moved")
        self.place.rename(moved)
        try:
            self.place.symlink_to(moved, target_is_directory=True)
            with self.assertRaises(OSError):
                self.backend()
        finally:
            self.place.unlink()
            moved.rename(self.place)
        with self.assertRaises(cache.CacheSecurityError):
            cache._private(SimpleNamespace(st_uid=os.getuid()+1, st_mode=stat.S_IFREG | 0o600, st_nlink=1))

    def test_bound_on_shared_keys_names_bytes_and_fixed_pending_files(self):
        backend = self.backend()
        for index in range(cache.MAX_KEYS):
            backend._key(self.base / ("directory-" + str(index)))
        with self.assertRaises(cache.CacheBoundError):
            self.backend()._key(self.area)
        self.assertEqual(len(json.loads((self.place / "REGISTRY.json").read_text())["keys"]), 64)
        with self.assertRaises(cache.CacheSecurityError):
            cache.NodeDirectoryCache._names(["entry"] * (cache.MAX_NAMES + 1))
        with self.assertRaises(cache.CacheBoundError):
            backend._write("oversize.json", {"text": "x" * (cache.MAX_BYTES + 1)})
        self.assertLessEqual(len(os.listdir(self.place)), 3)

    def test_lazy_enable_preserves_latches_and_injected_scanner_is_isolated(self):
        value = safety.SafetyPaths()
        value.latch((self.base, self.area), "already_stopped")
        cache.enable_node_cache(self.source, self.job)
        self.assertFalse(value.statistics()["shared_enabled"])
        self.assertEqual(value.present((self.target,), (self.area,)), set())
        self.assertTrue(value.statistics()["shared_enabled"])
        self.assertEqual(value.latched((self.base, self.area)), "already_stopped")
        self.backends.append(value.node_cache)
        isolated = safety.SafetyPaths(clock=self.clock, scanner=os.scandir)
        isolated.present((self.target,), (self.area,))
        self.assertFalse(isolated.statistics()["shared_enabled"])

    def test_shared_membership_keeps_production_handover_contents_live(self):
        root = self.base / "source"
        (root / "production").mkdir(parents=True)
        (root / "elastic-run/output").mkdir(parents=True)
        receipt = root / "production/STOP_REQUESTED.json"
        receipt.write_text(json.dumps({"reason": "authorized_elastic_handover"}))
        a = self.checker()
        with patch.object(worker, "SAFETY_PATHS", a), patch.object(worker, "STOP", False):
            self.assertFalse(worker.stop_requested(root, SimpleNamespace(area=self.area)))
            receipt.write_text(json.dumps({"reason": "changed_live_stop"}))
            self.assertTrue(worker.stop_requested(root, SimpleNamespace(area=self.area)))
            receipt.write_text(json.dumps({"reason": "authorized_elastic_handover"}))
            self.assertTrue(worker.stop_requested(root, SimpleNamespace(area=self.area)))
        self.assertGreaterEqual(a.statistics()["shared_hits"], 1)

    def child_environment(self):
        value = dict(os.environ)
        value.update({cache.DIRECTORY_ENV: str(self.place), cache.SOURCE_ENV: self.source,
                      cache.JOB_ENV: self.job, "PYTHONDONTWRITEBYTECODE": "1"})
        return value

    def test_actual_subprocesses_share_one_scan_and_late_stop_refreshes(self):
        counter, go = self.base / "scan-counter", self.base / "go"
        script = """
import json,os,sys,time
from pathlib import Path
import node_safety_cache as cache
import safety_paths as safety
area,counter,go,ready=map(Path,sys.argv[1:])
backend=cache.NodeDirectoryCache.from_environment(Path(safety.__file__).parent)
backend._key(area)
def scanner(path):
    with counter.open('a') as stream: stream.write('scan\\n')
    time.sleep(.1)
    return os.scandir(path)
value=safety.SafetyPaths(scanner=scanner,node_cache=backend)
ready.write_text('ready')
until=time.monotonic()+10
while not go.exists():
    if time.monotonic()>until: raise TimeoutError('test start barrier')
    time.sleep(.002)
try:
    found=value.present((area/'FAILURE.json',),anchors=(area,))
except Exception:
    descriptor=os.fstat(backend.descriptor)
    try:
        path=os.stat(os.environ[cache.DIRECTORY_ENV])
        path_status={'inode':path.st_ino,'links':path.st_nlink}
    except OSError as error:
        path_status={'errno':error.errno}
    print(json.dumps({'cache_directory':os.environ[cache.DIRECTORY_ENV],
                     'descriptor_inode':descriptor.st_ino,'descriptor_links':descriptor.st_nlink,
                     'path_status':path_status}),file=sys.stderr,flush=True)
    raise
print(json.dumps({'present':bool(found),'stats':value.statistics()}),flush=True)
backend.close()
"""
        processes = []
        try:
            for index in range(8):
                ready = self.base / ("ready-" + str(index))
                command = [sys.executable, "-B", "-c", script, str(self.area), str(counter), str(go), str(ready)]
                processes.append(subprocess.Popen(command, cwd=Path(safety.__file__).parent,
                                                  env=self.child_environment(), stdout=subprocess.PIPE,
                                                  stderr=subprocess.PIPE, text=True))
            until = time.monotonic() + 10
            while not all((self.base / ("ready-" + str(i))).exists() for i in range(8)):
                if time.monotonic() > until:
                    self.fail("subprocesses did not reach the local start barrier")
                time.sleep(.005)
            go.write_text("go")
            records = []
            outcomes = []
            for process in processes:
                output, error = process.communicate(timeout=10)
                outcomes.append((process.returncode, output, error))
            self.assertTrue(all(code == 0 for code, _, _ in outcomes), repr(outcomes))
            records = [json.loads(output) for _, output, _ in outcomes]
            self.assertEqual(counter.read_text().splitlines(), ["scan"])
            self.assertEqual(sum(v["stats"]["refreshes"] for v in records), 1)
            self.assertEqual(sum(v["stats"]["shared_hits"] for v in records), 7)
            self.assertTrue(all(v["stats"]["shared_enabled"] and not v["present"] for v in records))
            self.target.write_text("synthetic_stop")
            time.sleep(.26)
            result = subprocess.run([sys.executable, "-B", "-c", script, str(self.area), str(counter),
                                     str(go), str(self.base / "late-ready")], cwd=Path(safety.__file__).parent,
                                    env=self.child_environment(), capture_output=True, text=True, timeout=10)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertTrue(json.loads(result.stdout)["present"])
            self.assertEqual(counter.read_text().splitlines(), ["scan", "scan"])
        finally:
            for process in processes:
                if process.poll() is None:
                    process.kill()
                    process.wait(timeout=5)
                if process.stdout is not None:
                    process.stdout.close()
                if process.stderr is not None:
                    process.stderr.close()

    def test_actual_crash_after_invalidation_leaves_no_reusable_partial_negative(self):
        a = self.checker()
        a.present((self.target,), (self.area,))
        path, identity = self.snapshot(a.node_cache)
        script = """
import os,sys
from pathlib import Path
import node_safety_cache as cache
import safety_paths as safety
backend=cache.NodeDirectoryCache.from_environment(Path(safety.__file__).parent)
def interrupted(name,value,maximum=cache.MAX_BYTES):
    descriptor=backend._file(name+'.pending',create=True)
    os.ftruncate(descriptor,0)
    os.write(descriptor,b'{partial')
    os._exit(9)
backend._write=interrupted
value=safety.SafetyPaths(node_cache=backend)
value.present((Path(sys.argv[1])/'FAILURE.json',),anchors=(Path(sys.argv[1]),),fresh=True)
"""
        # Use real monotonic timestamps for the crash subprocess to validate
        # its prior snapshot while sharing exactly the same namespace.
        original = json.loads(path.read_text())
        original.update(scan_start=time.monotonic(), deadline=time.monotonic()+.2)
        path.write_text(json.dumps(original))
        result = subprocess.run([sys.executable, "-B", "-c", script, str(self.area)],
                                cwd=Path(safety.__file__).parent, env=self.child_environment(),
                                capture_output=True, text=True, timeout=10)
        self.assertEqual(result.returncode, 9, result.stderr)
        self.assertFalse(path.exists())
        self.assertEqual(path.with_name(path.name+".pending").read_bytes(), b"{partial")
        self.target.write_text("synthetic_stop")
        self.assertEqual(a.present((self.target,), (self.area,)), {self.target})
        self.assertFalse(path.with_name(path.name+".pending").exists())
        self.assertLessEqual(len(os.listdir(self.place)), 5)

    def test_actual_expired_reader_waits_for_scanner_instead_of_reusing_negative(self):
        a = self.checker()
        a.present((self.target,), (self.area,))
        holder_ready, reader_ready, release = (self.base / name for name in ("holder-ready", "reader-ready", "release"))
        script = """
import json,os,sys,time
from pathlib import Path
import node_safety_cache as cache
import safety_paths as safety
area,ready,release=map(Path,sys.argv[1:4]); holder=sys.argv[4]=='holder'
backend=cache.NodeDirectoryCache.from_environment(Path(safety.__file__).parent)
backend._key(area)
def scanner(path):
    if holder:
        ready.write_text('scanning')
        until=time.monotonic()+10
        while not release.exists():
            if time.monotonic()>until: raise TimeoutError('test scan barrier')
            time.sleep(.002)
    return os.scandir(path)
value=safety.SafetyPaths(scanner=scanner,node_cache=backend)
if not holder: ready.write_text('reading')
found=value.present((area/'FAILURE.json',),anchors=(area,),fresh=holder)
print(json.dumps({'present':bool(found),'stats':value.statistics()}),flush=True)
backend.close()
"""
        processes = []
        try:
            holder = subprocess.Popen([sys.executable, "-B", "-c", script, str(self.area), str(holder_ready), str(release), "holder"],
                                      cwd=Path(safety.__file__).parent, env=self.child_environment(),
                                      stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            processes.append(holder)
            until = time.monotonic()+10
            while not holder_ready.exists():
                if time.monotonic()>until: self.fail("holder failed to enter scan")
                time.sleep(.002)
            reader = subprocess.Popen([sys.executable, "-B", "-c", script, str(self.area), str(reader_ready), str(release), "reader"],
                                      cwd=Path(safety.__file__).parent, env=self.child_environment(),
                                      stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            processes.append(reader)
            until = time.monotonic()+10
            while not reader_ready.exists():
                if time.monotonic()>until: self.fail("reader failed to start")
                time.sleep(.002)
            time.sleep(.04)
            self.assertIsNone(reader.poll(), "reader returned an expired pre-refresh negative")
            self.target.write_text("synthetic_stop")
            release.write_text("release")
            records = []
            for process in processes:
                output, error = process.communicate(timeout=10)
                self.assertEqual(process.returncode, 0, error)
                records.append(json.loads(output))
            self.assertTrue(all(value["present"] for value in records))
            self.assertEqual(records[1]["stats"]["lock_waits"], 1)
        finally:
            for process in processes:
                if process.poll() is None:
                    process.kill()
                    process.wait(timeout=5)


if __name__ == "__main__":
    unittest.main(verbosity=2)
