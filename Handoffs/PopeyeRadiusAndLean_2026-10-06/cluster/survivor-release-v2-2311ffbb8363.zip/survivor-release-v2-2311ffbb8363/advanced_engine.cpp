// New, separately pinned evaluators; frozen native sources remain unchanged.
#include "advanced_src/plain_constraint.cpp"
#include <complex>

static void advanced_guard(){
 if(!std::numeric_limits<double>::is_iec559||std::fegetround()!=FE_TONEAREST)throw std::runtime_error("hardware");
 volatile double n=std::numeric_limits<double>::min(),h=.5,d=std::numeric_limits<double>::denorm_min();
 if(!(n*h>0&&d+d>d))throw std::runtime_error("underflow");
}
template<class F> static array<F,3> invariants(array<F,4>v){
 F s=-F(1)-v[0]-v[1],t=-F(1)-v[2]-v[3],r=-F(1)-v[2]*cj(v[0])-v[3]*cj(v[1]);
 F x=abs2(s),y=abs2(t),z=abs2(r);
 return {x+y+z,real(s*r*cj(t))*C(2),x*y+x*z+y*z-x*y*z};
}
template<class F> static F complement(array<F,3>v){
 const F&p=v[0],&j=v[1],&w=v[2];
 return j*(sq(j)*C(4)+sq(p)*p*C(2)-sq(p)*C(24)-p*w*C(2)+p*C(54)+w*C(30))*C(2);
}
// Input: 16 phase bounds +4 exact upper angular radii. No signed means built.
// Output: p,J,R,comparison pairs; four normalized split influences; derivatives.
extern "C" int advanced_cheap(const double*input,double*output,int derivatives){try{
 advanced_guard();auto phases=tseed(input,input+16);auto v=invariants(phases);
 T comparison=complement(v);double*q=output;
 put(fullbound(v[0]),q);put(fullbound(v[1]),q);put(fullbound(stableR2(v[0],v[1],v[2])),q);put(fullbound(comparison),q);
 array<double,4>scores={0,0,0,0};double total=0;
 for(int k=1;k<basis.n;k++)for(int i=0;i<4;i++)if(basis.e[k][i])scores[i]+=mag(comparison.a[k].re);
 for(double z:scores)total+=z;
 for(double z:scores)*q++=total>0?z/total:0;
 if(derivatives){
  // AD on complete phase rectangles bounds actual angular derivatives.
  // We never differentiate the unstructured Taylor remainder.
  array<J,4>box;
  for(int i=0;i<4;i++){box[i]=J(phases[i].range());box[i].d[i]=ii*box[i].v;}
  J f=complement(invariants(box));for(const C&x:f.d)put(x.re,q);
 }else for(int i=0;i<8;i++)*q++=0;
 return int(q-output);
 }catch(const NativeBudget&){return -2;}catch(...){return -1;}}

// A constant rational complex vector contracts a necessary Hermitian pencil.
// Matrix upper entries are z0,z1,z2, with determinant term z0*z2*conj(z1).
static J ray_form(const J&diag,const array<J,3>&off,const array<C,3>&v){
 J value=diag*C(norm2(v[0])+norm2(v[1])+norm2(v[2]));
 int i[3]={0,0,1},j[3]={1,2,2};
 for(int k=0;k<3;k++)value=value+real(off[k]*(cj(v[i[k]])*v[j[k]]))*C(2);
 return real(value);
}
using Z=std::complex<double>;
static double mid(I x){return x.l/2+x.u/2;}
static Z cmid(C x){return Z(mid(x.re),mid(x.im));}
static array<C,3> proposal(double diag,array<Z,3>off){
 // Floating arithmetic only proposes a dyadic witness. All acceptance below
 // uses the outward contraction of that exact dyadic vector.
 Z m[3][3]={{diag,off[0],off[1]},{std::conj(off[0]),diag,off[2]},{std::conj(off[1]),std::conj(off[2]),diag}};
 double shift=std::abs(diag)+2*(std::abs(off[0])+std::abs(off[1])+std::abs(off[2]))+1;
 array<Z,3>v={Z(1,0),Z(.5,.25),Z(-.25,.5)};
 for(int k=0;k<32;k++){
  array<Z,3>w;double scale=0;
  for(int i=0;i<3;i++){w[i]=shift*v[i];for(int j=0;j<3;j++)w[i]-=m[i][j]*v[j];scale=std::max(scale,std::abs(w[i]));}
  if(!(scale>0&&std::isfinite(scale)))break;
  for(int i=0;i<3;i++)v[i]=w[i]/scale;
 }
 array<C,3>out;for(int i=0;i<3;i++)out[i]=C(I(std::round(v[i].real()*1048576.)/1048576.),I(std::round(v[i].imag()*1048576.)/1048576.));
 return out;
}
// Output R interval, then36 records of [j,sigma,eps,vector6,A2,B2].
// The contracted pencil is A+qB, valid on the entire angular input box.
extern "C" int advanced_rays(const double*input,double*output){try{
 advanced_guard();budget_check();auto tm=tseed(input,input+16);
 array<J,4>center,box;
 for(int i=0;i<4;i++){
  C cv(I(input[4*i],input[4*i+1]),I(input[4*i+2],input[4*i+3]));
  center[i]=J(cv);box[i]=J(tm[i].range());center[i].d[i]=ii*cv;box[i].d[i]=ii*box[i].v;
  for(int k=0;k<10;k++)if(HI[k]==i&&HJ[k]==i){center[i].h[k]=-cv;box[i].h[k]=-box[i].v;}
 }
 auto ec=expressions(center,true,false),eb=expressions(box,true,false);
 auto ivs=invariants(tm);I rb=fullbound(stableR2(ivs[0],ivs[1],ivs[2]));
 double*out=output;put(rb,out);if(rb.u<=0)return 2;
 I qr=root(I(std::max(0.,rb.l),rb.u));
 for(int j=0;j<3;j++)for(int sg:{-1,1})for(int ep:{-1,1})for(double qp:{qr.l,mid(qr),qr.u}){
  budget_check();array<Z,3>off;
  for(int k=0;k<3;k++)off[k]=cmid(ec.gram[k].v)*qp+double(ep)*(cmid(ec.nf[j][k+1].a.v)+cmid(ec.nf[j][k+1].b.v)*(sg*qp));
  double diag=mid(ec.scale.v.re)*3*qp+ep*(mid(ec.nf[j][0].a.v.re)+sg*qp*mid(ec.nf[j][0].b.v.re));
  auto v=proposal(diag,off);
  auto forms=[&](const Expressions&e){
   array<J,3>a,b;for(int k=0;k<3;k++){a[k]=e.nf[j][k+1].a*C(ep);b[k]=e.gram[k]+e.nf[j][k+1].b*C(ep*sg);}
   return array<J,2>{ray_form(e.nf[j][0].a*C(ep),a,v),ray_form(e.scale*C(3)+e.nf[j][0].b*C(ep*sg),b,v)};
  };
  auto fc=forms(ec),fb=forms(eb);*out++=j;*out++=sg;*out++=ep;
  for(C x:v){*out++=x.re.l;*out++=x.im.l;}
  put(taylor_part(fc[0],fb[0],input+16,false),out);put(taylor_part(fc[1],fb[1],input+16,false),out);
 }
 return int(out-output);
 }catch(const NativeBudget&){return -2;}catch(...){return -1;}}

// Independent rational control hook for the contraction itself.
extern "C" int advanced_ray_control(const double*input,double*output){try{
 J d{C(I(input[0]))};array<J,3>off;array<C,3>v;
 for(int i=0;i<3;i++){off[i]=J(C(I(input[1+2*i]),I(input[2+2*i])));v[i]=C(I(input[7+2*i]),I(input[8+2*i]));}
 double*q=output;put(ray_form(d,off,v).v.re,q);return 2;
 }catch(...){return -1;}}

// Protocol control: four interval pairs Dh,Dv,Ah,Av -> nonnegative RHS pair.
// This calls the same helper as local_region's A-elimination branch.
extern "C" int advanced_elimination_control(const double*input,double*output){try{
 advanced_guard();const double*p=input;
 I dh=readI(p),dv=readI(p),ah=readI(p),av=readI(p);double*q=output;
 put(elimination_rhs(dh,dv,ah,av),q);return int(q-output);
 }catch(...){return -1;}}
