"""Bounded certificate hints and certified ancestor partials.

A cached recipe is never transported as a proof.  Each of the 16 D8 coordinate
permutations with global negation proposes a box for fresh evaluation/replay.
Only exact rational containment can then transfer whole-box exclusion to the
requested leaf.  Thus no unproved coordinate symmetry is used.
"""
from fractions import Fraction as Q
from pathlib import Path
import collections
import fcntl
import json
import os
import time

if __package__:
    from . import task_queue as tq
else:
    import task_queue as tq

MAX_PARTIAL_BYTES = 2 * 2**20
MAX_PARTIAL_RECORDS = 128
MAX_CONTRIBUTORS = 16
CACHE_SHARDS = 16
CACHE_ROWS = 256
MAX_HINT_BYTES = 16384


def contains(outer, inner):
    if outer.get("units") != "radians" or inner.get("units") != "radians":
        return False
    try:
        oc, oo = list(map(Q, outer["centers"])), list(map(Q, outer["radii"]))
        ic, ii = list(map(Q, inner["centers"])), list(map(Q, inner["radii"]))
    except (KeyError, ValueError, TypeError, ZeroDivisionError):
        return False
    return (len(oc) == len(oo) == len(ic) == len(ii) == 4
            and all(o > 0 and i > 0 and abs(a - b) + i <= o
                    for a, b, o, i in zip(oc, ic, oo, ii)))


def sign_boxes(box):
    cc, rr = list(map(Q, box["centers"])), list(map(Q, box["radii"]))
    generators = ((2, 3, 0, 1), (1, 0, 3, 2), (0, 2, 1, 3))
    group, todo = {(0, 1, 2, 3)}, [(0, 1, 2, 3)]
    while todo:
        perm = todo.pop()
        for gen in generators:
            nxt = tuple(perm[i] for i in gen)
            if nxt not in group:
                group.add(nxt)
                todo.append(nxt)
    if len(group) != 8:
        raise ArithmeticError("Unexpected D8 coordinate proposal group")
    for perm in sorted(group):
        for sign in (-1, 1):
            yield {"centers": [str(cc[i]*sign) for i in perm],
                   "radii": [str(rr[i]) for i in perm], "units": "radians"}


def _bucket(box):
    # Coarse absolute centers keep the sixteen sign variants in one bounded
    # shard.  A cache miss only costs performance, never proof coverage.
    cells = sorted(int(abs(Q(q))*4) for q in box["centers"])
    return int(tq.digest(cells)[:8], 16) % CACHE_SHARDS


class CertificateHints:
    def __init__(self, area):
        self.place = Path(area) / "reuse_hints"
        # The old shared SQLite files are preserved, but are no longer read.
        # A hint only proposes a fresh evaluation; it is never proof evidence.
        self.files = self.place / "atomic-v1"
        self.local = collections.OrderedDict()
        self.last_write = float("-inf")
        self.last_read = {}

    def _remember(self, hint):
        sha = tq.digest(hint)
        self.local[sha] = hint
        self.local.move_to_end(sha)
        while len(self.local) > 128:
            self.local.popitem(last=False)

    def _directory(self, bucket, create=False):
        directory = self.files / ("%02x" % bucket)
        if any(p.is_symlink() for p in (self.place, self.files, directory)):
            raise OSError("Optional hint cache contains a directory alias")
        if create:
            directory.mkdir(parents=True, exist_ok=True)
        return directory

    @staticmethod
    def _valid_hint(hint):
        return (isinstance(hint, dict)
                and set(hint) == {"method", "input", "provider_hashes", "recipe_sha256"}
                and isinstance(hint["method"], str) and bool(hint["method"])
                and isinstance(hint["provider_hashes"], dict)
                and isinstance(hint["recipe_sha256"], str)
                and len(hint["recipe_sha256"]) == 64
                and all(c in tq.SHARDS for c in hint["recipe_sha256"])
                and isinstance(hint["input"], dict)
                and contains(hint["input"], hint["input"]))

    @staticmethod
    def _entries(directory):
        """Bounded metadata only; never materialize an arbitrary directory."""
        result = []
        with os.scandir(directory) as entries:
            for index, entry in enumerate(entries):
                if index >= CACHE_ROWS * 4:
                    raise ValueError("Optional hint directory exceeds scan bound")
                if (len(entry.name) != 69 or not entry.name.endswith(".json")
                        or any(c not in tq.SHARDS for c in entry.name[:64])
                        or not entry.is_file(follow_symlinks=False)):
                    continue
                try:
                    stamp = entry.stat(follow_symlinks=False).st_mtime_ns
                except FileNotFoundError:
                    continue  # A concurrent writer pruned this optional hint.
                result.append((stamp, entry.name))
        return sorted(result, reverse=True)

    def _read(self, directory):
        # Populate oldest first so process-local LRU favors the newest hint.
        for _, name in reversed(self._entries(directory)[:128]):
            path = directory / name
            try:
                if path.is_symlink():
                    continue
                hint = tq.read_json(path, limit=MAX_HINT_BYTES + 1)
                if (not self._valid_hint(hint) or len(tq.canonical(hint)) > MAX_HINT_BYTES
                        or tq.digest(hint) != name[:-5]):
                    continue
                self._remember(hint)
            except (OSError, ValueError, TypeError, KeyError):
                # Missing, truncated, or malformed optional data is a miss.
                # Authoritative checkpoints and replay are outside this code.
                continue

    def add(self, recipe):
        if recipe.get("method") == "pooled_signs":
            return  # Regenerating a pool is not a cheap candidate-box proposal.
        hint = {"method": recipe["method"], "input": recipe["input"],
                "provider_hashes": recipe["provider_hashes"], "recipe_sha256": tq.digest(recipe)}
        raw = tq.canonical(hint)
        if len(raw) > MAX_HINT_BYTES:
            return
        if not self._valid_hint(hint):
            raise ValueError("Malformed generated certificate hint")
        self._remember(hint)
        if time.monotonic() - self.last_write < 30:
            return
        self.last_write = time.monotonic()
        lock = None
        try:
            directory = self._directory(_bucket(hint["input"]), create=True)
            lock_path = directory / "WRITE.lock"
            if lock_path.is_symlink():
                return
            lock = lock_path.open("a")
            # Cache contention is a miss, never a reason to stall a worker.
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            tq.durable_json(directory / (tq.digest(hint) + ".json"), hint)
            for _, name in self._entries(directory)[CACHE_ROWS:]:
                (directory / name).unlink(missing_ok=True)
        except (OSError, ValueError):
            # Only optional cache IO is contained. Memory/disk guards in the
            # worker, and authoritative evidence IO, retain their fatal paths.
            pass
        finally:
            if lock is not None:
                lock.close()

    def candidates(self, geometry, allowed_methods, limit=4):
        if not 0 <= limit <= 16:
            raise ValueError("Unbounded reuse lookup")
        if limit == 0:
            return []
        result, seen = [], set()
        try:
            bucket = _bucket(geometry)
            directory = self._directory(bucket)
            if directory.is_dir() and time.monotonic() - self.last_read.get(bucket, float("-inf")) >= 15:
                self.last_read[bucket] = time.monotonic()
                self._read(directory)
        except (OSError, ValueError):
            pass  # Retain useful process-local hints if shared storage misses.
        for hint in reversed(list(self.local.values())):
            if hint["method"] not in allowed_methods:
                continue
            for actual in sign_boxes(hint["input"]):
                sha = tq.digest(actual)
                if sha in seen or not contains(actual, geometry):
                    continue
                seen.add(sha)
                result.append({**hint, "input": actual})
                if len(result) >= limit:
                    return result
        return result


def pool_may_close(records):
    """Untrusted cheap scheduling hint; the provider verifies actual coverage."""
    masks = {False: set(), True: set()}
    non_tao = False
    for record in records:
        partial = record.get("partial", {})
        if partial.get("all_excluded") is True or record.get("ok") is True:
            return True
        non_tao |= partial.get("non_tao") is True
        for item in partial.get("exclusions", ()):
            orientation, sigma = item.get("orientation"), item.get("sigma")
            if type(orientation) is bool and type(sigma) is int:
                masks[orientation].add(sigma)
    matched = {-s if orientation else s for orientation, values in masks.items() for s in values}
    return any({-1, 1} <= values for values in masks.values()) or (non_tao and {-1, 1} <= matched)


class PartialStore:
    def __init__(self, state):
        self.state = state
        self.records = state.setdefault("partial_records", {})
        self.paths = state.setdefault("partial_paths", {})
        if len(self.records) > MAX_PARTIAL_RECORDS or sum(len(tq.canonical(r)) for r in self.records.values()) > MAX_PARTIAL_BYTES:
            raise ValueError("Partial checkpoint exceeds its bounded store")
        for refs in self.paths.values():
            if not isinstance(refs, list) or len(refs) > MAX_CONTRIBUTORS or any(sha not in self.records for sha in refs):
                raise ValueError("Invalid partial checkpoint index")
        for sha, record in self.records.items():
            if sha != tq.digest(record):
                raise ValueError("Partial checkpoint evidence changed")

    def add(self, path, record):
        partial = record.get("partial", {})
        if partial.get("schema") != "survivor-partial-signs-v1" or not (partial.get("exclusions") or partial.get("non_tao") or partial.get("all_excluded")):
            return False
        # The provider checks full witness pins again during composition.
        # This store does not convert a partial into a C acceptance itself.
        raw, sha = tq.canonical(record), tq.digest(record)
        if len(raw) > MAX_PARTIAL_BYTES // 4:
            return False
        refs = self.paths.setdefault(path, [])
        if sha in refs or len(refs) >= MAX_CONTRIBUTORS:
            return False
        if sha not in self.records:
            if len(self.records) >= MAX_PARTIAL_RECORDS or sum(len(tq.canonical(r)) for r in self.records.values()) + len(raw) > MAX_PARTIAL_BYTES:
                return False
            self.records[sha] = record
        refs.append(sha)
        return True

    def candidates(self, path, geometry):
        result, seen = [], set()
        # Prefer local evidence, then containing ancestor evidence.
        for end in range(len(path), -1, -1):
            for sha in self.paths.get(path[:end], ()):
                record = self.records[sha]
                if sha not in seen and contains(record.get("input", {}), geometry):
                    result.append(record)
                    seen.add(sha)
                    if len(result) >= MAX_CONTRIBUTORS:
                        return result
        return result

    def prune(self, pending_paths):
        # At most 4095 frontier paths and 128 partial records.  Called on
        # checkpoints only; accepted leaves never depend on this hint store.
        alive = [p for p in self.paths if any(q.startswith(p) for q in pending_paths)]
        self.paths = {p: self.paths[p] for p in alive}
        used = {sha for refs in self.paths.values() for sha in refs}
        self.records = {sha: self.records[sha] for sha in used}
        self.state["partial_paths"], self.state["partial_records"] = self.paths, self.records
