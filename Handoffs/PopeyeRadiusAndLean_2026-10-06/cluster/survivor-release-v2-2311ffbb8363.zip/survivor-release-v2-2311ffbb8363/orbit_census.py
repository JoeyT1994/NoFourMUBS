"""Exact geometric census of committed roots; no symmetry proof admission.

The eight coordinate permutations come from row/column swaps and transpose.
Global conjugation doubles the group. The temporary index is disk-backed and
removed on completion; only the compact result needs to be retained.
"""
from fractions import Fraction as Q
from pathlib import Path
import argparse
import hashlib
import json
import sqlite3
import tempfile
import time

import task_queue as tq


def permutations():
    group = {(0, 1, 2, 3)}
    pending = [(0, 1, 2, 3)]
    generators = ((2, 3, 0, 1), (1, 0, 3, 2), (0, 2, 1, 3))
    while pending:
        p = pending.pop()
        for q in generators:
            composed = tuple(p[q[i]] for i in range(4))
            if composed not in group:
                group.add(composed)
                pending.append(composed)
    if len(group) != 8:
        raise ValueError('Wrong finite coordinate group')
    return sorted(group)


def keys(geometry):
    cc, rr = tuple(map(Q, geometry['centers'])), tuple(map(Q, geometry['radii']))
    if len(cc) != 4 or len(rr) != 4 or any(r <= 0 for r in rr):
        raise ValueError('Invalid exact box')
    def encode(p, sign):
        return tq.canonical({'centers': [str(sign*cc[i]) for i in p],
                             'radii': [str(rr[i]) for i in p]})
    original = encode((0, 1, 2, 3), 1)
    conjugacy = min(original, encode((0, 1, 2, 3), -1))
    orbit = min(encode(p, sign) for p in permutations() for sign in (-1, 1))
    return tuple(hashlib.sha256(value).hexdigest() for value in (original, conjugacy, orbit))


def census(area, output, limit=100000):
    queue = tq.TaskQueue(area)
    tq.resource_guard(queue.area)
    config_sha = tq.sha_file(queue.area/'CONFIG.json')
    started = time.time()
    observed_tasks = 0
    with tempfile.TemporaryDirectory(prefix='orbit-census-', dir=queue.area) as temporary:
        db = sqlite3.connect(Path(temporary)/'index.sqlite')
        try:
            db.execute('PRAGMA cache_size=-4096')
            db.execute('CREATE TABLE boxes (id INTEGER PRIMARY KEY, input_sha TEXT, geometry TEXT, conjugacy TEXT, orbit TEXT)')
            for path in queue.iter_task_dirs():
                task = tq.read_json(path/'TASK.json')
                if not (queue.area/'batches'/f"{task['source_batch']:06d}.json").is_file():
                    continue
                observed_tasks += 1
                if observed_tasks > limit:
                    raise ValueError('Census exceeds its explicit task bound')
                key = keys(task['root_geometry'])
                previous = db.execute('SELECT input_sha,geometry FROM boxes WHERE id=?', (task['original_id'],)).fetchone()
                if previous is not None:
                    if previous != (task['input_sha256'], key[0]):
                        raise ValueError('Conflicting geometry for one original root')
                else:
                    db.execute('INSERT INTO boxes VALUES (?,?,?,?,?)', (task['original_id'], task['input_sha256'], *key))
            count, conjugacy, orbits = db.execute('SELECT COUNT(*),COUNT(DISTINCT conjugacy),COUNT(DISTINCT orbit) FROM boxes').fetchone()
        finally:
            db.close()
    if tq.sha_file(queue.area/'CONFIG.json') != config_sha:
        raise ValueError('Queue configuration changed during census')
    result = dict(status='EXACT_GEOMETRY_CENSUS', scope='Committed imported original roots encountered; concurrent imports may add roots. No certificate transport or physical exclusion.',
                  unique_roots=count, conjugacy_classes=conjugacy, box_symmetry_classes=orbits,
                  extra_exact_duplicates_beyond_conjugation=conjugacy-orbits, observed_tasks=observed_tasks,
                  queue_config_sha256=config_sha, started_unix=started, finished_unix=time.time(),
                  physical_lean_admissions=0)
    tq.durable_json(Path(output), result)
    print(json.dumps(result, sort_keys=True))
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--queue', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--max-tasks', type=int, default=100000)
    args = parser.parse_args()
    if not 1 <= args.max_tasks <= 100000:
        parser.error('Census needs an explicit bounded task limit')
    census(args.queue, args.output, args.max_tasks)
