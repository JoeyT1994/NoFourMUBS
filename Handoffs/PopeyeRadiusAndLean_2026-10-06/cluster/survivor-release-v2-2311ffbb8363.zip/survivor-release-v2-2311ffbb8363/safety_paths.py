"""Bounded safety-file membership checks without negative leaf stat calls.

Callers supply existing, independently verified anchors.  Requested paths are
normalized lexically only.  Directory entries are inspected by name, never by
DirEntry.stat/is_file/is_dir.  Missing intermediate names terminate traversal.
Listing errors and bounds propagate; no error is converted to guard absence.
"""
from collections import OrderedDict
from pathlib import Path
import errno
import math
import os
import time

if __package__:
    from . import node_safety_cache
else:
    import node_safety_cache

MAX_ENTRIES = 4096
MAX_DIRECTORIES = 16
MAX_PATHS = 64
MAX_ANCHORS = 8
MAX_LATCHES = 64
MAX_ANCHOR_SETS = 64
MAX_CHECK_DIRECTORIES = 32
MAX_NEGATIVE_TTL = 0.25


class SafetyPathLimit(ValueError):
    """A bounded safety check could not establish absence; fail closed."""


def absolute(path):
    """Lexical normalization only: never resolve/lstat a requested guard path."""
    return Path(os.path.abspath(os.fspath(path)))


class SafetyPaths:
    def __init__(self, ttl=MAX_NEGATIVE_TTL, clock=None, scanner=None, node_cache=None):
        if isinstance(ttl, bool) or not isinstance(ttl, (int, float)) or not math.isfinite(ttl) or not 0 <= ttl <= MAX_NEGATIVE_TTL:
            raise ValueError("Safety negative TTL must be within 0 through 0.25 seconds")
        self.ttl = float(ttl)
        self.clock = time.monotonic if clock is None else clock
        self.scanner = os.scandir if scanner is None else scanner
        self.directories = OrderedDict()
        self.stops = {}
        self.anchor_sets = {}
        self.node_cache = node_cache
        # Test scanners/clocks never silently consume a real process cache.
        self._environment_enabled = clock is None and scanner is None and node_cache is None
        self._stats = {"local_hits": 0, "refreshes": 0, "slow_refreshes": 0}

    def _backend(self):
        if self._environment_enabled:
            config = node_safety_cache.environment_config()
            if self.node_cache is None and config is not None:
                self.node_cache = node_safety_cache.NodeDirectoryCache(*config, Path(__file__).parent)
            elif self.node_cache is not None and config != self.node_cache.config:
                raise ValueError("Node-local safety cache configuration changed in a live process")
        return self.node_cache

    def statistics(self):
        shared = self.node_cache is not None
        values = dict(self._stats)
        values.update(shared_enabled=shared, shared_hits=0, lock_waits=0)
        if shared:
            for name, value in self.node_cache.stats.items():
                values[name] = values.get(name, 0) + value
        return values

    def verified_anchors(self, root, area):
        """Verify direct guard parents once, retaining ancestor fallback.

        Root and area are already verified anchors supplied by the caller.
        Only successful O_DIRECTORY opens add more specific anchors.  Missing
        optional parents are not cached as absent: every subsequent membership
        check still discovers them through the nearest existing ancestor.
        A verified parent disappearing makes its later scan fail closed.
        """
        key = self._key((root, area))
        if key in self.anchor_sets:
            return self.anchor_sets[key]
        if len(self.anchor_sets) >= MAX_ANCHOR_SETS:
            raise SafetyPathLimit("Safety verified anchor bound exhausted")
        root, area = key
        anchors = list(key)
        flags = os.O_RDONLY | os.O_DIRECTORY | getattr(os, "O_CLOEXEC", 0)
        for path in (root / "production", root / "elastic-run", root / "elastic-run/output", area):
            try:
                descriptor = os.open(path, flags)
            except OSError as error:
                if error.errno in (errno.ENOENT, errno.ENOTDIR):
                    continue
                raise
            else:
                os.close(descriptor)
                if path not in anchors:
                    anchors.append(path)
        # A failed verification never commits a partial trusted anchor set.
        result = tuple(anchors)
        self.anchor_sets[key] = result
        return result

    def _entries(self, path, fresh=False):
        backend = self._backend()
        if backend is not None:
            # Read shared state on every call. A failed forced refresh in one
            # process must invalidate another process's previous negative too.
            value, deadline = backend.entries(path, lambda: self._scan(path), self.clock, self.ttl, fresh=fresh)
            return value
        now = self.clock()
        cached = self.directories.get(path)
        if not fresh and cached is not None and now < cached[0]:
            self._stats["local_hits"] += 1
            self.directories.move_to_end(path)
            return cached[1]
        # A failed forced scan must not expose an older still-valid negative
        # snapshot to the next normal check.
        self.directories.pop(path, None)
        # Deadline begins before enumeration, so a slow successful listing
        # cannot extend negative freshness after it finally returns.
        began = now
        self._stats["refreshes"] += 1
        value = self._scan(path)
        if self.clock() >= began + self.ttl:
            self._stats["slow_refreshes"] += 1
        # Commit only a complete successful scan.  An exception leaves no new
        # negative cache deadline; an immediate retry must scan/raise again.
        self.directories[path] = (began + self.ttl, value)
        self.directories.move_to_end(path)
        while len(self.directories) > MAX_DIRECTORIES:
            self.directories.popitem(last=False)
        return value

    def _scan(self, path):
        names = set()
        with self.scanner(path) as entries:
            for count, entry in enumerate(entries):
                if count >= MAX_ENTRIES:
                    raise SafetyPathLimit("Safety directory exceeds 4096 entries: " + str(path))
                name = entry.name
                if not isinstance(name, str) or len(os.fsencode(name)) > 1024:
                    raise SafetyPathLimit("Invalid or oversized safety directory entry")
                names.add(name)
        return frozenset(names)

    def present(self, paths, anchors, fresh=False):
        """Return normalized requested paths whose names are present.

        Each shared parent is listed at most once in this call.  An ancestor
        missing from a verified parent's listing is absent without opening or
        statting that missing path.  Positive membership is a guard hint;
        callers latch actual stops after applying their policy exceptions.
        """
        paths = list(paths)
        anchors = list(anchors)
        if not 1 <= len(anchors) <= MAX_ANCHORS or len(paths) > MAX_PATHS:
            raise SafetyPathLimit("Unbounded safety path/anchor request")
        anchors = sorted(set(map(absolute, anchors)), key=lambda p: len(p.parts), reverse=True)
        roots = {}
        for path in paths:
            path = absolute(path)
            anchor = next((a for a in anchors if path.is_relative_to(a)), None)
            if anchor is None:
                raise ValueError("Safety path lies outside verified anchors: " + str(path))
            relative = path.relative_to(anchor).parts
            if not relative or len(relative) > 16:
                raise SafetyPathLimit("Safety target must be a bounded descendant of an anchor")
            node = roots.setdefault(anchor, {})
            for name in relative:
                node = node.setdefault(name, {})
            node.setdefault(None, set()).add(path)
        present, scanned = set(), {}
        todo = list(roots.items())
        while todo:
            directory, node = todo.pop()
            if directory not in scanned:
                if len(scanned) >= MAX_CHECK_DIRECTORIES:
                    raise SafetyPathLimit("Safety check exceeds 32 directory listings")
                scanned[directory] = self._entries(directory, fresh=fresh)
            names = scanned[directory]
            for name, child in node.items():
                if name not in names:
                    continue
                target = directory / name
                present.update(child.get(None, ()))
                if any(key is not None for key in child):
                    todo.append((target, {k:v for k,v in child.items() if k is not None}))
        return present

    @staticmethod
    def _key(key):
        values = tuple(map(absolute, key))
        if len(values) != 2:
            raise ValueError("Safety stop latch requires (root, area)")
        return values

    def latched(self, key):
        return self.stops.get(self._key(key))

    def latch(self, key, reason="stop_requested"):
        key = self._key(key)
        if key not in self.stops and len(self.stops) >= MAX_LATCHES:
            raise SafetyPathLimit("Safety stop latch bound exhausted")
        self.stops.setdefault(key, str(reason))
        return self.stops[key]


_DEFAULT = SafetyPaths()


def present(paths, anchors, fresh=False):
    return _DEFAULT.present(paths, anchors, fresh=fresh)
