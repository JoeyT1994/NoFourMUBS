"""Cancellation-preserving radial circuit; conditional numerical evidence only.

The rho^25-normalized H intervals have the same sign as physical H:
R=rho^4 Rbar, Delta=rho^12 Dbar, A=rho^12 Abar, B=rho^10 Bbar,
H=rho^25 Hsecant.  The exact secant operations happen before Taylor truncation.
Native arithmetic and physical moment transport are not Lean admissions.
"""
from fractions import Fraction as Q
from pathlib import Path
import ctypes
import fcntl
import hashlib
import importlib.util
import json
import math
import os
import subprocess
import time

HERE = Path(__file__).resolve().parent
METHOD = "cancellation_order4"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _chart_module():
    path = HERE / "normalized_provider.py"
    spec = importlib.util.spec_from_file_location("cancellation_chart_helpers", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class Provider:
    """One main-thread evaluator per worker; shared native state is not reentrant."""
    def __init__(self, root, cache, frozen):
        self.root, self.cache, self.c = Path(root), Path(cache), frozen
        self.chart_module = _chart_module()
        frozen.guard()
        source = HERE / "cancellation_engine.cpp"
        common = {"cancellation_native_source_sha256": sha(source),
                  "cancellation_provider_sha256": sha(__file__),
                  "cancellation_chart_helper_sha256": sha(self.chart_module.__file__),
                  "frozen_driver_sha256": sha(frozen.__file__),
                  "taylor_source_sha256": sha(frozen.MODULE / "taylor.hpp"),
                  "interval_source_sha256": sha(frozen.MODULE.parent / "SignedCornerPSDPrune/engine.cpp"),
                  "determinant_terms_sha256": sha(frozen.MODULE.parent / "SignedCornerPSDPrune/determinant_terms.hpp")}
        key = hashlib.sha256(json.dumps(common, sort_keys=True).encode()).hexdigest()[:24]
        directory = self.cache / ("cancellation-" + key)
        directory.mkdir(parents=True, exist_ok=True)
        target = directory / (METHOD + ".so")
        receipt = target.with_suffix(".build.json")
        with target.with_suffix(".lock").open("a") as lock:
            fcntl.flock(lock, fcntl.LOCK_EX)
            if not target.exists():
                tmp = target.with_name(target.name + "." + str(os.getpid()) + ".tmp.so")
                cmd = ["c++", "-std=c++17", "-O3", "-fno-fast-math", "-ffp-contract=off",
                       "-fPIC", "-shared", "-DTM_ORDER=4", str(source), "-o", str(tmp)]
                try:
                    frozen.guard()
                    subprocess.run(cmd, check=True, capture_output=True, text=True, timeout=60)
                    info = dict(common, order=4, binary_sha256=sha(tmp), command=cmd,
                                compiler=subprocess.check_output(["c++", "--version"], text=True).splitlines()[0])
                    os.replace(tmp, target)
                    receipt.write_text(json.dumps(info, indent=2) + "\n")
                finally:
                    tmp.unlink(missing_ok=True)
            info = json.loads(receipt.read_text())
            if info.get("order") != 4 or any(info.get(k) != v for k, v in common.items()) or info.get("binary_sha256") != sha(target):
                raise ValueError("Cancellation build receipt mismatch")
        self.lib = ctypes.CDLL(str(target))
        dp = ctypes.POINTER(ctypes.c_double)
        self.lib.cancellation_region.argtypes = [dp, dp]
        self.lib.cancellation_region.restype = ctypes.c_int
        self.lib.set_budget.argtypes = [ctypes.c_double]
        self.lib.set_budget.restype = None
        self.pins = {METHOD: {k:v for k,v in info.items() if k.endswith("sha256")}}

    def _data(self, centers, radii, info, perm):
        c = self.c
        def pairs(values):
            return [c.down(values[0]), c.up(values[1]), c.down(values[2]), c.up(values[3])]
        return (sum((c.phase(centers[k]) for k in perm), []) + [c.up(radii[k]) for k in perm]
                + sum((pairs(info["deltas"][k]) for k in perm), [])
                + sum((pairs(info["roots"][k]) for k in perm), []) + [float(info["rho"])])

    def native(self, data, deadline, budget_error):
        remaining = deadline - time.process_time()
        if remaining <= 0:
            raise budget_error("cpu_budget")
        self.lib.set_budget(remaining)
        out = (ctypes.c_double*38)()
        status = self.lib.cancellation_region((ctypes.c_double*53)(*data), out)
        if status == -2:
            raise budget_error("native_cpu_budget")
        if status != 38:
            raise ArithmeticError("Cancellation arithmetic status " + str(status))
        co = list(out)
        if not all(math.isfinite(x) for x in co) or any(co[k] > co[k+1] for k in range(0,34,2)):
            raise ArithmeticError("Malformed cancellation native intervals")
        return co

    def evaluate(self, centers, radii, deadline, budget_error):
        info = self.chart_module.chart(centers, radii)
        if info is None:
            return dict(ok=False, reason="cancellation_chart_outside_neighborhood",
                        axis=max(range(4), key=lambda k:radii[k]))
        rho = info["rho"]
        providers, seen, scores = [], set(), [0.0]*4
        for tr in (False, True):
            perm = (0, 2, 1, 3) if tr else (0, 1, 2, 3)
            co = self.native(self._data(centers, radii, info, perm), deadline, budget_error)
            # linear_signs uses only the signs of H. The positive rho divisor
            # is harmless; coefficient_scaling explicitly records the change.
            signs, why = self.c.linear_signs(co)
            providers.append(dict(transpose=tr, coefficients=co[:34], signs=sorted(signs), reason=why))
            if len(signs) == 2:
                verdict = dict(ok=True, reason=why)
                break
            if Q(co[1]) * rho**4 < 243:
                seen.update(-s if tr else s for s in signs)
            if seen == {-1, 1}:
                verdict = dict(ok=True, reason="coupled_cancellation_means_non_Tao")
                break
            for i,k in enumerate(perm):
                scores[k] += co[34+i]
        else:
            axis = max(range(4), key=lambda k:(scores[k],radii[k]))
            total = sum(scores)
            verdict = dict(ok=False, reason="unresolved_cancellation_mean", axis=axis,
                           split_diagnostic={"axis":axis,"score":max(scores)/total if total>0 else 0.0,
                                             "kind":"cancellation_influence","influences":scores,
                                             "acceptance_role":"none"})
        verdict.update(providers=providers, order=4,
                       normalization={"rho":str(rho), "seed_imaginary_signs":list(info["signs"]),
                                      "angular_distance_bound":str(info["angular_distance_bound"]),
                                      "coefficient_scaling":{"R":4,"Delta":12,"A":12,"B":10,"H":25},
                                      "coefficient_domain":"Rbar,Dbar,Abar,Bbar+-3rho^2Dbar,Hbar/rho",
                                      "secant_rewrite":"U=-S-conj(T)+rho*Udef; A=-18*Im(S*T)*B+rho*D; R=324*Im(S*T)^2+rho*Rdef"})
        return verdict
