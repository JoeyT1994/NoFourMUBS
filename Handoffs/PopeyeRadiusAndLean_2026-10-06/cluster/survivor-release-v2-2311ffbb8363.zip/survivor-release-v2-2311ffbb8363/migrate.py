"""Explicit stopped-checkpoint v1 -> v2 migration; no Slurm operations.

The controller must first verify obsolete coordinator/worker jobs disappeared.
This helper independently checks local flock barriers, preserves every encoded
forest/C recipe, leaves parked/done states byte unchanged, and journals each
queued/running state edit before atomically replacing it.  Original elastic
source workers and frozen source packets are not modified.
"""
from contextlib import contextmanager
from pathlib import Path
import argparse
import fcntl
import hashlib
import json
import os
import sqlite3

if __package__:
    from . import task_queue as tq, worker
    from .runtime import release_pins
    from .completion import seed as seed_completed
    from .parent_roots import seed_root
else:
    import task_queue as tq
    import worker
    from runtime import release_pins
    from completion import seed as seed_completed
    from parent_roots import seed_root

TERMINAL = {"ABSENT", "COMPLETED", "CANCELLED", "FAILED", "TIMEOUT", "PREEMPTED", "NODE_FAIL", "OUT_OF_MEMORY", "BOOT_FAIL"}
OPERATIONS = ("LAUNCH.json", "VALIDATION_PASS.json", "COORDINATOR_SUBMISSION.json", "CONTINUOUS_REPLAY.json",
              "CONTINUATION_STATUS.json", "COORDINATOR_STATUS.json", "FINAL_AUDIT.json", "CLOSED_NATIVE_IDS.jsonl.gz", "submissions")


@contextmanager
def free_lock(path):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a") as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("Cutover blocked by a live lock: " + str(path)) from error
        yield


def _node_locks(queue):
    nodes = queue.area / "nodes"
    if nodes.is_dir():
        with os.scandir(nodes) as entries:
            for entry in entries:
                if entry.is_dir(follow_symlinks=False):
                    with free_lock(Path(entry.path) / "RUN.lock"):
                        pass


def _submission_ids(place):
    path = place / "submissions"
    if path.is_dir():
        with os.scandir(path) as entries:
            for entry in entries:
                if entry.is_file(follow_symlinks=False) and entry.name.endswith(".json"):
                    value = tq.read_json(entry.path)
                    if "job_id" not in value:
                        raise ValueError("Ambiguous old submission cannot be migrated")
                    yield str(value["job_id"])
    path = place / "COORDINATOR_SUBMISSION.json"
    if path.exists():
        value = tq.read_json(path)
        if "job_id" in value:
            yield str(value["job_id"])


def verify_stop(queue, evidence, old_sha, archive=None):
    if (evidence.get("schema") != "survivor-cutover-stop-v2"
            or evidence.get("old_release_sha256") != old_sha
            or any(evidence.get(flag) is not True for flag in
                   ("coordinator_stopped", "workers_stopped", "source_workers_untouched"))):
        raise ValueError("Explicit verified coordinator/worker stop receipt is required")
    jobs = evidence.get("obsolete_jobs")
    if not isinstance(jobs, list) or not 1 <= len(jobs) <= 16384:
        raise ValueError("Stop receipt needs a bounded obsolete-job census")
    ids = set()
    for job in jobs:
        ident = job.get("job_id")
        if (not isinstance(ident, (str, int)) or str(ident) in ids
                or job.get("state") not in TERMINAL):
            raise ValueError("Obsolete job is live, duplicated, or unverified")
        ids.add(str(ident))
    expected = set(_submission_ids(queue.area))
    if archive is not None:
        expected.update(_submission_ids(archive))
    if not expected <= ids:
        raise ValueError("Stop receipt omitted an old continuation submission")
    if any((queue.area / name).exists() for name in ("FAILURE.json", "STOP_REQUESTED.json")):
        raise ValueError("Migration cannot erase or override a continuation stop/failure")
    return ids


def _preserved(state):
    fields = ("roots", "proofs", "proof_records", "evidence_bytes", "added_nodes", "cpu_seconds", "replay_cpu_seconds")
    return tq.digest({key: state[key] for key in fields})


def _next_state(state, migration_id, schedule_sha):
    value = dict(state)
    history = list(state.get("stage_history", []))
    value["stage_history"] = history
    if len(history) >= 8:
        raise ValueError("Bounded continuation stage history exhausted")
    history.append({"migration_id": migration_id, "before_state_sha256": tq.digest(state),
                    "schedule_sha256": state.get("schedule_sha256"), "attempts": state["attempts"],
                    "cursor": state.get("cursor"), "status": state["status"], "reason": state["reason"]})
    value.update(status="queued", reason="explicit_migrated_checkpoint", attempts=0, schedule_sha256=schedule_sha)
    if value.get("cursor"):
        cursor = value["cursor"]
        value["cursor"] = {"prefix": cursor["prefix"], "path": cursor["path"], "method_index": 0,
                           "axis": cursor["axis"], "available_seen": False}
    if _preserved(value) != _preserved(state):
        raise ValueError("Migration changed existing numerical forest/evidence")
    return value


def _journal_task(queue, directory, db, migration_id, schedule_sha, fault=None):
    with free_lock(directory / "RUN.lock"):
        task, state = tq.read_json(directory / "TASK.json"), tq.read_json(directory / "STATE.json.gz")
        tq.validate_state(task, state)
        ident = task["task_id"]
        row = db.execute("SELECT before_sha,after_sha,preserved_sha,after_payload,old_lease,phase,status FROM tasks WHERE task_id=?", (ident,)).fetchone()
        if row is None:
            before = tq.digest(state)
            after_state = _next_state(state, migration_id, schedule_sha) if state["status"] in ("queued", "running") else state
            lease = directory / "LEASE.json"
            old_lease = tq.read_json(lease) if lease.exists() else None
            patch_fields = ("status", "reason", "attempts", "schedule_sha256", "cursor", "stage_history")
            patch = {k: after_state[k] for k in patch_fields} if state["status"] in ("queued", "running") else {}
            row = (before, tq.digest(after_state), _preserved(state), tq.canonical(patch).decode(),
                   json.dumps(old_lease), "INTENT", state["status"])
            db.execute("INSERT INTO tasks VALUES (?,?,?,?,?,?,?,?)", (ident, *row))
            db.commit()
            if fault:
                fault("intent", ident)
        before, after, preserved, payload, old_lease, phase, old_status = row
        sha = tq.digest(state)
        if sha not in (before, after) or _preserved(state) != preserved:
            raise ValueError("Checkpoint differs from both journaled migration states")
        mutable = old_status in ("queued", "running")
        if mutable and sha != after:
            state = dict(state, **json.loads(payload))
            tq.validate_state(task, state)
            tq.durable_json(directory / "STATE.json.gz", state)
            if fault:
                fault("state", ident)
        if mutable:
            old = json.loads(old_lease)
            if old is not None:
                stale = dict(old, expires_unix=0, archived_by_migration=migration_id)
                tq.durable_json(directory / "LEASE.json", stale)
            queue._make_ready(ident)
        # Done/parked STATE and LEASE remain byte unchanged.  Interrupted pure
        # math is recomputed only from the same exact durable pending frontier.
        if tq.digest(tq.read_json(directory / "STATE.json.gz")) != after:
            raise ValueError("Migrated checkpoint did not commit atomically")
        db.execute("UPDATE tasks SET phase='COMMITTED' WHERE task_id=?", (ident,))
        db.commit()


def _archive_operations(queue, archive):
    archive.mkdir(parents=True, exist_ok=True)
    for name in OPERATIONS:
        src, dst = queue.area / name, archive / name
        if src.exists():
            if dst.exists():
                raise ValueError("Operational metadata appeared again during stopped migration: " + name)
            os.replace(src, dst)
            tq._fsync_dir(queue.area)
            tq._fsync_dir(archive)


def publish_runtime(queue, receipt, old_pins):
    runtime = {"schema": "survivor-runtime-v2", "migration_id": receipt["migration_id"],
               "migration_receipt_sha256": receipt["receipt_sha256"],
               "new_release": receipt["new_release"], "new_release_sha256": receipt["new_release_sha256"],
               "legacy_source": receipt["old_release"], "legacy_release_sha256": receipt["old_release_sha256"],
               "legacy_pins": old_pins, "queue_config_sha256": receipt["queue_config_sha256"],
               "schedule_sha256": receipt["schedule_sha256"], "physical_lean_admissions": 0}
    runtime["receipt_sha256"] = tq.digest(runtime)
    tq.immutable_json(queue.area / "RUNTIME.json", runtime)


def recover_committed(queue, directory, intent, old_pins):
    receipt = tq.read_json(directory / "COMMITTED.json")
    body = {k:v for k,v in receipt.items() if k != "receipt_sha256"}
    if receipt.get("receipt_sha256") != tq.digest(body) or any(receipt.get(k) != v for k,v in intent.items() if k != "schema"):
        raise ValueError("Interrupted committed migration receipt changed")
    if tq.sha_file(directory / "TASK_JOURNAL.sqlite") != receipt["journal_sha256"]:
        raise ValueError("Committed migration journal changed")
    db = sqlite3.connect((directory / "TASK_JOURNAL.sqlite").resolve().as_uri()+"?mode=ro&immutable=1", uri=True)
    db.execute("PRAGMA cache_size=-2048")
    try:
        count = 0
        for task_id, after_sha, phase in db.execute("SELECT task_id,after_sha,phase FROM tasks"):
            count += 1
            with free_lock(queue.task_dir(task_id) / "RUN.lock"):
                if phase != "COMMITTED" or tq.digest(tq.read_json(queue.task_dir(task_id) / "STATE.json.gz")) != after_sha:
                    raise ValueError("State changed before interrupted runtime admission")
        if count != receipt["tasks"]:
            raise ValueError("Committed migration journal task census changed")
    finally:
        db.close()
    tq.immutable_json(queue.area / "MIGRATION.json", receipt)
    publish_runtime(queue, receipt, old_pins)
    return receipt


def migrate(queue, old_release, new_release, schedule_path, stop_evidence, fault=None):
    queue = queue if isinstance(queue, tq.TaskQueue) else tq.TaskQueue(queue)
    old_release, new_release = Path(old_release).resolve(), Path(new_release).resolve()
    if old_release == new_release:
        raise ValueError("The running old release must remain a distinct immutable directory")
    old_pins, new_pins = release_pins(old_release), release_pins(new_release)
    old_sha, new_sha = tq.digest(old_pins), tq.digest(new_pins)
    schedule = worker.load_schedule(schedule_path)
    schedule_sha = tq.digest(schedule)
    evidence = tq.read_json(stop_evidence) if isinstance(stop_evidence, (str, Path)) else stop_evidence
    config = tq.read_json(queue.area / "CONFIG.json")
    if config.get("max_depth") != 48 or config.get("max_tree_nodes") != 262143 or config.get("physical_lean_admissions") != 0:
        raise ValueError("Original queue guards or numerical scope changed")
    intent = {"schema": "survivor-migration-intent-v2", "old_release": str(old_release),
              "new_release": str(new_release), "old_release_sha256": old_sha, "new_release_sha256": new_sha,
              "schedule_sha256": schedule_sha, "stop_evidence_sha256": tq.digest(evidence),
              "queue_config_sha256": tq.digest(config), "physical_lean_admissions": 0}
    ident = tq.digest(intent)
    directory = queue.area / "migrations" / ident
    archive = directory / "operations"
    with free_lock(queue.area / "MIGRATE.lock"), free_lock(queue.area / "RUNTIME.lock"), free_lock(queue.area / "COORDINATOR.lock"), free_lock(queue.area / "IMPORT.lock"):
        tq.resource_guard(queue.area)
        verify_stop(queue, evidence, old_sha, archive)
        _node_locks(queue)
        runtime_path = queue.area / "RUNTIME.json"
        if runtime_path.exists():
            runtime = tq.read_json(runtime_path)
            if runtime.get("migration_id") != ident:
                raise ValueError("Another explicit runtime stage is already committed")
            return tq.read_json(queue.area / "MIGRATION.json")
        tq.immutable_json(directory / "INTENT.json", intent)
        tq.immutable_json(directory / "STOP_EVIDENCE.json", evidence)
        tq.immutable_json(directory / "OLD_PINS.json", old_pins)
        tq.immutable_json(directory / "NEW_PINS.json", new_pins)
        if (directory / "COMMITTED.json").exists():
            return recover_committed(queue, directory, intent, old_pins)
        # Read-only preflight sees all task locks before the first state edit.
        for place in queue.iter_task_dirs():
            tq.resource_guard(queue.area)
            with free_lock(place / "RUN.lock"):
                task = tq.read_json(place / "TASK.json")
                tq.validate_state(task, tq.read_json(place / "STATE.json.gz"))
        db = sqlite3.connect(directory / "TASK_JOURNAL.sqlite")
        try:
            db.execute("PRAGMA cache_size=-2048")
            db.execute("PRAGMA synchronous=FULL")
            db.execute("CREATE TABLE IF NOT EXISTS tasks(task_id TEXT PRIMARY KEY,before_sha TEXT,after_sha TEXT,preserved_sha TEXT,after_payload TEXT,old_lease TEXT,phase TEXT,status TEXT)")
            db.commit()
            for place in queue.iter_task_dirs():
                tq.resource_guard(queue.area)
                _journal_task(queue, place, db, ident, schedule_sha, fault)
            count, unfinished = db.execute("SELECT COUNT(*),COALESCE(SUM(phase!='COMMITTED'),0) FROM tasks").fetchone()
            if unfinished:
                raise ValueError("Migration journal has unfinished state writes")
            before_chain, after_chain, evidence_chain = hashlib.sha256(), hashlib.sha256(), hashlib.sha256()
            statuses = {}
            for task_id, before, after, preserved, status in db.execute("SELECT task_id,before_sha,after_sha,preserved_sha,status FROM tasks ORDER BY task_id"):
                before_chain.update(bytes.fromhex(task_id)+bytes.fromhex(before))
                after_chain.update(bytes.fromhex(task_id)+bytes.fromhex(after))
                evidence_chain.update(bytes.fromhex(task_id)+bytes.fromhex(preserved))
                statuses[status] = statuses.get(status, 0) + 1
        finally:
            db.close()
        for key in queue.iter_parent_keys():
            with free_lock(queue.parent_dir(key) / "PARENT_RUN.lock"):
                seed_completed(queue, key)
                if schedule["whole_root"]:
                    seed_root(queue, key)
        _archive_operations(queue, archive)
        tq.resource_guard(queue.area)
        receipt = {**intent, "schema": "survivor-migration-receipt-v2", "migration_id": ident,
                   "tasks": count, "old_status_counts": statuses,
                   "before_state_chain_sha256": before_chain.hexdigest(), "after_state_chain_sha256": after_chain.hexdigest(),
                   "preserved_forest_evidence_chain_sha256": evidence_chain.hexdigest(),
                   "journal_sha256": tq.sha_file(directory / "TASK_JOURNAL.sqlite"),
                   "operational_archive": str(archive), "status": "COMMITTED"}
        receipt["receipt_sha256"] = tq.digest(receipt)
        tq.immutable_json(directory / "COMMITTED.json", receipt)
        tq.immutable_json(queue.area / "MIGRATION.json", receipt)
        publish_runtime(queue, receipt, old_pins)
        return receipt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--queue", required=True)
    parser.add_argument("--old-release", required=True)
    parser.add_argument("--new-release", required=True)
    parser.add_argument("--schedule", required=True)
    parser.add_argument("--stop-evidence", required=True)
    args = parser.parse_args()
    worker._memory_limit()
    result = migrate(args.queue, args.old_release, args.new_release, args.schedule, args.stop_evidence)
    print(json.dumps(result, sort_keys=True), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
