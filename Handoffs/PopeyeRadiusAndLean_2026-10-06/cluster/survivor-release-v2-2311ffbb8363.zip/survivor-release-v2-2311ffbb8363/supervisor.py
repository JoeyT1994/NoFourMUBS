"""Bounded Slurm continuation; source DONE packets are immutable input.

The original campaign may finish its disjoint unfinished batches in parallel.
No original job is cancelled until all of its batch DONE receipts exist. New
workers consume only committed exact frontier chunks and preserve all guards.
"""
from pathlib import Path
import argparse
import fcntl
import hashlib
import json
import os
import signal
import subprocess
import sys
import time
import traceback
import uuid

import task_queue as tq
from safety_paths import SafetyPaths, absolute
from node_safety_cache import enable_node_cache

SOURCE = Path(__file__).resolve().parent
STOP = False
SAFETY_PATHS = SafetyPaths()


class ContinuousReplay:
    """One separate verifier beside the importer, inside its two-core job.

    The numerical nodes only publish readiness hints. The auditor validates
    those hints and replays certificates under independent parent locks.
    """
    def __init__(self, root, area):
        self.root, self.area = Path(root), Path(area)
        self.process = None
        self.log = None
        self.starts = 0
        self.reopens = 0
        self.draining = False

    def tick(self):
        if self.process is not None:
            code = self.process.poll()
            if code is None:
                return False
            if self.log is not None:
                self.log.close()
                self.log = None
            self.process = None
            if code != 0:
                raise RuntimeError('Continuous fresh replay stopped with code ' + str(code))
            if self.draining:
                return True
        if self.draining:
            return True
        if self.starts >= 3 + self.reopens:
            raise RuntimeError('Bounded continuous replay restarts exhausted')
        self.starts += 1
        self.log = (self.area / 'continuous-replay.log').open('a')
        self.process = subprocess.Popen(
            [sys.executable, '-B', str(SOURCE / 'audit_worker.py'),
             '--root', str(self.root), '--queue', str(self.area),
             '--cache', str(self.area / 'cache'), '--jobs', '1',
             '--watch', '--ready-only', '--wall-seconds', str(60 * 3600),
             '--parent-cpu-seconds', '3600'], cwd=self.root,
            stdout=self.log, stderr=subprocess.STDOUT, env=environment())
        tq.durable_json(self.area / 'CONTINUOUS_REPLAY.json',
                        dict(pid=self.process.pid, starts=self.starts, reopens=self.reopens,
                             source_sha256=verify_source(), started_unix=time.time(),
                             physical_lean_admissions=0))
        return False

    def drain(self):
        if not self.draining:
            tq.durable_json(self.area / 'REPLAY_DRAIN_REQUESTED.json',
                            dict(source_sha256=verify_source(), requested_unix=time.time()))
            self.draining = True
        return self.tick()

    def resume(self):
        """A timed-out root replay may restore descendant work during drain."""
        if not self.draining:
            return
        if self.reopens >= 64:
            raise RuntimeError('Bounded replay drain reopen attempts exhausted')
        path = self.area / 'REPLAY_DRAIN_REQUESTED.json'
        if path.exists():
            if tq.read_json(path).get('source_sha256') != verify_source():
                raise ValueError('Replay drain request belongs to another release')
            path.unlink()
            tq._fsync_dir(self.area)
        self.reopens += 1
        self.draining = False
        self.tick()

    def close(self):
        if self.process is not None and self.process.poll() is None:
            self.process.send_signal(signal.SIGUSR1)
            try:
                self.process.wait(timeout=55)
            except subprocess.TimeoutExpired:
                self.process.kill()
                self.process.wait(timeout=5)
        if self.log is not None:
            self.log.close()
            self.log = None


def stop(signum, frame):
    global STOP
    STOP = True


def verify_source():
    pins = tq.read_json(SOURCE / 'PINS.json')
    for name, sha in pins.items():
        if Path(name).is_absolute() or '..' in Path(name).parts or tq.sha_file(SOURCE / name) != sha:
            raise ValueError('Continuation source differs from pinned release: ' + name)
    return tq.digest(pins)


def environment():
    env = dict(os.environ)
    for key in ('SBATCH_RESERVATION', 'SLURM_RESERVATION'):
        env.pop(key, None)
    return env


def invoke(args, root, check=True, timeout=45):
    return subprocess.run(args, cwd=root, env=environment(), capture_output=True,
                          text=True, check=check, timeout=timeout)


def jobs(ids, root):
    if not ids:
        return []
    result = invoke(['squeue', '-h', '-r', '-j', ','.join(ids), '-o', '%i|%T'], root, False)
    if result.returncode and 'Invalid job id' not in result.stderr:
        raise RuntimeError('Cannot read Slurm job state: ' + result.stderr)
    return [line.split('|') for line in result.stdout.splitlines() if '|' in line]


def submit(root, area, name, options=()):
    """An ambiguous submission fails closed instead of creating duplicate jobs."""
    path = area / 'submissions' / (name + '.json')
    if path.exists():
        receipt = tq.read_json(path)
        if not receipt.get('job_id'):
            raise RuntimeError('Ambiguous Slurm submission requires reconciliation: ' + name)
        return receipt['job_id']
    script = 'ccq48.sbatch' if name.startswith('ccq') else 'genx.sbatch'
    receipt = dict(state='SUBMITTING', token=uuid.uuid4().hex, source=str(SOURCE),
                   source_sha256=verify_source(), options=list(options), created_unix=time.time())
    tq.durable_json(path, receipt)
    result = invoke(['sbatch', '--parsable', '--comment=mub6-survivor-' + receipt['token'],
                     *options, str(SOURCE / script), str(SOURCE), str(area)], root)
    ident = result.stdout.strip().split(';')[0]
    if not ident.isdigit():
        raise ValueError('Invalid Slurm submission response')
    receipt.update(state='SUBMITTED', job_id=ident)
    tq.durable_json(path, receipt)
    return ident


def safety_stop(root, area):
    root, area = absolute(root), absolute(area)
    key = (root, area)
    if STOP:
        return SAFETY_PATHS.latch(key, 'supervisor_signal')
    prior = SAFETY_PATHS.latched(key)
    if prior:
        return prior
    paths = (area / 'FAILURE.json', area / 'STOP_REQUESTED.json',
                 root / 'production/FAILURE.json', root / 'elastic-run/FAILURE.json',
                 root / 'scope-correction/FAILURE.json',
                 root / 'elastic-run/STOP_REQUESTED.json',
                 root / 'elastic-run/output/STOP_REQUESTED.json')
    legacy = root / 'production/STOP_REQUESTED.json'
    found = SAFETY_PATHS.present((*paths, legacy), anchors=(root, area))
    for path in paths:
        if path in found:
            return SAFETY_PATHS.latch(key, str(path))
    # The filename may remain while its reason changes. Read its contents on
    # every check; the directory snapshot never caches a handover permission.
    if legacy in found and tq.read_json(legacy).get('reason') != 'authorized_elastic_handover':
        return SAFETY_PATHS.latch(key, str(legacy))
    return None


def source_census(root, area):
    plan = tq.read_json(root / 'elastic-run/PLAN.json')
    done = committed = 0
    for item in plan['batches']:
        bid = item['batch']
        done += (root / 'elastic-run/batches' / f'{bid // 1000:03d}/{bid:06d}/DONE.json').exists()
        committed += (area / 'batches' / f'{bid:06d}.json').exists()
    return dict(total=len(plan['batches']), done=done, committed=committed)


def cancel_finished_original_jobs(root, area, census):
    if census['done'] != census['total'] or census['committed'] != census['total']:
        return
    path = area / 'ORIGINAL_JOBS_FINISHED.json'
    if path.exists():
        return
    original = tq.read_json(root / 'elastic-run/SUBMISSION.json')['worker_arrays']
    recovery = root / 'elastic-run/RECOVERY_SUBMISSIONS.json'
    if recovery.exists():
        original += [r['job_id'] for r in tq.read_json(recovery) if r.get('job_id')]
    active = jobs(original, root)
    receipt = dict(reason='Every original scheduled batch has an immutable final DONE receipt; only idle old allocations remain.',
                   source_census=census, jobs=[i for i, _ in active], created_unix=time.time())
    tq.durable_json(area / 'ORIGINAL_CANCEL_INTENT.json', receipt)
    if active:
        result = invoke(['scancel', *receipt['jobs']], root, False)
        if result.returncode and 'Invalid job id' not in result.stderr:
            raise RuntimeError('Could not cancel completed original allocations: ' + result.stderr)
    tq.durable_json(path, receipt)


def allocation_plan(ready):
    """Use genx for a small tail and fill whole ccq nodes for a large queue."""
    if type(ready) is not int or ready < 1:
        raise ValueError('An allocation requires ready work')
    if ready <= 490:
        return [('genx', max(1, (ready + 9) // 10))]
    return [('ccq', min(50, max(1, (ready - 490 + 93) // 94))), ('genx', 49)]


def node(root, area, capacity, wall_seconds):
    source_sha = verify_source()
    started = time.monotonic()
    if not 1 <= capacity <= 47:
        raise ValueError('Worker capacity exceeds node guard')
    if not os.environ.get('SLURM_JOB_ID') or capacity > int(os.environ.get('SLURM_CPUS_PER_TASK', '0')):
        raise ValueError('Workers require a sufficient Slurm CPU allocation')
    if int(os.environ.get('SLURM_MEM_PER_NODE', '0')) < (capacity + 1) * 768:
        raise ValueError('Workers require a sufficient Slurm memory allocation')
    # Share only fresh directory membership on this allocated node. Live stop
    # contents and all mathematical/resource guards keep their existing rules.
    enable_node_cache(source_sha)
    key = '_'.join(os.environ.get(k, 'local') for k in ('SLURM_JOB_ID', 'SLURM_ARRAY_TASK_ID', 'SLURM_PROCID'))
    directory = area / 'nodes' / key
    directory.mkdir(parents=True, exist_ok=True)
    children = []
    with (directory / 'RUN.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        if safety_stop(root, area):
            return 75
        try:
            for rank in range(capacity):
                owner = key + '_' + str(rank)
                log = (directory / ('worker-' + str(rank) + '.log')).open('a')
                command = [sys.executable, '-B', str(SOURCE / 'worker.py'), '--root', str(root),
                           '--queue', str(area), '--cache', str(area / 'cache'),
                           '--schedule', str(SOURCE / 'SCHEDULE.json'), '--owner', owner,
                           '--wall-seconds', str(max(1, min(wall_seconds * .8, wall_seconds - 3600)))]
                process = subprocess.Popen(command, cwd=root, stdout=log, stderr=subprocess.STDOUT)
                children.append((process, log))
            while any(p.poll() is None for p, _ in children):
                live = sum(p.poll() is None for p, _ in children)
                tq.durable_json(directory / 'STATUS.json', dict(status='RUNNING', live=live,
                                capacity=capacity, updated_unix=time.time(), physical_lean_admissions=0))
                failed = [p.returncode for p, _ in children if p.poll() not in (None, 0, 75)]
                if failed or safety_stop(root, area):
                    for p, _ in children:
                        if p.poll() is None:
                            p.send_signal(signal.SIGUSR1)
                time.sleep(5)
            codes = [p.returncode for p, _ in children]
            if any(code not in (0, 75) for code in codes):
                raise RuntimeError('Worker exited unsuccessfully: ' + str(codes))
            tq.durable_json(directory / 'STATUS.json', dict(status='SEARCH_FINISHED', exit_codes=codes,
                            updated_unix=time.time(), physical_lean_admissions=0))
            # Completed roots already entered the independent continuous
            # replay queue. Do not make every node scan the entire campaign.
            tq.durable_json(directory / 'STATUS.json', dict(status='NODE_FINISHED',
                            updated_unix=time.time(), physical_lean_admissions=0))
            return 0
        finally:
            deadline = time.monotonic() + 60
            for p, log in children:
                if p.poll() is None:
                    p.send_signal(signal.SIGUSR1)
            for p, log in children:
                if p.poll() is None:
                    try:
                        p.wait(timeout=max(.01, deadline - time.monotonic()))
                    except subprocess.TimeoutExpired:
                        # The queue's process-held flock and last durable
                        # checkpoint survive forced infrastructure cleanup.
                        p.kill()
                        p.wait(timeout=10)
                log.close()


def coordinator(root, area):
    source_sha = verify_source()
    validation = tq.read_json(area / 'VALIDATION_PASS.json')
    if validation.get('status') != 'PASS' or validation.get('source_sha256') != source_sha:
        raise ValueError('This immutable release has not passed cluster validation')
    queue = tq.TaskQueue(area)
    if (not os.environ.get('SLURM_JOB_ID')
            or int(os.environ.get('SLURM_CPUS_PER_TASK', '0')) < 2
            or int(os.environ.get('SLURM_MEM_PER_NODE', '0')) < 4096):
        raise ValueError('Coordinator plus independent replay requires two CPUs and 4 GiB')
    from runtime import RuntimeLease
    from worker import load_schedule
    with RuntimeLease(queue, SOURCE, tq.digest(load_schedule(SOURCE / 'SCHEDULE.json'))), (area / 'COORDINATOR.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        tq.immutable_json(area / 'LAUNCH.json', dict(source=str(SOURCE), source_sha256=source_sha,
                          max_waves=64, chunk_leaves=32, physical_lean_admissions=0))
        last_submit = 0
        replay = ContinuousReplay(root, area)
        try:
          while True:
            stopped = safety_stop(root, area)
            if stopped:
                raise RuntimeError('Continuation safety stop: ' + stopped)
            # Bounded imports publish only fully validated source batches.
            tq.resource_guard(area)
            imported = queue.import_finalized(root, chunk_leaves=32, batch_limit=64)
            census = source_census(root, area)
            cancel_finished_original_jobs(root, area, census)
            submissions = sorted((area / 'submissions').glob('*.json'))
            receipts = [tq.read_json(p) for p in submissions]
            if any(not r.get('job_id') for r in receipts):
                raise RuntimeError('An earlier Slurm submission is ambiguous')
            active = jobs([r['job_id'] for r in receipts], root)
            counts = queue.dispatch_status()
            # A parent and its descendants cannot run simultaneously. Counting
            # both as separate demand would reserve redundant allocations.
            searchable = max(counts['ready_markers'], counts.get('root_ready_markers', 0))
            if searchable:
                replay.resume()
            replay.tick()
            summary = dict(status='SURVIVOR_CONTINUATION_RUNNING', source=census, queue=counts,
                           active_jobs=len(active), imports=imported, updated_unix=time.time(),
                           continuous_replay_pid=(replay.process.pid if replay.process else None),
                           physical_lean_admissions=0)
            tq.durable_json(area / 'STATUS.json', summary)
            tq.durable_json(root / 'SURVIVOR_AUTHORITATIVE_STATUS.json', summary)
            # Release unused pending allocations as soon as all searchable
            # work has been consumed, rather than waiting for their start.
            if searchable == 0 and census['committed'] == census['total']:
                pending = [i for i, state in active if state == 'PENDING']
                if pending:
                    invoke(['scancel', *pending], root)
                    tq.durable_json(area / ('UNUSED_PENDING_CANCELLED_' + str(time.time_ns()) + '.json'),
                                    dict(jobs=pending, reason='No queued continuation tasks', created_unix=time.time()))
            if searchable and time.monotonic() - last_submit >= 190:
                # Imports may add work while a smaller first wave is active.
                # Expand toward useful capacity without waiting for that wave
                # to drain the entire enlarged queue by itself.
                kinds = {r['job_id']: p.stem.split('-', 1)[0] for p, r in zip(submissions, receipts)}
                allocated = {'ccq': 0, 'genx': 0}
                for ident, state in active:
                    kind = kinds.get(ident.split('_', 1)[0])
                    if kind is None:
                        raise ValueError('Active allocation has no pinned submission')
                    allocated[kind] += 1
                wanted = [(kind, max(0, count - allocated[kind]))
                          for kind, count in allocation_plan(searchable)]
                wave = 1 + max([int(p.stem.rsplit('-', 1)[1]) for p in submissions] or [-1])
                if any(count for _, count in wanted) and wave >= 64:
                    raise RuntimeError('Bounded infrastructure launch waves exhausted')
                # Fully use billed ccq nodes; genx jobs are billed per core.
                for kind, count in wanted:
                    if count:
                        submit(root, area, kind + '-%02d' % wave, ('--array=0-' + str(count - 1),))
                last_submit = time.monotonic()
            if census['committed'] == census['total'] and not active and searchable == 0:
                if not replay.drain():
                    summary['status'] = 'DRAINING_FINAL_REPLAY'
                    tq.durable_json(area / 'STATUS.json', summary)
                    time.sleep(10)
                    continue
                # A root candidate may have hit its replay budget and restored
                # descendants while the final verifier was draining. Never
                # finalize from the stale pre-drain readiness snapshot.
                after = queue.dispatch_status()
                if (after['ready_markers'] or after.get('root_ready_markers', 0)
                        or after.get('replay_ready_markers', 0)):
                    replay.resume()
                    continue
                # audit_worker aggregates only completed fresh replay receipts;
                # parked/guarded mathematical obligations remain explicit.
                original_audit = root / 'COMBINED_FINAL_AUDIT.json'
                if not original_audit.exists() or 'main_audit_sha256' not in tq.read_json(original_audit):
                    summary['status'] = 'WAITING_FOR_ORIGINAL_FINAL_AUDIT'
                    tq.durable_json(area / 'STATUS.json', summary)
                    time.sleep(120)
                    continue
                # Recheck current provider/state pins immediately before
                # combining. An old summary is never used as a proof cache.
                invoke([sys.executable, '-B', str(SOURCE / 'audit_worker.py'), '--root', str(root),
                        '--queue', str(area), '--cache', str(area / 'cache'), '--summary-only'], root, timeout=10800)
                invoke([sys.executable, '-B', str(SOURCE / 'combine.py'), '--root', str(root),
                        '--queue', str(area)], root, timeout=10800)
                summary['status'] = 'CONTINUATION_FINISHED'
                summary['final_audit'] = str(area / 'COMBINED_FINAL_AUDIT.json')
                summary['result'] = tq.read_json(area / 'COMBINED_FINAL_AUDIT.json')
                tq.durable_json(area / 'STATUS.json', summary)
                tq.durable_json(root / 'SURVIVOR_AUTHORITATIVE_STATUS.json', summary)
                return 0
            time.sleep(30 if imported['imported_batches'] else 120)
        finally:
            replay.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=('node', 'coordinator'))
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--queue', type=Path, required=True)
    parser.add_argument('--capacity', type=int, default=47)
    parser.add_argument('--wall-seconds', type=float, default=60 * 3600)
    args = parser.parse_args()
    if not __debug__:
        raise ValueError('Optimized Python is forbidden')
    root, area = args.root.resolve(), args.queue.resolve()
    area.mkdir(parents=True, exist_ok=True)
    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGUSR1, stop)
    try:
        if args.command == 'node':
            return node(root, area, args.capacity, args.wall_seconds)
        return coordinator(root, area)
    except BaseException:
        detail = dict(status='SUPERVISOR_NEEDS_ATTENTION', traceback=traceback.format_exc(),
                      updated_unix=time.time(), physical_lean_admissions=0)
        tq.durable_json(area / ('SUPERVISOR_FAILURE_' + str(os.getpid()) + '.json'), detail)
        with tq.locked(area / 'FAILURE.lock'):
            if not (area / 'FAILURE.json').exists():
                tq.durable_json(area / 'FAILURE.json', detail)
        raise


if __name__ == '__main__':
    sys.exit(main())
