"""Bounded independent exact, physical, compound and legacy controls for v2."""
from fractions import Fraction as Q
from pathlib import Path
import argparse
import copy
import ctypes
import json
import math
import resource
import subprocess
import sys
import time
import engines
import engine_tests


def require(value,message):
    if not value:raise AssertionError(message)


def elimination_protocol_controls(provider):
    """Exact RHS containment and unchanged upper bounds, including underflow.

    These are protocol controls, not physical certificates.  The native helper
    used by local_region must retain the outward upper endpoint and report the
    independently known nonnegative lower endpoint.  The decoder stays strict.
    """
    from advanced_provider import decode_plain
    lib=provider.lib;dp=ctypes.POINTER(ctypes.c_double)
    lib.test_arithmetic.argtypes=[ctypes.c_int,dp,dp];lib.test_arithmetic.restype=ctypes.c_int
    tiny=math.ulp(0.0)
    cases=[((1.,2.),(3.,4.),(-6.,5.),(-7.,8.)),
           ((0.,0.),(0.,0.),(-1.,1.),(-1.,1.)),
           ((0.,1.),(0.,0.),(0.,0.),(-1.,1.)),
           ((0.,tiny),(0.,tiny),(0.,tiny),(0.,tiny)),
           ((0.,2.**-400),(0.,2.**-400),(-2.**-400,2.**-400),(0.,2.**-400)),
           ((0.,2.**200),(0.,2.**200),(-2.**200,2.**200),(0.,2.**200))]
    def arithmetic(op,a,b):
        out=(ctypes.c_double*2)()
        require(lib.test_arithmetic(op,(ctypes.c_double*4)(*a,*b),out)==0,"RHS core arithmetic failed")
        return list(out)
    accepted=rejected=negative_raw=0;examples=[]
    def rejected_witness(out):
        nonlocal rejected
        try:decode_plain(4,out)
        except ArithmeticError:rejected+=1
        else:raise AssertionError("Invalid A-elimination protocol accepted")
    for dh,dv,ah,av in cases:
        data=[*dh,*dv,*ah,*av];out=(ctypes.c_double*2)()
        require(lib.advanced_elimination_control((ctypes.c_double*8)(*data),out)==2,"RHS control status")
        left=arithmetic(2,(0.,max(0.,dh[1])),(0.,max(map(abs,av))))
        right=arithmetic(2,(0.,max(0.,dv[1])),(0.,max(map(abs,ah))))
        raw=arithmetic(0,left,right)
        exact=Q(max(0.,dh[1]))*Q(max(map(abs,av)))+Q(max(0.,dv[1]))*Q(max(map(abs,ah)))
        require(out[0]==0 and Q(out[0])<=exact<=Q(out[1]),"Nonnegative RHS exact containment")
        require(out[1].hex()==raw[1].hex(),"RHS acceptance upper endpoint changed")
        witness=[0.]*64;witness[1]=1.;witness[7:9]=list(out)
        margin=math.nextafter(out[1],math.inf)
        for sign in (-1,1):
            witness[5:7]=[sign*margin]*2
            require(decode_plain(4,witness)=="A_elimination","Valid A-elimination witness rejected")
            accepted+=1
        if raw[0]<0:
            negative_raw+=1;bad=witness[:];bad[7:9]=raw;rejected_witness(bad)
        bad=witness[:];bad[5:7]=[out[1]]*2;rejected_witness(bad)
        bad=witness[:];bad[5:7]=[-margin,margin];rejected_witness(bad)
        examples.append({"raw_rhs_hex":[v.hex() for v in raw],"rhs_hex":[v.hex() for v in out]})
    require(negative_raw>=1,"Outward-zero rounding regression not exercised")
    require(float.fromhex(examples[0]["raw_rhs_hex"][0])==-3*tiny,"Expected zero-product rounding changed")
    for field,value in ((1,243.),(2,3.),(4,2.),(5,math.nan),(7,-tiny)):
        bad=witness[:];bad[field]=value;rejected_witness(bad)
    bad=witness[:];bad[7:9]=[1.,0.];rejected_witness(bad)
    require(lib.advanced_elimination_control((ctypes.c_double*8)(1.,0.,0.,1.,0.,1.,0.,1.),(ctypes.c_double*2)())<0,"Reversed native input accepted")
    return {"status":"PASS","exact_rhs_cases":len(cases),"valid_signed_witnesses":accepted,
            "invalid_witnesses_rejected":rejected,"raw_negative_lower_cases":negative_raw,
            "upper_endpoints_bitwise_unchanged":True,"examples":examples}


def elimination_saved_case_controls():
    """Bounded exact checkpoint sample from failed validation job2481779.

    The saved preorder need not equal the former process's in-memory order.
    Record every native status/branch without claiming an unseen branch fired.
    Every accepted record is added to the separate-process replay below.
    """
    from advanced_provider import decode_plain
    fixture=Path(__file__).with_name("advanced_elimination_cases.json")
    saved=json.loads(fixture.read_text());cases=saved["cases"]
    require(len(cases)==13 and len({row["path"] for row in cases})==13,"Saved pending geometry inventory changed")
    checked=[];accepted=[];branch0=[]
    for case in cases:
        cc,rr=list(map(Q,case["centers"])),list(map(Q,case["radii"]))
        record=engines.evaluate(cc,rr,"handoff_plain4",8)
        witness=record["witness"]
        row=dict(case,ok=record["ok"],reason=record["reason"],cpu_seconds=record["cpu_seconds"],
                 evidence_sha256=record["replay"]["evidence_sha256"],native_status=None,branch=None)
        if witness:
            status=witness["native_status"];out=list(map(float.fromhex,witness["output_hex"]))
            require(decode_plain(status,out)==record["reason"],"Saved-case strict decoder disagreement")
            row.update(native_status=status,output_hex=witness["output_hex"])
            if status==4:
                row["branch"]=int(out[4])
                if out[4]==0:
                    require(out[7]==0 and (out[5]>out[8] or -out[6]>out[8]),"Saved-case RHS protocol failed")
                    branch0.append(case["path"])
        else:
            require(not record["ok"] and record["reason"] in ("cpu_budget","native_cpu_budget"),"Missing saved-case native output")
        if record["ok"]:accepted.append(record)
        checked.append(row)
    return {"status":"PASS","fixture_sha256":engines._sha(fixture),
            "source_checkpoint_sha256":saved["source_checkpoint_sha256"],"task_id":saved["task_id"],
            "original_id":saved["original_id"],"cases_checked":len(checked),"accepted":len(accepted),
            "branch0_paths":branch0,"cases":checked},accepted


def exact_controls(root,provider):
    reference=engine_tests._reference_module(root);Z=reference.Z;c=provider.c;lib=provider.lib
    cases=[]
    for ints in ((-3,2,1,5,2,1,-2,3),(2,1,3,1,4,3,5,2),(1,2,2,3,3,4,4,5)):
        cases.append([Z(Q(m*m-n*n,m*m+n*n),Q(2*m*n,m*m+n*n)) for m,n in zip(ints[::2],ints[1::2])])
    class Dual:
        def __init__(self,v=0,d=None):self.v=reference.asZ(v);self.d=d if d is not None else [Z()]*4
        def __add__(self,b):
            b=b if isinstance(b,Dual) else Dual(b)
            return Dual(self.v+b.v,[x+y for x,y in zip(self.d,b.d)])
        __radd__=__add__
        def __neg__(self):return Dual(-self.v,[-x for x in self.d])
        def __sub__(self,b):return self+-asdual(b)
        def __rsub__(self,b):return asdual(b)+-self
        def __mul__(self,b):
            b=asdual(b);return Dual(self.v*b.v,[x*b.v+self.v*y for x,y in zip(self.d,b.d)])
        __rmul__=__mul__
        def bar(self):return Dual(self.v.bar(),[x.bar() for x in self.d])
        def real(self):return Dual(self.v.re,[Z(x.re) for x in self.d])
    def asdual(x):return x if isinstance(x,Dual) else Dual(x)
    def invariants(ph):
        xs=[]
        for i,z in enumerate(ph):
            d=[Z()]*4;d[i]=Z(0,1)*z;xs.append(Dual(z,d))
        a,b,cc,d=xs;s=-1-a-b;t=-1-cc-d;r=-1-cc*a.bar()-d*b.bar()
        x,y,z=[(v*v.bar()).real() for v in (s,t,r)];p=x+y+z;j=(s*r*t.bar()).real()*2;w=x*y+x*z+y*z-x*y*z
        f=2*j*(4*j*j+2*p*p*p-24*p*p+54*p+(30-2*p)*w)
        return p,j,f
    count={"plain_exact_coefficients":0,"cheap_exact_values":0,"analytic_derivative_containments":0,"ray_exact_coefficients":0,"ray_dense_contractions":0}
    for ph in cases:
        raw=sum(([c.down(z.re),c.up(z.re),c.down(z.im),c.up(z.im)] for z in ph),[])
        out=(ctypes.c_double*32)();require(lib.local_coefficients((ctypes.c_double*20)(*raw,*([0.0]*4)),out)==32,"Plain coefficient status")
        for tr,perm in enumerate(((0,1,2,3),(0,2,1,3))):
            ref=reference.reference([ph[k] for k in perm]);expected=ref[:2]+sum(([ref[2+5*j],(ref[3+5*j]+ref[4+5*j])/2] for j in range(3)),[])
            for k,v in enumerate(expected):
                require(Q(out[16*tr+2*k])<=v<=Q(out[16*tr+2*k+1]),("Plain exact coefficient",tr,k));count["plain_exact_coefficients"]+=1
        for radius in (Q(0),Q(1,128)):
            out=(ctypes.c_double*20)();lib.set_budget(30)
            require(lib.advanced_cheap((ctypes.c_double*20)(*raw,*([float(radius)]*4)),out,1)==20,"Cheap derivative status")
            p,j,f=invariants(ph)
            for k,v in ((0,p.v.re),(2,j.v.re),(4,reference.reference(ph)[0]),(6,f.v.re)):
                require(Q(out[k])<=v<=Q(out[k+1]),("Cheap exact value",k));count["cheap_exact_values"]+=1
            samples=[ph]
            if radius:
                for axis in range(4):
                    for sign in (-1,1):
                        tangent=Q(sign,1024);rot=Z((1-tangent*tangent)/(1+tangent*tangent),2*tangent/(1+tangent*tangent))
                        sample=ph[:];sample[axis]=sample[axis]*rot;samples.append(sample)
                        require(2*abs(tangent)<radius,"Exact arc sample outside input")
            for sample in samples:
                _,_,f=invariants(sample)
                for axis,v in enumerate(f.d):
                    require(Q(out[12+2*axis])<=v.re<=Q(out[13+2*axis]),("Analytic derivative containment",axis,radius));count["analytic_derivative_containments"]+=1
    # Independent uncleared reference, then exact clearing, checks every proposed
    # rational vector coefficient on one positive-R rational-unit point.
    exact=engines._load("advanced_exact_reference",root/"engine/upstream/ProvenResults/SignedCornerPSDPrune/exact_reference.py")
    ph=cases[0];ref=exact.reference([exact.Q(z.re,z.im) for z in ph],[],cleared=True)
    raw=sum(([c.down(z.re),c.up(z.re),c.down(z.im),c.up(z.im)] for z in ph),[])+[0.0]*4
    out=(ctypes.c_double*470)();lib.set_budget(30)
    require(lib.advanced_rays((ctypes.c_double*20)(*raw),out)==470,"Ray coefficient status")
    def dense(diag,off,v):
        matrix=[[Z(diag),off[0],off[1]],[off[0].bar(),Z(diag),off[2]],[off[1].bar(),off[2].bar(),Z(diag)]]
        return sum((v[i].bar()*matrix[i][j]*v[j] for i in range(3) for j in range(3)),Z()).re
    for k in range(2,470,13):
        row=list(out[k:k+13]);j,sg,ep=map(int,row[:3]);v=[Z(Q(row[3+2*i]),Q(row[4+2*i])) for i in range(3)]
        q=8+16*j
        fa=ep*ref[q];fb=3*ref[1]+ep*sg*ref[q+2]
        aa=[Z(ref[q+4*(i+1)],ref[q+4*(i+1)+1])*ep for i in range(3)]
        bb=[Z(ref[2+2*i],ref[3+2*i])+Z(ref[q+4*(i+1)+2],ref[q+4*(i+1)+3])*(ep*sg) for i in range(3)]
        for lower,upper,value in ((row[9],row[10],dense(fa,aa,v)),(row[11],row[12],dense(fb,bb,v))):
            require(Q(lower)<=value<=Q(upper),"Exact ray coefficient missed");count["ray_exact_coefficients"]+=1
    for n in range(1,7):
        raw=[Q(n-3)]+[Q(i-n,8) for i in range(6)]+[Q((i+1)*(n-2),16) for i in range(6)]
        out=(ctypes.c_double*2)();require(lib.advanced_ray_control((ctypes.c_double*13)(*map(float,raw)),out)==2,"Ray control status")
        expected=dense(raw[0],[Z(*raw[1+2*i:3+2*i]) for i in range(3)],[Z(*raw[7+2*i:9+2*i]) for i in range(3)])
        require(Q(out[0])<=expected<=Q(out[1]),"Dense contraction missed");count["ray_dense_contractions"]+=1
    return count


def replay_controls():
    cc=[Q(0),Q(1),Q(2),Q(3)];rr=[Q(1,2**20)]*4
    source=engines.evaluate(cc,rr,"complement4",30);require(source["ok"],"Missing accepted complement control")
    require(engines.replay(source,30)["ok"],"Direct replay failed")
    pooled=engines.compose_partials([source],30,cc,[r/2 for r in rr]);require(pooled["ok"],"Ancestor pool failed")
    recipe=engines.make_recipe(pooled);require(engines.replay_recipe(recipe,30)["ok"],"Compound replay failed")
    mutations=0
    for field in ("input","provider_hashes","witness_sha256"):
        bad=copy.deepcopy(recipe)
        if field=="input":bad["contributors"][0]["input"]["centers"][0]="1/10"
        elif field=="provider_hashes":bad["contributors"][0][field]["survivor_driver_sha256"]="0"*64
        else:bad["contributors"][0][field]="0"*64
        try:engines.replay_recipe(bad,30)
        except ValueError:mutations+=1
        else:raise AssertionError("Mutated compound recipe accepted")
    try:engines.compose_partials([source],30,cc,[r*2 for r in rr])
    except ValueError:mutations+=1
    else:raise AssertionError("Noncontained source accepted")
    legacy=[];examples=[pooled]
    for module in engines._STATE["legacy"]:
        record=module.evaluate(cc,rr,"order3",30);require(record["ok"],"Legacy accepted control missing")
        require(engines.replay(record,30)["ok"],"Legacy dispatch failed")
        require(engines.replay_recipe(engines.make_recipe(record),30)["ok"],"Legacy compact dispatch failed")
        legacy.append(record["provider_hashes"]["survivor_driver_sha256"])
        examples.append(record)
    # Exercise substantive positive-R paths rather than only the R<=0 shortcut.
    ints=(-3,2,1,5,2,1,-2,3)
    generic=[Q(math.atan2(2*m*n,m*m-n*n)) for m,n in zip(ints[::2],ints[1::2])]
    seed=[Q(float(s+o/100)) for s,o in zip((2*math.pi/3,-2*math.pi/3,-2*math.pi/3,2*math.pi/3),(1,2,3,-1))]
    paths=[]
    for method,geometry,reason in (("complement4",generic,"complementary_corner"),("handoff_plain4",seed,"linear_sign_cover"),("psd_ray",generic,"rational_quadratic_PSD")):
        record=engines.evaluate(geometry,rr,method,30)
        require(record["ok"] and record["reason"]==reason,("Substantive control missing",method,record["reason"]))
        require(engines.replay(record,30)["ok"],"Substantive replay failed")
        examples.append(record);paths.append({"method":method,"reason":reason})
    face=engines.evaluate(seed,rr,"complement_face4",30)
    require("face" in face["witness"],"Monotonic face path not exercised")
    require(not face["ok"],"Face negative-path control changed")
    return {"status":"PASS","mutations_rejected":mutations,"legacy_driver_hashes":legacy,
            "substantive_replay_paths":paths,"face_unresolved_path":True},examples


def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument("--root",type=Path,required=True);ap.add_argument("--cache",type=Path,required=True);ap.add_argument("--output",type=Path,required=True)
    ap.add_argument("--native-only",action="store_true",help="Run direct advanced controls without unavailable Python dependencies")
    ap.add_argument("--replay-input",type=Path,help="Fresh-process replay control mode")
    args=ap.parse_args();start=time.process_time()
    if args.native_only:
        c=engines._load("advanced_frozen",args.root/"engine/certify_leaves.py");c.guard()
        module=engines._load("advanced_only",Path(__file__).with_name("advanced_provider.py"));provider=module.Provider(args.root,args.cache,c)
        report={"exact_controls":exact_controls(args.root,provider),
                "elimination_protocol_controls":elimination_protocol_controls(provider),"scope":"native exact controls only"}
    else:
        manifest=engines.initialize(args.root,args.cache)
        if args.replay_input:
            records=json.loads(args.replay_input.read_text())
            receipts=[engines.replay(record,30) for record in records]
            require(all(x["ok"] and x["status"]=="PASS" for x in receipts),"Fresh-process replay failed")
            args.output.write_text(json.dumps({"status":"PASS","receipts":receipts,"physical_lean_admissions":0},sort_keys=True)+"\n")
            print(json.dumps({"status":"PASS","independent_replays":len(receipts)}));return
        replay_result,examples=replay_controls()
        saved_case_result,saved_examples=elimination_saved_case_controls();examples.extend(saved_examples)
        report={"manifest":manifest,"exact_controls":exact_controls(args.root,engines._STATE["advanced"]),
                "elimination_protocol_controls":elimination_protocol_controls(engines._STATE["advanced"]),
                "saved_elimination_case_controls":saved_case_result,
                "physical_negative_controls":engine_tests.physical_controls(args.root,["complement4","complement_face4","handoff_plain4","psd_ray"]),
                "compound_legacy_replay_controls":replay_result,
                "method_replay_controls":engine_tests.replay_controls(["complement4","complement_face4","handoff_plain4","psd_ray"])}
        args.output.parent.mkdir(parents=True,exist_ok=True)
        replay_input=args.output.with_suffix(".replay-input.json");replay_output=args.output.with_suffix(".fresh-replay.json")
        replay_input.write_text(json.dumps(examples,sort_keys=True,allow_nan=False)+"\n")
        subprocess.run([sys.executable,str(Path(__file__).resolve()),"--root",str(args.root.resolve()),"--cache",str(args.cache.resolve()),
                        "--output",str(replay_output.resolve()),"--replay-input",str(replay_input.resolve())],check=True,timeout=240)
        report["fresh_process_replay"]=json.loads(replay_output.read_text())
    (c if args.native_only else engines._STATE["c"]).guard()
    report.update(status="PASS",cpu_seconds=time.process_time()-start,peak_rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,physical_lean_admissions=0)
    args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(report,indent=2,sort_keys=True,allow_nan=False)+"\n")
    summary={k:v for k,v in report.items() if k not in ("manifest","physical_negative_controls","fresh_process_replay","saved_elimination_case_controls")}
    if "saved_elimination_case_controls" in report:
        summary["saved_elimination_case_controls"]={k:report["saved_elimination_case_controls"][k] for k in ("cases_checked","accepted","branch0_paths")}
    print(json.dumps(summary,sort_keys=True))


if __name__=="__main__":main()
