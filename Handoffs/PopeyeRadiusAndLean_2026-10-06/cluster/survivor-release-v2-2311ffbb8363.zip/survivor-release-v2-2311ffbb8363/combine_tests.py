"""Synthetic-only tests of final native/conjugate ledger accounting.

Eight original IDs form four exact representative/conjugate pairs. Two roots
were unresolved in the old audit; fresh numerical receipts may close either or
both. The literal 1857 supplement guard is retained in this small fixture.
Only resource_guard is mocked. No production, source, Slurm, or Lean operation.
"""
from array import array
from pathlib import Path
import gzip
import json
import sys
import tempfile
import unittest
from unittest.mock import patch

if __package__:
    from . import combine, task_queue as tq
else:
    import combine
    import task_queue as tq


class CombineTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="mub6-combine-test-")
        self.base = Path(self.temp.name)
        self.root, self.area = self.base / "source", self.base / "queue"
        self.root.mkdir()
        self.area.mkdir()
        self.guard_patch = patch.object(tq, "resource_guard", return_value=None)
        self.guard_patch.start()
        self.addCleanup(self.guard_patch.stop)
        self.addCleanup(self.temp.cleanup)
        self.queue = tq.TaskQueue(self.area)
        self.keys = {ident: f"{ident:012d}-{tq.tree_sha('P')[:24]}" for ident in (0, 2)}
        self.receipts = {}
        self.make_fixture()

    def gz_lines(self, path, rows):
        path.parent.mkdir(parents=True, exist_ok=True)
        with gzip.open(path, "wb") as f:
            for row in rows:
                f.write(tq.canonical(row) + b"\n")

    def update_json(self, path, **changes):
        value = tq.read_json(path)
        value.update(changes)
        tq.durable_json(path, value)
        return value

    def rewrite_main(self, **changes):
        main_path = self.root / "production/FINAL_AUDIT.json"
        value = self.update_json(main_path, **changes)
        self.update_json(self.root / "COMBINED_FINAL_AUDIT.json", main_audit_sha256=tq.sha_file(main_path))
        return value

    def write_receipt(self, ident, **changes):
        key = self.keys[ident]
        value = dict(self.receipts.get(ident, {}))
        value.update(changes)
        value.pop("receipt_sha256", None)
        value["receipt_sha256"] = tq.digest(value)
        self.receipts[ident] = value
        tq.durable_json(self.queue.parent_dir(key) / "FINAL_REPLAY.json", value)
        return value

    def accepted_stream(self, ids=(0,), rows=None, count=None):
        if rows is None:
            rows = [{"id": ident, "parent_key": self.keys[ident],
                     "receipt_sha256": self.receipts[ident]["receipt_sha256"]} for ident in ids]
        path = self.area / "CLOSED_NATIVE_IDS.jsonl.gz"
        self.gz_lines(path, rows)
        fresh = tq.read_json(self.area / "FINAL_AUDIT.json") if (self.area / "FINAL_AUDIT.json").exists() else {}
        n = len(rows) if count is None else count
        fresh.update(schema="survivor-final-audit-v1", original_roots=2,
                     original_roots_closed=n, original_roots_incomplete=2-n,
                     production_config_sha256=tq.sha_file(self.root / "production/CONFIG.json"),
                     closed_native_ids={"path": path.name, "sha256": tq.sha_file(path), "count": n},
                     committed_source_batches=1, missing_source_batches=0, source_batches=1,
                     source_records_in_committed_batches=8, source_already_closed_records=1,
                     skipped_non_native_records=5, physical_lean_admissions=0)
        tq.durable_json(self.area / "FINAL_AUDIT.json", fresh)

    def make_fixture(self):
        self.selection = array("I", [0, 0x80000000, 2, 0x80000002,
                                     4, 0x80000004, 6, 0x80000006])
        values = array("I", self.selection)
        if sys.byteorder != "little":
            values.byteswap()
        selection_path = self.root / "campaign/selection.u32le"
        selection_path.parent.mkdir(parents=True, exist_ok=True)
        selection_path.write_bytes(values.tobytes())
        run_pins = self.root / "campaign/RUN_PINS.json"
        tq.durable_json(run_pins, {"files": [{"path": "campaign/selection.u32le",
                                            "sha256": tq.sha_file(selection_path)}]})
        config_path = self.root / "production/CONFIG.json"
        tq.durable_json(config_path, {"campaign_sha256": "a" * 64, "run_pins_sha256": tq.sha_file(run_pins),
                                      "physical_lean_admissions": 0})
        main_path = self.root / "production/FINAL_AUDIT.json"
        tq.durable_json(main_path, {"campaign_sha256": "a" * 64, "original_inputs": 8,
                                   "conditionally_accounted_for": 4, "unresolved": 4,
                                   "native_replayed_representatives": 1,
                                   "accepted_handoff_representatives": 1,
                                   "physical_lean_admissions": 0})
        supplement_path = self.root / "scope-correction/FINAL_AUDIT.json"
        tq.durable_json(supplement_path, {"accepted": 1857, "original_inputs": 1857,
                                         "unresolved_ids": [], "physical_lean_admissions": 0})
        tq.durable_json(self.root / "COMBINED_FINAL_AUDIT.json",
                        {"original_inputs": 8, "conditionally_accounted_for": 4, "unresolved": 4,
                         "main_audit_sha256": tq.sha_file(main_path),
                         "supplemental_audit_sha256": tq.sha_file(supplement_path),
                         "physical_lean_admissions": 0})
        self.old_rows = [{"id": 0, "representative": 0}, {"id": 1, "representative": 0},
                         {"id": 2, "representative": 2}, {"id": 3, "representative": 2}]
        self.gz_lines(self.root / "production/UNRESOLVED.jsonl.gz", self.old_rows)
        tq.durable_json(self.root / "elastic-run/PLAN.json", {"batches": [{"batch": 0, "n": 8}]})
        done = self.root / "elastic-run/batches/000/000000/DONE.json"
        tq.durable_json(done, {"batch": 0, "n": 8, "sha256": "b" * 64,
                               "closed": 1, "settled": 6, "physical_lean_admissions": 0})
        tq.durable_json(self.area / "batches/000000.json", {"batch": 0, "done_sha256": tq.sha_file(done),
                        "records": 8, "parents": 2, "skipped_non_native": 5})
        for ident, key in self.keys.items():
            place = self.queue.parent_dir(key)
            row = {"id": ident, "centers": [str(1 + (ident // 2)), "1", "1", "1"], "radii": ["1/8"] * 4}
            tq.durable_json(place / "SOURCE.json.gz", {"input": row, "id": ident, "parent_key": key,
                            "input_sha256": tq.digest(row), "source": {"batch": 0},
                            "physical_lean_admissions": 0})
            tq.durable_json(place / "READY.json", {"parent_key": key, "physical_lean_admissions": 0})
            binding = {"id": ident, "parent_key": key, "input_sha256": tq.digest(row),
                       "source_config_sha256": tq.sha_file(config_path),
                       "task_states_sha256": "c" * 64}
            self.receipts[ident] = {"schema": "survivor-final-replay-v1", "id": ident, "parent_key": key,
                                    "binding": binding, "binding_sha256": tq.digest(binding),
                                    "status": "PASS", "closed": True, "audit": "FRESH_ALL_LEAVES_PASS",
                                    "physical_lean_admissions": 0}
            self.write_receipt(ident)
        self.accepted_stream()

    def run_combine(self):
        return combine.combine(self.root, self.area)

    def assert_rejected(self, pattern=None):
        with self.assertRaisesRegex(ValueError, pattern or ".*"):
            self.run_combine()
        self.assertFalse((self.area / "COMBINED_FINAL_AUDIT.json").exists())

    def test_native_and_conjugate_counts_preserve_old_ledger(self):
        hashes = {str(p.relative_to(self.root)): tq.sha_file(p) for p in self.root.rglob("*") if p.is_file()}
        report = self.run_combine()
        self.assertEqual(report["status"], "CONDITIONAL_EXPORT_STILL_OPEN")
        self.assertEqual((report["original_inputs"], report["conditionally_accounted_for"], report["unresolved"]), (8, 6, 2))
        self.assertEqual((report["newly_replayed_native_roots"], report["newly_accounted_original_inputs"]), (1, 2))
        self.assertEqual(report["preserved_supplemental_all_completion_certificates"], 1857)
        self.assertEqual(list(combine.lines(self.area / "UNRESOLVED_ORIGINALS.jsonl.gz")), self.old_rows[2:])
        self.assertEqual(hashes, {str(p.relative_to(self.root)): tq.sha_file(p) for p in self.root.rglob("*") if p.is_file()})
        self.assertEqual(report["physical_lean_admissions"], 0)

    def test_full_closure_counts_each_original_exactly_once(self):
        self.accepted_stream(ids=(0, 2))
        report = self.run_combine()
        self.assertEqual((report["conditionally_accounted_for"], report["unresolved"]), (8, 0))
        self.assertEqual((report["newly_replayed_native_roots"], report["newly_accounted_original_inputs"]), (2, 4))
        self.assertEqual(report["status"], "CONDITIONAL_EXPORT_CLOSED")
        self.assertEqual(list(combine.lines(self.area / "UNRESOLVED_ORIGINALS.jsonl.gz")), [])

    def test_empty_fresh_stream_preserves_all_unresolved(self):
        self.accepted_stream(ids=())
        report = self.run_combine()
        self.assertEqual((report["conditionally_accounted_for"], report["unresolved"]), (4, 4))
        self.assertEqual(list(combine.lines(self.area / "UNRESOLVED_ORIGINALS.jsonl.gz")), self.old_rows)

    def test_missing_fresh_id_is_rejected_by_count(self):
        self.accepted_stream(ids=(), count=1)
        self.assert_rejected("closure count")

    def test_duplicate_fresh_native_id_is_rejected(self):
        row = {"id": 0, "parent_key": self.keys[0], "receipt_sha256": self.receipts[0]["receipt_sha256"]}
        self.accepted_stream(rows=[row, row])
        self.assert_rejected("unique imported root")

    def test_forged_nonimported_id_is_rejected(self):
        row = {"id": 4, "parent_key": self.keys[0], "receipt_sha256": self.receipts[0]["receipt_sha256"]}
        self.accepted_stream(rows=[row])
        self.assert_rejected("unique imported root")

    def test_forged_conjugate_id_cannot_be_counted_as_native(self):
        row = {"id": 1, "parent_key": self.keys[0], "receipt_sha256": self.receipts[0]["receipt_sha256"]}
        self.accepted_stream(rows=[row])
        self.assert_rejected("unique imported root")

    def test_forged_embedded_receipt_id_is_rejected_even_after_rehash(self):
        self.write_receipt(0, id=2)
        self.accepted_stream()
        self.assert_rejected()

    def test_forged_embedded_receipt_parent_is_rejected_even_after_rehash(self):
        self.write_receipt(0, parent_key=self.keys[2])
        self.accepted_stream()
        self.assert_rejected()

    def test_missing_old_original_id_is_rejected(self):
        self.gz_lines(self.root / "production/UNRESOLVED.jsonl.gz", self.old_rows[:-1])
        self.assert_rejected("imported exact cover")

    def test_duplicate_old_original_id_is_rejected(self):
        self.gz_lines(self.root / "production/UNRESOLVED.jsonl.gz", self.old_rows[:1] + self.old_rows)
        self.assert_rejected("imported exact cover")

    def test_extra_old_original_id_is_rejected(self):
        self.gz_lines(self.root / "production/UNRESOLVED.jsonl.gz", self.old_rows + [{"id": 4, "representative": 4}])
        self.assert_rejected("covered exactly")

    def test_original_native_root_coverage_count_mismatch_is_rejected(self):
        self.rewrite_main(native_replayed_representatives=0)
        self.assert_rejected("coverage is incomplete")

    def test_imported_root_count_mismatch_is_rejected(self):
        self.update_json(self.area / "FINAL_AUDIT.json", original_roots=3)
        self.assert_rejected("omitted an imported root")

    def test_missing_source_batch_count_is_rejected(self):
        self.update_json(self.area / "FINAL_AUDIT.json", missing_source_batches=1)
        self.assert_rejected()

    def test_committed_source_batch_count_mismatch_is_rejected(self):
        self.update_json(self.area / "FINAL_AUDIT.json", committed_source_batches=0)
        self.assert_rejected()

    def test_committed_source_record_count_mismatch_is_rejected(self):
        self.update_json(self.area / "FINAL_AUDIT.json", source_records_in_committed_batches=7)
        self.assert_rejected()

    def test_1857_supplement_count_guard_is_preserved(self):
        supplement = self.root / "scope-correction/FINAL_AUDIT.json"
        self.update_json(supplement, accepted=1856)
        self.update_json(self.root / "COMBINED_FINAL_AUDIT.json", supplemental_audit_sha256=tq.sha_file(supplement))
        self.assert_rejected("sheet-scope supplement")

    def test_supplement_unresolved_branch_cannot_be_removed(self):
        supplement = self.root / "scope-correction/FINAL_AUDIT.json"
        self.update_json(supplement, unresolved_ids=[123])
        self.update_json(self.root / "COMBINED_FINAL_AUDIT.json", supplemental_audit_sha256=tq.sha_file(supplement))
        self.assert_rejected("sheet-scope supplement")

    def test_changed_done_receipt_is_rejected(self):
        self.update_json(self.root / "elastic-run/batches/000/000000/DONE.json", n=7)
        self.assert_rejected("batch coverage changed")

    def test_changed_pinned_selection_is_rejected(self):
        path = self.root / "campaign/selection.u32le"
        path.write_bytes(path.read_bytes()[:-4])
        self.assert_rejected("conjugation selection changed")

    def test_fresh_id_stream_sha_tamper_is_rejected(self):
        path = self.area / "CLOSED_NATIVE_IDS.jsonl.gz"
        path.write_bytes(path.read_bytes() + b"tamper")
        self.assert_rejected("native ID ledger changed")

    def test_fresh_receipt_sha_tamper_is_rejected(self):
        path = self.queue.parent_dir(self.keys[0]) / "FINAL_REPLAY.json"
        self.update_json(path, id=2)
        self.assert_rejected("final replay receipt")


if __name__ == "__main__":
    unittest.main(verbosity=2)
