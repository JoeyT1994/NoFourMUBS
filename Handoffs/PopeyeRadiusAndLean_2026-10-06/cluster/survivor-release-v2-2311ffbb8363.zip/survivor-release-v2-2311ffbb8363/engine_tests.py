"""Targeted native coefficient, physical-control, and replay regressions.

Every normalized coefficient must contain an independently evaluated exact
rational reference after its correct power-of-rho scaling.  Overlap between
two numerical interval implementations is not sufficient for these controls.
No numerical result is a physical Lean admission.
"""
from fractions import Fraction as Q
from pathlib import Path
import argparse
import copy
import ctypes
import importlib.util
import json
import sys
import time

import engines


def _require(condition, message):
    if not condition:
        raise AssertionError(message)


def _reference_module(root):
    sys.path.insert(0, str(root / "engine"))
    import controls
    return controls


def coefficient_controls(root):
    c = engines._STATE["c"]
    controls = _reference_module(root)
    normal = engines._STATE["normalized"]
    pi, sqrt3 = normal_module().constants()
    cases = []
    for ints in [(-3,2,1,5,2,1,-2,3),(2,1,3,1,4,3,5,2),(1,2,2,3,3,4,4,5)]:
        cases.append([controls.Z(Q(m*m-n*n,m*m+n*n),Q(2*m*n,m*m+n*n))
                      for m,n in zip(ints[::2],ints[1::2])])
    # A rational-unit sample genuinely near the radial chart, with independent
    # nonzero coordinate offsets, as well as the generic exact unit controls.
    anchors = engines._STATE["exact"]._anchors([Q(209,100),-Q(208,100),-Q(211,100),Q(21,10)])
    cases.append([controls.Z(*a) for a in anchors])
    count = {"original":0, "normalized":0}
    for case in cases:
        reference = controls.reference(case)
        raw = sum(([c.down(z.re),c.up(z.re),c.down(z.im),c.up(z.im)] for z in case),[])
        for order in (3,4,5):
            lib = engines._STATE["native"][order]
            lib.set_budget(30)
            out = (ctypes.c_double*38)()
            _require(lib.linear_region((ctypes.c_double*20)(*raw,*([0.0]*4)),out)==38,"Reference native status")
            for k,value in enumerate(reference):
                _require(Q(out[2*k]) <= value <= Q(out[2*k+1]),("original",order,k,value,list(out[2*k:2*k+2])))
                count["original"] += 1
            for rho in (Q(1,8),Q(1,32)):
                for signs in ((1,-1,-1,1),(-1,1,1,-1)):
                    roots, deltas = [], []
                    for z,sign in zip(case,signs):
                        imag = (sqrt3[0]/2,sqrt3[1]/2) if sign>0 else (-sqrt3[1]/2,-sqrt3[0]/2)
                        roots.extend([-.5,-.5,c.down(imag[0]),c.up(imag[1])])
                        deltas.extend([c.down((z.re+Q(1,2))/rho),c.up((z.re+Q(1,2))/rho),
                                       c.down((z.im-imag[1])/rho),c.up((z.im-imag[0])/rho)])
                    data = raw+[0.0]*4+deltas+roots+[float(rho)]
                    lib = normal.libs[order]
                    lib.set_budget(30)
                    out = (ctypes.c_double*38)()
                    _require(lib.normalized_region((ctypes.c_double*53)(*data),out)==38,"Normalized native status")
                    powers = [4,12]+[12,10,10,24,24]*3
                    for k,(value,power) in enumerate(zip(reference,powers)):
                        scaled = value/rho**power
                        _require(Q(out[2*k])<=scaled<=Q(out[2*k+1]),
                                 ("normalized",order,str(rho),signs,k,str(scaled),list(out[2*k:2*k+2])))
                        count["normalized"] += 1
    return count


def normal_module():
    return sys.modules.get("survivor_normalized_provider") or engines._load(
        "survivor_normalized_test", Path(__file__).with_name("normalized_provider.py"))


def physical_controls(root, methods):
    controls = _reference_module(root)
    lo,hi = controls.atan_bounds(Q(1,5))
    lo2,hi2 = controls.atan_bounds(Q(1,239))
    pi = 16*lo-4*hi2,16*hi-4*lo2
    midpoint = sum(pi)/2
    result = []
    for delta in (Q(1,100),Q(1,5),Q(1,2)):
        exact = [-2*midpoint/3,-midpoint/3+delta,Q(0),-midpoint+delta]
        for tr in (False,True):
            perm = (0,2,1,3) if tr else (0,1,2,3)
            cc,rr = [Q(float(exact[k])) for k in perm],[Q(1,2**35)]*4
            _require(all(abs(cc[i]-exact[k])+(pi[1]-pi[0])<rr[i] for i,k in enumerate(perm)),"Physical control not enclosed")
            for method in methods:
                value = engines.evaluate(cc,rr,method,30)
                _require(value["ok"] is False,("Known physical corner excluded",delta,tr,method,value))
                _require("budget" not in value["reason"],("Control exhausted budget",method))
                result.append(dict(delta=str(delta),transpose=tr,method=method,reason=value["reason"],
                                   substantive=value["reason"]!="normalized_chart_outside_neighborhood"))
    return result


def exact_context_controls(root):
    controls = _reference_module(root)
    cases = []
    for ints in ((-3,2,1,5,2,1,-2,3),(2,1,3,1,4,3,5,2)):
        cases.append([controls.Z(Q(m*m-n*n,m*m+n*n),Q(2*m*n,m*m+n*n))
                      for m,n in zip(ints[::2],ints[1::2])])
    tangents = (Q(19,100),Q(1,5),Q(21,100))
    angle_bounds = [tuple(2*x for x in controls.atan_bounds(t)) for t in tangents]
    angle_lo,angle_hi = min(x[0] for x in angle_bounds),max(x[1] for x in angle_bounds)
    angle_center,angle_radius = (angle_lo+angle_hi)/2,(angle_hi-angle_lo)/2
    t0 = Q(1,7)
    anchor = (1-t0*t0)/(1+t0*t0),2*t0/(1+t0*t0)
    result = []
    for bits,core in engines._STATE["exact"].contexts.items():
        _require(core.P==bits and core.S==1<<bits,"Wrong precision instance")
        _require(core.IM.im.lo==core.S and core.IM.im.hi==core.S,"Precision-corrupted imaginary unit")
        # An exact tiny negative interval is preserved at high precision and
        # cannot be represented with the old fixed absolute 2^-80 arithmetic.
        tiny = core.I(-Q(1,2**160))
        _require(tiny.hi<0,"Tiny exact negative rounded to zero")
        checked = 0
        for case in cases:
            reference = controls.reference(case)
            anchors = [(z.re,z.im) for z in case]
            phases = core.phase_jets(anchors,[Q(0)]*4,center=True)
            for cleared in (True,False):
                ex = core.expressions(phases,cleared)
                delta = reference[1]
                expected = [(ex["R"].v.re,reference[0]),(ex["Delta"].v.re,delta),
                            (ex["scale"].v.re,delta if cleared else Q(1))]
                for j in range(3):
                    k = 2+5*j
                    divisor = Q(1) if cleared else delta
                    expected.extend(((ex["nf"][j][0].a.v.re,reference[k]/divisor),
                                     (ex["nf"][j][0].b.v.re,(reference[k+1]+reference[k+2])/(2*divisor))))
                for interval,value in expected:
                    _require(Q(interval.lo,core.S)<=value<=Q(interval.hi,core.S),
                             ("exact point coefficient",bits,cleared,str(value),interval.endpoints()))
                    checked += 1
        cayley_radius = core.arc_radius(angle_center,angle_radius,anchor)
        for t in tangents:
            x,y = (1-t*t)/(1+t*t),2*t/(1+t*t)
            exact_u = (y*anchor[0]-x*anchor[1])/(1+x*anchor[0]+y*anchor[1])
            _require(abs(exact_u)<=cayley_radius,("Exact angular/Cayley containment",bits,str(exact_u),str(cayley_radius)))
        result.append(dict(precision_bits=bits,tiny_negative=tiny.endpoints(),
                           exact_point_coefficients_contained=checked,
                           rational_phase_arc_controls=len(tangents)))
    return result


def replay_controls(methods):
    module = normal_module()
    pi,_ = module.constants()
    p = sum(pi)/2
    seed = [2*p/3,-2*p/3,-2*p/3,2*p/3]
    cases = [[Q(0),Q(1),Q(2),Q(3)]]
    for offsets in ((1,2,3,-1),(2,-1,1,3),(-1,3,2,1)):
        cases.append([Q(float(s+Q(d,100))) for s,d in zip(seed,offsets)])
    results = []
    for method in methods:
        accepted = None
        for cc in cases:
            value = engines.evaluate(cc,[Q(1,2**30)]*4,method,30)
            if value["ok"]:
                accepted = value
                break
        if accepted is None:
            results.append(dict(method=method,status="NO_ACCEPTED_CONTROL"))
            continue
        receipt = engines.replay(accepted,30)
        _require(receipt["ok"] and receipt["status"]=="PASS",("Fresh replay failed",method))
        recipe = {k:copy.deepcopy(accepted[k]) for k in ("method","input","provider_hashes","reason","replay")}
        recipe.update(schema="survivor-leaf-recipe-v1",witness_sha256=engines._digest(accepted["witness"]))
        _require(engines.replay_recipe(recipe,30)["ok"],"Compact replay failed")
        for key in ("input","provider_hashes","witness"):
            mutated = copy.deepcopy(accepted)
            if key=="input":
                mutated[key]["centers"][0]="0"
                if mutated[key]==accepted[key]:
                    mutated[key]["centers"][0]="1"
            elif key=="provider_hashes":
                mutated[key][next(iter(mutated[key]))]="0"*64
            else:
                mutated[key]["mutated"]=True
            try:
                engines.replay(mutated,30)
            except ValueError:
                pass
            else:
                raise AssertionError("Mutated replay accepted: "+key)
        bad_recipe = copy.deepcopy(recipe)
        bad_recipe["witness_sha256"]="0"*64
        try:
            engines.replay_recipe(bad_recipe,30)
        except ValueError:
            pass
        else:
            raise AssertionError("Mutated compact witness accepted")
        results.append(dict(method=method,status="PASS",reason=accepted["reason"]))
    return results


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root",type=Path,default=Path(__file__).resolve().parent.parent)
    parser.add_argument("--cache",type=Path,required=True)
    parser.add_argument("--output",type=Path,required=True)
    parser.add_argument("--exact",action="store_true",help="Also test selective exact PSD acceptance/negative controls")
    args = parser.parse_args()
    started = time.process_time()
    manifest = engines.initialize(args.root,args.cache)
    methods = ["order3","order4","order5","paired_psd","normalized_order3","normalized_order4","normalized_order5"]
    if args.exact:
        methods.append("exact_psd256")
    result = dict(status="PASS",manifest=manifest,
                  exact_coefficient_containment=coefficient_controls(args.root),
                  exact_precision_controls=exact_context_controls(args.root),
                  physical_negative_controls=physical_controls(args.root,methods),
                  replay_controls=replay_controls(methods),physical_lean_admissions=0)
    result["cpu_seconds"]=time.process_time()-started
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(result,indent=2,sort_keys=True,allow_nan=False)+"\n")
    print(json.dumps({k:v for k,v in result.items() if k not in ("manifest","physical_negative_controls")},sort_keys=True))


if __name__=="__main__":
    main()
