// Exact secant identities are applied before Taylor truncation.  This is a
// numerical implementation of conditional scalar algebra, not a Lean binding
// of the physical Hadamard interface or of native interval arithmetic.
#include "../engine/upstream/ProvenResults/SignedCornerPSDPrune/engine.cpp"
#include "../engine/upstream/ProvenResults/Patch2442Region_v3/taylor.hpp"

// A secant stores b + rho*d without subtracting nearly equal evaluations.
// The Taylor variables occur in both b and d; rho is a positive fixed dyadic.
static C cancellation_rho;
struct CSec {
 T b,d;
 CSec(double x=0):b(x),d(0){}
 CSec(T x):b(x),d(0){}
 CSec(T x,T y):b(x),d(y){}
};
static CSec operator+(const CSec&a,const CSec&b){return CSec(a.b+b.b,a.d+b.d);}
static CSec operator-(const CSec&a){return CSec(-a.b,-a.d);}
static CSec operator-(const CSec&a,const CSec&b){return a+-b;}
static CSec operator*(const CSec&a,const CSec&b){return CSec(a.b*b.b,a.b*b.d+a.d*b.b+(a.d*b.d)*cancellation_rho);}
static CSec operator*(const CSec&a,C b){return CSec(a.b*b,a.d*b);}
static CSec cj(const CSec&a){return CSec(cj(a.b),cj(a.d));}
static CSec real(const CSec&a){return CSec(real(a.b),real(a.d));}
static CSec abs2(const CSec&a){return real(a*cj(a));}
static CSec sq(const CSec&a){return a*a;}
static CSec powu(CSec a,int k){if(k<0)return powu(cj(a),-k);CSec z(1);for(int i=0;i<k;i++)z=z*a;return z;}
static T value(const CSec&a){return a.b+a.d*cancellation_rho;}
static array<CSec,6> cancellation_coeffs(CSec A,CSec B){CSec ai=cj(A),bi=cj(B);return {
 -sq(A-B)*(A+B)*sq(ai)*sq(bi),
 (A-B)*(A+B)*(A*B-CSec(1))*sq(ai)*bi,
 sq(B-CSec(1))*(B+CSec(1))*ai*bi,
 -(sq(A)-B)*(B-CSec(1))*(B+CSec(1))*ai*sq(bi),
 sq(A-CSec(1))*(A+CSec(1))*ai*bi,
 (A-CSec(1))*(A+CSec(1))*(A-sq(B))*sq(ai)*bi};}

// Layout is identical to normalized_region: centers[16], radii[4],
// (center phase - exact cube-root anchor)/rho[16], roots[16], rho[1].
static array<T,4> cancellation_displacements(const double*input){
 array<T,4>out;I rho(input[52]);
 for(int i=0;i<4;i++){
  C centre(I(input[4*i],input[4*i+1]),I(input[4*i+2],input[4*i+3]));
  const double*p=input+20+4*i;
  T z(C(I(p[0],p[1]),I(p[2],p[3])));C co=centre*(I(1)/rho);
  for(int k=1;k<=TM_ORDER;k++){
   co=co*ii*(I(input[16+i])/I(k));array<int,4>e={0,0,0,0};e[i]=k;
   int n=0;while(basis.e[n]!=e)n++;z.a[n]=co;
  }
  I rem(1);for(int k=1;k<=TM_ORDER+1;k++)rem=rem*I(input[16+i])/I(k);
  rem=rem/rho;z.error=C(I(-rem.u,rem.u),I(-rem.u,rem.u));out[i]=z;
 }
 return out;
}

extern "C" int cancellation_region(const double*input,double*output){try{
 if(!std::numeric_limits<double>::is_iec559||std::fegetround()!=FE_TONEAREST)return -9;
 volatile double tiny=std::numeric_limits<double>::denorm_min(),one=1.0;
 if(tiny*one==0)return -9;
 if(!(input[52]>0 && input[52]<=1))return -8;
 auto ds0=cancellation_displacements(input);array<C,4>root;
 for(int i=0;i<4;i++){const double*p=input+36+4*i;root[i]=C(I(p[0],p[1]),I(p[2],p[3]));}
 C rho(input[52]),rho2=rho*rho;cancellation_rho=rho;
 CSec h(T(0),T(1)),h2=h*h,h3=h2*h,h4=h2*h2,h5=h4*h,h6=h3*h3;
 CSec a(T(root[0]),ds0[0]),b(T(root[1]),ds0[1]),c(T(root[2]),ds0[2]),d(T(root[3]),ds0[3]);
 T s=-ds0[0]-ds0[1],t=-ds0[2]-ds0[3],u0=-s-cj(t);
 // For unit phases and roots (alpha,beta,beta,alpha), alpha*beta=1:
 // U=-S-conj(T)+rho*(alpha*(|da|^2+|dc|^2)
 //   +beta*(|db|^2+|dd|^2)-dc*conj(da)-dd*conj(db)).
 T udef=(abs2(ds0[0])+abs2(ds0[2]))*root[0]
       +(abs2(ds0[1])+abs2(ds0[3]))*root[1]
       -ds0[2]*cj(ds0[0])-ds0[3]*cj(ds0[1]);
 CSec S(s),V(t),U(u0,udef);
 CSec x=abs2(S),y=abs2(V),z=abs2(U),p=x+y+z;
 CSec j=real(S*U*cj(V))*C(2),w=x*y+x*z+y*z-x*y*z*h2;
 CSec pp=sq(p),jj=sq(j);
 CSec R=w*C(324)-pp*C(81)+p*j*h*C(54)
   +(jj*C(27)+pp*p*C(18)-p*w*C(54))*h2
   +j*(w*C(30)-pp*C(24))*h3
   +(pp*w*C(2)-sq(pp)-sq(w)+p*jj*C(2))*h4
   +(jj*j*C(4)+pp*p*j*C(2)-p*w*j*C(2))*h5-pp*jj*h6;
 auto E=[&](const CSec&v){return p*C(9)-v*C(18)+j*h*C(3)
                 +(w-pp+v*p*C(2))*h2+(p-v*C(2))*j*h3;};
 array<CSec,3>P={S*V*C(3)+(U*sq(S)+cj(U)*sq(V))*h-z*S*V*h2,
                 U*cj(S)*C(3)+(V*sq(cj(S))+sq(U)*cj(V))*h-y*U*cj(S)*h2,
                 cj(U)*cj(V)*C(3)+(S*sq(cj(V))+sq(cj(U))*cj(S))*h-x*cj(U)*cj(V)*h2};
 array<CSec,3>n={abs2(P[0]),abs2(P[1]),abs2(P[2])};
 CSec delta=n[0]*n[1]*n[2];T deltaValue=value(delta),D=deltaValue*rho2*C(3);
 CSec f0=P[0]*n[1]*n[2]*C(0.5),f1=cj(P[1])*n[0]*n[2]*C(0.5),f2=cj(P[2])*n[0]*n[1]*C(0.5);
 array<CSec,6>M={delta*S*V*h2-E(z)*f0,delta*cj(U)*h,
                 delta*S*cj(U)*h2-E(y)*f1,delta*V*h,
                 delta*V*U*h2-E(x)*f2,delta*S*h};
 array<CSec,6>B={f0*(-ii),CSec(0),f1*ii,CSec(0),f2*ii,CSec(0)};
 array<CSec,3>xx={CSec(1),a,b},yy={CSec(1),c,d};
 int pq[6][2]={{1,1},{1,-1},{2,-1},{0,1},{-1,2},{1,0}},pairs[3][2]={{0,1},{0,2},{1,2}};
 T im=real((s*t)*(-ii)),im2=sq(im);
 // Scalar identities at rho=0: R0=324*im^2,
 // B0=1458*|S|^2*|T|^2*|S+conj(T)|^2*im^2; A0=-18*im*B0.
 T Rvalue=im2*C(324)+R.d*rho;
 T beta0=abs2(s)*abs2(t)*abs2(u0)*im2*C(1458);
 double*q=output;put(Rvalue.range().re,q);put(deltaValue.range().re,q);
 double best=INF;array<double,4>scores={1,1,1,1};
 for(int k=0;k<3;k++){
  int u=pairs[k][0],v=pairs[k][1];auto ds=cancellation_coeffs(xx[v]*cj(xx[u]),yy[v]*cj(yy[u]));CSec sa,sb;
  for(int m=0;m<6;m++){CSec co=ds[m]*powu(xx[u],-pq[m][0])*powu(yy[u],-pq[m][1]);sa=sa+co*M[m];sb=sb+co*B[m];}
  CSec aa=real((sa-cj(sa))*ii),bb=real((sb-cj(sb))*ii);
  T beta=beta0+bb.d*rho;
  T defect=aa.d+im*bb.d*C(18);
  T A=-(im*beta*C(18))+defect*rho;
  T Hbase=sq(defect)*rho-im*beta*defect*C(36)-sq(beta)*R.d;
  T common=beta*deltaValue*C(6),tail=sq(deltaValue)*rho2*C(9);
  // Output H/rho, not H: rho>0 preserves its sign. Physical H=rho^25*output.
  T Hm=Hbase+(common-tail)*Rvalue*rho;
  T Hp=Hbase-(common+tail)*Rvalue*rho;
  put(A.range().re,q);put((beta-D).range().re,q);put((beta+D).range().re,q);
  I hm=Hm.range().re,hp=Hp.range().re;
  if(hm.l<=0 && hm.u>=0)hm=intersect(hm,bernstein_real(Hm));
  if(hp.l<=0 && hp.u>=0)hp=intersect(hp,bernstein_real(Hp));
  put(hm,q);put(hp,q);
  double ma=mag(A.a[0].re),mh=std::max(mag(Hm.a[0].re),mag(Hp.a[0].re));
  if(ma>0 && mh>0){double rate=std::min((hm.u-hm.l)/mh,(hp.u-hp.l)/mh);
   if(rate<best){best=rate;scores={0,0,0,0};
    for(int m=1;m<basis.n;m++)for(int i=0;i<4;i++)if(basis.e[m][i])
     scores[i]+=mag(A.a[m].re)/ma+std::min(mag(Hm.a[m].re),mag(Hp.a[m].re))/mh;
   }
  }
 }
 for(double v:scores)*q++=v;return int(q-output);
 }catch(const NativeBudget&){return -2;}catch(...){return -1;}}
