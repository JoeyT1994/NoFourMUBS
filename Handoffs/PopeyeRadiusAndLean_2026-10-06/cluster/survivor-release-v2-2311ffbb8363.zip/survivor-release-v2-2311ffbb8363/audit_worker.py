"""Independent process for final replay of complete numerical parent covers.

Every inherited L/S terminal is recomputed with production's frozen replay
binary and PSD cache. Every new C terminal is recomputed from its exact method
recipe. Atomic receipts bind the unchanged source and all current task states;
an incomplete replay cannot mark a parent closed. No Lean admission follows.
"""
from __future__ import annotations

from fractions import Fraction as Q
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor, wait, FIRST_COMPLETED
from multiprocessing import get_context
import argparse
import collections
import ctypes
import fcntl
import gzip
import hashlib
import json
import math
import os
import resource
import signal
import sqlite3
import sys
import time
import traceback
import uuid

if __package__:
    from . import engines, task_queue as tq
    from . import safety_paths
else:
    import engines
    import task_queue as tq
    import safety_paths

STOP = False
STOP_EVENT = None
POOL_RUNTIME = None
POOL_QUEUE = None
SAFETY_PATHS = safety_paths.SafetyPaths()


class AuditBudget(Exception):
    pass


def _stop(signum, frame):
    global STOP
    STOP = True


def _memory_limit():
    if sys.platform == "linux":
        soft, hard = resource.getrlimit(resource.RLIMIT_AS)
        bound = 768 * 2**20
        for current in (soft,hard):
            if current != resource.RLIM_INFINITY:
                bound = min(bound,current)
        resource.setrlimit(resource.RLIMIT_AS,(bound,bound))


def _seconds(value, name, maximum):
    if isinstance(value,bool) or not math.isfinite(value) or not 0 < value <= maximum:
        raise ValueError(name + " outside its supported bound")
    return float(value)


class ReplayRuntime:
    def __init__(self, root, cache, leaf_seconds, area=None):
        self.root, self.cache = Path(root).resolve(), Path(cache).resolve()
        self.leaf_seconds = leaf_seconds
        self.config_path = self.root / "production/CONFIG.json"
        self.config = tq.read_json(self.config_path)
        self.config_sha = tq.sha_file(self.config_path)
        if self.config.get("physical_lean_admissions") != 0:
            raise ValueError("Production numerical scope changed")
        config_body = dict(self.config)
        campaign_sha = config_body.pop("campaign_sha256")
        if tq.digest(config_body) != campaign_sha:
            raise ValueError("Production configuration self-digest differs")
        if self.config.get("max_depth") != tq.MAX_DEPTH or self.config.get("max_tree_nodes") != tq.MAX_TREE_NODES:
            raise ValueError("Production depth/forest guards changed")
        for item in self.config["code_pins"]:
            if tq.sha_file(self.root / item["path"]) != item["sha256"]:
                raise ValueError("Frozen production source changed: " + item["path"])
        manifest = self.root / "SOURCE_PINS.json"
        for item in tq.read_json(manifest)["files"]:
            if tq.sha_file(self.root / item["path"]) != item["sha256"]:
                raise ValueError("Frozen provider source/input changed: " + item["path"])
        run_pins = self.root / "campaign/RUN_PINS.json"
        if tq.sha_file(run_pins) != self.config["run_pins_sha256"]:
            raise ValueError("Production run source manifest changed")
        self.old = engines._load("survivor_original_replay", self.root / "engine/certify_leaves.py")
        self.old.check_sources()
        self.old.guard()
        binary = Path(self.config["replay_binary"]).resolve()
        if not binary.is_relative_to(self.root) or tq.sha_file(binary) != self.config["replay_binary_sha256"]:
            raise ValueError("Frozen production linear replay binary changed")
        self.old.init(binary,3,"linear")
        psd_folder = self.root / "engine/upstream/ProvenResults/SignedCornerPSDPrune"
        self.psd = engines._load("survivor_original_psd_replay",psd_folder / "predicate.py")
        key = hashlib.sha256((psd_folder / "engine.cpp").read_bytes()
                             +(psd_folder / "determinant_terms.hpp").read_bytes()).hexdigest()[:24]
        old_cache = Path(self.config["replay_psd_cache"]).resolve()
        if not old_cache.is_relative_to(self.root):
            raise ValueError("Frozen PSD replay cache is outside the campaign")
        # Do not invoke library(): a missing historical verifier must not be
        # silently rebuilt or replaced by a newly compiled provider.
        psd_binary = old_cache / ("nofourmubs-signed-psd-" + key) / "engine.so"
        if tq.sha_file(psd_binary) != self.config["replay_psd_binary_sha256"]:
            raise ValueError("Frozen production PSD replay binary changed")
        lib = ctypes.CDLL(str(psd_binary))
        dp = ctypes.POINTER(ctypes.c_double)
        lib.compute.argtypes = [dp,dp,ctypes.c_int]
        lib.compute.restype = ctypes.c_int
        lib.certify.argtypes = [dp,ctypes.c_int,ctypes.c_int,dp]
        lib.certify.restype = ctypes.c_int
        self.psd._LIB = lib
        self.frozen_pins = {
            "production_config_sha256":self.config_sha,
            "linear_replay_binary_sha256":self.config["replay_binary_sha256"],
            "psd_replay_binary_sha256":self.config["replay_psd_binary_sha256"],
            "frozen_driver_sha256":tq.sha_file(self.old.__file__),
            "frozen_predicate_sha256":tq.sha_file(self.psd.__file__),
            "source_manifest_sha256":tq.sha_file(manifest),
            "run_pins_sha256":tq.sha_file(run_pins)}
        self.runtime_lease = None
        kwargs = {}
        if area is not None:
            if __package__:
                from .runtime import RuntimeLease
            else:
                from runtime import RuntimeLease
            self.runtime_lease = RuntimeLease(tq.TaskQueue(area), Path(__file__).resolve().parent)
            kwargs = self.runtime_lease.engine_kwargs()
        self.new_manifest = engines.initialize(self.root,self.cache, **kwargs)
        self.batch_cache = collections.OrderedDict()
        self.source_db = sqlite3.connect((self.root / "campaign/full_ring.sqlite").resolve().as_uri()+"?mode=ro&immutable=1",uri=True)
        self.source_db.execute("PRAGMA cache_size=-4096")
        self.reset(time.process_time()+600)

    @staticmethod
    def _identity(path):
        stat = path.stat()
        return (stat.st_dev,stat.st_ino,stat.st_size,stat.st_mtime_ns,stat.st_ctime_ns)

    def verify_parent_source(self, queue, key):
        """Hash each bounded source batch once per process; guard its identity."""
        parent = tq.read_json(queue.parent_dir(key) / "SOURCE.json.gz")
        source = parent["source"]
        batch = source["batch"]
        packet = self.root / "production/batches" / f"{batch//1000:03d}/{batch:06d}.json.gz"
        done = self.root / "elastic-run/batches" / f"{batch//1000:03d}/{batch:06d}/DONE.json"
        identity = (self._identity(packet),self._identity(done),self._identity(self.config_path))
        expected = (source["packet_sha256"],source["done_sha256"],source["input_batch_sha256"],source["config_sha256"])
        if batch not in self.batch_cache:
            if (tq.sha_file(packet)!=expected[0] or tq.sha_file(done)!=expected[1]
                    or expected[3]!=self.config_sha or tq.sha_file(self.config_path)!=self.config_sha):
                raise ValueError("Frozen parent source packet/DONE/config changed")
            rows, input_sha = tq._load_inputs(self.source_db,batch)
            if input_sha!=expected[2]:
                raise ValueError("Frozen parent input batch changed")
            record_hashes = bytearray()
            header = {}
            seen = 0
            for name,value in tq.stream_packet(packet):
                if name!="record":
                    header[name] = value
                    continue
                if (seen>=len(rows) or value.get("id")!=rows[seen]["id"]
                        or value.get("input_sha256")!=tq.digest(rows[seen])):
                    raise ValueError("Frozen source packet record/input census differs")
                record_hashes.extend(bytes.fromhex(tq.digest(value)))
                seen += 1
            if (seen!=len(rows) or header.get("batch")!=batch or header.get("count")!=seen
                    or header.get("input_batch_sha256")!=input_sha
                    or header.get("campaign_sha256")!=self.config["campaign_sha256"]):
                raise ValueError("Frozen source packet header differs")
            if identity!=(self._identity(packet),self._identity(done),self._identity(self.config_path)):
                raise ValueError("Source batch changed while hashing")
            # Compact fixed-size hashes avoid retaining all decoded source rows.
            entry = {"identity":identity,"expected":expected,"first":rows[0]["id"],
                     "count":len(rows),"row_hashes":b"".join(bytes.fromhex(tq.digest(row)) for row in rows),
                     "record_hashes":bytes(record_hashes)}
            self.batch_cache[batch] = entry
            if len(self.batch_cache)>4096:
                self.batch_cache.popitem(last=False)
        entry = self.batch_cache[batch]
        self.batch_cache.move_to_end(batch)
        if entry["identity"]!=identity or entry["expected"]!=expected:
            raise ValueError("Cached immutable source identity or pins changed")
        index = parent["id"]-entry["first"]
        if not 0<=index<entry["count"] or entry["row_hashes"][32*index:32*(index+1)]!=bytes.fromhex(tq.digest(parent["input"])):
            raise ValueError("Parent exact input differs from the original database")
        if entry["record_hashes"][32*index:32*(index+1)]!=bytes.fromhex(tq.digest(parent["source_record"])):
            raise ValueError("Parent source record is not the pinned original packet member")

    def reset(self, deadline):
        self.deadline = deadline
        self.counts = collections.Counter()
        self.chain = hashlib.sha256()
        self.new_provider_pins = {}

    def _budget(self):
        if STOP or (STOP_EVENT is not None and STOP_EVENT.is_set()):
            raise AuditBudget("stop_requested")
        self.old.guard()
        remaining = self.deadline-time.process_time()
        if remaining <= 0:
            raise AuditBudget("parent_cpu_budget")
        return min(self.leaf_seconds,remaining)

    def old_leaf(self, token, centers, radii):
        seconds = self._budget()
        began = time.process_time()
        try:
            with engines._cpu_limit(seconds):
                if token == "L":
                    self.old._LIB.set_budget(seconds)
                    witness = self.old.terminal(centers,radii)
                    if witness.get("ok") is not True:
                        raise ValueError("Inherited signed-linear leaf failed fresh replay")
                elif token == "S":
                    witness = self.psd.coupled_leaf(centers,radii,extra=False,q_depth=8,q_nodes=511)
                    if witness is None:
                        raise ValueError("Inherited original PSD leaf failed fresh replay")
                    engines._finite(witness)
                else:
                    raise ValueError("Unknown inherited leaf method")
                if time.process_time()-began > seconds:
                    raise AuditBudget("inherited_leaf_cpu_budget")
        except engines.CpuBudget as error:
            raise AuditBudget("inherited_leaf_cpu_budget") from error
        except self.old.Budget as error:
            if str(error) == "native_cpu_budget":
                raise AuditBudget("inherited_leaf_cpu_budget") from error
            raise
        geometry = {"centers":list(map(str,centers)),"radii":list(map(str,radii)),"units":"radians"}
        evidence = tq.digest({"method":token,"input":geometry,"witness":witness,
                              "provider_hashes":self.frozen_pins})
        self.chain.update(tq.canonical({"method":token,"evidence_sha256":evidence})+b"\n")
        self.counts[token] += 1
        return {"ok":True,"status":"PASS","method":token,"evidence_sha256":evidence,
                "physical_lean_admissions":0}

    def new_leaf(self, recipe):
        fresh = engines.replay_recipe(recipe,self._budget())
        if fresh.get("ok") is not True or fresh.get("status") != "PASS":
            if fresh.get("reason") in ("cpu_budget","native_cpu_budget"):
                raise AuditBudget("new_leaf_cpu_budget")
            raise ValueError("New survivor recipe failed independent final replay: " + str(fresh.get("reason")))
        method = recipe["method"]
        for identity, item in tq.recipe_identities(recipe).items():
            self.new_provider_pins[identity] = item["provider_hashes"]
        self.chain.update(tq.canonical({"method":method,"evidence_sha256":fresh["evidence_sha256"]})+b"\n")
        self.counts[method] += 1
        return fresh


def _binding(value):
    keys = ("id","parent_key","input_sha256","source_tree_sha256","source_record_sha256",
            "source_packet_sha256","source_done_sha256","source_config_sha256","task_states_sha256",
            "old_closed_leaves","new_closed_leaves","pending_leaves","tasks","nodes")
    extra = {k: value[k] for k in ("cover_mode", "root_candidate_sha256", "historical_tree_sha256", "historical_nodes") if k in value}
    return {**{k:value[k] for k in keys}, **extra, "tree_sha256":tq.tree_sha(value["tree"]),
            "new_leaf_index_sha256":tq.digest(value["new_leaf_proofs"])}


def _task_entries(place):
    with (place / "TASKS.jsonl").open("rb") as stream:
        while line := stream.readline(65537):
            if len(line)>65536 or not line.endswith(b"\n"):
                raise ValueError("Interrupted or oversized task inventory")
            yield json.loads(line)


def _ready_candidate(queue, key):
    """Cheap readiness filter; audit_parent is the authoritative validation."""
    place = queue.parent_dir(key)
    root_state = place / "ROOT_STATE.json"
    if root_state.exists() and tq.read_json(root_state).get("status") in ("candidate", "accepted"):
        return True
    for item in _task_entries(place):
        state = tq.read_json(queue.task_dir(item["task_id"]) / "STATE.json.gz")
        if state["status"] not in ("done","parked") or any("P" in r["tree"] for r in state["roots"]):
            return False
    return True


def _publish_receipt(place, value):
    receipt = dict(value)
    receipt["receipt_sha256"] = tq.digest(value)
    archive = place / "final_replays" / (receipt["receipt_sha256"] + ".json")
    tq.immutable_json(archive,receipt)
    tq.durable_json(place / "FINAL_REPLAY.json",receipt)
    return receipt


def audit_provider_hashes():
    place = Path(__file__).resolve().parent
    return {"audit_worker_sha256": tq.sha_file(__file__),
            "queue_driver_sha256": tq.sha_file(tq.__file__),
            "survivor_driver_sha256": tq.sha_file(engines.__file__),
            "parent_roots_sha256": tq.sha_file(place / "parent_roots.py"),
            "reuse_store_sha256": tq.sha_file(place / "reuse_store.py"),
            "safety_paths_sha256": tq.sha_file(place / "safety_paths.py"),
            "node_safety_cache_sha256": tq.sha_file(place / "node_safety_cache.py")}


def queue_failure_detected(root, queue):
    key = (safety_paths.absolute(root), safety_paths.absolute(queue.area))
    if SAFETY_PATHS.latched(key) is not None:
        return True
    failure = key[1] / "FAILURE.json"
    if failure in SAFETY_PATHS.present((failure,), anchors=(key[1],)):
        SAFETY_PATHS.latch(key, "continuation_failure")
        return True
    return False


def _new_pins_match(receipt, runtime, value):
    expected = _provider_dependencies(value)
    stored = receipt.get("new_provider_hashes",{})
    return stored == {identity: item["provider_hashes"] for identity, item in expected.items()} and _providers_authorized(runtime, expected)


def _provider_dependencies(value):
    expected = {}
    for proof in value["new_leaf_proofs"].values():
        expected.update(proof.get("provider_dependencies", {
            proof["provider_identity"]: {"method": proof["method"], "provider_hashes": proof["provider_hashes"]}}))
    return expected


def _providers_authorized(runtime, expected):
    authorized = {item["method"] + "@" + tq.digest(item["provider_hashes"]): item["provider_hashes"]
                  for item in runtime.new_manifest.get("provider_identities", [])}
    if not authorized:
        authorized = {method + "@" + tq.digest(pins): pins for method, pins in runtime.new_manifest["provider_hashes"].items()}
    return all(authorized.get(identity) == item["provider_hashes"] for identity, item in expected.items())


def _audit_one_locked(queue, key, runtime, parent_seconds):
    place = queue.parent_dir(key)
    with (place / "AUDIT.lock").open("a") as lock:
        try:
            fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:
            return {"parent_key":key,"status":"BUSY","closed":False,"physical_lean_admissions":0}
        if not _ready_candidate(queue,key):
            return {"parent_key":key,"status":"NOT_READY","closed":False,"physical_lean_admissions":0}
        began = time.process_time()
        runtime.verify_parent_source(queue,key)
        before = tq.audit_parent(queue,key,require_final=True)
        if not before["candidate_complete"]:
            return {"parent_key":key,"status":"NOT_READY","closed":False,"physical_lean_admissions":0}
        binding = _binding(before)
        expected = _provider_dependencies(before)
        pin = audit_provider_hashes()
        prior_path = place / "FINAL_REPLAY.json"
        if prior_path.exists():
            prior = tq.read_json(prior_path)
            body = {k:v for k,v in prior.items() if k!="receipt_sha256"}
            if prior.get("receipt_sha256") != tq.digest(body):
                raise ValueError("Prior final replay receipt changed")
            same = (prior.get("binding")==binding and prior.get("audit_provider_hashes")==pin
                    and prior.get("frozen_provider_hashes")==runtime.frozen_pins
                    and _new_pins_match(prior,runtime,before))
            if same and prior.get("status")=="PASS" and prior.get("closed") is True:
                return dict(prior,reused_unchanged_receipt=True)
            if (same and prior.get("status")=="UNRESOLVED"
                    and prior.get("reason") in ("parent_cpu_budget","inherited_leaf_cpu_budget","new_leaf_cpu_budget")
                    and prior.get("attempted_parent_cpu_seconds",0)>=parent_seconds
                    and prior.get("attempted_leaf_cpu_seconds",0)>=runtime.leaf_seconds):
                return dict(prior,reused_unchanged_budget_result=True)
        runtime.reset(began+parent_seconds)
        base = {"schema":"survivor-final-replay-v1","parent_key":key,"id":before["id"],
                "binding":binding,"binding_sha256":tq.digest(binding),"audit_provider_hashes":pin,
                "frozen_provider_hashes":runtime.frozen_pins,"auditor_pid":os.getpid(),
                "new_provider_hashes":{identity:item["provider_hashes"] for identity,item in expected.items()},
                "attempted_parent_cpu_seconds":parent_seconds,"attempted_leaf_cpu_seconds":runtime.leaf_seconds,
                "updated_unix":time.time(),"physical_lean_admissions":0}
        try:
            if not _providers_authorized(runtime, expected):
                raise ValueError("Current/legacy dependent provider is not pinned by this release")
            result = tq.audit_parent(queue,key,require_final=True,
                                     replay_fn=runtime.new_leaf,old_replay_fn=runtime.old_leaf)
            if not result["closed"] or result["audit"]!="FRESH_ALL_LEAVES_PASS":
                raise ValueError("Final replay did not verify a complete all-leaf cover")
            after = tq.audit_parent(queue,key,require_final=True)
            if _binding(result)!=binding or _binding(after)!=binding:
                raise ValueError("Parent/task state changed during final replay")
            runtime.old.guard()
            runtime.verify_parent_source(queue,key)
            value = dict(base,status="PASS",closed=True,audit="FRESH_ALL_LEAVES_PASS",
                         certificate_sha256=result["certificate_sha256"],
                         replayed_leaves=dict(runtime.counts),replay_evidence_chain_sha256=runtime.chain.hexdigest(),
                         new_provider_hashes=base["new_provider_hashes"],
                         cpu_seconds=time.process_time()-began)
            return _publish_receipt(place,value)
        except AuditBudget as error:
            return _publish_receipt(place,dict(base,status="UNRESOLVED",closed=False,reason=str(error),
                                              replayed_leaves=dict(runtime.counts),
                                              cpu_seconds=time.process_time()-began))
        except BaseException as error:
            _publish_receipt(place,dict(base,status="FAIL",closed=False,reason=str(error),
                                       exception_type=type(error).__name__,traceback=traceback.format_exc(),
                                       replayed_leaves=dict(runtime.counts),cpu_seconds=time.process_time()-began))
            raise


def audit_one(queue, key, runtime, parent_seconds):
    """Hold the parent gate while selecting/accepting an alternate root cover."""
    place = queue.parent_dir(key)
    with (place / "PARENT_RUN.lock").open("a") as gate:
        try:
            fcntl.flock(gate, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            return {"parent_key": key, "status": "BUSY", "closed": False, "physical_lean_admissions": 0}
        parent = tq.read_json(place / "SOURCE.json.gz")
        dispatch = queue.parent_dispatch(parent)
        if not queue.dispatch_runnable(dispatch):
            queue.suppress_held_parent(parent, dispatch)
            return {"parent_key": key, "status": "HELD_DISPATCH", "closed": False,
                    "reason": dispatch["decision"]["reason"], "physical_lean_admissions": 0}
        value = _audit_one_locked(queue, key, runtime, parent_seconds)
        if value["status"] in ("PASS", "UNRESOLVED"):
            if __package__:
                from .parent_roots import finalize_root
            else:
                from parent_roots import finalize_root
            finalize_root(queue, key, value["status"] == "PASS")
            queue.parent_marker("replay_ready", key).unlink(missing_ok=True)
        elif value["status"] == "NOT_READY":
            queue.parent_marker("replay_ready", key).unlink(missing_ok=True)
        return value


def _pool_init(root, area, cache, leaf_seconds, stop_event):
    global POOL_RUNTIME, POOL_QUEUE, STOP_EVENT
    _memory_limit()
    signal.signal(signal.SIGTERM,_stop)
    signal.signal(signal.SIGUSR1,_stop)
    STOP_EVENT = stop_event
    POOL_QUEUE = tq.TaskQueue(area)
    POOL_RUNTIME = ReplayRuntime(root,cache,leaf_seconds,area)


def _pool_one(task):
    key,seconds = task
    value = audit_one(POOL_QUEUE,key,POOL_RUNTIME,seconds)
    return {"parent_key":key,"status":value["status"],"closed":value["closed"],
            "receipt_sha256":value.get("receipt_sha256"),"physical_lean_admissions":0}


def _summarize(queue, root, cache, accept, seen):
    """Stream current exact covers and matching final replay receipts."""
    root = Path(root).resolve()
    runtime = ReplayRuntime(root,cache,30,queue.area)
    config_sha = tq.sha_file(root / "production/CONFIG.json")
    audit_pins = audit_provider_hashes()
    counts = collections.Counter()
    chain = hashlib.sha256()
    source_batches = set()
    for key in queue.iter_parent_keys():
        place = queue.parent_dir(key)
        parent = tq.read_json(place / "SOURCE.json.gz")
        batch = parent["source"]["batch"]
        runtime.verify_parent_source(queue,key)
        source_batches.add(batch)
        value = tq.audit_parent(queue,key,require_final=False)
        try:
            seen.execute("INSERT INTO seen VALUES (?)",(value["id"],))
        except sqlite3.IntegrityError as error:
            raise ValueError("Duplicate original root in final summary") from error
        binding = _binding(value)
        parked = active = False
        for item in _task_entries(place):
            ident = item["task_id"]
            state = tq.read_json(queue.task_dir(ident) / "STATE.json.gz")
            if state["status"]=="parked":
                parked = True
                counts["parked_tasks"] += 1
            if state["status"] not in ("done","parked"):
                active = True
        accepted = False
        receipt_sha = None
        path = place / "FINAL_REPLAY.json"
        if path.exists():
            receipt = tq.read_json(path)
            body = {k:v for k,v in receipt.items() if k!="receipt_sha256"}
            if receipt.get("receipt_sha256")!=tq.digest(body):
                raise ValueError("Final parent receipt digest differs")
            receipt_sha = receipt["receipt_sha256"]
            accepted = (receipt.get("status")=="PASS" and receipt.get("closed") is True
                        and receipt.get("binding")==binding and receipt.get("binding_sha256")==tq.digest(binding)
                        and receipt.get("audit")=="FRESH_ALL_LEAVES_PASS"
                        and receipt.get("audit_provider_hashes")==audit_pins
                        and receipt.get("frozen_provider_hashes")==runtime.frozen_pins
                        and _new_pins_match(receipt,runtime,value)
                        and receipt.get("physical_lean_admissions")==0
                        and value["candidate_complete"] and (not active or value.get("cover_mode") == "whole_original_root"))
            if receipt.get("status")=="FAIL":
                counts["failed_replay_roots"] += 1
        if accepted and value.get("cover_mode") == "whole_original_root":
            active = False  # Historical runnable states are superseded, preserved evidence.
        counts["original_roots"] += 1
        counts["original_roots_closed" if accepted else "original_roots_incomplete"] += 1
        counts["parked_roots"] += parked
        counts["active_roots"] += active
        counts["candidate_roots_without_replay"] += value["candidate_complete"] and not accepted
        counts["pending_leaves"] += value["pending_leaves"]
        counts["old_closed_leaves"] += value["old_closed_leaves"]
        counts["new_closed_leaves"] += value["new_closed_leaves"]
        if accepted:
            counts["fresh_replayed_inherited_leaves"] += value["old_closed_leaves"]
            accept({"id":value["id"],"parent_key":key,"receipt_sha256":receipt_sha})
        chain.update(tq.canonical({"parent_key":key,"binding_sha256":tq.digest(binding),
                                   "receipt_sha256":receipt_sha,"closed":accepted})+b"\n")
    if tq.sha_file(root / "production/CONFIG.json")!=config_sha:
        raise ValueError("Production config changed during final summary")
    for name in ("original_roots","original_roots_closed","original_roots_incomplete","parked_roots",
                 "parked_tasks","active_roots","candidate_roots_without_replay","failed_replay_roots",
                 "pending_leaves","old_closed_leaves","new_closed_leaves","fresh_replayed_inherited_leaves"):
        counts.setdefault(name,0)
    commits = queue.area / "batches"
    committed = set()
    if commits.exists():
        with os.scandir(commits) as entries:
            for entry in entries:
                if entry.is_file() and entry.name.endswith(".json"):
                    commit = tq.read_json(entry.path)
                    committed.add(commit["batch"])
                    counts["source_records_in_committed_batches"] += commit["records"]
                    counts["source_already_closed_records"] += commit["records"]-commit["parents"]-commit["skipped_non_native"]
                    counts["skipped_non_native_records"] += commit["skipped_non_native"]
                    counts["source_native_survivor_parents"] += commit["parents"]
                    if commit["records"]<commit["parents"]+commit["skipped_non_native"]:
                        raise ValueError("Impossible committed source census")
    if counts["source_native_survivor_parents"]!=counts["original_roots"]:
        raise ValueError("Final summary omitted or duplicated committed survivor parents")
    plan_path = root / "elastic-run/PLAN.json"
    planned = {item["batch"] for item in tq.read_json(plan_path)["batches"]} if plan_path.exists() else None
    missing_batches = len(planned-committed) if planned is not None else None
    result = {"schema":"survivor-final-audit-v1",
              "status":"PASS_FRESH_NUMERICAL_AUDIT" if counts["original_roots_incomplete"]==0 and missing_batches==0 else "INCOMPLETE_NUMERICAL_COVER",
              "scope":"finalized imported native survivor parent roots only",
              **dict(counts),"source_batches":len(source_batches),"production_config_sha256":config_sha,
              "committed_source_batches":len(committed),"missing_source_batches":missing_batches,
              "parent_state_and_receipt_chain_sha256":chain.hexdigest(),"audit_provider_hashes":audit_pins,
              "all_imported_roots_closed":counts["original_roots_incomplete"]==0,
              "updated_unix":time.time(),"physical_lean_admissions":0}
    return result


def summarize(queue, root, cache):
    """Publish a compact accepted-ID stream bound to the final summary."""
    target = queue.area / "CLOSED_NATIVE_IDS.jsonl.gz"
    tmp = target.with_name(target.name+"."+uuid.uuid4().hex+".tmp")
    count = 0
    seen = sqlite3.connect("")
    seen.execute("PRAGMA cache_size=-4096")
    seen.execute("CREATE TABLE seen (id INTEGER PRIMARY KEY)")
    try:
        with tmp.open("xb") as raw:
            with gzip.GzipFile(fileobj=raw,mode="wb",compresslevel=3,mtime=0) as compressed:
                def accept(record):
                    nonlocal count
                    compressed.write(tq.canonical(record)+b"\n")
                    count += 1
                result = _summarize(queue,root,cache,accept,seen)
            raw.flush()
            os.fsync(raw.fileno())
        if count!=result["original_roots_closed"]:
            raise ValueError("Accepted-ID stream count differs from final replay census")
        os.replace(tmp,target)
        tq._fsync_dir(queue.area)
        result["closed_native_ids"] = {"path":target.name,"sha256":tq.sha_file(target),"count":count}
        tq.durable_json(queue.area / "FINAL_AUDIT.json",result)
        return result
    finally:
        seen.close()
        tmp.unlink(missing_ok=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root",type=Path,required=True)
    parser.add_argument("--queue",type=Path,required=True)
    parser.add_argument("--cache",type=Path,required=True)
    parser.add_argument("--parent")
    parser.add_argument("--jobs",type=int,default=1)
    parser.add_argument("--summary-only",action="store_true")
    parser.add_argument("--watch",action="store_true")
    parser.add_argument("--ready-only",action="store_true")
    parser.add_argument("--max-parents",type=int,default=0)
    parser.add_argument("--wall-seconds",type=float,default=3600)
    parser.add_argument("--parent-cpu-seconds",type=float,default=600)
    parser.add_argument("--leaf-cpu-seconds",type=float,default=30)
    args = parser.parse_args()
    if not __debug__ or args.max_parents<0 or not 1<=args.jobs<=128:
        raise ValueError("Unsupported audit invocation")
    _seconds(args.wall_seconds,"wall seconds",60*3600)
    _seconds(args.parent_cpu_seconds,"parent CPU seconds",86400)
    _seconds(args.leaf_cpu_seconds,"leaf CPU seconds",600)
    _memory_limit()
    signal.signal(signal.SIGTERM,_stop)
    signal.signal(signal.SIGUSR1,_stop)
    queue = tq.TaskQueue(args.queue)
    queue_config = tq.read_json(queue.area / "CONFIG.json")
    if queue_config["config_sha256"]!=tq.sha_file(args.root / "production/CONFIG.json"):
        raise ValueError("Audit queue belongs to a different production source")
    if args.summary_only:
        print(json.dumps(summarize(queue,args.root,args.cache),sort_keys=True),flush=True)
        return 0
    started = time.monotonic()
    counts = collections.Counter()
    if args.watch and (args.parent or args.summary_only):
        raise ValueError("Watch requires the incremental ready marker stream")
    ctx = get_context("spawn")
    stop_event = ctx.Event()
    exhausted = False
    submitted = 0
    drained = False
    keys = ((args.parent,) if args.parent else queue.iter_parent_markers("replay_ready")
            if args.ready_only or args.watch else queue.iter_parent_keys())
    iterator = iter(keys)
    with ProcessPoolExecutor(max_workers=args.jobs,mp_context=ctx,initializer=_pool_init,
                             initargs=(args.root,queue.area,args.cache,args.leaf_cpu_seconds,stop_event)) as pool:
        pending = {}
        in_flight = set()
        while pending or not exhausted or args.watch:
            if queue_failure_detected(args.root, queue):
                raise ValueError("Continuation failure stops independent replay watch")
            if STOP or time.monotonic()-started >= args.wall_seconds:
                exhausted = True
                stop_event.set()
            while not exhausted and len(pending) < 2*args.jobs:
                if args.max_parents and submitted >= args.max_parents:
                    exhausted = True
                    break
                key = next(iterator,None)
                if key is None:
                    exhausted = True
                    break
                if key in in_flight:
                    continue
                if not (args.parent or args.ready_only or args.watch) and not _ready_candidate(queue,key):
                    continue
                future = pool.submit(_pool_one,(key,args.parent_cpu_seconds))
                pending[future] = key
                in_flight.add(key)
                submitted += 1
            if pending:
                done,_ = wait(pending,timeout=1,return_when=FIRST_COMPLETED)
                for future in done:
                    key = pending.pop(future)
                    in_flight.remove(key)
                    try:
                        value = future.result()
                    except BaseException as error:
                        tq.durable_json(queue.area / "FAILURE.json", {
                            "reason": "independent_replay_failure", "parent_key": key,
                            "type": type(error).__name__, "error": str(error),
                            "physical_lean_admissions": 0})
                        stop_event.set()
                        raise
                    counts[value["status"]] += 1
                    counts["attempted"] += 1
                    print(json.dumps(value,sort_keys=True),flush=True)
            if not pending and exhausted:
                if (not args.watch or STOP or time.monotonic()-started >= args.wall_seconds
                        or args.max_parents and submitted >= args.max_parents):
                    break
                # At most the bounded in-flight window is ever loaded.  Budget
                # receipts consume their markers, so they are never hot retried.
                iterator = iter(queue.iter_parent_markers("replay_ready"))
                first = next(iterator,None)
                drain_request = safety_paths.absolute(queue.area) / "REPLAY_DRAIN_REQUESTED.json"
                if first is None and drain_request in SAFETY_PATHS.present((drain_request,), anchors=(queue.area,)):
                    drained = True
                    break
                if first is None:
                    time.sleep(1)
                    iterator = iter(queue.iter_parent_markers("replay_ready"))
                else:
                    from itertools import chain
                    iterator = chain((first,),iterator)
                    time.sleep(0.25)
                exhausted = False
    result = {"status":"CHECKPOINTED" if STOP else "AUDIT_DRAINED" if drained else "AUDIT_FINISHED","counts":dict(counts),
              "pid":os.getpid(),"updated_unix":time.time(),"physical_lean_admissions":0}
    tq.durable_json(queue.area / "audit_workers" / (str(os.getpid())+".json"),result)
    print(json.dumps(result,sort_keys=True),flush=True)
    return 75 if STOP else 0


if __name__=="__main__":
    raise SystemExit(main())
