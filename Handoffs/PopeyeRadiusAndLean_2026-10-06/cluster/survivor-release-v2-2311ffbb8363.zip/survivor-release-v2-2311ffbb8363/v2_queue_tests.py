"""Synthetic v2 gates, exact containing replay, partials, and root audit tests."""
from fractions import Fraction as Q
from pathlib import Path
from types import SimpleNamespace
import collections
import json
import sqlite3
import tempfile
import unittest
from unittest.mock import patch

import audit_worker as audit
import frontier
import normalized_audit_tests as old_audit
import parent_roots
import queue_tests as fixtures
import reuse_store as reuse
import task_queue as tq
import worker


def root_schedule(methods=None):
    value = fixtures.schedule(methods)
    value.update(root_methods=methods or [{"method": "order3", "cpu_seconds": 1}],
                 root_cpu_seconds=30, root_max_attempts=2, partial_composition=False)
    return value


def partial(cc, rr, sigma=1, orientation=False, non_tao=False):
    value = fixtures.GoodProvider.evaluate(cc, rr, "order3", 1)
    value["ok"] = False
    value["reason"] = "synthetic_partial"
    value["witness"] = {"signed": sigma, "orientation": orientation, "non_tao": non_tao}
    value["replay"]["evidence_sha256"] = tq.digest({k:value[k] for k in
        ("schema", "ok", "reason", "method", "input", "provider_hashes", "witness")})
    value["partial"] = {"schema": "survivor-partial-signs-v1", "same_box": True,
                        "exclusions": [] if sigma == 0 else [{"orientation": orientation, "sigma": sigma}],
                        "non_tao": non_tao, "all_excluded": False}
    return value


class PooledProvider:
    @staticmethod
    def evaluate(cc, rr, method, seconds):
        record = partial(cc, rr, 1 if method == "order3" else -1)
        record["method"] = method
        record["replay"].update(method=method, evidence_sha256=tq.digest({k:record[k] for k in
            ("schema", "ok", "reason", "method", "input", "provider_hashes", "witness")}))
        return record

    @staticmethod
    def make_recipe(record):
        recipe = {"schema": "survivor-leaf-recipe-v1", "method": record["method"],
                  "input": record["input"], "provider_hashes": record["provider_hashes"],
                  "reason": record["reason"], "replay": record["replay"],
                  "witness_sha256": tq.digest(record["witness"]), "source_ok": record["ok"]}
        if record["method"] == "pooled_signs":
            recipe["contributors"] = record["witness"]["contributors"]
        return recipe

    @staticmethod
    def compose_partials(records, seconds=10, centers=None, radii=None):
        box = {"centers": list(map(str, centers)), "radii": list(map(str, radii)), "units": "radians"}
        if not all(reuse.contains(r["input"], box) for r in records):
            raise ArithmeticError("Synthetic ancestor containment failed")
        result = fixtures.GoodProvider.evaluate(centers, radii, "pooled_signs", seconds)
        result["witness"] = {"contributors": [PooledProvider.make_recipe(r) for r in records]}
        result["replay"]["evidence_sha256"] = tq.digest({k:result[k] for k in
            ("schema", "ok", "reason", "method", "input", "provider_hashes", "witness")})
        return result

    replay = staticmethod(fixtures.GoodProvider.replay)

    @staticmethod
    def replay_recipe(recipe):
        contributors = []
        for saved in recipe["contributors"]:
            record = PooledProvider.evaluate(list(map(Q,saved["input"]["centers"])),
                                            list(map(Q,saved["input"]["radii"])), saved["method"], 10)
            if PooledProvider.make_recipe(record) != saved:
                raise ArithmeticError("Synthetic contributor reconstruction changed")
            contributors.append(record)
        record = PooledProvider.compose_partials(contributors, centers=list(map(Q,recipe["input"]["centers"])),
                                                radii=list(map(Q,recipe["input"]["radii"])))
        if tq.digest(record["witness"]) != recipe["witness_sha256"] or record["replay"] != recipe["replay"]:
            raise ArithmeticError("Synthetic pooled reconstruction changed")
        return PooledProvider.replay(record)


class V2Tests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="mub6-v2-test-")
        self.base = Path(self.temp.name)
        self.root, self.area = self.base / "source", self.base / "queue"
        worker.HINT_CACHE = None

    def tearDown(self):
        self.temp.cleanup()

    def make(self, tree="0LP", reason="cpu_budget"):
        fixtures.fixture(self.root, tree, reason=reason)
        tq.durable_json(self.root / "elastic-run/PLAN.json", {"batches": [{"batch": 0}]})
        queue = tq.TaskQueue(self.area)
        queue.import_finalized(self.root, 16)
        return queue, next(queue.iter_parent_keys())

    def candidate(self, queue):
        lease = queue.claim_root("root", schedule_sha256="a"*64)
        self.assertIsNotNone(lease)
        result = worker.process_root_lease(lease, root_schedule(), self.root, provider=fixtures.GoodProvider)
        self.assertEqual(result["status"], "root_candidate")

    def test_root_and_descendant_live_leases_exclude_each_other(self):
        queue, key = self.make()
        leaf = queue.claim("leaf")
        self.assertIsNone(queue.claim_root("root", schedule_sha256="a"*64))
        leaf.release()
        root = queue.claim_root("root", schedule_sha256="a"*64)
        self.assertIsNone(queue.claim("leaf2"))
        self.assertIsNone(queue.claim_root("root2", schedule_sha256="a"*64))
        root.release("root_schedule_exhausted")
        leaf = queue.claim("leaf3")
        self.assertIsNotNone(leaf)
        leaf.close()

    def test_expired_live_root_flock_cannot_be_stolen(self):
        queue, key = self.make()
        root = queue.claim_root("root", schedule_sha256="a"*64)
        value = tq.read_json(root.directory / "ROOT_LEASE.json")
        value["expires_unix"] = 0
        tq.durable_json(root.directory / "ROOT_LEASE.json", value)
        self.assertIsNone(queue.claim_root("thief", schedule_sha256="a"*64))
        root.close()
        recovered = queue.claim_root("recover", schedule_sha256="a"*64)
        self.assertIsNotNone(recovered)
        recovered.release("root_schedule_exhausted")

    def test_whole_root_candidate_preserves_descendants_until_fresh_replay(self):
        queue, key = self.make("0L"+fixtures.full_tree(5))
        before = {p.name: tq.sha_file(p/"STATE.json.gz") for p in queue.iter_task_dirs()}
        source_sha = tq.sha_file(queue.parent_dir(key)/"SOURCE.json.gz")
        self.candidate(queue)
        self.assertEqual(queue.readiness_count(), 0)
        self.assertEqual(list(queue.iter_parent_markers("replay_ready")), [key])
        self.assertIsNone(queue.claim("descendant"))
        value = tq.audit_parent(queue, key, self.root, require_final=True)
        self.assertEqual((value["tree"], value["nodes"], value["old_closed_leaves"], value["pending_leaves"]), ("C", 1, 0, 0))
        self.assertFalse(value["closed"])
        value = tq.audit_parent(queue, key, self.root, True, fixtures.GoodProvider.replay_recipe)
        self.assertTrue(value["closed"])
        self.assertEqual(value["audit"], "FRESH_ALL_LEAVES_PASS")
        self.assertEqual(before, {p.name:tq.sha_file(p/"STATE.json.gz") for p in queue.iter_task_dirs()})
        self.assertEqual(source_sha, tq.sha_file(queue.parent_dir(key)/"SOURCE.json.gz"))

    def test_whole_root_audit_budget_restores_exact_frontier_and_consumes_marker(self):
        queue, key = self.make("0L"+fixtures.full_tree(4))
        before = {p.name:tq.sha_file(p/"STATE.json.gz") for p in queue.iter_task_dirs()}
        self.candidate(queue)
        runtime = old_audit.FakeRuntime(self.root)
        try:
            runtime.new_leaf = lambda recipe: (_ for _ in ()).throw(audit.AuditBudget("new_leaf_cpu_budget"))
            value = audit.audit_one(queue, key, runtime, 600)
            self.assertEqual(value["status"], "UNRESOLVED")
            self.assertEqual(tq.read_json(queue.parent_dir(key)/"ROOT_STATE.json")["status"], "replay_parked")
            self.assertEqual(queue.readiness_count(), len(before))
            self.assertEqual(list(queue.iter_parent_markers("replay_ready")), [])
            self.assertEqual(before, {p.name:tq.sha_file(p/"STATE.json.gz") for p in queue.iter_task_dirs()})
            self.assertIsNone(queue.claim_root("root-again", schedule_sha256="a"*64))
            lease = queue.claim("descendant")
            self.assertIsNotNone(lease)
            lease.close()
        finally:
            runtime.source_db.close()

    def test_whole_root_final_receipt_can_close_preserved_runnable_history(self):
        queue, key = self.make("0L"+fixtures.full_tree(4))
        self.candidate(queue)
        runtime = old_audit.FakeRuntime(self.root)
        try:
            value = audit.audit_one(queue, key, runtime, 600)
            self.assertEqual((value["status"], runtime.old_calls, runtime.new_calls), ("PASS", 0, 1))
            self.assertEqual(tq.read_json(queue.parent_dir(key)/"ROOT_STATE.json")["status"], "accepted")
            with patch.object(audit,"ReplayRuntime",return_value=runtime):
                summary = audit.summarize(queue,self.root,self.base/"cache")
            self.assertEqual((summary["original_roots_closed"], summary["active_roots"]), (1, 0))
            again = audit.audit_one(queue, key, runtime, 600)
            self.assertTrue(again["reused_unchanged_receipt"])
        finally:
            runtime.source_db.close()

    def test_candidate_detects_historical_state_changes_and_external_source_changes(self):
        queue, key = self.make()
        self.candidate(queue)
        directory = next(queue.iter_task_dirs())
        state = tq.read_json(directory/"STATE.json.gz")
        state["reason"] = "forged-history"
        tq.durable_json(directory/"STATE.json.gz", state)
        with self.assertRaisesRegex(ValueError,"descendant history"):
            tq.audit_parent(queue,key,self.root,require_final=True)
        state["reason"] = "unattempted"
        tq.durable_json(directory/"STATE.json.gz", state)
        path = self.root/"elastic-run/batches/000/000000/DONE.json"
        value = tq.read_json(path)
        value["owner"] = "altered"
        tq.durable_json(path,value)
        with self.assertRaisesRegex(ValueError,"source changed"):
            tq.audit_parent(queue,key,self.root)

    def test_source_guard_or_parked_descendant_never_gets_root_supersession(self):
        queue, key = self.make(reason="depth_guard")
        queue.make_parent_marker("root_ready",key)
        self.assertIsNone(queue.claim_root("root",schedule_sha256="a"*64))
        self.assertEqual(queue.status()["parked"],1)

    def test_root_compact_evidence_budget_parks_only_attempt_without_overwrite(self):
        queue, key = self.make()
        lease = queue.claim_root("root",schedule_sha256="a"*64)
        with patch.object(lease,"candidate",side_effect=tq.EvidenceLimit("root_evidence_size_guard")):
            result = worker.process_root_lease(lease,root_schedule(),self.root,provider=fixtures.GoodProvider)
        self.assertEqual(result["status"],"root_parked")
        leaf = queue.claim("leaf")
        self.assertIsNotNone(leaf)
        leaf.close()

    def test_incremental_done_index_is_idempotent_and_not_early(self):
        queue,key = self.make("0L"+fixtures.full_tree(5))
        lease = queue.claim("first")
        worker.process_lease(lease,fixtures.schedule(),self.root,provider=fixtures.GoodProvider)
        self.assertEqual(list(queue.iter_parent_markers("replay_ready")),[])
        lease = queue.claim("second")
        worker.process_lease(lease,fixtures.schedule(),self.root,provider=fixtures.GoodProvider)
        self.assertEqual(list(queue.iter_parent_markers("replay_ready")),[key])
        import completion
        completion.seed(queue,key)
        self.assertEqual(list(queue.iter_parent_markers("replay_ready")),[key])
        directory = next(queue.iter_task_dirs())
        with self.assertRaisesRegex(ValueError,"checkpoint changed"):
            completion.note_done(queue,key,directory.name,"f"*64)

    def test_frontier_rebuild_once_and_strongest_split_survives_last_axis(self):
        queue,key = self.make("P")
        lease = queue.claim("frontier")
        index = frontier.Frontier(lease.task,lease.state)
        node,path,cc,rr = index.next()
        cursor={"axis":0}
        frontier.select_axis(cursor,{"split_diagnostic":{"axis":2,"score":0.9,"kind":"best"}})
        frontier.select_axis(cursor,{"split_diagnostic":{"axis":1,"score":0.2,"kind":"last"}})
        self.assertEqual(cursor["axis"],2)
        self.assertTrue(lease.reserve_split())
        index.split(path,cursor["axis"])
        self.assertEqual(index.next()[1],"0")
        index.sync()
        self.assertEqual(lease.state["roots"][0]["tree"],"2PP")
        lease.release()

    def test_split_diagnostic_nonfinite_is_arithmetic_failure(self):
        with self.assertRaises(ArithmeticError):
            frontier.select_axis({"axis":0},{"split_diagnostic":{"axis":1,"score":float("nan")}})

    def test_containing_certificate_replay_binds_actual_superbox(self):
        queue,key = self.make()
        lease = queue.claim("containing")
        initial = lease.task["roots"][0]
        cc,rr=list(map(Q,initial["centers"])),list(map(Q,initial["radii"]))
        outer = fixtures.GoodProvider.evaluate(cc,[2*r for r in rr],"order3",1)
        receipt = fixtures.GoodProvider.replay(outer)
        proof = lease.install_proof(initial["prefix"],cc,rr,outer,receipt)
        lease.state["proofs"][initial["prefix"]]=proof
        lease.state["roots"][0]["tree"]="C"
        lease.finish()
        value=tq.audit_parent(queue,key,self.root,True,fixtures.GoodProvider.replay_recipe,lambda *args:{"status":"PASS"})
        self.assertTrue(value["closed"])
        saved=tq.read_json(lease.directory/"STATE.json.gz")["proof_records"][proof["sha256"]]
        self.assertNotEqual(saved["evaluation"]["input"],saved["geometry"])
        self.assertFalse(saved["containment"]["algebraic_transport"])
        saved["containment"]["target_input_sha256"]="f"*64
        with self.assertRaisesRegex(ValueError,"containment binding"):
            tq.validate_proof(lease.task,initial["prefix"],cc,rr,saved)

    def test_noncontaining_recipe_cannot_receive_credit(self):
        queue,key=self.make()
        lease=queue.claim("reject")
        initial=lease.task["roots"][0]
        cc,rr=list(map(Q,initial["centers"])),list(map(Q,initial["radii"]))
        record=fixtures.GoodProvider.evaluate(cc,[r/2 for r in rr],"order3",1)
        with self.assertRaisesRegex(ValueError,"exactly contain"):
            lease.install_proof(initial["prefix"],cc,rr,record,fixtures.GoodProvider.replay(record))
        lease.close()

    def test_sixteen_actual_group_proposals_permute_radii_and_share_bucket(self):
        box={"centers":["1/4","1/2","3/4","1"],"radii":["1/16","1/32","1/64","1/128"],"units":"radians"}
        proposals=list(reuse.sign_boxes(box))
        self.assertEqual(len({tq.digest(x) for x in proposals}),16)
        self.assertTrue(any(x["centers"]==["1/2","1/4","1","3/4"] and x["radii"]==["1/32","1/16","1/128","1/64"] for x in proposals))
        self.assertEqual({reuse._bucket(x) for x in proposals},{reuse._bucket(box)})

    def test_hint_cache_zero_limit_and_local_boundedness(self):
        hints=reuse.CertificateHints(self.area)
        for n in range(160):
            record=fixtures.GoodProvider.evaluate([Q(1)+Q(n,4096)]*4,[Q(1,16)]*4,"order3",1)
            hints.add({"method":record["method"],"input":record["input"],"provider_hashes":record["provider_hashes"]})
        self.assertEqual(len(hints.local),128)
        self.assertEqual(hints.candidates(record["input"],{"order3"},0),[])
        proposals=hints.candidates(record["input"],{"order3"},2)
        self.assertTrue(all(reuse.contains(x["input"],record["input"]) for x in proposals))

    def test_hint_cache_legacy_database_is_ignored_then_reads_atomic_population(self):
        record=fixtures.GoodProvider.evaluate([Q(1)]*4,[Q(1,16)]*4,"order3",1)
        recipe={"method":record["method"],"input":record["input"],"provider_hashes":record["provider_hashes"]}
        for kind in ("zero_length", "sqlite_without_hints"):
            with self.subTest(kind=kind):
                reader=reuse.CertificateHints(self.area/kind)
                path=reader.place/("%02x.sqlite" % reuse._bucket(record["input"]))
                path.parent.mkdir(parents=True,exist_ok=True)
                if kind=="zero_length":
                    path.touch()
                else:
                    with sqlite3.connect(path) as db:
                        db.execute("CREATE TABLE initializing (id INTEGER)")
                with patch.object(reuse.time,"monotonic",return_value=0):
                    self.assertEqual(reader.candidates(record["input"],{"order3"},2),[])
                self.assertEqual(reader.local,{})
                writer=reuse.CertificateHints(self.area/kind)
                writer.add(recipe)
                # Retain the existing read throttle; the transient miss is
                # retried after its ordinary bounded interval.
                with patch.object(reuse.time,"monotonic",return_value=16):
                    proposals=reader.candidates(record["input"],{"order3"},2)
                self.assertEqual(len(proposals),1)
                self.assertEqual(proposals[0]["input"],record["input"])
                self.assertEqual(proposals[0]["method"],"order3")

    def test_hint_cache_legacy_schema_is_not_an_authoritative_input(self):
        record=fixtures.GoodProvider.evaluate([Q(1)]*4,[Q(1,16)]*4,"order3",1)
        hints=reuse.CertificateHints(self.area)
        path=hints.place/("%02x.sqlite" % reuse._bucket(record["input"]))
        path.parent.mkdir(parents=True,exist_ok=True)
        with sqlite3.connect(path) as db:
            db.execute("CREATE TABLE hints (unexpected INTEGER)")
        before=path.read_bytes()
        self.assertEqual(hints.candidates(record["input"],{"order3"},2),[])
        self.assertEqual(path.read_bytes(),before)

    def test_partials_inherit_only_containing_ancestors_and_keep_non_tao(self):
        state={}
        store=reuse.PartialStore(state)
        cc,rr=[Q(1)]*4,[Q(1,8)]*4
        self.assertTrue(store.add("0",partial(cc,rr,non_tao=True)))
        self.assertTrue(store.add("0",partial(cc,rr,sigma=0,non_tao=True)))
        child={"centers":["1"]*4,"radii":["1/16"]*4,"units":"radians"}
        self.assertEqual(len(store.candidates("001",child)),2)
        self.assertEqual(store.candidates("1",child),[])
        outside={"centers":["3"]*4,"radii":["1/16"]*4,"units":"radians"}
        self.assertEqual(store.candidates("001",outside),[])
        store.prune(["1"])
        self.assertEqual(store.records,{})

    def test_pool_gate_waits_for_certifiable_signed_union(self):
        cc,rr=[Q(1)]*4,[Q(1,8)]*4
        a=partial(cc,rr,1,False)
        b=partial(cc,rr,-1,False)
        self.assertFalse(reuse.pool_may_close([a]))
        self.assertTrue(reuse.pool_may_close([a,b]))
        c=partial(cc,rr,1,True)
        self.assertFalse(reuse.pool_may_close([a,c]))
        self.assertTrue(reuse.pool_may_close([a,c,partial(cc,rr,0,False,True)]))

    def test_worker_composes_ancestor_partial_and_keeps_original_contributor_box(self):
        queue,key=self.make("P")
        lease=queue.claim("partial-worker")
        index=frontier.Frontier(lease.task,lease.state)
        node,path,cc,rr=index.next()
        ancestor=PooledProvider.evaluate(cc,rr,"order3",1)
        reuse.PartialStore(lease.state).add("",ancestor)
        self.assertTrue(lease.reserve_split())
        index.split("",0)
        index.sync()
        settings=fixtures.schedule([{"method":"order4","cpu_seconds":1}])
        settings["partial_composition"]=True
        result=worker.process_lease(lease,settings,self.root,provider=PooledProvider)
        self.assertEqual(result["status"],"done")
        value=tq.audit_parent(queue,key,self.root,True,PooledProvider.replay_recipe)
        self.assertTrue(value["closed"])
        saved=tq.read_json(lease.directory/"STATE.json.gz")
        self.assertEqual(saved["roots"][0]["tree"],"0CC")
        for proof in saved["proof_records"].values():
            self.assertEqual(proof["evaluation"]["method"],"pooled_signs")
            contributors=proof["evaluation"]["contributors"]
            self.assertTrue(any(item["input"]==ancestor["input"] for item in contributors))
            self.assertTrue(all(reuse.contains(item["input"],proof["geometry"]) for item in contributors))
        self.assertEqual(saved["partial_records"],{})

    def test_whole_root_composes_partial_cover_before_exhausting_methods(self):
        queue,key=self.make()
        lease=queue.claim_root("pooled-root",schedule_sha256="a"*64)
        methods=[{"method":"order3","cpu_seconds":1},{"method":"order4","cpu_seconds":1}]
        settings=root_schedule(methods)
        settings["partial_composition"]=True
        result=worker.process_root_lease(lease,settings,self.root,provider=PooledProvider)
        self.assertEqual(result["status"],"root_candidate")
        value=tq.audit_parent(queue,key,self.root,True,PooledProvider.replay_recipe)
        self.assertTrue(value["closed"])
        self.assertEqual(value["new_leaf_proofs"][""]["method"],"pooled_signs")

    def test_recursive_provider_inventory_includes_legacy_pool_contributors(self):
        value={"method":"pooled_signs","provider_hashes":{"v2":"a"*64},"contributors":[
            {"method":"order3","provider_hashes":{"v1":"b"*64}},
            {"method":"order3","provider_hashes":{"v2":"c"*64}}]}
        identities=tq.recipe_identities(value)
        self.assertEqual(len(identities),3)
        manifest={"provider_identities":[{**item,"package":"legacy" if "v1" in item["provider_hashes"] else "current"} for item in identities.values()]}
        refs={"new_leaf_proofs":{"": {"provider_identity":"unused","method":"pooled_signs","provider_hashes":value["provider_hashes"],"provider_dependencies":identities}}}
        runtime=SimpleNamespace(new_manifest=manifest)
        receipt={"new_provider_hashes":{identity:item["provider_hashes"] for identity,item in identities.items()}}
        self.assertTrue(audit._new_pins_match(receipt,runtime,refs))
        manifest["provider_identities"].pop()
        self.assertFalse(audit._new_pins_match(receipt,runtime,refs))

    def test_failed_final_receipt_is_counted_and_parent_helpers_pinned(self):
        queue,key=self.make()
        lease=queue.claim("complete")
        worker.process_lease(lease,fixtures.schedule(),self.root,provider=fixtures.GoodProvider)
        runtime=old_audit.FakeRuntime(self.root)
        try:
            runtime.new_leaf=lambda recipe: (_ for _ in ()).throw(ArithmeticError("synthetic failure"))
            with self.assertRaises(ArithmeticError):
                audit.audit_one(queue,key,runtime,600)
            with patch.object(audit,"ReplayRuntime",return_value=runtime):
                summary=audit.summarize(queue,self.root,self.base/"cache")
            self.assertEqual(summary["failed_replay_roots"],1)
            self.assertIn("parent_roots_sha256",summary["audit_provider_hashes"])
            self.assertIn("reuse_store_sha256",summary["audit_provider_hashes"])
        finally:
            runtime.source_db.close()


if __name__=="__main__":
    unittest.main(verbosity=2)
