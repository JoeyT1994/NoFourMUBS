"""Independent exact-reference controls for the cancellation-only provider.

These are implementation regressions, not a proof of arithmetic or physical
soundness. Controls bypass chart admission to exercise known physical corners.
"""
from fractions import Fraction as Q
from pathlib import Path
import argparse
import ctypes
import importlib.util
import json
import sys
import time

import cancellation_provider


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def require(test, message):
    if not test:
        raise AssertionError(message)


def forced_chart(provider, centers, signs, rho):
    _, sqrt3 = provider.chart_module.constants()
    roots, deltas = [], []
    for center, sign in zip(centers, signs):
        imag = (sqrt3[0]/2,sqrt3[1]/2) if sign>0 else (-sqrt3[1]/2,-sqrt3[0]/2)
        root = (-Q(1,2),-Q(1,2),*imag)
        ph = provider.chart_module.trig_bounds(center)
        roots.append(root)
        deltas.append(((ph[0]+Q(1,2))/rho,(ph[1]+Q(1,2))/rho,
                       (ph[2]-root[3])/rho,(ph[3]-root[2])/rho))
    return dict(roots=roots,deltas=deltas,rho=rho,signs=signs)


def coefficient_controls(provider, controls):
    c = provider.c
    _, sqrt3 = provider.chart_module.constants()
    cases = []
    for ints in [(-3,2,1,5,2,1,-2,3),(2,1,3,1,4,3,5,2)]:
        cases.append([controls.Z(Q(m*m-n*n,m*m+n*n),Q(2*m*n,m*m+n*n))
                      for m,n in zip(ints[::2],ints[1::2])])
    for conjugate in (1,-1):
        tangents = [conjugate*(sign*Q(1732051,1000000)+Q(offset,10000))
                    for sign,offset in zip((1,-1,-1,1),(1,-2,3,5))]
        cases.append([controls.Z((1-t*t)/(1+t*t),2*t/(1+t*t)) for t in tangents])
    count = 0
    powers = [4,12]+[12,10,10,25,25]*3
    for case_id,case in enumerate(cases):
        reference = controls.reference(case)
        raw = sum(([c.down(z.re),c.up(z.re),c.down(z.im),c.up(z.im)] for z in case),[])
        for rho in (Q(1,8),Q(1,32)):
            for signs in ((1,-1,-1,1),(-1,1,1,-1)):
                roots, deltas = [], []
                for z,sign in zip(case,signs):
                    imag = (sqrt3[0]/2,sqrt3[1]/2) if sign>0 else (-sqrt3[1]/2,-sqrt3[0]/2)
                    roots.extend([-.5,-.5,c.down(imag[0]),c.up(imag[1])])
                    deltas.extend([c.down((z.re+Q(1,2))/rho),c.up((z.re+Q(1,2))/rho),
                                   c.down((z.im-imag[1])/rho),c.up((z.im-imag[0])/rho)])
                # Include the exact center point both in a point control and
                # in a genuine four-variable Taylor box with nonzero widths.
                for radius in (0.0,2.0**-24):
                    data = raw+[radius]*4+deltas+roots+[float(rho)]
                    out = provider.native(data,time.process_time()+20,RuntimeError)
                    for k,(value,power) in enumerate(zip(reference,powers)):
                        scaled = value/rho**power
                        require(Q(out[2*k])<=scaled<=Q(out[2*k+1]),
                                (case_id,str(rho),signs,radius,k,str(scaled),out[2*k:2*k+2]))
                        count += 1
    return dict(exact_coefficients_contained=count,cases=len(cases),
                physical_coefficient_powers=powers,
                includes_both_seed_charts=True,includes_nonzero_taylor_radii=True)


def physical_controls(provider):
    c = provider.c
    pi,_ = provider.chart_module.constants()
    midpoint = sum(pi)/2
    results = []
    for delta in (Q(1,100),Q(1,5),Q(1,2)):
        exact = [-2*midpoint/3,-midpoint/3+delta,Q(0),-midpoint+delta]
        cc,rr = [Q(float(x)) for x in exact],[Q(1,2**35)]*4
        require(all(abs(cc[k]-exact[k])+(pi[1]-pi[0])<rr[k] for k in range(4)),"Physical control not contained")
        for signs in ((1,-1,-1,1),(-1,1,1,-1)):
            info = forced_chart(provider,cc,signs,Q(1))
            seen = set()
            for tr in (False,True):
                perm = (0,2,1,3) if tr else (0,1,2,3)
                co = provider.native(provider._data(cc,rr,info,perm),time.process_time()+20,RuntimeError)
                excluded, reason = c.linear_signs(co)
                require(len(excluded)<2,("Physical corner excluded",str(delta),signs,tr,reason))
                if Q(co[1])<243:
                    seen.update(-s if tr else s for s in excluded)
                require(seen!={-1,1},("Physical coupled corner excluded",str(delta),signs,tr))
                results.append(dict(delta=str(delta),seed_signs=list(signs),transpose=tr,
                                    reason=reason,excluded_signs=sorted(excluded),chart_admission_bypassed=True))
    return results


def budget_and_chart_controls(provider):
    try:
        provider.native([0.0]*53,time.process_time()-1,RuntimeError)
    except RuntimeError as ex:
        require(str(ex)=="cpu_budget","Wrong exhausted-budget result")
    else:
        raise AssertionError("Exhausted CPU budget was ignored")
    out = (ctypes.c_double*38)()
    require(provider.lib.cancellation_region((ctypes.c_double*53)(*([0.0]*53)),out)==-8,
            "Nonpositive rho accepted")
    answer = provider.evaluate([Q(0),Q(1),Q(2),Q(3)],[Q(1,1000)]*4,
                               time.process_time()+20,RuntimeError)
    require(not answer["ok"] and answer["reason"]=="cancellation_chart_outside_neighborhood",
            "Outside chart was not refused")
    return dict(expired_budget_rejected=True,zero_rho_rejected=True,outside_chart_refused=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root",type=Path,default=Path(__file__).resolve().parent.parent)
    parser.add_argument("--cache",type=Path,required=True)
    parser.add_argument("--output",type=Path,required=True)
    args = parser.parse_args()
    started = time.process_time()
    c = load("cancellation_frozen_controls",args.root/"engine/certify_leaves.py")
    c.check_sources()
    c.guard()
    sys.path.insert(0,str(args.root/"engine"))
    controls = load("cancellation_exact_reference",args.root/"engine/controls.py")
    provider = cancellation_provider.Provider(args.root,args.cache,c)
    result = dict(status="PASS",pins=provider.pins,
                  exact_reference=coefficient_controls(provider,controls),
                  physical_negative_controls=physical_controls(provider),
                  resource_and_chart_controls=budget_and_chart_controls(provider),
                  physical_lean_admissions=0,controls_sha256=cancellation_provider.sha(__file__),
                  exact_reference_sha256=cancellation_provider.sha(controls.__file__))
    result["cpu_seconds"]=time.process_time()-started
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(result,indent=2,sort_keys=True,allow_nan=False)+"\n")
    print(json.dumps({k:v for k,v in result.items() if k not in ("pins","physical_negative_controls")},sort_keys=True))


if __name__=="__main__":
    main()
