"""Small deterministic benchmark sample from finalized, immutable packets only."""
from pathlib import Path
from fractions import Fraction as Q
import argparse, gzip, hashlib, json, math, sqlite3, sys

def sha(b): return hashlib.sha256(b).hexdigest()
def canonical(v): return json.dumps(v,sort_keys=True,separators=(',',':')).encode()

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,required=True)
    ap.add_argument('--output',type=Path,required=True);ap.add_argument('--batch-limit',type=int,default=160)
    a=ap.parse_args();root=a.root.resolve()
    sys.path.insert(0,str(root/'campaign'));import core
    plan=json.loads((root/'elastic-run/PLAN.json').read_bytes())
    entries=sorted(plan['batches'],key=lambda e:sha(str(e['batch']).encode()))
    db=sqlite3.connect((root/'campaign/full_ring.sqlite').as_uri()+'?mode=ro&immutable=1',uri=True)
    buckets={};scanned=0
    for e in entries:
        bid=e['batch'];done=root/f'elastic-run/batches/{bid//1000:03d}/{bid:06d}/DONE.json'
        if not done.exists():continue
        d=json.loads(done.read_bytes())
        if d['n']==d['settled']:continue
        blob=(root/f'production/batches/{bid//1000:03d}/{bid:06d}.json.gz').read_bytes()
        if sha(blob)!=d['sha256']:raise ValueError('Final packet changed')
        packet=json.loads(gzip.decompress(blob))
        _,_,expected,compressed=db.execute('SELECT first_id,n,raw_sha,payload FROM batches WHERE id=?',(bid,)).fetchone()
        raw=gzip.decompress(compressed)
        if sha(raw)!=expected or packet['input_batch_sha256']!=expected:raise ValueError('Input changed')
        rows={r['id']:r for r in map(json.loads,raw.splitlines())}
        for rec in packet['records']:
            if rec['closed'] or 'transport' in rec or 'external_claim_sha256' in rec:continue
            row=rows[rec['id']]
            if sha(canonical(row))!=rec['input_sha256']:raise ValueError('Wrong row')
            # Approximate distances select a benchmark only; they never accept a box.
            sg=[1,-1,-1,1] if row['seed']=='2,4,4,2' else [-1,1,1,-1]
            distance=max(abs(float(Q(c))-s*2*math.pi/3) for c,s in zip(row['centers'],sg))
            band=next(i for i,v in enumerate([.001,.005,.01,.02,.04,.06,.071]) if distance<=v)
            key=(band,row['seed']);candidate=(sha(str(row['id']).encode()),row,rec,d['sha256'])
            if key not in buckets or candidate[0]<buckets[key][0]:buckets[key]=candidate
        scanned+=1
        if scanned>=a.batch_limit:break
    cases=[]
    for key,(_,row,rec,packet_sha) in sorted(buckets.items()):
        base={'root_id':row['id'],'seed':row['seed'],'radius_band':key[0],
              'source_tree_sha256':sha(rec['tree'].encode()),'source_packet_sha256':packet_sha,
              'input_sha256':rec['input_sha256'],'source_reason':rec['reason']}
        cases.append(dict(base,case_id=str(row['id'])+':parent',kind='parent',prefix='',centers=row['centers'],radii=row['radii']))
        _,pending,splits=core.decode(rec['tree'])
        for p in dict.fromkeys([pending[0],pending[len(pending)//2],pending[-1]]):
            cc,rr=core.c.geometry(row,p,splits)
            cases.append(dict(base,case_id=str(row['id'])+':'+p,kind='frontier',prefix=p,
                              centers=list(map(str,cc)),radii=list(map(str,rr))))
    value={'scope':'Deterministic stratified benchmark, not a statistical runtime estimate or exclusion certificate.',
           'source_packets_scanned':scanned,'cases':cases,'physical_lean_admissions':0}
    a.output.parent.mkdir(parents=True,exist_ok=True)
    if a.output.exists():raise FileExistsError(a.output)
    a.output.write_text(json.dumps(value,indent=2)+'\n')
    print(json.dumps({'cases':len(cases),'bands':len(buckets),'output':str(a.output),'sha256':sha(a.output.read_bytes())}))

if __name__=='__main__':main()
