"""Bounded, source-pinned whole-leaf numerical evaluators.

Each Taylor order has a separate native handle.  This module never calls
certify_leaves.init or swaps that module's current library.  Use one evaluator
at a time, in the main thread of a worker process.  These are numerical
strict-D0 certificates relative to the upstream physical interface, not Lean
admissions and not a proof of the four-MUB conjecture.
"""
from __future__ import annotations

from contextlib import contextmanager
from fractions import Fraction
from pathlib import Path
import ctypes
import fcntl
import hashlib
import importlib.util
import json
import math
import os
import resource
import signal
import subprocess
import sys
import threading
import time

_STATE = None
_BUSY = False
SCHEMA = "survivor-leaf-v1"
METHODS = ("order3", "order4", "order5", "paired_psd",
           "normalized_order3", "normalized_order4", "normalized_order5",
           "exact_psd", "exact_psd192", "exact_psd256", "exact_psd384",
           "complement4", "complement_face4", "handoff_plain4", "psd_ray",
           "pooled_signs", "cancellation_order4")


class CpuBudget(Exception):
    pass


def _sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _digest(obj):
    return hashlib.sha256(json.dumps(obj, sort_keys=True, separators=(",", ":"),
                                     allow_nan=False).encode()).hexdigest()


def _load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _atomic(path, value):
    tmp = path.with_name(path.name + "." + str(os.getpid()) + ".tmp")
    tmp.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n")
    os.replace(tmp, path)


def _compile_psd(root, cache):
    source = root / "engine/upstream/ProvenResults/SignedCornerPSDPrune/engine.cpp"
    terms = source.with_name("determinant_terms.hpp")
    pins = {"native_source_sha256": _sha(source), "determinant_terms_sha256": _sha(terms)}
    directory = cache / ("psd-" + _digest(pins)[:24])
    directory.mkdir(parents=True, exist_ok=True)
    target = directory / "paired_psd.so"
    receipt = target.with_suffix(".build.json")
    with (directory / "BUILD.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        if not target.exists():
            tmp = target.with_name("paired_psd." + str(os.getpid()) + ".tmp.so")
            command = ["c++", "-std=c++17", "-O3", "-fno-fast-math", "-ffp-contract=off",
                       "-fPIC", "-shared", str(source), "-o", str(tmp)]
            try:
                subprocess.run(command, check=True, capture_output=True, text=True, timeout=60)
                info = dict(pins, binary_sha256=_sha(tmp), command=command,
                            compiler=subprocess.check_output(["c++", "--version"], text=True).splitlines()[0])
                os.replace(tmp, target)
                _atomic(receipt, info)
            finally:
                tmp.unlink(missing_ok=True)
        info = json.loads(receipt.read_text())
        if any(info.get(k) != v for k, v in pins.items()) or info.get("binary_sha256") != _sha(target):
            raise ValueError("Paired PSD build receipt mismatch")
    return target, info


def initialize(root: Path, cache: Path, legacy_source=None, legacy_pins=None) -> dict:
    """Build/load isolated libraries; cache must be outside frozen engine paths.

    Call in each worker process, before evaluate.  Unknown/unavailable methods
    are reported explicitly.  Build receipts include source and binary hashes.
    """
    global _STATE
    if threading.current_thread() is not threading.main_thread() or _BUSY:
        raise RuntimeError("Initialize only in an idle worker's main thread")
    root, cache = Path(root).resolve(), Path(cache).resolve()
    if sys.platform == "linux":
        soft, hard = resource.getrlimit(resource.RLIMIT_AS)
        cap = min([768*2**20]+[v for v in (soft,hard) if v != resource.RLIM_INFINITY])
        resource.setrlimit(resource.RLIMIT_AS,(cap,cap))
    if cache == root / "engine" or root / "engine" in cache.parents:
        raise ValueError("Survivor cache must not alter the frozen engine")
    cache.mkdir(parents=True, exist_ok=True)
    c = _load("survivor_frozen_certify", root / "engine/certify_leaves.py")
    c.check_sources()
    c.guard()
    native = {}
    pins = {}
    dp = ctypes.POINTER(ctypes.c_double)
    for order in (3, 4, 5):
        with (cache / ("ORDER" + str(order) + ".lock")).open("a") as lock:
            fcntl.flock(lock, fcntl.LOCK_EX)
            binary = c.build(order, "linear", build_root=cache / "linear")
        lib = ctypes.CDLL(str(binary))
        lib.linear_region.argtypes = [dp, dp]
        lib.linear_region.restype = ctypes.c_int
        lib.set_budget.argtypes = [ctypes.c_double]
        lib.set_budget.restype = None
        info = json.loads(binary.with_suffix(".build.json").read_text())
        native[order] = lib
        pins["order" + str(order)] = {k: v for k, v in info.items() if k.endswith("sha256")}
        pins["order" + str(order)]["frozen_driver_sha256"] = _sha(c.__file__)
    psd_path, psd_info = _compile_psd(root, cache)
    psd = _load("survivor_frozen_psd", root / "engine/upstream/ProvenResults/SignedCornerPSDPrune/predicate.py")
    psd_lib = ctypes.CDLL(str(psd_path))
    psd_lib.compute.argtypes = [dp, dp, ctypes.c_int]
    psd_lib.compute.restype = ctypes.c_int
    psd_lib.certify.argtypes = [dp, ctypes.c_int, ctypes.c_int, dp]
    psd_lib.certify.restype = ctypes.c_int
    psd_lib.test_arithmetic.argtypes = [ctypes.c_int, dp, dp]
    psd_lib.test_arithmetic.restype = ctypes.c_int
    psd._LIB = psd_lib
    pins["paired_psd"] = {k: v for k, v in psd_info.items() if k.endswith("sha256")}
    pins["paired_psd"]["predicate_sha256"] = _sha(psd.__file__)
    normalized_module = _load("survivor_normalized_provider", Path(__file__).with_name("normalized_provider.py"))
    normalized = normalized_module.Provider(root, cache, c)
    exact_module = _load("survivor_normalized_exact", Path(__file__).with_name("normalized_exact.py"))
    exact = exact_module.Provider(root, normalized_module)
    advanced_module = _load("survivor_advanced_provider", Path(__file__).with_name("advanced_provider.py"))
    advanced = advanced_module.Provider(root, cache, c)
    pins.update(normalized.pins)
    pins.update(exact.pins)
    pins.update(advanced.pins)
    cancellation = None
    cancellation_path = Path(__file__).with_name("cancellation_provider.py")
    if cancellation_path.exists():
        cancellation_module = _load("survivor_cancellation_provider", cancellation_path)
        cancellation = cancellation_module.Provider(root, cache, c)
        pins.update(cancellation.pins)
    _STATE = dict(root=root, cache=cache, c=c, native=native, psd=psd,
                  pins=pins, pid=os.getpid(), normalized=normalized, exact=exact,
                  advanced=advanced, cancellation=cancellation, legacy=[])
    for method in pins:
        pins[method]["survivor_driver_sha256"] = _sha(__file__)
    pins["pooled_signs"] = {"survivor_driver_sha256":_sha(__file__),
                            "provider_inventory_sha256":_digest(pins)}
    legacy_source = Path(legacy_source) if legacy_source else Path(__file__).with_name("legacy")
    if (legacy_source/"engines.py").exists():
        configure_legacy(root, cache, legacy_source, legacy_pins)
    availability = {m: {"available": m in pins,
                        "reason": "ready" if m in pins else "provider_not_installed"}
                    for m in METHODS}
    _STATE["availability"] = availability
    identities = [{"method":m,"provider_hashes":p,"package":"current"} for m,p in pins.items()]
    for legacy in _STATE["legacy"]:
        identities.extend({"method":m,"provider_hashes":p,"package":"legacy"} for m,p in legacy._STATE["pins"].items())
    return {"schema": SCHEMA, "methods": availability, "provider_hashes": pins,
            "provider_identities":identities,
            "physical_lean_admissions": 0}


def configure_legacy(root, cache, legacy_source, pins=None):
    """Load immutable v1 code; old proofs are never regenerated by v2 logic."""
    if _STATE is None:
        raise RuntimeError("Initialize current engines before legacy configuration")
    source = Path(legacy_source).resolve()
    if pins is not None:
        for name, expected in pins.items():
            if _sha(source/name) != expected:
                raise ValueError("Legacy package source pin differs: "+name)
    for name in ("SignedCornerPSDPrune/engine.cpp","SignedCornerPSDPrune/determinant_terms.hpp","Patch2442Region_v3/taylor.hpp"):
        copied = source.parent/"engine/upstream/ProvenResults"/name
        if not copied.exists() or _sha(copied)!=_sha(Path(root)/"engine/upstream/ProvenResults"/name):
            raise ValueError("Legacy relative native dependency differs: "+name)
    legacy = _load("survivor_legacy_"+_sha(source/"engines.py")[:16],source/"engines.py")
    legacy.initialize(Path(root),Path(cache))
    _STATE["legacy"].append(legacy)
    return {m:dict(p) for m,p in legacy._STATE["pins"].items()}


def _legacy_provider(record):
    if _STATE is None:
        return None
    for module in _STATE.get("legacy",[]):
        if record.get("provider_hashes")==module._STATE["pins"].get(record.get("method")):
            return module
    return None


def _alarm(signum, frame):
    raise CpuBudget("cpu_budget")


@contextmanager
def _cpu_limit(seconds):
    if threading.current_thread() is not threading.main_thread():
        raise RuntimeError("Evaluation requires the worker's main thread")
    prior_timer = signal.getitimer(signal.ITIMER_PROF)
    if prior_timer[0] or prior_timer[1]:
        raise RuntimeError("An enclosing CPU timer is already active")
    prior_handler = signal.getsignal(signal.SIGPROF)
    signal.signal(signal.SIGPROF, _alarm)
    try:
        signal.setitimer(signal.ITIMER_PROF, seconds)
        yield
    finally:
        signal.setitimer(signal.ITIMER_PROF, 0)
        signal.signal(signal.SIGPROF, prior_handler)


def _validate_box(centers, radii):
    if len(centers) != 4 or len(radii) != 4:
        raise ValueError("Exactly four centers/radii are required")
    if any(isinstance(x, bool) or not isinstance(x, (int, Fraction)) for x in (*centers, *radii)):
        raise ValueError("Exact Fraction/integer geometry is required")
    cc, rr = list(map(Fraction, centers)), list(map(Fraction, radii))
    if not all(abs(x) < 4 for x in cc) or not all(0 < x <= 1 for x in rr):
        raise ValueError("Outside the guarded radians domain")
    return cc, rr


def _finite(value):
    if isinstance(value, float) and not math.isfinite(value):
        raise ArithmeticError("Nonfinite provider witness")
    if isinstance(value, dict):
        for item in value.values():
            _finite(item)
    elif isinstance(value, (list, tuple)):
        for item in value:
            _finite(item)


def _linear(cc, rr, order, deadline):
    c, lib = _STATE["c"], _STATE["native"][order]
    providers, seen, scores = [], set(), [0.0] * 4
    for transpose in (False, True):
        perm = (0, 2, 1, 3) if transpose else (0, 1, 2, 3)
        data = sum((c.phase(cc[k]) for k in perm), []) + [c.up(rr[k]) for k in perm]
        remaining = deadline - time.process_time()
        if remaining <= 0:
            raise CpuBudget("cpu_budget")
        lib.set_budget(remaining)
        out = (ctypes.c_double * 38)()
        code = lib.linear_region((ctypes.c_double * 20)(*data), out)
        if code == -2:
            raise CpuBudget("native_cpu_budget")
        if code != 38:
            raise ArithmeticError("Native arithmetic status " + str(code))
        co = list(out)
        _finite(co)
        if any(co[i] > co[i + 1] for i in range(0, 34, 2)):
            raise ArithmeticError("Malformed native interval")
        signs, reason = c.linear_signs(co)
        providers.append(dict(transpose=transpose, coefficients=co[:34],
                              signs=sorted(signs), reason=reason))
        if len(signs) == 2:
            return dict(ok=True, reason=reason, providers=providers, order=order)
        if co[1] < 243:
            seen.update(-s if transpose else s for s in signs)
        if seen == {-1, 1}:
            return dict(ok=True, reason="coupled_signed_means_non_Tao", providers=providers, order=order)
        for i, k in enumerate(perm):
            scores[k] += co[34 + i]
    axis=max(range(4),key=lambda k:(scores[k],rr[k]))
    total=sum(max(0,x) for x in scores)
    return dict(ok=False, reason="unresolved_mean", providers=providers,
                axis=axis, split_diagnostic={"axis":axis,"score":max(0,scores[axis])/total if total else 0,
                    "kind":"signed_mean_influence","influences":scores,"acceptance_role":"none"}, order=order)


def _evidence(result):
    return {k: result[k] for k in ("schema", "ok", "reason", "method", "input",
                                  "provider_hashes", "witness")}


def evaluate(centers: list[Fraction], radii: list[Fraction], method: str,
             cpu_seconds: float) -> dict:
    """Evaluate an entire exact angular box, with no sample-based acceptance.

    Arithmetic/malformed-source errors and inherited resource guards raise.
    CPU exhaustion returns unresolved.  Witnesses bind exact input strings and pinned
    providers, with a digest suitable for fresh replay in another process.
    """
    global _BUSY
    if _STATE is None or _STATE["pid"] != os.getpid():
        raise RuntimeError("Call initialize in this process first")
    if _BUSY:
        raise RuntimeError("Concurrent evaluator calls are forbidden")
    if isinstance(cpu_seconds, bool) or not isinstance(cpu_seconds, (int, float)) or not math.isfinite(cpu_seconds) or not 0 < cpu_seconds <= 600:
        raise ValueError("CPU budget must be finite and in (0,600]")
    cc, rr = _validate_box(centers, radii)
    if method not in METHODS:
        raise ValueError("Unknown method " + str(method))
    if method == "pooled_signs":
        raise ValueError("Use compose_partials for pooled_signs")
    input_box = {"centers": list(map(str, cc)), "radii": list(map(str, rr)), "units": "radians"}
    pins = _STATE["pins"].get(method, {})
    started = time.process_time()
    deadline = started + cpu_seconds
    witness = {}
    verdict = dict(ok=False, reason="method_unavailable", axis=max(range(4), key=lambda k: rr[k]))
    _BUSY = True
    try:
        _STATE["c"].guard()
        if _STATE["availability"][method]["available"]:
            with _cpu_limit(cpu_seconds):
                if method.startswith("order"):
                    witness = _linear(cc, rr, int(method[-1]), deadline)
                    verdict = witness
                elif method == "paired_psd":
                    cert = _STATE["psd"].coupled_leaf(cc, rr, extra=True, q_depth=8, q_nodes=511)
                    if cert is None:
                        verdict = dict(ok=False, reason="unresolved_paired_psd", axis=max(range(4), key=lambda k: rr[k]))
                    else:
                        _finite(cert)
                        witness = {"extra": True, "q_depth": 8, "q_nodes": 511, "certificate": cert}
                        verdict = dict(ok=True, reason=cert["reason"])
                elif method.startswith("normalized_order"):
                    witness = _STATE["normalized"].evaluate(cc, rr, int(method[-1]), deadline, CpuBudget)
                    _finite(witness)
                    verdict = witness
                elif method.startswith("exact_psd"):
                    precision = 256 if method == "exact_psd" else int(method.removeprefix("exact_psd"))
                    witness = _STATE["exact"].evaluate(cc, rr, precision)
                    verdict = witness
                    if not verdict["ok"]:
                        verdict["axis"] = max(range(4), key=lambda k: rr[k])
                elif method in ("complement4","complement_face4","handoff_plain4","psd_ray"):
                    witness = _STATE["advanced"].evaluate(cc,rr,method,deadline,CpuBudget)
                    _finite(witness)
                    verdict = witness
                elif method == "cancellation_order4":
                    witness = _STATE["cancellation"].evaluate(cc,rr,deadline,CpuBudget)
                    _finite(witness)
                    verdict = witness
                else:
                    raise RuntimeError("Available provider has no evaluator")
                if time.process_time() > deadline:
                    raise CpuBudget("cpu_budget")
        _STATE["c"].guard()
    except CpuBudget as error:
        verdict = dict(ok=False, reason=str(error), axis=max(range(4), key=lambda k: rr[k]))
        witness = {}
    finally:
        _BUSY = False
    result = {"schema": SCHEMA, "ok": verdict["ok"] is True,
              "reason": verdict["reason"], "method": method, "input": input_box,
              "provider_hashes": dict(pins), "witness": witness,
              "cpu_seconds": time.process_time() - started, "physical_lean_admissions": 0}
    if "axis" in verdict:
        result["axis"] = verdict["axis"]
    if "split_diagnostic" in verdict:
        result["split_diagnostic"] = verdict["split_diagnostic"]
    result["replay"] = {"schema": SCHEMA, "evidence_sha256": _digest(_evidence(result)),
                        "input_sha256": _digest(input_box), "method": method}
    result["partial"] = _partial_for(result)
    return result


def _partial_for(record):
    """Derive certified signs from accepting circuits, never diagnostic samples."""
    witness=record.get("witness",{})
    signs=[];non_tao=bool(witness.get("non_tao",False))
    for row in witness.get("exclusions",[]):
        if type(row.get("orientation")) is not bool or row.get("sigma") not in (-1,1):
            raise ArithmeticError("Malformed partial sign")
        signs.append({"orientation":row["orientation"],"sigma":row["sigma"]})
    if record["method"].startswith(("order","normalized_order","cancellation_order")):
        rho=Fraction(witness.get("normalization",{}).get("rho","1"))
        for provider in witness.get("providers",[]):
            co=provider["coefficients"]
            certified,_=_STATE["c"].linear_signs(co)
            if sorted(certified)!=provider["signs"]:
                raise ArithmeticError("Partial signed coefficient inconsistency")
            non_tao=non_tao or Fraction(co[1])*rho**4<243
            signs.extend({"orientation":provider["transpose"],"sigma":sigma} for sigma in sorted(certified))
    unique=sorted({(x["orientation"],x["sigma"]) for x in signs})
    return {"schema":"survivor-partial-signs-v1","exclusions":[{"orientation":o,"sigma":s} for o,s in unique],
            "non_tao":non_tao,"all_excluded":record.get("ok") is True,
            "evidence_sha256":record.get("replay",{}).get("evidence_sha256"),
            "scope":"whole exact source box; strict-D0 physical interface"}


def _check_record(record):
    if record.get("schema")!=SCHEMA or record.get("replay",{}).get("evidence_sha256")!=_digest(_evidence(record)):
        raise ValueError("Partial evidence digest differs")
    if record["replay"].get("input_sha256")!=_digest(record["input"]):
        raise ValueError("Partial input digest differs")
    if record["provider_hashes"]!=_STATE["pins"].get(record["method"]) and _legacy_provider(record) is None:
        raise ValueError("Partial provider pins differ")
    if record["input"].get("units")!="radians":raise ValueError("Partial units differ")


def make_recipe(record):
    """Compact reconstruction data, also for unresolved signed contributors."""
    _check_record(record)
    recipe={k:record[k] for k in ("method","input","provider_hashes","reason","replay")}
    recipe.update(schema="survivor-leaf-recipe-v1",witness_sha256=_digest(record["witness"]),source_ok=record["ok"])
    if record["method"]=="pooled_signs":recipe["contributors"]=record["witness"]["contributors"]
    return recipe


def compose_partials(records,cpu_seconds=30,centers=None,radii=None):
    """Combine whole-box certificates after exact ancestor containment checks."""
    if _STATE is None or _STATE["pid"]!=os.getpid():raise RuntimeError("Initialize this process")
    if _BUSY or threading.current_thread() is not threading.main_thread():
        raise RuntimeError("Compose only in an idle worker's main thread")
    if not isinstance(cpu_seconds,(int,float)) or not math.isfinite(cpu_seconds) or not 0<cpu_seconds<=600:
        raise ValueError("Invalid composition budget")
    if not isinstance(records,list) or not 1<=len(records)<=32:raise ValueError("Need1–32 partial records")
    began=time.process_time();_STATE["c"].guard()
    if centers is None and radii is None:
        centers=list(map(Fraction,records[0]["input"]["centers"]));radii=list(map(Fraction,records[0]["input"]["radii"]))
    cc,rr=_validate_box(centers,radii)
    selected=[];masks={False:set(),True:set()};non_tao=False;all_excluded=False;budget_hit=False
    ordered=sorted(records,key=lambda r:r.get("replay",{}).get("evidence_sha256",""))
    for record in ordered:
        if time.process_time()-began>cpu_seconds:
            budget_hit=True
            break
        _check_record(record)
        sc=list(map(Fraction,record["input"]["centers"]));sr=list(map(Fraction,record["input"]["radii"]))
        _validate_box(sc,sr)
        if not all(abs(c-s)+r<=radius for c,s,r,radius in zip(cc,sc,rr,sr)):
            raise ValueError("Partial source does not contain target box")
        partial=_partial_for(record)
        useful=partial["all_excluded"] or (partial["non_tao"] and not non_tao) or any(x["sigma"] not in masks[x["orientation"]] for x in partial["exclusions"])
        if not useful:continue
        selected.append(make_recipe(record));non_tao=non_tao or partial["non_tao"]
        all_excluded=all_excluded or partial["all_excluded"]
        for row in partial["exclusions"]:masks[row["orientation"]].add(row["sigma"])
        matched={-s if o else s for o,ss in masks.items() for s in ss}
        if all_excluded or any(len(x)==2 for x in masks.values()) or (non_tao and matched=={-1,1}):break
    matched={-s if o else s for o,ss in masks.items() for s in ss}
    ok=all_excluded or any(len(x)==2 for x in masks.values()) or (non_tao and matched=={-1,1})
    geometry={"centers":list(map(str,cc)),"radii":list(map(str,rr)),"units":"radians"}
    witness={"contributors":selected,"non_tao":non_tao,"source_fully_excluded":all_excluded,
             "exclusions":[{"orientation":o,"sigma":s} for o in (False,True) for s in sorted(masks[o])],
             "containment":"exact closed angular intervals"}
    result={"schema":SCHEMA,"ok":ok,"reason":"pooled_signed_cover" if ok else "unresolved_pooled_signs",
            "method":"pooled_signs","input":geometry,"provider_hashes":dict(_STATE["pins"]["pooled_signs"]),
            "witness":witness,"cpu_seconds":time.process_time()-began,"physical_lean_admissions":0}
    if budget_hit or time.process_time()-began>cpu_seconds:
        result.update(ok=False,reason="cpu_budget",witness={})
    result["replay"]={"schema":SCHEMA,"evidence_sha256":_digest(_evidence(result)),"input_sha256":_digest(geometry),"method":"pooled_signs"}
    result["partial"]=_partial_for(result)
    _STATE["c"].guard()
    return result


def replay(record: dict, cpu_seconds: float = 30) -> dict:
    """Freshly recompute a successful leaf and reject changed inputs/providers.

    This is a numerical replay receipt, never a Lean admission.  Replay is
    intentionally performed under exactly the original method and source pins.
    """
    if record.get("schema") != SCHEMA or record.get("ok") is not True:
        raise ValueError("Only an accepted survivor leaf can be replayed")
    legacy=_legacy_provider(record)
    if legacy is not None:
        return legacy.replay(record,cpu_seconds)
    if record.get("method")=="pooled_signs":
        return replay_recipe(make_recipe(record),cpu_seconds)
    receipt = record.get("replay", {})
    if receipt.get("evidence_sha256") != _digest(_evidence(record)) or receipt.get("input_sha256") != _digest(record["input"]):
        raise ValueError("Leaf evidence/input digest mismatch")
    method = record["method"]
    if _STATE is None or record["provider_hashes"] != _STATE["pins"].get(method):
        raise ValueError("Replay provider pins differ")
    if record["input"].get("units") != "radians":
        raise ValueError("Unsupported replay geometry units")
    fresh = evaluate(list(map(Fraction, record["input"]["centers"])),
                     list(map(Fraction, record["input"]["radii"])), method, cpu_seconds)
    if not fresh["ok"]:
        return {"ok": False, "status": "UNRESOLVED", "reason": fresh["reason"], "method": method,
                "cpu_seconds": fresh["cpu_seconds"], "physical_lean_admissions": 0}
    if fresh["replay"]["evidence_sha256"] != receipt["evidence_sha256"]:
        raise ValueError("Fresh provider evidence differs")
    return {"ok": True, "status": "PASS", "method": method, "evidence_sha256": receipt["evidence_sha256"],
            "provider_hashes": fresh["provider_hashes"], "cpu_seconds": fresh["cpu_seconds"],
            "physical_lean_admissions": 0}


def replay_recipe(recipe: dict, cpu_seconds: float = 30) -> dict:
    """Recompute a compact leaf recipe without trusting any stored PASS flag."""
    if recipe.get("schema") != "survivor-leaf-recipe-v1":
        raise ValueError("Unsupported compact leaf recipe")
    legacy=_legacy_provider(recipe)
    if legacy is not None:
        return legacy.replay_recipe(recipe,cpu_seconds)
    if recipe.get("method")=="pooled_signs":
        began=time.process_time()
        try:
            fresh=_regenerate_recipe(recipe,cpu_seconds)
        except CpuBudget as error:
            return {"ok":False,"status":"UNRESOLVED","reason":str(error),"method":"pooled_signs",
                    "cpu_seconds":time.process_time()-began,"physical_lean_admissions":0}
        if not fresh["ok"]:
            return {"ok":False,"status":"UNRESOLVED","reason":fresh["reason"],"method":"pooled_signs",
                    "cpu_seconds":time.process_time()-began,"physical_lean_admissions":0}
        return {"ok":True,"status":"PASS","method":"pooled_signs","provider_hashes":fresh["provider_hashes"],
                "evidence_sha256":fresh["replay"]["evidence_sha256"],"cpu_seconds":time.process_time()-began,
                "physical_lean_admissions":0}
    method, geometry = recipe["method"], recipe["input"]
    if _STATE is None or recipe["provider_hashes"] != _STATE["pins"].get(method):
        raise ValueError("Compact replay provider pins differ")
    receipt = recipe["replay"]
    if receipt.get("schema") != SCHEMA or receipt.get("method") != method or receipt.get("input_sha256") != _digest(geometry):
        raise ValueError("Compact replay geometry binding differs")
    if geometry.get("units") != "radians":
        raise ValueError("Unsupported compact replay geometry units")
    fresh = evaluate(list(map(Fraction, geometry["centers"])),
                     list(map(Fraction, geometry["radii"])), method, cpu_seconds)
    if not fresh["ok"]:
        return {"ok": False, "status": "UNRESOLVED", "method": method,
                "reason": fresh["reason"], "cpu_seconds": fresh["cpu_seconds"],
                "physical_lean_admissions": 0}
    if (fresh["reason"] != recipe["reason"] or _digest(fresh["witness"]) != recipe["witness_sha256"]
            or fresh["replay"]["evidence_sha256"] != receipt["evidence_sha256"]):
        raise ValueError("Compact replay regenerated different evidence")
    return {"ok": True, "status": "PASS", "method": method,
            "evidence_sha256": receipt["evidence_sha256"], "provider_hashes": fresh["provider_hashes"],
            "cpu_seconds": fresh["cpu_seconds"], "physical_lean_admissions": 0}


def _regenerate_recipe(recipe,cpu_seconds,depth=0):
    if depth>8 or recipe.get("schema")!="survivor-leaf-recipe-v1":
        raise ValueError("Unsupported/deep compound recipe")
    began=time.process_time();method=recipe["method"];geometry=recipe["input"]
    legacy=_legacy_provider(recipe)
    if recipe["provider_hashes"]!=_STATE["pins"].get(method) and legacy is None:
        raise ValueError("Compound contributor pins differ")
    if geometry.get("units")!="radians" or recipe["replay"].get("input_sha256")!=_digest(geometry):
        raise ValueError("Compound contributor geometry differs")
    cc,rr=_validate_box(list(map(Fraction,geometry["centers"])),list(map(Fraction,geometry["radii"])))
    if method=="pooled_signs":
        contributors=recipe.get("contributors",[])
        if not isinstance(contributors,list) or not 1<=len(contributors)<=32:
            raise ValueError("Missing/bounded compound contributors")
        fresh_sources=[]
        for source in contributors:
            remaining=cpu_seconds-(time.process_time()-began)
            if remaining<=0:raise CpuBudget("cpu_budget")
            fresh_sources.append(_regenerate_recipe(source,remaining,depth+1))
        remaining=cpu_seconds-(time.process_time()-began)
        if remaining<=0:raise CpuBudget("cpu_budget")
        fresh=compose_partials(fresh_sources,remaining,cc,rr)
    else:
        fresh=(legacy.evaluate if legacy is not None else evaluate)(cc,rr,method,cpu_seconds)
    if "budget" in fresh["reason"]:raise CpuBudget(fresh["reason"])
    if (fresh["ok"]!=recipe.get("source_ok",True) or fresh["reason"]!=recipe["reason"] or
        _digest(fresh["witness"])!=recipe["witness_sha256"] or
        fresh["replay"]["evidence_sha256"]!=recipe["replay"]["evidence_sha256"]):
        raise ValueError("Compound contributor regenerated different evidence")
    return fresh
