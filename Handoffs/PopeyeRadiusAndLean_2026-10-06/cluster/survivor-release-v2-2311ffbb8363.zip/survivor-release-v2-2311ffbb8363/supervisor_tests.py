"""Small safety tests; no cluster calls, large data or numerical evaluation."""
from pathlib import Path
import json
import tempfile
import unittest
from unittest.mock import patch, MagicMock

import supervisor as s


class SupervisorSafety(unittest.TestCase):
    def setUp(self):
        self.safety = patch.object(s, 'SAFETY_PATHS', s.SafetyPaths())
        self.safety.start()
        self.addCleanup(self.safety.stop)

    def test_continuous_replay_is_one_independent_process(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            process = MagicMock(pid=42)
            process.poll.return_value = None
            with patch.object(s, 'verify_source', return_value='pinned'), patch.object(s.subprocess, 'Popen', return_value=process) as spawn:
                audit = s.ContinuousReplay(root, root)
                self.assertFalse(audit.tick())
                self.assertFalse(audit.tick())
                spawn.assert_called_once()
                command = spawn.call_args.args[0]
                self.assertIn('--watch', command)
                self.assertIn('--ready-only', command)
                self.assertFalse(audit.drain())
                self.assertTrue((root / 'REPLAY_DRAIN_REQUESTED.json').is_file())
                process.poll.return_value = 0
                self.assertTrue(audit.tick())
                self.assertEqual(spawn.call_count, 1)
                audit.close()

    def test_replay_failure_is_not_silently_restarted(self):
        with tempfile.TemporaryDirectory() as tmp:
            audit = s.ContinuousReplay(tmp, tmp)
            process = MagicMock()
            process.poll.return_value = 1
            audit.process = process
            with patch.object(s.subprocess, 'Popen') as spawn:
                with self.assertRaises(RuntimeError):
                    audit.tick()
                spawn.assert_not_called()

    def test_replay_restart_budget_is_finite(self):
        with tempfile.TemporaryDirectory() as tmp:
            audit = s.ContinuousReplay(tmp, tmp)
            audit.starts = 3
            with self.assertRaises(RuntimeError):
                audit.tick()

    def test_replay_drain_reopens_for_restored_descendants(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            process = MagicMock(pid=42)
            process.poll.return_value = None
            with patch.object(s, 'verify_source', return_value='pinned'), patch.object(s.subprocess, 'Popen', return_value=process) as spawn:
                audit = s.ContinuousReplay(root, root)
                audit.tick()
                audit.drain()
                audit.resume()
                self.assertFalse(audit.draining)
                self.assertFalse((root / 'REPLAY_DRAIN_REQUESTED.json').exists())
                self.assertEqual(audit.reopens, 1)
                self.assertEqual(spawn.call_count, 1)
                process.poll.return_value = 0
                audit.close()

    def test_completed_drain_can_restart_one_verifier(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            process = MagicMock(pid=42)
            process.poll.return_value = None
            with patch.object(s, 'verify_source', return_value='pinned'), patch.object(s.subprocess, 'Popen', return_value=process) as spawn:
                audit = s.ContinuousReplay(root, root)
                audit.tick()
                audit.drain()
                process.poll.return_value = 0
                self.assertTrue(audit.tick())
                audit.resume()
                self.assertFalse(audit.draining)
                self.assertEqual(spawn.call_count, 2)
                audit.close()

    def test_useful_capacity(self):
        self.assertEqual(s.allocation_plan(1), [('genx', 1)])
        self.assertEqual(s.allocation_plan(490), [('genx', 49)])
        self.assertEqual(s.allocation_plan(584), [('ccq', 1), ('genx', 49)])
        self.assertEqual(s.allocation_plan(100000), [('ccq', 50), ('genx', 49)])

    def test_no_empty_allocation(self):
        for value in (0, -1, True):
            with self.assertRaises(ValueError):
                s.allocation_plan(value)

    def test_no_early_original_cancellation(self):
        with tempfile.TemporaryDirectory() as tmp, patch.object(s, 'jobs') as jobs:
            p = Path(tmp)
            s.cancel_finished_original_jobs(p, p, dict(done=2, committed=1, total=2))
            s.cancel_finished_original_jobs(p, p, dict(done=1, committed=1, total=2))
            jobs.assert_not_called()

    def test_original_cancellation_preserves_coordinator(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / 'elastic-run').mkdir()
            (root / 'new').mkdir()
            (root / 'elastic-run/SUBMISSION.json').write_text(json.dumps(dict(worker_arrays=['11', '12'], coordinator_job_id='10')))
            with patch.object(s, 'jobs', return_value=[['11_1', 'RUNNING']]) as jobs, patch.object(s, 'invoke') as invoke:
                invoke.return_value.returncode = 0
                s.cancel_finished_original_jobs(root, root, dict(done=2, committed=2, total=2))
                self.assertEqual(jobs.call_args.args[0], ['11', '12'])
                self.assertEqual(invoke.call_args.args[0], ['scancel', '11_1'])
                self.assertTrue((root / 'ORIGINAL_JOBS_FINISHED.json').exists())

    def test_inherited_stop(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / 'elastic-run').mkdir()
            (root / 'new').mkdir()
            (root / 'elastic-run/STOP_REQUESTED.json').write_text('{}')
            self.assertIsNotNone(s.safety_stop(root, root / 'new'))

    def test_legacy_handover_is_not_safety_failure(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / 'production').mkdir()
            (root / 'new').mkdir()
            path = root / 'production/STOP_REQUESTED.json'
            path.write_text(json.dumps(dict(reason='authorized_elastic_handover')))
            self.assertIsNone(s.safety_stop(root, root / 'new'))
            path.write_text(json.dumps(dict(reason='disk_reserve_8GiB')))
            self.assertIsNotNone(s.safety_stop(root, root / 'new'))

    def test_stop_latches_after_file_removed(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            path = root / 'STOP_REQUESTED.json'
            path.write_text('{}')
            expected = str(path)
            self.assertEqual(s.safety_stop(root, root), expected)
            path.unlink()
            self.assertEqual(s.safety_stop(root, root), expected)

    def test_signal_stop_does_not_need_filesystem(self):
        with patch.object(s, 'STOP', True), patch.object(s.SAFETY_PATHS, 'present') as scan:
            self.assertEqual(s.safety_stop('/signal-root', '/signal-area'), 'supervisor_signal')
            scan.assert_not_called()

    def test_listing_failure_is_fatal(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            with patch.object(s.SAFETY_PATHS, 'present', side_effect=PermissionError('unavailable')):
                with self.assertRaises(PermissionError):
                    s.safety_stop(root, root)


if __name__ == '__main__':
    unittest.main()
