# Scoped proof status

**66 theorems are kernel checked. No physical strict-D0 exclusion, complete
ring closure, uniform seed radius, or no-four-MUB theorem is admitted.**

The four successful serialized checks are:

| Source | Theorems | Receipt | Wall time | Peak RSS |
|---|---:|---|---:|---:|
| `SurvivorV2Rules.lean` | 33 | `lean-20261005T150907/RESULT.json` | 11.04 s | 1425.4 MiB |
| `CancellationBinding.lean` | 19 | `lean-20261005T153919/RESULT.json` | 12.67 s | 1426.5 MiB |
| `HermitianRayBinding.lean` | 6 | `lean-20261005T153959/RESULT.json` | 10.83 s | 1382.4 MiB |
| `NonnegativeRhsClipping.lean` | 8 | `lean-20261005T172439/RESULT.json` | 10.82 s | 1346.8 MiB |

All checks used the existing Lean serialization lock, 1536 MiB Lean heap,
2048 MiB resident-memory guard, 120-second wall limit, and 3 GiB disk reserve.
All printed axiom lists contain only `propext`, `Classical.choice`, and
`Quot.sound`, or no axioms. There are no `sorry` declarations or custom axioms.

The 33-rule packet proves conditional branch pooling/inheritance, containment,
finite transport and covers, whole-root supersession, complementary-corner
guards, constrained lower bounds, monotonic-face consequences, scalar
quadratic obstruction, and scalar cancellation/sign identities. Concrete
regions, transports, monotonicity, native bounds, and physical necessity remain
hypotheses wherever stated as such. These generic rules do not certify a
specific runtime queue or numerical receipt.

The 19-theorem packet proves the new cancellation algebra on actual complex
unit phases: both conjugate cube-root seeds; the unit-phase U rewrite; all
three anchor coefficient lists, including third-pair weights; leading
f0/f1/f2 moments; and the exact A0, B0, R0 identities used by the evaluator.
It does not merely assume the terminal leading cancellation. The prior
exit-monitor race receipt `lean-20261005T153421/RESULT.json` is retained. An
authorized unchanged-source rerun produced the identical object and log
hashes and passed the corrected resource wrapper. Earlier failed compilation
attempts are also preserved and receive no proof credit.

The six Hermitian theorems prove the native ray contraction formula from a
complex Hermitian 3x3 form, its exact representation in six real coordinates,
the arbitrary/rational-complex vector obstruction, affine radical dependence,
and the nonnegative-parameter endpoint upper bound. Thus the real-vector-only
scope of the earlier generic PSD lemma is not being substituted for the
complex native rays. The physical matrix pencil and its native enclosures
still require their own bindings. The AD derivative-to-monotonicity binding
also remains open.

The eight added interval-normalization lemmas prove nonnegativity of a product
of squared norms and of the A-elimination RHS, endpoint bounds for absolute
values, its scalar upper bound, containment after clipping/resetting a lower
endpoint to zero, and invariance of the upper-only accepting comparisons.
They support the native `elimination_rhs` correction while retaining enclosure
membership and the physical necessary inequality as explicit hypotheses. The
previous 58 proof sources and receipts remain unchanged; their aggregate
record is preserved as `FORMALIZATION_RECORD.pre-rhs-58.json`.

`cancellation_order4` is implemented as a compact exact secant circuit before
Taylor truncation. The native controls passed 544 independent exact rational
coefficient containments, including both seeds and nonzero Taylor widths;
12 forced-chart evaluations of known physical corners survived. CPU expiry,
nonpositive rho, and chart admission controls passed. These tests are
implementation evidence, not kernel proofs of native arithmetic.

The output H signs remove an additional positive rho: physical coefficient
powers are R=4, Delta=12, A=12, B=10, and H=25. Provider metadata records this
explicitly. The unchanged frozen physical interface still supplies strict-D0
necessity and the R<243 opposite-orientation coupling condition.

Remaining end-to-end gaps include C++/Taylor/interval soundness, rational
trigonometric input enclosure, strict-D0 completion-to-moment and MC4 transport,
the physical Hermitian pencil, native AD monotonicity, actual finite-cover
admission, and the practical uniform seed-radius problem. The workspace Lean
policy file remains iCloud dataless; no authoritative registry was changed.
