# A-elimination lower-bound normalization

Independent source review approves the scoped correction in
`advanced_src/plain_constraint.cpp`, `elimination_rhs`.

The exact target is `Dh*abs(Av)+Dv*abs(Ah)`. Each Delta is a product of three
squared complex norms, so `Dh=3*Delta_h` and `Dv=3*Delta_v` are nonnegative.
The factors `abs(Av)` and `abs(Ah)` are nonnegative. Therefore the target is
nonnegative even when an outward interval operation rounds its zero lower
endpoint to a tiny negative number.

The helper first computes exactly the old interval expression, then returns
`I(0,rhs.u)`. Given original enclosure membership, this replacement preserves
membership. It remains conservative even if the old lower endpoint were
positive. In this expression each factor interval contains zero, so the old
product/sum enclosure also contains zero and resetting the lower endpoint is
the expected intersection with the known nonnegative range.

The acceptance comparisons remain `hr.l > rhs.u` and `-hr.u > rhs.u`.
Replacing only the lower endpoint does not change either scalar condition.
The Python decoder can retain its nonnegative-RHS requirement and strict
comparison checks. The native shared-helper control export only observes
this expression and adds no production acceptance branch.

`NonnegativeRhsClipping.lean` proves eight supporting statements. Its successful
serialized receipt is `lean-20261005T172439/RESULT.json`: exit 0, 10.82 seconds,
1346.75 MiB peak RSS, standard axioms only. The prior 58 proof sources and
receipts were preserved. No new physical assumption or physical admission is
introduced. Native IEEE arithmetic and the necessary physical A-elimination
inequality remain outside this scalar packet.

This worker performed source review and a bounded Lean check only. Native
regression execution and reproduction of checkpoint
`work/plain_bound_failure_2481779.json` belong to the engine validation work;
they are not claimed by this record. The numerical 8 GiB guard was not bypassed.
