# Cancellation evaluator and exact algebra

The additive `cancellation_order4` provider uses the existing rational phase
enclosures, a positive dyadic radial scale, and the frozen native Taylor
arithmetic. Its new step is a compact exact secant circuit, applied before
Taylor truncation. No large expanded polynomial is stored.

At either seed write the four unit phases as
`(alpha,beta,beta,alpha) + rho*(da,db,dc,dd)`, with
`alpha=-1/2+i*eta/2`, `beta=-1/2-i*eta/2`, and `eta^2=3`.
Put `S=-da-db`, `T=-dc-dd`, `U0=-S-conj(T)`. The unit-phase identity is

```
U = U0 + rho*Udef
Udef = alpha*(|da|^2+|dc|^2) + beta*(|db|^2+|dd|^2)
       - dc*conj(da) - dd*conj(db).
```

`CancellationBinding.unit_phase_U_binding` proves this identity from explicit
unit-phase hypotheses. `cube_root_relations` covers both signs of eta.
Transposing the seed exchanges its two beta coordinates and preserves this
anchor pattern.

Each circuit node stores `(base,defect)` for `base+rho*defect`. Multiplication
uses `baseA*baseB` and
`baseA*defectB+defectA*baseB+rho*defectA*defectB`; conjugation is componentwise.
The complex product, conjugate, and norm identities are proved in
`CancellationBinding.lean`. The frozen normalized polynomial circuit is then
evaluated with this representation.

Put `I=Im(S*T)`, `x=|S|^2`, `y=|T|^2`, `z=|U0|^2`. The actual three weighted
anchor coefficient lists are all `[-3,0,3,0,3,0]`.
`all_three_anchor_coefficients` proves this, including the factors for the
third pair. `base_f0`, `base_f1`, `base_f2`, `rawA_binding`, and `rawB_binding`
connect these coefficients to the leading moment circuit. They establish

```
R0 = 324*I^2
B0 = 1458*x*y*z*I^2
A0 = -18*I*B0.
```

For the secant defects `Ad`, `Bd`, `Rd`, let
`B=B0+rho*Bd`, `D=Ad+18*I*Bd`. Then
`A=-18*I*B+rho*D` and `R=324*I^2+rho*Rd`. The evaluator computes

```
H0/rho = rho*D^2 - 36*I*B*D - B^2*Rd
Hminus/rho = H0/rho + rho*(6*B*Delta - 9*rho^2*Delta^2)*R
Hplus/rho  = H0/rho - rho*(6*B*Delta + 9*rho^2*Delta^2)*R.
```

The corresponding scalar equalities and positive-factor sign rules are
kernel checked in `SurvivorV2Rules.lean`. In physical coefficient units the
output powers are `R:4`, `Delta:12`, `A:12`, `B:10`, **`H:25`**. Removing a
positive rho changes no sign. The provider records these powers explicitly;
the frozen selector reads only the H signs. The transposed sign reversal and
the physical `rho^4*Rbar < 243` condition are retained.

The implementation controls independently compare all 17 output coefficient
intervals with the frozen exact rational moment formulas, with the stated
powers. They test four unit-phase cases, both anchors, two rho values, and
both point and nonzero-width Taylor inputs: 544 containments. Twelve forced
chart evaluations of known physical corners survive. A chart refusal alone
is not counted as a substantive negative control.

These proofs establish the new exact algebra. They do not prove the native
Taylor/interval implementation, rational trigonometric wrapper, C++ translation,
strict-D0-to-moment transport, MC4 coupling, actual cover completeness, or any
positive uniform seed radius. See `FORMALIZATION_RECORD.json` for exact kernel
and resource-wrapper receipt status; no physical exclusion is admitted.
