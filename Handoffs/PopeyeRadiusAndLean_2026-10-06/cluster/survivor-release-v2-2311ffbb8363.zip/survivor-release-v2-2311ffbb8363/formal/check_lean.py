"""Small serialized Lean check using only a materialized known runtime recipe.

This does not override the numerical campaign's 8 GiB free-space gate: it is
a separate bounded scalar proof check. Limits: 1536 MiB Lean heap, 2048 MiB
resident memory, 120 seconds wall time, 64 MiB per output file, 3 GiB free
disk. The existing integration lock is acquired read-only. No global state
or source outside this assigned directory is changed.
"""
from pathlib import Path
import argparse, ctypes, fcntl, hashlib, json, os, resource, shutil, signal, subprocess, time

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[3]
RECIPE=ROOT/'runs/patch2442-certification-2026-10-04.nosync/lean/scalar-05/JOB.json'
LOCK=ROOT/'runs/full-proof-integration-2026-10-03/LEAN_SERIAL.lock'

def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,obj): p.write_text(json.dumps(obj,indent=2)+'\n')

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--source", default="SurvivorV2Rules")
    args=parser.parse_args()
    if not args.source.replace("_", "").isalnum(): raise ValueError("Local Lean basename required")
    recipe=json.loads(RECIPE.read_text())
    out=HERE/('lean-'+time.strftime('%Y%m%dT%H%M%S'))
    out.mkdir()
    src=HERE/(args.source+'.lean')
    free=shutil.disk_usage(HERE).free
    if free<3*2**30: raise RuntimeError('scalar check needs 3 GiB free disk')
    cmd=[recipe['command'][0],'-j1','-M1536','-T2000000','-o',str(out/(args.source+'.olean')),str(src)]
    paths=[str(HERE)]+[p for p in recipe['lean_path'] if '/lib/lean' in p]
    env=dict(os.environ,LEAN_PATH=':'.join(paths))
    libproc=ctypes.CDLL('/usr/lib/libproc.dylib')
    info=libproc.proc_pidinfo
    info.argtypes=[ctypes.c_int,ctypes.c_int,ctypes.c_uint64,ctypes.c_void_p,ctypes.c_int]
    info.restype=ctypes.c_int
    buf=ctypes.create_string_buffer(1024)
    limits={'lean_heap_mib':1536,'resident_mib':2048,'wall_seconds':120,
            'file_bytes':64*2**20,'minimum_free_disk_bytes':3*2**30}
    save(out/'JOB.json',{'command':cmd,'lean_path':paths,'source':str(src),
         'source_sha256':digest(src),'limits':limits,'lock':str(LOCK),
         'recipe':str(RECIPE),'recipe_sha256':digest(RECIPE)})
    def prepare():
        os.setsid()
        resource.setrlimit(resource.RLIMIT_FSIZE,(64*2**20,64*2**20))
        resource.setrlimit(resource.RLIMIT_CPU,(120,125))
    peak=0; reason=None; start=time.monotonic()
    with LOCK.open('r') as lock, (out/'compile.log').open('w') as log:
        fcntl.flock(lock,fcntl.LOCK_EX)
        child=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,env=env,preexec_fn=prepare)
        save(out/'PROCESS.json',{'pid':child.pid,'started':time.time()})
        while child.poll() is None:
            n=info(child.pid,4,0,buf,len(buf))
            if n>=16:
                rss=ctypes.c_uint64.from_buffer(buf,8).value
                peak=max(peak,rss)
                if rss>2048*2**20: reason='resident_memory_limit'
            elif child.poll() is not None: break
            elif time.monotonic()-start>5:
                # proc_pidinfo can lose an exiting process just before waitpid
                # observes its normal exit. Give that race a bounded 50 ms;
                # a live unmonitorable process still triggers the same guard.
                try:
                    child.wait(timeout=.05)
                    break
                except subprocess.TimeoutExpired:
                    reason='resident_monitor_unavailable'
            if time.monotonic()-start>120: reason='wall_limit'
            if shutil.disk_usage(HERE).free<3*2**30: reason='disk_guard'
            if reason:
                if child.poll() is not None:
                    reason=None
                    break
                child.kill()
                break
            time.sleep(.2)
        rc=child.wait()
    logfile=out/'compile.log'
    result={'success':rc==0 and reason is None,'exit_code':rc,'stop_reason':reason,
        'seconds':time.monotonic()-start,'peak_rss_mib':peak/2**20,
        'free_disk_before':free,'source_sha256':digest(src),
        'compile_log_sha256':digest(logfile),'physical_exclusions_admitted':0,'object_sha256':digest(out/(args.source+'.olean')) if (out/(args.source+'.olean')).exists() else None,
        'scope':'Generic conditional logic and scalar algebra; no native or physical bindings.'}
    save(out/'RESULT.json',result)
    print(json.dumps(dict(output=str(out),**result),indent=2))
    print(logfile.read_text())
    return 0 if result['success'] else 1

if __name__=='__main__': raise SystemExit(main())
