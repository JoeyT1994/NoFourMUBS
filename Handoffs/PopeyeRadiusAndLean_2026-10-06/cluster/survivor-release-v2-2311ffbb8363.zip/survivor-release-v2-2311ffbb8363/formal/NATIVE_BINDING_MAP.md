# Algebra-to-source review map

This is a reviewed correspondence, not a formal verification of the C++
program or its floating-point interval implementation. The exact source
hashes and kernel receipts are in `FORMALIZATION_RECORD.json`.

| Native expression | Kernel-checked statement |
|---|---|
| `cancellation_engine.cpp`, `CSec` product/conjugate/norm | `CancellationBinding.complex_secant_product`, `complex_secant_conjugate`, `complex_secant_normSq` |
| roots `(alpha,beta,beta,alpha)` in either conjugate chart | `cube_root_relations`, with eta^2=3 |
| `udef` at line 67 | `unit_phase_U_binding` under four explicit unit-phase hypotheses and rho nonzero |
| three weighted `cancellation_coeffs` bases | `all_three_anchor_coefficients`; third-pair factors explicitly included |
| leading `f0`, `f1`, `f2`, signed A/B moments | `base_f0`, `base_f1`, `base_f2`, `rawA_binding`, `rawB_binding` |
| `Rvalue` base at line 96 | `actual_base_R_value` |
| `beta0` at line 97 | `actual_base_B_value` |
| `A` base and `defect` at lines 105–106 | `actual_base_A_relation`, `SurvivorV2Rules.terminal_secant_rewrite` |
| `Hbase`, `Hm`, `Hp` at lines 107–111 | `cancellation_H`, `cancellation_Hminus`, `cancellation_Hplus`, positive-factor sign theorems |
| `advanced_engine.cpp`, `ray_form` | `HermitianRayBinding.Hermitian_contraction`, `exact_realification` |
| dyadic complex ray vectors | `complex_vector_obstruction`, `rational_complex_vector_obstruction` |
| `advanced_provider.py`, radical endpoint upper check | `affine_pencil_contraction`, `nonnegative_parameter_endpoint_upper` |
| `advanced_src/plain_constraint.cpp`, `elimination_rhs` | `NonnegativeRhsClipping.elimination_rhs_nonnegative`, `elimination_rhs_upper`, `zero_lower_contains`, `lower_change_preserves_upper_test` |

The native ray proposal is only a vector-selection heuristic. Acceptance
contracts the resulting fixed dyadic vector with outward bounds. The reviewed
face logic evaluates a maximizing face selected from whole-box angular AD
derivative intervals; the derivative-to-monotonicity theorem and native AD
binding are not supplied by the generic face lemma.

The reviewed complement formula is exactly 2*J*complementBracket. Its direct
negative-gap obstruction requires maximality but no fixed seed radius. The
J<0 shortcut additionally uses p<1, Gram nonnegativity, and the nonnegative W
deduction; the latter scalar lemma already exists in the preserved
`survivor/seed_math/archive_review/ArchiveConstraintAlgebra.lean` packet.
The current plain handoff provider disables domain shifts. MC4 matching and
physical PSD necessity remain inherited physical assumptions throughout.

The `elimination_rhs` normalization recomputes the old outward expression and
then returns `(0,oldUpper)`. It preserves the exact nonnegative target and
the upper-only decision. This is a scalar order proof under supplied enclosure
membership, not a proof of the underlying IEEE interval implementation.
