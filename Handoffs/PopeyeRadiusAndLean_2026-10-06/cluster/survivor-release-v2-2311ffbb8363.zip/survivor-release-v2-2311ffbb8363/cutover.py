"""Validated, durable replacement of obsolete v1 Slurm workers.

Only the named continuation is stopped. Its last atomic checkpoints and all
proof data remain. Existing safety stops are never removed. Original elastic
source jobs are outside this controller's job set and continue independently.
"""
from pathlib import Path
import argparse
import fcntl
import json
import os
import re
import shlex
import subprocess
import sys
import time
import uuid

import supervisor as s
import task_queue as tq


def run(args, root, timeout=45, check=True):
    return subprocess.run(args, cwd=root, env=s.environment(), text=True,
                          capture_output=True, timeout=timeout, check=check)


def active(ids, root):
    return s.jobs(sorted(set(ids)), root)


def stop_allocations(ids, root):
    ids = sorted(set(ids))
    if not ids:
        return
    live = active(ids, root)
    if live:
        # v1 treats an intentional TERM/USR1 as a safety failure or parked
        # mathematical task. KILL instead leaves its last atomic checkpoint;
        # interrupted in-memory work is recomputed under the new release.
        result = run(['scancel', '--signal=KILL', '--full', *ids], root, check=False)
        if result.returncode and 'Invalid job id' not in result.stderr:
            raise RuntimeError('Obsolete allocation cancellation failed: ' + result.stderr)
    until = time.monotonic() + 180
    while active(ids, root):
        if time.monotonic() >= until:
            raise TimeoutError('Old allocations still present; migration forbidden')
        time.sleep(3)


def old_submissions(area, source, root):
    ids = []
    for path in sorted((area/'submissions').glob('*.json')):
        receipt = tq.read_json(path)
        if Path(receipt['source']).resolve() != source:
            raise ValueError('Another release owns an active submission receipt')
        if receipt.get('job_id'):
            ids.append(str(receipt['job_id']))
        else:
            # Both migration and cancellation require the same durable job
            # census. Resolve an ambiguous prior sbatch before cutover, never
            # merely infer an ID in memory and then strand migration.
            raise RuntimeError('Ambiguous old submission requires reconciliation before cutover: ' + str(path))
    if any(not x.isdigit() for x in ids):
        raise ValueError('Malformed old Slurm job id')
    return sorted(set(ids))


def verify_coordinator(root, area, release, ident):
    if not active([str(ident)], root):
        return
    info = run(['scontrol', 'show', 'job', '-o', str(ident)], root, check=False)
    def field(name):
        match = re.search(r'(?<!\S)' + name + r'=(.*?)(?= [A-Za-z][A-Za-z0-9_/]*=|$)', info.stdout.strip())
        return match.group(1) if match else ''
    def resolved(token):
        path = Path(token)
        return (path if path.is_absolute() else root / path).resolve()
    expected = [release / 'coordinator.sbatch', release, area]
    command = shlex.split(field('Command'))
    matches = False
    if len(command) == 3:
        matches = (list(map(resolved, command)) == expected
                   and (all(Path(token).is_absolute() for token in command)
                        or field('WorkDir') == str(root)))
    elif len(command) == 1 and resolved(command[0]) == expected[0]:
        # Popeye records only the script in Command. SubmitLine retains its
        # arguments; resolve relative paths against the exact pinned WorkDir.
        submitted = shlex.split(field('SubmitLine'))
        matches = (len(submitted) >= 4 and Path(submitted[0]).name == 'sbatch'
                   and field('WorkDir') == str(root)
                   and list(map(resolved, submitted[-3:])) == expected)
    if info.returncode != 0 or not matches:
        raise ValueError('Active coordinator ownership could not be verified; cancellation forbidden')


def stop_coordinator_at_import_boundary(root, area, release, ident, wait_seconds=1800):
    """Do not interrupt publication between a task file and its initial state."""
    until = time.monotonic() + wait_seconds
    with (area / 'IMPORT.lock').open('a') as barrier:
        while True:
            try:
                fcntl.flock(barrier, fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except BlockingIOError:
                if time.monotonic() >= until:
                    raise TimeoutError('Importer did not reach its checkpoint boundary; no jobs stopped')
                stopped = s.safety_stop(root, area)
                if stopped:
                    raise RuntimeError('Existing safety stop is preserved: ' + stopped)
                tq.resource_guard(area)
                time.sleep(1)
        verify_coordinator(root, area, release, ident)
        stop_allocations([str(ident)], root)


def cutover(root, area, old_release, coordinator_id, validation):
    root, area, old_release = (Path(p).resolve() for p in (root, area, old_release))
    source = Path(__file__).resolve().parent
    new_sha = s.verify_source()
    validation = Path(validation).resolve()
    verified = tq.read_json(validation)
    if verified.get('status') != 'PASS' or verified.get('source_sha256') != new_sha:
        raise ValueError('Replacement release has not passed its pinned cluster validation')
    if not str(coordinator_id).isdigit():
        raise ValueError('Invalid old coordinator id')
    old_pins = tq.read_json(old_release/'PINS.json')
    old_sha = tq.digest(old_pins)
    for name, expected in old_pins.items():
        p = Path(name)
        if p.is_absolute() or '..' in p.parts or tq.sha_file(old_release/p) != expected:
            raise ValueError('Legacy source pin mismatch')
    stopped = s.safety_stop(root, area)
    if stopped:
        raise RuntimeError('Existing safety stop is preserved: ' + stopped)
    tq.resource_guard(area)
    with (area/'CUTOVER.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        journal = area/'V2_CUTOVER.json'
        if journal.exists():
            state = tq.read_json(journal)
            if state['new_source_sha256'] != new_sha or state['old_source_sha256'] != old_sha:
                raise ValueError('Another cutover already owns this queue')
            if state.get('old_coordinator_job_id') != str(coordinator_id):
                raise ValueError('Old coordinator identity changed during cutover')
            if state.get('new_coordinator_job_id'):
                print(json.dumps(state,sort_keys=True))
                return state
            if state.get('phase') == 'SUBMITTING_NEW_COORDINATOR':
                raise RuntimeError('Ambiguous replacement submission requires token reconciliation')
        else:
            launch = tq.read_json(area/'LAUNCH.json')
            if Path(launch['source']).resolve() != old_release or launch['source_sha256'] != old_sha:
                raise ValueError('Old launch does not belong to the requested continuation')
            state = dict(schema='survivor-cutover-v2',phase='VALIDATED',
                         old_release=str(old_release), new_release=str(source),
                         old_source_sha256=old_sha,new_source_sha256=new_sha,
                         old_coordinator_job_id=str(coordinator_id),
                         validation_path=str(validation), validation_sha256=tq.sha_file(validation),
                         started_unix=time.time(),physical_lean_admissions=0)
            tq.durable_json(journal,state)
        if state['phase'] == 'VALIDATED':
            verify_coordinator(root, area, old_release, coordinator_id)
            old_submissions(area, old_release, root)
            state.update(phase='STOPPING_OLD_COORDINATOR')
            tq.durable_json(journal,state)
        if state['phase'] == 'STOPPING_OLD_COORDINATOR':
            stop_coordinator_at_import_boundary(root, area, old_release, coordinator_id)
            state.update(phase='STOPPING_OLD_WORKERS',obsolete_worker_jobs=old_submissions(area,old_release,root))
            tq.durable_json(journal,state)
        if state['phase'] == 'STOPPING_OLD_WORKERS':
            stop_allocations(state['obsolete_worker_jobs'],root)
            # Re-read once after the killed importer/sbatch children are gone.
            extra = old_submissions(area,old_release,root)
            stop_allocations(extra,root)
            state['obsolete_worker_jobs']=sorted(set(state['obsolete_worker_jobs']+extra))
            all_ids=state['obsolete_worker_jobs']+[str(coordinator_id)]
            if active(all_ids,root):
                raise RuntimeError('Old workers reappeared; migration forbidden')
            evidence = dict(schema='survivor-cutover-stop-v2',
                            obsolete_jobs=[dict(job_id=i,state='ABSENT') for i in all_ids],
                            coordinator_stopped=True,workers_stopped=True,source_workers_untouched=True,
                            old_release_sha256=old_sha,new_release_sha256=new_sha,
                            observed_unix=time.time(),cutover_journal_sha256=tq.sha_file(journal))
            tq.durable_json(area/'V2_STOP_EVIDENCE.json',evidence)
            state['phase']='MIGRATING_CHECKPOINTS'
            tq.durable_json(journal,state)
        if state['phase'] == 'MIGRATING_CHECKPOINTS':
            result=run([sys.executable,'-B',str(source/'migrate.py'),
                        '--queue',str(area),'--old-release',str(old_release),'--new-release',str(source),
                        '--schedule',str(source/'SCHEDULE.json'),'--stop-evidence',str(area/'V2_STOP_EVIDENCE.json')],
                       root,timeout=3*3600)
            (area/'V2_MIGRATION_OUTPUT.txt').write_text(result.stdout+result.stderr)
            tq.durable_json(area/'VALIDATION_PASS.json',verified)
            state['phase']='READY_TO_LAUNCH'
            tq.durable_json(journal,state)
        if state['phase'] == 'READY_TO_LAUNCH':
            token=uuid.uuid4().hex
            state.update(phase='SUBMITTING_NEW_COORDINATOR',submission_token=token)
            tq.durable_json(journal,state)
            result=run(['sbatch','--parsable','--comment=mub6-cutover-'+token,
                        str(source/'coordinator.sbatch'),str(source),str(area)],root)
            ident=result.stdout.strip().split(';')[0]
            if not ident.isdigit():
                raise ValueError('Invalid replacement coordinator response')
            state.update(phase='DEPLOYED',new_coordinator_job_id=ident,finished_unix=time.time())
            tq.durable_json(journal,state)
        print(json.dumps(state,sort_keys=True))
        return state


if __name__ == '__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,required=True)
    parser.add_argument('--queue',type=Path,required=True)
    parser.add_argument('--old-release',type=Path,required=True)
    parser.add_argument('--old-coordinator',required=True)
    parser.add_argument('--validation',type=Path,required=True)
    args=parser.parse_args()
    cutover(args.root,args.queue,args.old_release,args.old_coordinator,args.validation)
