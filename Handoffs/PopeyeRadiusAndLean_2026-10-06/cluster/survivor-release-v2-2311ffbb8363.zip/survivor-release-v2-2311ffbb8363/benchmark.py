"""Bounded method comparison on identical saved survivor geometries."""
from concurrent.futures import ProcessPoolExecutor,as_completed
from multiprocessing import get_context
from pathlib import Path
from fractions import Fraction
import argparse,collections,hashlib,json,os,resource,sys,time

import dispatch_hold

ENG=None
def initialize(root,cache):
    global ENG
    if sys.platform == 'linux':
        resource.setrlimit(resource.RLIMIT_AS,(768*2**20,768*2**20))
    sys.path.insert(0,str(Path(__file__).parent))
    import engines
    ENG=engines;ENG.initialize(Path(root),Path(cache))

def trial(task):
    case,method,budget=task;start=time.process_time()
    result=ENG.evaluate(list(map(Fraction,case['centers'])),list(map(Fraction,case['radii'])),method,budget)
    search_cpu=time.process_time()-start
    return {'case_id':case['case_id'],'root_id':case['root_id'],'kind':case['kind'],
            'radius_band':case['radius_band'],'method':method,'cpu_seconds':search_cpu,
            'result':result,'physical_lean_admissions':0}

def replay(row):
    start=time.process_time();fresh=ENG.replay(row['result'],cpu_seconds=30)
    if fresh.get('ok') is not True:raise ValueError('Fresh benchmark replay failed '+row['case_id'])
    return dict(row,replay=fresh,replay_cpu_seconds=time.process_time()-start)

def write(path,value):
    tmp=path.with_suffix(path.suffix+'.tmp');tmp.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n');os.replace(tmp,path)

def dispatch_partition(cases):
    """Never evaluate a saved geometry whose original parent is held."""
    parents={};duplicates=set()
    for case in cases:
        if case.get('kind')=='parent' and case.get('prefix')=='' and case.get('root_id') is not None:
            key=case['root_id']
            if key in parents:duplicates.add(key)
            parents[key]=case
    parent_decisions={}
    for key,parent in parents.items():
        try:
            value=dispatch_hold.classify({'centers':parent.get('centers'),'radii':parent.get('radii')})
            parent_decisions[key]=(value['dispatch']=='RUN_WHOLE_PARENT_STRICTLY_OUTSIDE_HOLD',value['reason'])
        except (KeyError,TypeError,ValueError,ZeroDivisionError) as error:
            parent_decisions[key]=(False,'invalid_exact_parent_geometry:'+type(error).__name__)
    runnable=[];held=[]
    for case in cases:
        root_id=case.get('root_id')
        if root_id in duplicates:
            held.append({'case_id':case.get('case_id'),'reason':'duplicate_original_parent'})
            continue
        parent_relation=parent_decisions.get(root_id)
        if parent_relation is None:
            held.append({'case_id':case.get('case_id'),'reason':'missing_original_parent_geometry'})
            continue
        if not parent_relation[0]:
            held.append({'case_id':case.get('case_id'),'reason':'original_parent_held:'+parent_relation[1]})
            continue
        try:
            decision=dispatch_hold.classify({'centers':case.get('centers'),'radii':case.get('radii')})
            if decision['dispatch']=='RUN_WHOLE_PARENT_STRICTLY_OUTSIDE_HOLD':
                runnable.append(case);continue
            reason=decision['reason']
        except (KeyError,TypeError,ValueError,ZeroDivisionError) as error:
            reason='invalid_exact_geometry:'+type(error).__name__
        held.append({'case_id':case.get('case_id'),'reason':reason})
    ledger={'schema':'benchmark-dispatch-hold-v1','input_cases':len(cases),
            'runnable_whole_boxes':len(runnable),'held_without_evaluation':len(held),
            'held_cases':held,'parent_level_inheritance':True,
            'hold_radius_radians':str(dispatch_hold.HOLD_RADIUS),
            'hold_config_sha256':dispatch_hold.CONFIG_SHA256,
            'classifier_sha256':dispatch_hold.SOURCE_SHA256,
            'closure_credit':False,'physical_lean_admissions':0}
    return runnable,ledger

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,required=True);ap.add_argument('--input',type=Path,required=True)
    ap.add_argument('--output',type=Path,required=True);ap.add_argument('--cache',type=Path,required=True)
    ap.add_argument('--methods',nargs='+',default=['order3','order4','order5','paired_psd'])
    ap.add_argument('--jobs',type=int,default=8);ap.add_argument('--cpu',type=float,default=3);ap.add_argument('--limit',type=int,default=0)
    a=ap.parse_args()
    if not 1<=a.jobs<=47 or not 0<a.cpu<=60:ap.error('Resource limit')
    if a.input.stat().st_size>8*2**20:ap.error('Benchmark input exceeds bound')
    all_cases=json.loads(a.input.read_text())['cases'];all_cases=all_cases[:a.limit] if a.limit else all_cases
    if not 1<=len(all_cases)<=256 or not 1<=len(a.methods)<=16:ap.error('Benchmark census exceeds bound')
    cases,dispatch=dispatch_partition(all_cases)
    a.output.mkdir(parents=True,exist_ok=False)
    write(a.output/'DISPATCH_HOLD.json',dispatch)
    if cases:
        initialize(a.root,a.cache)
        manifest={'methods':ENG._STATE['availability'],'provider_hashes':ENG._STATE['pins']}
    else:
        manifest={'status':'NO_WHOLE_BOX_OUTSIDE_DISPATCH_HOLD','methods':{},'provider_hashes':{}}
    write(a.output/'PROVIDERS.json',manifest)
    results=[];tasks=[(c,m,a.cpu) for c in cases for m in a.methods]
    # A fresh process pool performs replay after producer processes have exited.
    for phase in ['search','replay']:
        todo=tasks if phase=='search' else [r for r in results if r['result'].get('ok') is True]
        accepted=[]
        with ProcessPoolExecutor(max_workers=a.jobs,mp_context=get_context('spawn'),initializer=initialize,
                                 initargs=(str(a.root),str(a.cache))) as pool:
            futures=[pool.submit(trial if phase=='search' else replay,t) for t in todo]
            for f in as_completed(futures):
                r=f.result()
                if phase=='search':results.append(r)
                else:accepted.append(r)
                write(a.output/'STATUS.json',{'phase':phase,'finished':len(results) if phase=='search' else len(accepted),'total':len(todo)})
        if phase=='replay':
            verified={(r['case_id'],r['method']):r for r in accepted}
            results=[verified.get((r['case_id'],r['method']),r) for r in results]
    summary={};by_kind={}
    for r in results:
        z=summary.setdefault(r['method'],{'attempted':0,'accepted_replayed':0,'cpu_seconds':0,'replay_cpu_seconds':0,'reasons':{}})
        z['attempted']+=1;z['accepted_replayed']+=int(r.get('replay',{}).get('ok') is True)
        z['cpu_seconds']+=r['cpu_seconds'];z['replay_cpu_seconds']+=r.get('replay_cpu_seconds',0)
        reason=r['result'].get('reason','unknown');z['reasons'][reason]=z['reasons'].get(reason,0)+1
        k=by_kind.setdefault(r['kind'],{}).setdefault(r['method'],dict(attempted=0,accepted_replayed=0,cpu_seconds=0))
        k['attempted']+=1;k['accepted_replayed']+=int(r.get('replay',{}).get('ok') is True);k['cpu_seconds']+=r['cpu_seconds']
    write(a.output/'RESULTS.json',{'scope':'Only whole boxes strictly outside the dispatch hold were evaluated; benchmark leaf/root candidates do not close original roots without full coverage assembly.',
                                'input_sha256':hashlib.sha256(a.input.read_bytes()).hexdigest(),
                                'dispatch_hold':dispatch,'summary':summary,'summary_by_kind':by_kind,
                                'results':results,'physical_lean_admissions':0})
    print(json.dumps(summary))

if __name__=='__main__':main()
