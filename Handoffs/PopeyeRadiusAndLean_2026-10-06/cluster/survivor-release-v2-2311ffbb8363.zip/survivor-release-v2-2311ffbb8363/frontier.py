"""Bounded in-memory frontier rebuilt once per durable task attempt.

Encoded STATE forests remain authoritative.  No unbounded campaign index is
loaded: at most the original 4095 task nodes are materialized here.
"""
from fractions import Fraction as Q

if __package__:
    from . import task_queue as tq
else:
    import task_queue as tq


class Frontier:
    def __init__(self, task, state):
        self.task, self.state = task, state
        self.nodes = {}
        self.roots = []
        self.pending = {}
        for initial, saved in zip(task["roots"], state["roots"]):
            prefix = initial["prefix"]
            self.roots.append(prefix)
            stack = [(prefix, list(map(Q, initial["centers"])), list(map(Q, initial["radii"])))]
            for token in saved["tree"]:
                if not stack:
                    raise ValueError("Trailing task frontier tokens")
                path, cc, rr = stack.pop()
                node = {"token": token, "centers": cc, "radii": rr, "prefix": prefix}
                if path in self.nodes:
                    raise ValueError("Duplicate task frontier node")
                self.nodes[path] = node
                if token in "0123":
                    if len(path) >= tq.MAX_DEPTH:
                        raise ValueError("Frontier depth guard changed")
                    axis = int(token)
                    stack.append((path + "1", *tq.bisect(cc, rr, axis, "1")))
                    stack.append((path + "0", *tq.bisect(cc, rr, axis, "0")))
                elif token == "P":
                    self.pending[path] = node
                elif token != "C":
                    raise ValueError("Unknown task frontier token")
            if stack:
                raise ValueError("Truncated task frontier")
        if len(self.nodes) > task["limits"]["max_task_nodes"]:
            raise ValueError("Task frontier exceeds original node guard")

    def next(self, cursor=None):
        if cursor:
            path = cursor["path"]
            if path not in self.pending:
                raise ValueError("Saved method cursor lost its pending leaf")
        elif self.pending:
            path = next(iter(self.pending))
        else:
            return None
        node = self.pending[path]
        return node, path, node["centers"], node["radii"]

    def close(self, path):
        node = self.pending.pop(path)
        node["token"] = "C"

    def split(self, path, axis):
        if len(path) >= tq.MAX_DEPTH or len(self.nodes) + 2 > self.task["limits"]["max_task_nodes"]:
            raise ValueError("Attempt to bypass a frontier guard")
        node = self.pending.pop(path)
        node["token"] = str(axis)
        # Child insertion is deterministic; independent audit uses encoded
        # preorder, not this scheduling order.
        for bit in "01":
            cc, rr = tq.bisect(node["centers"], node["radii"], axis, bit)
            child = {"token": "P", "centers": cc, "radii": rr, "prefix": node["prefix"]}
            self.nodes[path + bit] = self.pending[path + bit] = child
        self.state["added_nodes"] += 2

    def sync(self):
        for saved, prefix in zip(self.state["roots"], self.roots):
            result, stack = [], [prefix]
            while stack:
                path = stack.pop()
                token = self.nodes[path]["token"]
                result.append(token)
                if token in "0123":
                    stack.extend((path + "1", path + "0"))
            saved["tree"] = "".join(result)
        return self.state


def select_axis(cursor, verdict):
    """Retain the highest finite scored diagnostic, rather than the last method.

    Legacy unscored axes receive score zero and only replace the default once.
    A malformed diagnostic is an arithmetic verification failure.
    """
    import math
    diag = verdict.get("split_diagnostic")
    if diag is None and "axis" in verdict:
        diag = {"axis": verdict["axis"], "score": 0.0, "kind": "legacy_axis"}
    if diag is None:
        return
    axis, score = diag.get("axis"), diag.get("score")
    if type(axis) is not int or not 0 <= axis < 4 or isinstance(score, bool) or not isinstance(score, (int, float)) or not math.isfinite(score):
        raise ArithmeticError("Malformed survivor split diagnostic")
    if score > cursor.get("axis_score", float("-inf")):
        cursor.update(axis=axis, axis_score=float(score), axis_kind=diag.get("kind", "provider"))
