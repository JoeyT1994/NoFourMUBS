"""Pinned v2 runtime admission after an explicit checkpoint migration."""
from pathlib import Path
import fcntl

if __package__:
    from . import task_queue as tq
else:
    import task_queue as tq


def release_pins(source):
    source = Path(source).resolve()
    pins = tq.read_json(source / "PINS.json")
    if not isinstance(pins, dict) or not pins:
        raise ValueError("Release needs a nonempty flat PINS.json")
    for name, expected in pins.items():
        path = Path(name)
        if path.is_absolute() or ".." in path.parts or not isinstance(expected, str) or len(expected) != 64:
            raise ValueError("Invalid immutable release pin")
        if tq.sha_file(source / path) != expected:
            raise ValueError("Pinned release changed: " + name)
    return pins


class RuntimeLease:
    def __init__(self, queue, source, schedule_sha256=None):
        self.lock = (queue.area / "RUNTIME.lock").open("a")
        try:
            fcntl.flock(self.lock, fcntl.LOCK_SH | fcntl.LOCK_NB)
            value = tq.read_json(queue.area / "RUNTIME.json")
            body = {k: v for k, v in value.items() if k != "receipt_sha256"}
            if value.get("schema") != "survivor-runtime-v2" or value.get("receipt_sha256") != tq.digest(body):
                raise ValueError("V2 runtime receipt changed")
            migration = tq.read_json(queue.area / "MIGRATION.json")
            migration_body = {k: v for k, v in migration.items() if k != "receipt_sha256"}
            if migration.get("receipt_sha256") != tq.digest(migration_body) or migration["receipt_sha256"] != value["migration_receipt_sha256"]:
                raise ValueError("V2 migration has not committed")
            source = Path(source).resolve()
            if Path(value["new_release"]).resolve() != source or tq.digest(release_pins(source)) != value["new_release_sha256"]:
                raise ValueError("V2 worker release differs from migration")
            if value["queue_config_sha256"] != tq.digest(tq.read_json(queue.area / "CONFIG.json")):
                raise ValueError("Migration queue source configuration changed")
            if schedule_sha256 is not None and schedule_sha256 != value["schedule_sha256"]:
                raise ValueError("V2 worker schedule differs from committed migration stage")
            if value.get("legacy_source") is not None:
                legacy = Path(value["legacy_source"]).resolve()
                old_pins = release_pins(legacy)
                if tq.digest(old_pins) != value["legacy_release_sha256"] or old_pins != value["legacy_pins"]:
                    raise ValueError("Legacy replay release differs from migration")
            self.value = value
        except BaseException:
            self.close()
            raise

    def engine_kwargs(self):
        if self.value.get("legacy_source") is None:
            return {}
        return {"legacy_source": Path(self.value["legacy_source"]), "legacy_pins": self.value["legacy_pins"]}

    def close(self):
        if self.lock is not None:
            self.lock.close()
            self.lock = None

    def __enter__(self):
        return self

    def __exit__(self, kind, value, tb):
        self.close()
