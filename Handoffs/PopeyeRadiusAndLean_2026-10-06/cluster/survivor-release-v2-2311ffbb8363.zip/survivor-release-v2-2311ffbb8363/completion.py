"""Incremental, bounded parent completion hints, never proof acceptance."""
from pathlib import Path
import sqlite3

if __package__:
    from . import task_queue as tq
else:
    import task_queue as tq


def note_done(queue, key, ident, state_sha):
    place = queue.parent_dir(key)
    with tq.locked(place / "COMPLETION.lock"):
        db = sqlite3.connect(place / "COMPLETION.sqlite", timeout=30)
        try:
            db.execute("PRAGMA cache_size=-512")
            db.execute("PRAGMA synchronous=FULL")
            db.execute("CREATE TABLE IF NOT EXISTS done (task_id TEXT PRIMARY KEY, state_sha TEXT NOT NULL)")
            prior = db.execute("SELECT state_sha FROM done WHERE task_id=?", (ident,)).fetchone()
            if prior is not None and prior[0] != state_sha:
                raise ValueError("Completed parent checkpoint changed")
            db.execute("INSERT OR IGNORE INTO done VALUES (?,?)", (ident, state_sha))
            db.commit()
            count = db.execute("SELECT COUNT(*) FROM done").fetchone()[0]
            expected = tq.read_json(place / "READY.json")["tasks"]
            if count > expected:
                raise ValueError("Parent completion index has duplicate/outside tasks")
            if count == expected:
                queue.make_parent_marker("replay_ready", key)
            return count == expected
        finally:
            db.close()


def seed(queue, key):
    """Migration recovery: scan once, then normal finishes update incrementally."""
    place = queue.parent_dir(key)
    for line in tq.inventory_lines(place / "TASKS.jsonl"):
        item = __import__("json").loads(line)
        state = tq.read_json(queue.task_dir(item["task_id"]) / "STATE.json.gz")
        if state["status"] == "done":
            note_done(queue, key, item["task_id"], tq.digest(state))
