"""Optional, cooperative node-local directory membership cache.

One process scans a guard directory under its local flock. Other processes may
reuse only a completed snapshot whose original scan-start deadline is fresh.
Membership is never a permanent stop decision; callers retain their policy
latches and live reads of authorized production-handover contents.

Ordinary readers retain a published scan error until an explicit successful
fresh revalidation. A reader already holding a completed snapshot before a
refresh invalidates it may finish that read within its original deadline;
calls begun after error publication cannot reuse a private prior negative.
Read-only snapshots may retain an inode detached by atomic replacement. Locks,
registry and writable files retain exactly one link; all real hard links fail.

Enable before children start with enable_node_cache(pinned_source_sha256).
No daemon, shared-filesystem cache, stale fallback, or cache-error suppression.
Private cache files are managed only by this API; removing an active job's
cache/lock files externally is unsupported.
"""
from pathlib import Path
import ctypes
import errno
import fcntl
import hashlib
import json
import math
import os
import re
import stat

DIRECTORY_ENV = "MUB6_SAFETY_CACHE_DIR"
SOURCE_ENV = "MUB6_SAFETY_CACHE_SOURCE_SHA256"
JOB_ENV = "MUB6_SAFETY_CACHE_JOB_ID"
MAX_KEYS = 64
MAX_BYTES = 8 * 1024 * 1024
MAX_REGISTRY_BYTES = 16384
MAX_NAMES = 4096
MAX_NAME_BYTES = 1024
MAX_TTL = 0.25
SCHEMA = "node-safety-membership-v1"


class CacheSecurityError(RuntimeError):
    pass


class CacheBoundError(ValueError):
    pass


def _canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def _absolute(path):
    return Path(os.path.abspath(os.fspath(path)))


def _scope(source_sha256, job_id):
    if not isinstance(source_sha256, str) or re.fullmatch(r"[0-9a-f]{64}", source_sha256) is None:
        raise ValueError("Node safety cache requires the exact pinned source SHA-256")
    job_id = os.environ.get("SLURM_JOB_ID") if job_id is None else str(job_id)
    if not isinstance(job_id, str) or re.fullmatch(r"[0-9]{1,16}", job_id) is None:
        raise ValueError("Node safety cache requires an exact numeric Slurm job id")
    actual_job = os.environ.get("SLURM_JOB_ID")
    if actual_job is not None and actual_job != job_id:
        raise ValueError("Node safety cache belongs to another Slurm job")
    return source_sha256, job_id


def _temp_root():
    system = os.uname().sysname
    if system == "Linux":
        return Path("/tmp")
    if system == "Darwin":
        return Path("/private/tmp")
    raise CacheSecurityError("Unsupported node-local safety cache platform")


def _boot_identity():
    if os.uname().sysname == "Linux":
        with open("/proc/sys/kernel/random/boot_id", "rb") as stream:
            value = stream.read(128).decode("ascii").strip()
        if re.fullmatch(r"[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}", value) is None:
            raise CacheSecurityError("Invalid Linux boot identity")
        return value
    if os.uname().sysname == "Darwin":
        libc = ctypes.CDLL(None, use_errno=True)
        value = (ctypes.c_long * 2)()
        size = ctypes.c_size_t(ctypes.sizeof(value))
        call = libc.sysctlbyname
        call.argtypes = [ctypes.c_char_p, ctypes.c_void_p, ctypes.POINTER(ctypes.c_size_t), ctypes.c_void_p, ctypes.c_size_t]
        call.restype = ctypes.c_int
        if call(b"kern.boottime", value, ctypes.byref(size), None, 0) != 0:
            code = ctypes.get_errno()
            raise OSError(code, os.strerror(code))
        if size.value != ctypes.sizeof(value) or value[0] <= 0 or not 0 <= value[1] < 1000000:
            raise CacheSecurityError("Invalid Darwin boot identity")
        return "darwin:" + os.uname().nodename + ":" + str(value[0]) + ":" + str(value[1])
    raise CacheSecurityError("Unsupported boot identity")


def _require_local_filesystem(descriptor):
    # fstatfs's first word is the Linux filesystem magic. Darwin's documented
    # statfs64 layout puts its 16-byte f_fstypename at byte 72. Oversized buffers
    # avoid relying on the rest of either system structure.
    libc = ctypes.CDLL(None, use_errno=True)
    buffer = ctypes.create_string_buffer(4096)
    system = os.uname().sysname
    if system == "Darwin":
        # Intel Darwin exports the INODE64 alias; modern ARM64 has only the
        # plain symbol, whose sole ABI is the same statfs64 structure.
        try:
            call = getattr(libc, "fstatfs$INODE64")
        except AttributeError:
            call = libc.fstatfs
    else:
        call = libc.fstatfs
    call.argtypes = [ctypes.c_int, ctypes.c_void_p]
    call.restype = ctypes.c_int
    if call(descriptor, buffer) != 0:
        code = ctypes.get_errno()
        raise OSError(code, os.strerror(code))
    if system == "Linux":
        magic = ctypes.c_long.from_buffer(buffer).value & 0xffffffff
        # ext[234], XFS, tmpfs, btrfs, ramfs, overlay. Ceph/FUSE/NFS are excluded.
        local = magic in (0xef53, 0x58465342, 0x01021994, 0x9123683e, 0x858458f6, 0x794c7630)
    else:
        local = buffer.raw[72:88].split(b"\0", 1)[0] in (b"apfs", b"hfs", b"tmpfs")
    if not local:
        raise CacheSecurityError("Safety cache filesystem is not an approved node-local filesystem")


def _private(stat_result, directory=False, detached_snapshot=False):
    valid_type = stat.S_ISDIR(stat_result.st_mode) if directory else stat.S_ISREG(stat_result.st_mode)
    if not valid_type or stat_result.st_uid != os.getuid() or stat_result.st_mode & 0o077:
        raise CacheSecurityError("Safety cache object must be owned, private, and of the expected type")
    links = (0, 1) if detached_snapshot else (1,)
    if not directory and stat_result.st_nlink not in links:
        raise CacheSecurityError("Safety cache files must not have hard links")


def _open_cache_directory(path, source_sha256, job_id, create=False):
    expected = _temp_root() / ("mub6-safety-" + str(os.getuid())) / (source_sha256 + "-" + job_id)
    path = Path(os.fspath(path))
    if not path.is_absolute() or path != expected or ".." in path.parts:
        raise CacheSecurityError("Safety cache path differs from its exact node-local namespace")
    flags = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | getattr(os, "O_CLOEXEC", 0)
    current = os.open("/", flags)
    try:
        for index, name in enumerate(path.parts[1:]):
            private = index >= len(_temp_root().parts) - 1
            if private and create:
                try:
                    os.mkdir(name, 0o700, dir_fd=current)
                except FileExistsError:
                    pass
            following = os.open(name, flags, dir_fd=current)
            try:
                info = os.fstat(following)
                if private:
                    _private(info, directory=True)
                elif info.st_uid not in (0, os.getuid()) or (info.st_mode & 0o022 and not info.st_mode & stat.S_ISVTX):
                    raise CacheSecurityError("Unsafe node-local safety cache ancestor")
            except BaseException:
                os.close(following)
                raise
            os.close(current)
            current = following
        _require_local_filesystem(current)
        return current
    except BaseException:
        os.close(current)
        raise


def prepare_node_cache(source_sha256, job_id=None):
    """Create/verify the exact owned mode-0700 node-local job namespace."""
    source_sha256, job_id = _scope(source_sha256, job_id)
    path = _temp_root() / ("mub6-safety-" + str(os.getuid())) / (source_sha256 + "-" + job_id)
    descriptor = _open_cache_directory(path, source_sha256, job_id, create=True)
    try:
        flags = os.O_RDWR | os.O_NOFOLLOW | os.O_NONBLOCK | getattr(os, "O_CLOEXEC", 0)
        try:
            lock = os.open("REGISTRY.lock", flags | os.O_CREAT | os.O_EXCL, 0o600, dir_fd=descriptor)
        except FileExistsError:
            lock = os.open("REGISTRY.lock", flags, dir_fd=descriptor)
        try:
            _private(os.fstat(lock))
            os.fsync(descriptor)
        finally:
            os.close(lock)
    finally:
        os.close(descriptor)
    return path


def enable_node_cache(source_sha256, job_id=None):
    """Enable lazy SafetyPaths cache attachment before child processes start."""
    source_sha256, job_id = _scope(source_sha256, job_id)
    path = prepare_node_cache(source_sha256, job_id)
    os.environ.update({DIRECTORY_ENV: str(path), SOURCE_ENV: source_sha256, JOB_ENV: job_id})
    return path


def environment_config():
    values = tuple(os.environ.get(name) for name in (DIRECTORY_ENV, SOURCE_ENV, JOB_ENV))
    if not any(value is not None for value in values):
        return None
    if any(value is None for value in values):
        raise ValueError("Incomplete node-local safety cache configuration")
    _scope(values[1], values[2])
    return values


class NodeDirectoryCache:
    def __init__(self, path, source_sha256, job_id, source_directory):
        source_sha256, job_id = _scope(source_sha256, job_id)
        self.config = (str(path), source_sha256, job_id)
        self.identity = {"schema": SCHEMA, "uid": os.getuid(), "boot": _boot_identity(),
                         "source_sha256": source_sha256, "job_id": job_id,
                         "source_directory": str(_absolute(source_directory)),
                         "implementation_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
        self.descriptor = _open_cache_directory(path, source_sha256, job_id)
        self.keys = {}
        self.stats = {"shared_hits": 0, "refreshes": 0, "slow_refreshes": 0, "lock_waits": 0}

    @classmethod
    def from_environment(cls, source_directory):
        config = environment_config()
        return None if config is None else cls(*config, source_directory)

    def close(self):
        if self.descriptor is not None:
            os.close(self.descriptor)
            self.descriptor = None

    def _file(self, name, create=False, writable=False, detached_snapshot=False):
        if detached_snapshot and (create or writable or not isinstance(name, str) or
                                  re.fullmatch(r"[0-9a-f]{64}\.json", name) is None):
            raise CacheSecurityError("Detached cache inodes are allowed only for read-only keyed snapshots")
        flags = os.O_RDWR if create or writable else os.O_RDONLY
        flags |= os.O_NOFOLLOW | os.O_NONBLOCK | getattr(os, "O_CLOEXEC", 0)
        try:
            if create:
                try:
                    # Plain concurrent O_CREAT can return ENOENT on a live
                    # APFS directory. Exclusive first creation has an atomic
                    # winner; only EEXIST permits opening the existing file.
                    descriptor = os.open(name, flags | os.O_CREAT | os.O_EXCL, 0o600, dir_fd=self.descriptor)
                except FileExistsError:
                    descriptor = os.open(name, flags, dir_fd=self.descriptor)
            else:
                descriptor = os.open(name, flags, dir_fd=self.descriptor)
        except FileNotFoundError:
            if create:
                raise
            return None
        try:
            _private(os.fstat(descriptor), detached_snapshot=detached_snapshot)
            return descriptor
        except BaseException:
            os.close(descriptor)
            raise

    def _read(self, name, maximum=MAX_BYTES, detached_snapshot=False):
        descriptor = self._file(name, detached_snapshot=detached_snapshot)
        if descriptor is None:
            return None
        try:
            info = os.fstat(descriptor)
            _private(info, detached_snapshot=detached_snapshot)
            if info.st_size > maximum:
                raise CacheBoundError("Safety cache file exceeds its byte bound")
            with os.fdopen(descriptor, "rb", closefd=False) as stream:
                raw = stream.read(maximum + 1)
            if len(raw) > maximum:
                raise CacheBoundError("Safety cache file exceeds its byte bound")
            return json.loads(raw)
        finally:
            os.close(descriptor)

    def _write(self, name, value, maximum=MAX_BYTES):
        raw = _canonical(value)
        if len(raw) > maximum:
            raise CacheBoundError("Safety cache publication exceeds its byte bound")
        temporary = name + ".pending"
        descriptor = self._file(temporary, create=True)
        try:
            os.ftruncate(descriptor, 0)
            with os.fdopen(descriptor, "wb", closefd=False) as stream:
                stream.write(raw)
                stream.flush()
                os.fsync(descriptor)
        finally:
            os.close(descriptor)
        os.replace(temporary, name, src_dir_fd=self.descriptor, dst_dir_fd=self.descriptor)
        os.fsync(self.descriptor)

    def _key(self, directory):
        directory = str(_absolute(directory))
        identity = dict(self.identity, directory=directory)
        key = hashlib.sha256(_canonical(identity)).hexdigest()
        if key in self.keys:
            return key, identity
        if len(self.keys) >= MAX_KEYS:
            raise CacheBoundError("Safety cache exceeds 64 directory keys")
        lock = self._file("REGISTRY.lock", writable=True)
        if lock is None:
            raise CacheSecurityError("Prepared safety cache registry lock is missing")
        try:
            fcntl.flock(lock, fcntl.LOCK_EX)
            registry = self._read("REGISTRY.json", MAX_REGISTRY_BYTES)
            if registry is None:
                registry = {"schema": SCHEMA, "keys": []}
            if registry.get("schema") != SCHEMA or not isinstance(registry.get("keys"), list) or len(registry["keys"]) > MAX_KEYS:
                raise CacheSecurityError("Invalid bounded safety cache registry")
            if len(set(registry["keys"])) != len(registry["keys"]) or any(not isinstance(k, str) or re.fullmatch(r"[0-9a-f]{64}", k) is None for k in registry["keys"]):
                raise CacheSecurityError("Invalid safety cache registry keys")
            if key not in registry["keys"]:
                if len(registry["keys"]) >= MAX_KEYS:
                    raise CacheBoundError("Safety cache exceeds 64 shared directory keys")
                registry["keys"].append(key)
                self._write("REGISTRY.json", registry, MAX_REGISTRY_BYTES)
            self.keys[key] = identity
            return key, identity
        finally:
            os.close(lock)

    @staticmethod
    def _names(value):
        if not isinstance(value, list) or len(value) > MAX_NAMES:
            raise CacheSecurityError("Invalid safety cache directory membership")
        if any(not isinstance(name, str) or not name or name in (".", "..") or "/" in name or "\0" in name or len(os.fsencode(name)) > MAX_NAME_BYTES for name in value):
            raise CacheSecurityError("Invalid safety cache directory entry")
        if len(set(value)) != len(value):
            raise CacheSecurityError("Duplicate safety cache directory entry")
        return frozenset(value)

    def _fresh(self, key, identity, clock, ttl, revalidate_error=False):
        # Publication replaces immutable snapshots atomically. A reader that
        # opened the old inode may see nlink=0; its contents and original final
        # freshness check remain valid. No lock or mutable file gets this opt-in.
        value = self._read(key + ".json", detached_snapshot=True)
        if value is None:
            return None
        if not isinstance(value, dict) or value.get("identity") != identity:
            raise CacheSecurityError("Safety cache snapshot identity differs")
        if value.get("status") == "error":
            error = value.get("error")
            if not isinstance(error, dict) or not isinstance(error.get("message"), str) or len(error["message"]) > 2048:
                raise CacheSecurityError("Invalid shared safety cache error")
            code = error.get("errno")
            if code is not None and type(code) is not int:
                raise CacheSecurityError("Invalid shared safety cache errno")
            # Ordinary readers retain the error. An explicit synchronous
            # fresh scan may replace it only after successful revalidation.
            if revalidate_error:
                return None
            if code is not None:
                raise OSError(code, "Shared guard-directory scan failed: " + error["message"])
            raise CacheSecurityError("Shared guard-directory scan failed: " + error["message"])
        if value.get("status") != "complete":
            raise CacheSecurityError("Incomplete safety cache snapshot")
        began, deadline = value.get("scan_start"), value.get("deadline")
        if any(isinstance(x, bool) or not isinstance(x, (float, int)) or not math.isfinite(x) for x in (began, deadline)):
            raise CacheSecurityError("Invalid safety cache timestamps")
        if began < 0 or not began <= deadline <= began + MAX_TTL:
            raise CacheSecurityError("Future or invalid safety cache freshness")
        names = self._names(value.get("names"))
        now = clock()
        if now < began:
            raise CacheSecurityError("Future or invalid safety cache freshness")
        deadline = min(deadline, began + ttl)
        return (names, deadline) if now < deadline else None

    def entries(self, directory, scan, clock, ttl, fresh=False):
        key, identity = self._key(directory)
        lock = self._file(key + ".lock", create=True)
        try:
            value = self._fresh(key, identity, clock, ttl, revalidate_error=fresh)
            if not fresh and value is not None:
                self.stats["shared_hits"] += 1
                return value
            try:
                fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:
                self.stats["lock_waits"] += 1
                fcntl.flock(lock, fcntl.LOCK_EX)
            value = self._fresh(key, identity, clock, ttl, revalidate_error=fresh)
            if not fresh and value is not None:
                self.stats["shared_hits"] += 1
                return value
            # Never expose an old negative after a failed forced refresh or a
            # dead scanner. Only the completed atomic replacement is reusable.
            previous = self._file(key + ".json")
            if previous is not None:
                os.close(previous)
                os.unlink(key + ".json", dir_fd=self.descriptor)
            began = clock()
            self.stats["refreshes"] += 1
            try:
                names = scan()
                self._names(sorted(names))
            except Exception as error:
                self._write(key + ".json", {"identity": identity, "status": "error",
                            "error": {"errno": error.errno if isinstance(error, OSError) else None,
                                      "message": str(error)[:2048]}})
                raise
            deadline = began + ttl
            self._write(key + ".json", {"identity": identity, "status": "complete",
                        "scan_start": began, "deadline": deadline, "names": sorted(names)})
            if clock() >= deadline:
                self.stats["slow_refreshes"] += 1
            # The scanning process consumes its own synchronous result even if
            # slow, exactly as uncached SafetyPaths does. Other readers cannot.
            return frozenset(names), deadline
        finally:
            os.close(lock)
