"""Isolated comparison of the complete-residual handoff on saved geometries.

This does not register a production method, edit a deployed engine, import a
stored PASS, or close an original root. The archive is pinned and only native
source dependencies are extracted into a separate benchmark cache. Optional
ablations remove domain constraints in separately hashed translation units.
Accepted benchmark leaves are recomputed by a second, independent process pool.
All results remain conditional numerical research, with zero Lean admissions.
"""
from __future__ import annotations

from concurrent.futures import ProcessPoolExecutor, wait, FIRST_COMPLETED
from fractions import Fraction as Q
from functools import lru_cache
from multiprocessing import get_context
from pathlib import Path, PurePosixPath
from zipfile import ZipFile
import argparse
import collections
import ctypes
import fcntl
import hashlib
import importlib.util
import json
import math
import os
import resource
import subprocess
import sys
import time

ARCHIVE_SHA256 = "f0274d7280d1fef3f28e8edaf2ba57091dfb8daa390b1167b04cc07e921c3466"
PREFIX = "ProvenResults/Patch2442Local/"
NATIVE = "constraint_engine.cpp"
DEPENDENCIES = (
    "inputs/repo/ProvenResults/SignedCornerPSDPrune/engine.cpp",
    "inputs/repo/ProvenResults/SignedCornerPSDPrune/determinant_terms.hpp",
    "inputs/repo/ProvenResults/Patch2442Region_v3/taylor.hpp")
HANDOFF_METHODS = ("handoff_full4", "handoff_no_j4", "handoff_plain4")
SCHEMA = "handoff-comparison-leaf-v1"
BASE = None
ADAPTER = None


def canonical(obj):
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def digest(obj):
    return hashlib.sha256(canonical(obj)).hexdigest()


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda:stream.read(2**20),b""):
            h.update(block)
    return h.hexdigest()


def write(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp = path.with_name(path.name+"."+str(os.getpid())+".tmp")
    try:
        with tmp.open("wb") as stream:
            stream.write(canonical(value)+b"\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(tmp,path)
    finally:
        tmp.unlink(missing_ok=True)


def archive_sources(archive, root):
    """Read/hash the reviewed ZIP directly; never extract archive paths blindly."""
    archive, root = Path(archive),Path(root)
    if sha(archive)!=ARCHIVE_SHA256:
        raise ValueError("Handoff archive differs from the reviewed version")
    with ZipFile(archive) as source:
        infos = source.infolist()
        if len({info.filename for info in infos})!=len(infos) or sum(info.file_size for info in infos)>32*2**20:
            raise ValueError("Duplicate/oversized ZIP payload")
        manifest_raw = source.read(PREFIX+"MANIFEST.sha256")
        expected = {}
        for line in manifest_raw.decode().splitlines():
            checksum,name = line.split(maxsplit=1)
            name = name.strip()
            parts = PurePosixPath(name)
            if parts.is_absolute() or ".." in parts.parts or name in expected or len(checksum)!=64:
                raise ValueError("Malformed archive manifest")
            raw = source.read(PREFIX+name)
            if len(raw)>8*2**20 or hashlib.sha256(raw).hexdigest()!=checksum:
                raise ValueError("Archive manifest mismatch: "+name)
            expected[name] = checksum
        payload = {name:source.read(PREFIX+name) for name in (NATIVE,*DEPENDENCIES)}
        # Hold the arithmetic implementation fixed in this comparison.
        shared = {}
        for name in DEPENDENCIES:
            current = root / "engine/upstream" / name.removeprefix("inputs/repo/")
            shared[name] = sha(current)==expected[name]
            if not shared[name]:
                raise ValueError("Shared baseline arithmetic source differs: "+name)
    return payload,{"archive_sha256":ARCHIVE_SHA256,
                    "archive_manifest_sha256":hashlib.sha256(manifest_raw).hexdigest(),
                    "verified_manifest_files":len(expected),"source_sha256":expected,
                    "shared_arithmetic_identical":shared,"physical_lean_admissions":0}


@lru_cache(maxsize=1)
def pi_bounds():
    def atan(q):
        s = sum((Q((-1)**k,(2*k+1)*q**(2*k+1)) for k in range(64)),Q(0))
        rem = Q(1,129*q**129)
        return s,s+rem
    a,b = atan(5)
    c,d = atan(239)
    return 16*a-4*d,16*b-4*c


def membership(centers, radii):
    """The archive's exact closed-box, punctured 3/50 admission filter."""
    pi = pi_bounds()
    midpoint = sum(pi)/2
    radius = Q(3,50)
    for sign,label in ((1,"2442"),(-1,"4224")):
        offsets,lifts = [],[]
        for center,r,base in zip(centers,radii,(Q(2,3),-Q(2,3),-Q(2,3),Q(2,3))):
            a = base*sign
            guess = (center/midpoint-a)/2+Q(1,2)
            k0 = guess.numerator//guess.denominator
            found = None
            for k in (k0,k0-1,k0+1):
                lo,hi = sorted(((a+2*k)*pi[0],(a+2*k)*pi[1]))
                dl,du = center-r-hi,center+r-lo
                if -radius<=dl and du<=radius:
                    found = (k,dl,du)
                    break
            if found is None:
                break
            k,dl,du = found
            lifts.append(k)
            offsets.append((dl,du))
        else:
            if any(lo>0 or hi<0 for lo,hi in offsets):
                return {"ok":True,"seed":label,"radius_filter":"3/50","lifts":lifts,
                        "offset_intervals":[list(map(str,pair)) for pair in offsets]}
    return {"ok":False,"reason":"outside_filter_or_seed_touching_or_boundary_unresolved","radius_filter":"3/50"}


def _variant(source, method):
    text = source.decode()
    if method=="handoff_full4":
        return source,"unchanged_archive"
    if method=="handoff_no_j4":
        needle = "use_J=output[52]<1;output[53]=use_J?1:0;"
        if text.count(needle)!=1:
            raise ValueError("J-ablation injection point changed")
        return text.replace(needle,"use_J=false;output[53]=0;").encode(),"disable_J_domain_shifting_only"
    if method=="handoff_plain4":
        needle = "static I domain_bound(const T&f){"
        if text.count(needle)!=1:
            raise ValueError("Domain-ablation injection point changed")
        return text.replace(needle,needle+"\n return plain_bound(f); // isolated benchmark ablation\n").encode(),"disable_all_domain_shifting"
    raise ValueError("Unknown handoff variant")


class Adapter:
    def __init__(self, root, archive, cache, methods, phase_wrapper):
        self.root,self.cache = Path(root).resolve(),Path(cache).resolve()
        if any(self.cache==self.root/p or self.root/p in self.cache.parents for p in ("engine","production","elastic-run")):
            raise ValueError("Handoff cache must be separate from frozen production assets")
        self.phase_wrapper = phase_wrapper
        payload,self.archive_manifest = archive_sources(archive,self.root)
        self.libs,self.pins = {},{}
        for method in methods:
            directory = self.cache / method
            directory.mkdir(parents=True,exist_ok=True)
            unit,recipe = _variant(payload[NATIVE],method)
            with (directory / "BUILD.lock").open("a") as lock:
                fcntl.flock(lock,fcntl.LOCK_EX)
                for name,raw in {**payload,NATIVE:unit}.items():
                    target = directory / name
                    if target.exists():
                        if target.read_bytes()!=raw:
                            raise ValueError("Extracted pinned handoff source changed")
                    else:
                        target.parent.mkdir(parents=True,exist_ok=True)
                        target.write_bytes(raw)
                pins = {"archive_sha256":ARCHIVE_SHA256,"adapter_sha256":sha(__file__),
                        "phase_reference_driver_sha256":sha(BASE._STATE["c"].__file__),
                        "translation_unit_sha256":hashlib.sha256(unit).hexdigest(),
                        "archive_core_sha256":self.archive_manifest["source_sha256"]["constraint_core.py"],
                        "archive_geometry_sha256":self.archive_manifest["source_sha256"]["local_core.py"],
                        "shared_arithmetic_sha256":digest({name:self.archive_manifest["source_sha256"][name] for name in DEPENDENCIES})}
                binary = directory / "constraint_order4.so"
                receipt_path = directory / "BUILD.json"
                if not binary.exists():
                    tmp = binary.with_name(binary.name+"."+str(os.getpid())+".tmp.so")
                    command = ["c++","-O3","-DTM_ORDER=4","-std=c++17","-fno-fast-math","-ffp-contract=off",
                               "-fPIC","-shared",str(directory/NATIVE),"-o",str(tmp)]
                    try:
                        subprocess.run(command,check=True,capture_output=True,text=True,timeout=60)
                        receipt = {"pins":pins,"binary_sha256":sha(tmp),"command":command,"recipe":recipe,
                                   "compiler":subprocess.check_output(["c++","--version"],text=True).splitlines()[0]}
                        os.replace(tmp,binary)
                        write(receipt_path,receipt)
                    finally:
                        tmp.unlink(missing_ok=True)
                receipt = json.loads(receipt_path.read_text())
                if receipt["pins"]!=pins or receipt["binary_sha256"]!=sha(binary) or receipt["recipe"]!=recipe:
                    raise ValueError("Handoff build receipt mismatch")
            library = ctypes.CDLL(str(binary))
            dp = ctypes.POINTER(ctypes.c_double)
            library.local_region.argtypes = [dp,dp]
            library.local_region.restype = ctypes.c_int
            library.local_coefficients.argtypes = [dp,dp]
            library.local_coefficients.restype = ctypes.c_int
            library.set_budget.argtypes = [ctypes.c_double]
            library.set_budget.restype = None
            self.libs[method] = library
            self.pins[method] = dict(pins,binary_sha256=receipt["binary_sha256"],
                                     compiler_sha256=digest(receipt["compiler"]),
                                     phase_wrapper_sha256=digest(phase_wrapper))

    def _data(self, centers, radii):
        c = BASE._STATE["c"]
        if self.phase_wrapper=="shared_rational80":
            return sum((c.phase(q) for q in centers),[])+[c.up(r) for r in radii]
        import mpmath
        from mpmath import iv
        if mpmath.__version__!="1.3.0":
            raise ValueError("Archive phase wrapper requires mpmath1.3.0")
        prior = iv.prec
        iv.prec = 192
        try:
            def value(q):
                return iv.mpf(q.numerator)/q.denominator
            def bounds(x):
                lo,hi = math.nextafter(float(x.a),-math.inf),math.nextafter(float(x.b),math.inf)
                if not (math.isfinite(lo) and math.isfinite(hi) and iv.mpf(lo)<=x.a and iv.mpf(hi)>=x.b):
                    raise ArithmeticError("Handoff outward phase conversion failed")
                return [lo,hi]
            data = []
            for q in centers:
                data.extend(bounds(iv.cos(value(q))))
                data.extend(bounds(iv.sin(value(q))))
            return data+[bounds(value(r))[1] for r in radii]
        finally:
            iv.prec = prior

    @staticmethod
    def _decode(status, out):
        def check(test,message):
            if not test:
                raise ArithmeticError(message)
        def interval(k):
            check(out[k]<=out[k+1],"Reversed native handoff interval")
            return out[k],out[k+1]
        def integer(k,values):
            check(out[k] in values,"Invalid handoff discrete witness")
            return int(out[k])
        check(all(math.isfinite(x) for x in out),"Nonfinite handoff witness")
        interval(0)
        guard = integer(53,(0,1))
        check(not guard or out[52]<1,"Invalid J-domain guard")
        if status==0:
            return "unresolved"
        if status==1:
            check(out[1]<=0,"Invalid nonpositive-R witness")
            return "R_nonpositive"
        if status in (2,4):
            check(out[1]<243,"Missing non-Tao matching guard")
            integer(2,range(3));integer(3,range(3))
        if status==2:
            integer(4,(-1,1));integer(5,(-1,1))
            for k in (6,8,10):
                interval(k);check(out[k]>0,"Invalid coherent-product margin")
            return "coherent_product"
        if status==3:
            hm,vm = integer(2,range(4)),integer(3,range(4))
            check(hm==3 or vm==3 or (out[1]<243 and ((hm&1) or (vm&2)) and ((hm&2) or (vm&1))),"Incomplete sign cover")
            for mask,offset in ((hm,16),(vm,34)):
                for sg in range(2):
                    if not mask&(1<<sg):
                        continue
                    k = offset+sg*9
                    integer(k,range(3));integer(k+1,(-1,1));kind=integer(k+2,(1,2,3))
                    a,b,margin = interval(k+3),interval(k+5),interval(k+7)
                    check((kind==1 and a[0]>=0 and b[0]>=0 and (a[0]>0 or b[0]>0))
                          or (kind==2 and a[0]>0 and margin[0]>0)
                          or (kind==3 and b[0]>0 and margin[0]>0),"Invalid linear-sign margin")
            return "linear_sign_cover"
        if status==4:
            branch = integer(4,(0,1))
            if branch==0:
                h,rhs = interval(5),interval(7)
                check(rhs[0]>=0 and (h[0]>rhs[1] or -h[1]>rhs[1]),"Invalid A-elimination bound")
            else:
                for k in (5,6,7):
                    integer(k,(-1,1))
                interval(8);check(out[8]>0,"Invalid constrained A-elimination gap")
            return "A_elimination"
        if status==5:
            interval(2);check(out[3]<0,"Invalid complementary-corner witness")
            return "complementary_corner"
        raise ArithmeticError("Unknown handoff native status "+str(status))

    def _native(self, centers, radii, method, deadline):
        data = self._data(centers,radii)
        remaining = deadline-time.process_time()
        if remaining<=0:
            raise BASE.CpuBudget("cpu_budget")
        lib = self.libs[method]
        lib.set_budget(remaining)
        out = (ctypes.c_double*64)()
        status = lib.local_region((ctypes.c_double*20)(*data),out)
        if status==-2:
            raise BASE.CpuBudget("native_cpu_budget")
        if status<0:
            raise ArithmeticError("Handoff native arithmetic/hardware status "+str(status))
        values = list(out)
        reason = self._decode(status,values)
        return {"ok":status>0,"reason":reason,"native_status":status,
                "domain_p_upper":str(Q(values[52])),"J_guard":bool(values[53]),
                "phase_input_hex":[x.hex() for x in data],"output_hex":[x.hex() for x in values],
                "axis":max(range(4),key=lambda k:(values[12+k],radii[k]))}

    def evaluate(self, centers, radii, method, cpu_seconds):
        cc,rr = BASE._validate_box(centers,radii)
        if method not in self.libs or not math.isfinite(cpu_seconds) or not 0<cpu_seconds<=600:
            raise ValueError("Unknown handoff method or invalid CPU budget")
        BASE._STATE["c"].guard()
        began = time.process_time()
        admitted = {}
        witness = {}
        try:
            with BASE._cpu_limit(cpu_seconds):
                admitted = membership(cc,rr)
                if not admitted["ok"]:
                    verdict = {"ok":False,"reason":"admission_filter_refused"}
                else:
                    witness = self._native(cc,rr,method,began+cpu_seconds)
                    verdict = witness
                if time.process_time()-began>cpu_seconds:
                    raise BASE.CpuBudget("cpu_budget")
        except BASE.CpuBudget as error:
            verdict = {"ok":False,"reason":str(error)}
            witness = {}
        BASE._STATE["c"].guard()
        result = {"schema":SCHEMA,"ok":verdict["ok"],"reason":verdict["reason"],"method":method,
                  "input":{"centers":list(map(str,cc)),"radii":list(map(str,rr)),"units":"radians"},
                  "membership":admitted,"witness":witness,"provider_hashes":self.pins[method],
                  "phase_wrapper":self.phase_wrapper,"cpu_seconds":time.process_time()-began,
                  "scope":"experimental whole-leaf strict-D0 comparison only","physical_lean_admissions":0}
        result["evidence_sha256"] = digest({k:v for k,v in result.items() if k!="cpu_seconds"})
        return result

    def replay(self, record, cpu_seconds=30):
        if record.get("schema")!=SCHEMA or record.get("ok") is not True:
            raise ValueError("Not an accepted handoff benchmark leaf")
        old = {k:v for k,v in record.items() if k not in ("evidence_sha256","cpu_seconds")}
        if digest(old)!=record["evidence_sha256"]:
            raise ValueError("Handoff benchmark evidence changed")
        fresh = self.evaluate(list(map(Q,record["input"]["centers"])),list(map(Q,record["input"]["radii"])),record["method"],cpu_seconds)
        if not fresh["ok"]:
            return {"ok":False,"status":"UNRESOLVED","reason":fresh["reason"],"physical_lean_admissions":0}
        for field in ("input","membership","witness","reason","phase_wrapper"):
            if fresh[field]!=record[field]:
                raise ValueError("Fresh handoff witness differs: "+field)
        strip_binary = lambda pins:{k:v for k,v in pins.items() if k!="binary_sha256"}
        if strip_binary(fresh["provider_hashes"])!=strip_binary(record["provider_hashes"]):
            raise ValueError("Handoff replay source/compiler pins differ")
        return {"ok":True,"status":"PASS","method":record["method"],"evidence_sha256":record["evidence_sha256"],
                "search_binary_sha256":record["provider_hashes"]["binary_sha256"],
                "replay_binary_sha256":fresh["provider_hashes"]["binary_sha256"],"cpu_seconds":fresh["cpu_seconds"],
                "physical_lean_admissions":0}


def initialize(root, baseline_source, archive, cache, methods, phase_wrapper):
    global BASE,ADAPTER
    if sys.platform=="linux":
        soft,hard=resource.getrlimit(resource.RLIMIT_AS)
        cap=768*2**20
        for limit in (soft,hard):
            if limit!=resource.RLIM_INFINITY:
                cap=min(cap,limit)
        resource.setrlimit(resource.RLIMIT_AS,(cap,cap))
    spec = importlib.util.spec_from_file_location("handoff_baseline_engines",Path(baseline_source)/"engines.py")
    BASE = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(BASE)
    manifest = BASE.initialize(Path(root),Path(cache)/"baseline")
    ADAPTER = Adapter(root,archive,Path(cache)/"handoff",[m for m in methods if m in HANDOFF_METHODS],phase_wrapper)
    return {"baseline":manifest,"handoff_provider_hashes":ADAPTER.pins,"archive":ADAPTER.archive_manifest,
            "phase_wrapper":phase_wrapper,"physical_lean_admissions":0}


def trial(task):
    case,method,seconds = task
    began=time.process_time()
    provider = ADAPTER if method in HANDOFF_METHODS else BASE
    result = provider.evaluate(list(map(Q,case["centers"])),list(map(Q,case["radii"])),method,seconds)
    return {"case_id":case["case_id"],"root_id":case["root_id"],"kind":case["kind"],
            "radius_band":case["radius_band"],"method":method,"result":result,
            "cpu_seconds":time.process_time()-began,"physical_lean_admissions":0}


def replay_trial(record):
    provider = ADAPTER if record["method"] in HANDOFF_METHODS else BASE
    began=time.process_time()
    fresh = provider.replay(record["result"],cpu_seconds=30)
    if fresh.get("ok") is not True:
        raise ValueError("Independent benchmark replay failed: "+record["case_id"]+" "+record["method"])
    return dict(record,replay=fresh,replay_cpu_seconds=time.process_time()-began)


def controls(root):
    """Exact coefficient checks and genuine physical negative controls."""
    sys.path.insert(0,str(Path(root)/"engine"))
    import controls as reference
    c=BASE._STATE["c"]
    coefficient_checks=0
    negative=[]
    for method,lib in ADAPTER.libs.items():
        for ints in ((-3,2,1,5,2,1,-2,3),(2,1,3,1,4,3,5,2),(1,2,2,3,3,4,4,5)):
            phases=[reference.Z(Q(m*m-n*n,m*m+n*n),Q(2*m*n,m*m+n*n)) for m,n in zip(ints[::2],ints[1::2])]
            raw=sum(([c.down(z.re),c.up(z.re),c.down(z.im),c.up(z.im)] for z in phases),[])+[0.0]*4
            out=(ctypes.c_double*32)()
            with BASE._cpu_limit(30):
                status=lib.local_coefficients((ctypes.c_double*20)(*raw),out)
            if status!=32:
                raise ArithmeticError("Handoff coefficient-control status")
            for tr,perm in enumerate(((0,1,2,3),(0,2,1,3))):
                values=reference.reference([phases[k] for k in perm])
                expected=values[:2]+sum(([values[2+5*j],(values[3+5*j]+values[4+5*j])/2] for j in range(3)),[])
                for k,value in enumerate(expected):
                    lo,hi=out[16*tr+2*k],out[16*tr+2*k+1]
                    if not Q(lo)<=value<=Q(hi):
                        raise ArithmeticError("Handoff missed independent exact point coefficient")
                    coefficient_checks+=1
        pi=pi_bounds();mid=sum(pi)/2
        for delta in (Q(1,100),Q(1,5),Q(1,2)):
            exact=[-2*mid/3,-mid/3+delta,Q(0),-mid+delta]
            for tr,perm in enumerate(((0,1,2,3),(0,2,1,3))):
                cc=[Q(float(exact[k])) for k in perm];rr=[Q(1,2**35)]*4
                if not all(abs(cc[i]-exact[k])+(pi[1]-pi[0])<rr[i] for i,k in enumerate(perm)):
                    raise ValueError("Physical control geometry is not enclosed")
                # Bypass admission to test the accepting circuit itself.
                with BASE._cpu_limit(30):
                    value=ADAPTER._native(cc,rr,method,time.process_time()+30)
                if value["ok"]:
                    raise ArithmeticError("Handoff excluded a known physical strict-D0 corner")
                negative.append({"method":method,"delta":str(delta),"transpose":bool(tr),"excluded":False})
    return {"status":"PASS","exact_coefficients_contained":coefficient_checks,"physical_negative_controls":negative,
            "physical_lean_admissions":0}


def bounded_pool(function, tasks, jobs, initargs):
    tasks=iter(tasks)
    with ProcessPoolExecutor(max_workers=jobs,mp_context=get_context("spawn"),initializer=initialize,initargs=initargs) as pool:
        pending=set()
        exhausted=False
        while pending or not exhausted:
            while not exhausted and len(pending)<2*jobs:
                task=next(tasks,None)
                if task is None:
                    exhausted=True
                    break
                pending.add(pool.submit(function,task))
            if pending:
                done,pending=wait(pending,return_when=FIRST_COMPLETED)
                for future in done:
                    yield future.result()


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--root",type=Path,required=True)
    ap.add_argument("--baseline-source",type=Path,default=Path(__file__).resolve().parent)
    ap.add_argument("--archive",type=Path,required=True)
    ap.add_argument("--input",type=Path)
    ap.add_argument("--output",type=Path)
    ap.add_argument("--cache",type=Path)
    ap.add_argument("--inspect-only",action="store_true")
    ap.add_argument("--jobs",type=int,default=8)
    ap.add_argument("--cpu",type=float,default=3)
    ap.add_argument("--phase-wrapper",choices=("archive_iv192","shared_rational80"),default="archive_iv192")
    ap.add_argument("--methods",nargs="+",default=["order3","order4","order5","paired_psd","normalized_order3","normalized_order4","normalized_order5","handoff_full4"])
    args=ap.parse_args()
    if not __debug__:
        ap.error("Optimized Python is forbidden")
    if args.inspect_only:
        _,report=archive_sources(args.archive,args.root)
        report={k:v for k,v in report.items() if k!="source_sha256"}
        print(json.dumps(report,sort_keys=True))
        return
    if not args.input or not args.output or not args.cache or not 1<=args.jobs<=47 or not 0<args.cpu<=60:
        ap.error("Supply input/output/cache and bounded jobs/CPU")
    if not any(m in HANDOFF_METHODS for m in args.methods) or len(set(args.methods))!=len(args.methods):
        ap.error("Methods need a handoff variant and no duplicates")
    raw=args.input.read_bytes()
    cases=json.loads(raw)["cases"]
    if not 1<=len(cases)<=256 or len({c["case_id"] for c in cases})!=len(cases):
        ap.error("Use a saved comparison set of at most256 unique cases")
    args.output.mkdir(parents=True,exist_ok=False)
    search_args=(args.root,args.baseline_source,args.archive,args.cache/"search",args.methods,args.phase_wrapper)
    manifest=initialize(*search_args)
    if any(m not in HANDOFF_METHODS and m not in BASE.METHODS for m in args.methods):
        ap.error("Unknown baseline comparison method")
    write(args.output/"PROVIDERS.json",manifest)
    write(args.output/"CONTROLS.json",controls(args.root))
    write(args.output/"CONFIG.json",{"input_sha256":hashlib.sha256(raw).hexdigest(),"cases":len(cases),
          "methods":args.methods,"cpu_seconds_per_leaf":args.cpu,"jobs":args.jobs,
          "baseline_source":str(args.baseline_source.resolve()),"physical_lean_admissions":0})
    results=[]
    tasks=((case,method,args.cpu) for case in cases for method in args.methods)
    for value in bounded_pool(trial,tasks,args.jobs,search_args):
        results.append(value)
    # Independent child processes and a separate pinned build cache replay.
    replay_args=(args.root,args.baseline_source,args.archive,args.cache/"replay",args.methods,args.phase_wrapper)
    verified={}
    for value in bounded_pool(replay_trial,(r for r in results if r["result"]["ok"]),args.jobs,replay_args):
        verified[value["case_id"],value["method"]]=value
    results=[verified.get((r["case_id"],r["method"]),r) for r in results]
    summary={}
    by_kind={}
    accepted=collections.defaultdict(set)
    for row in results:
        item=summary.setdefault(row["method"],{"attempted":0,"accepted_replayed":0,"cpu_seconds":0.0,"replay_cpu_seconds":0.0,"reasons":{}})
        item["attempted"]+=1
        ok=row.get("replay",{}).get("ok") is True
        item["accepted_replayed"]+=ok
        item["cpu_seconds"]+=row["cpu_seconds"]
        item["replay_cpu_seconds"]+=row.get("replay_cpu_seconds",0.0)
        reason=row["result"]["reason"]
        item["reasons"][reason]=item["reasons"].get(reason,0)+1
        if ok:
            accepted[row["method"]].add(row["case_id"])
        group=by_kind.setdefault(row["kind"],{}).setdefault(row["method"],
            {"attempted":0,"accepted_replayed":0,"cpu_seconds":0.0,"accepted_case_ids":[]})
        group["attempted"]+=1
        group["accepted_replayed"]+=ok
        group["cpu_seconds"]+=row["cpu_seconds"]
        if ok:
            group["accepted_case_ids"].append(row["case_id"])
    baseline_union=set().union(*(accepted[m] for m in args.methods if m not in HANDOFF_METHODS))
    incremental={m:sorted(accepted[m]-baseline_union) for m in args.methods if m in HANDOFF_METHODS}
    report={"scope":"Same saved whole-leaf geometries only; no original-root closure or physical Lean admission.",
            "summary":summary,"summary_by_kind":by_kind,"additional_cases_over_baseline_union":incremental,
            "input_sha256":hashlib.sha256(raw).hexdigest(),"archive_sha256":ARCHIVE_SHA256,
            "results":sorted(results,key=lambda r:(r["case_id"],r["method"])),"physical_lean_admissions":0}
    write(args.output/"RESULTS.json",report)
    print(json.dumps({"summary":summary,"summary_by_kind":by_kind,"additional_cases_over_baseline_union":incremental},sort_keys=True))


if __name__=="__main__":
    main()
