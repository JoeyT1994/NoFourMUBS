"""Exact geometry and queue controls for the parent-level 1/40 dispatch hold."""
from fractions import Fraction as Q
from pathlib import Path
import gzip
import hashlib
import json
import sqlite3
import tempfile
import unittest

import dispatch_hold as hold
import task_queue as tq
import audit_worker
import benchmark


CAMPAIGN = hold.CONFIG["campaign_scope"]["campaign_sha256"]
ARCHIVE = hold.CONFIG["campaign_scope"]["source_archive_sha256"]


def near_seed(label="2442", offsets=None, extras=None, lifts=None, ident=0):
    offsets = [Q(0)] * 4 if offsets is None else list(map(Q, offsets))
    extras = [Q(1, 1000)] * 4 if extras is None else list(map(Q, extras))
    lifts = [0] * 4 if lifts is None else lifts
    centers, radii = [], []
    for coefficient, offset, extra, lift in zip(hold.SEEDS[label], offsets, extras, lifts):
        lo, hi = hold._alias(coefficient, lift)
        centers.append((lo + hi) / 2 + offset)
        radii.append((hi - lo) / 2 + extra)
    return {"id": ident, "centers": list(map(str, centers)), "radii": list(map(str, radii))}


def source_fixture(root, row, tree="P"):
    root = Path(root)
    raw = tq.canonical(row) + b"\n"
    input_sha = hashlib.sha256(raw).hexdigest()
    (root / "campaign").mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(root / "campaign/full_ring.sqlite")
    db.executescript("CREATE TABLE batches(id INTEGER PRIMARY KEY,first_id INTEGER,n INTEGER,raw_sha TEXT,payload BLOB);"
                     "CREATE TABLE metadata(key TEXT PRIMARY KEY,value TEXT);")
    db.execute("INSERT INTO batches VALUES(0,0,1,?,?)", (input_sha, gzip.compress(raw)))
    db.execute("INSERT INTO metadata VALUES('source_archive_sha256',?)", (json.dumps(ARCHIVE),))
    db.commit()
    db.close()
    tq.durable_json(root / "production/CONFIG.json",
                    {"campaign_sha256": CAMPAIGN, "source_archive_sha256": ARCHIVE})
    record = {"id": row["id"], "input_sha256": tq.digest(row), "tree": tree,
              "stage": 4, "closed": False, "reason": "cpu_budget",
              "search_cpu_seconds": 1.0, "replay_cpu_seconds": 0.0,
              "physical_lean_admissions": 0}
    packet = {"schema": 1, "campaign_sha256": CAMPAIGN, "input_batch_sha256": input_sha,
              "batch": 0, "stage": 4, "closed": 0, "settled_work": 0,
              "count": 1, "physical_lean_admissions": 0, "records": [record]}
    path = root / "production/batches/000/000000.json.gz"
    path.parent.mkdir(parents=True, exist_ok=True)
    with gzip.open(path, "wt") as stream:
        json.dump(packet, stream, separators=(",", ":"))
    tq.durable_json(root / "elastic-run/batches/000/000000/DONE.json",
                    {"batch": 0, "sha256": tq.sha_file(path), "n": 1,
                     "closed": 0, "settled": 0, "owner": "synthetic",
                     "physical_lean_admissions": 0})


class GeometryTests(unittest.TestCase):
    def test_pi_bounds_are_exact_and_nonempty(self):
        lo, hi = hold.pi_bounds()
        self.assertEqual((lo, hi), (hold.PI_LO, hold.PI_HI))
        self.assertLess(lo, hi)
        self.assertLess(Q(314159, 100000), lo)
        self.assertLess(hi, Q(314160, 100000))

    def test_seed_and_small_ball_are_held_with_R_zero_component_separate(self):
        value = hold.classify(near_seed())
        self.assertEqual(value["dispatch"], "HOLD_PARENT_UNRESOLVED")
        theorem = value["reviewed_numerical_theorem"]
        self.assertEqual(theorem["status"], "REVIEWED_NUMERICAL_EVIDENCE_ONLY")
        self.assertTrue(theorem["seed_point_R_zero_separate"])
        self.assertFalse(theorem["whole_box_interface_accepts"])
        relation = next(x for x in value["seed_relations"] if x["seed"] == "2442")
        self.assertTrue(relation["seed_point_guaranteed_in_box"])

    def test_punctured_reviewed_ball_is_recorded_but_never_closed(self):
        row = near_seed(offsets=[Q(1, 200), 0, 0, 0], extras=[Q(1, 2000)] * 4)
        value = hold.classify(row)
        theorem = value["reviewed_numerical_theorem"]
        self.assertEqual(theorem["status"], "REVIEWED_NUMERICAL_EVIDENCE_ONLY")
        self.assertTrue(theorem["whole_box_interface_accepts"])
        self.assertFalse(value["closure_credit"])
        self.assertFalse(value["changes_tree_tokens"])
        self.assertEqual(value["physical_lean_admissions"], 0)

    def test_boundary_faces_and_straddlers_are_held(self):
        boundary = near_seed(offsets=[hold.HOLD_RADIUS, 0, 0, 0], extras=[0] * 4)
        crossing = near_seed(offsets=[hold.HOLD_RADIUS + Q(1, 1000), 0, 0, 0],
                             extras=[Q(2, 1000), Q(1, 1000), Q(1, 1000), Q(1, 1000)])
        self.assertEqual(hold.classify(boundary)["dispatch"], "HOLD_PARENT_UNRESOLVED")
        self.assertEqual(hold.classify(crossing)["dispatch"], "HOLD_PARENT_UNRESOLVED")

    def test_whole_box_strictly_outside_runs_and_every_face_child_stays_outside(self):
        row = near_seed(offsets=[hold.HOLD_RADIUS + Q(1, 100), 0, 0, 0],
                        extras=[Q(1, 1000)] * 4)
        value = hold.classify(row)
        self.assertEqual(value["dispatch"], "RUN_WHOLE_PARENT_STRICTLY_OUTSIDE_HOLD")
        cc, rr = list(map(Q, row["centers"])), list(map(Q, row["radii"]))
        for axis in range(4):
            for bit in "01":
                child_c, child_r = tq.bisect(cc, rr, axis, bit)
                child = {"id": 1, "centers": list(map(str, child_c)), "radii": list(map(str, child_r))}
                self.assertTrue(hold.is_runnable(child))

    def test_both_seeds_and_circular_lift_are_checked(self):
        self.assertEqual(hold.classify(near_seed("4224"))["dispatch"], "HOLD_PARENT_UNRESOLVED")
        coefficient = hold.SEEDS["4224"][0]
        target_lo, target_hi = hold._alias(coefficient, 1)
        metrics = hold._coordinate_metrics(target_lo - Q(1, 1000), target_hi + Q(1, 1000), coefficient)
        self.assertEqual(metrics["lower"], 0)
        # A valid source parent can reach the same wrapped seed through a face.
        wrapped = near_seed("4224")
        wrapped["centers"][0] = "39/10"
        wrapped["radii"][0] = "2/5"
        self.assertEqual(hold.classify(wrapped)["dispatch"], "HOLD_PARENT_UNRESOLVED")

    def test_malformed_float_and_wrong_scope_are_nonadmissible(self):
        row = near_seed()
        row["centers"][0] = 0.0
        with self.assertRaisesRegex(ValueError, "exact rational strings"):
            hold.classify(row)
        row = near_seed()
        row["radii"][0] = "0"
        with self.assertRaisesRegex(ValueError, "frozen ring source domain"):
            hold.classify(row)

    def test_saved_benchmark_rows_are_filtered_before_any_provider(self):
        inside = dict(near_seed(), case_id="inside-parent", root_id=1, kind="parent", prefix="")
        inherited = dict(near_seed(offsets=[hold.HOLD_RADIUS + Q(1, 100), 0, 0, 0],
                                   extras=[Q(1, 1000)] * 4),
                         case_id="outside-child-of-held-parent", root_id=1, kind="frontier", prefix="0")
        outside = dict(near_seed(offsets=[hold.HOLD_RADIUS + Q(1, 100), 0, 0, 0],
                                 extras=[Q(1, 1000)] * 4),
                       case_id="outside", root_id=2, kind="parent", prefix="")
        malformed = {"case_id": "malformed", "root_id": 3, "kind": "parent", "prefix": "",
                     "centers": [0.0] * 4, "radii": ["1/10"] * 4}
        runnable, ledger = benchmark.dispatch_partition([inside, inherited, outside, malformed])
        self.assertEqual([row["case_id"] for row in runnable], ["outside"])
        self.assertEqual((ledger["input_cases"], ledger["runnable_whole_boxes"],
                          ledger["held_without_evaluation"]), (4, 1, 3))
        self.assertTrue(ledger["parent_level_inheritance"])
        self.assertFalse(ledger["closure_credit"])


class QueueIntegrationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="mub6-dispatch-hold-")
        self.addCleanup(self.temp.cleanup)
        self.base = Path(self.temp.name)

    def queue_for(self, row, tree="P"):
        root, area = self.base / "source", self.base / "queue"
        source_fixture(root, row, tree)
        queue = tq.TaskQueue(area)
        imported = queue.import_finalized(root, 16)
        key = next(queue.iter_parent_keys())
        return root, queue, key, imported

    @staticmethod
    def force_stale_marker(path):
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(b"")

    def test_future_import_holds_parent_without_changing_task_state(self):
        root, queue, key, imported = self.queue_for(near_seed())
        self.assertEqual((imported["held_parents"], imported["held_tasks"],
                          imported["held_pending_roots"]), (1, 1, 1))
        self.assertEqual(queue.readiness_count(), 0)
        self.assertEqual(list(queue.iter_parent_markers("root_ready")), [])
        directory = next(queue.iter_task_dirs())
        state = tq.read_json(directory / "STATE.json.gz")
        self.assertEqual((state["status"], state["reason"], state["roots"][0]["tree"]),
                         ("queued", "unattempted", "P"))
        decision = tq.read_json(queue.parent_dir(key) / "DISPATCH.json")
        self.assertTrue(decision["unresolved_obligation_preserved"])
        self.assertEqual(decision["decision"]["dispatch"], "HOLD_PARENT_UNRESOLVED")
        self.assertIsNone(queue.claim("descendant"))
        self.assertIsNone(queue.claim_root("root", schedule_sha256="a" * 64))

    def test_reconcile_removes_stale_hints_and_preserves_every_checkpoint_byte(self):
        root, queue, key, _ = self.queue_for(near_seed(), "0PP")
        directories = list(queue.iter_task_dirs())
        before = {p.name: (p / "STATE.json.gz").read_bytes() for p in directories}
        source_before = (queue.parent_dir(key) / "SOURCE.json.gz").read_bytes()
        for directory in directories:
            self.force_stale_marker(queue.marker(directory.name))
        self.force_stale_marker(queue.parent_marker("root_ready", key))
        self.force_stale_marker(queue.parent_marker("replay_ready", key))
        census = queue.reconcile_dispatch_hold()
        self.assertEqual((census["parents"], census["held_parents"],
                          census["runnable_parents"]), (1, 1, 0))
        self.assertEqual((census["ready_markers_after"], census["root_ready_markers_after"],
                          census["replay_ready_markers_after"]), (0, 0, 0))
        self.assertEqual(before, {p.name: (p / "STATE.json.gz").read_bytes() for p in directories})
        self.assertEqual(source_before, (queue.parent_dir(key) / "SOURCE.json.gz").read_bytes())
        status = queue.dispatch_status()
        self.assertEqual((status["held_parents"], status["held_tasks"],
                          status["held_pending_roots"], status["ready_markers"]), (1, 1, 2, 0))
        self.assertEqual(status["runnable_parent_upper_count"], 0)
        audit = tq.audit_parent(queue, key)
        self.assertEqual(audit["pending_leaves"], 2)
        self.assertFalse(audit["closed"])

    def test_claim_rechecks_exact_geometry_even_with_a_stale_marker(self):
        root, queue, key, _ = self.queue_for(near_seed())
        directory = next(queue.iter_task_dirs())
        self.force_stale_marker(queue.marker(directory.name))
        self.assertIsNone(queue.claim("stale"))
        self.assertEqual(queue.readiness_count(), 0)
        self.force_stale_marker(queue.parent_marker("root_ready", key))
        self.assertIsNone(queue.claim_root("stale-root", schedule_sha256="a" * 64))
        self.assertEqual(list(queue.iter_parent_markers("root_ready")), [])

    def test_all_marker_publishers_and_final_replay_fail_closed(self):
        root, queue, key, _ = self.queue_for(near_seed())
        directory = next(queue.iter_task_dirs())
        self.assertFalse(queue._make_ready(directory.name))
        self.assertFalse(queue.make_parent_marker("root_ready", key))
        self.assertFalse(queue.make_parent_marker("replay_ready", key))
        self.force_stale_marker(queue.parent_marker("replay_ready", key))
        value = audit_worker.audit_one(queue, key, runtime=None, parent_seconds=1)
        self.assertEqual(value["status"], "HELD_DISPATCH")
        self.assertEqual(list(queue.iter_parent_markers("replay_ready")), [])

    def test_strictly_outside_parent_remains_runnable(self):
        row = near_seed(offsets=[hold.HOLD_RADIUS + Q(1, 100), 0, 0, 0],
                        extras=[Q(1, 1000)] * 4)
        root, queue, key, imported = self.queue_for(row)
        self.assertEqual(imported["held_parents"], 0)
        self.assertEqual(queue.readiness_count(), 1)
        self.assertEqual(list(queue.iter_parent_markers("root_ready")), [key])
        lease = queue.claim("outside")
        self.assertIsNotNone(lease)
        lease.close()

    def test_numerical_theorem_scope_is_bound_to_campaign_but_has_no_credit(self):
        root, queue, key, _ = self.queue_for(near_seed())
        record = tq.read_json(queue.parent_dir(key) / "DISPATCH.json")
        self.assertTrue(record["decision"]["campaign_scope_match"])
        theorem = record["decision"]["reviewed_numerical_theorem"]
        self.assertEqual(theorem["status"], "REVIEWED_NUMERICAL_EVIDENCE_ONLY")
        self.assertEqual(theorem["physical_lean_admissions"], 0)
        self.assertFalse(record["decision"]["closure_credit"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
