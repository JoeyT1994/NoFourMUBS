"""Whole-original-root tests with immutable descendant history.

Descendant leases hold a shared parent gate.  A root tester holds it exclusively
and writes a separate candidate.  No descendant C evidence or split is replaced.
Independent final replay may select the full root as an alternate exact cover.
"""
import fcntl
import hashlib
import json
import os
import time
import uuid

if __package__:
    from . import task_queue as tq
else:
    import task_queue as tq


def root_task(parent):
    return {"task_id": tq.digest({"whole_original_root": parent["parent_key"]}),
            "parent_key": parent["parent_key"], "original_id": parent["id"],
            "input_sha256": parent["input_sha256"], "source_tree_sha256": parent["source_tree_sha256"]}


def _states(queue, place):
    for line in tq.inventory_lines(place / "TASKS.jsonl"):
        item = json.loads(line)
        directory = queue.task_dir(item["task_id"])
        task = tq.read_json(directory / "TASK.json")
        state = tq.read_json(directory / "STATE.json.gz")
        tq.validate_state(task, state)
        yield task, state


def seed_root(queue, key):
    place = queue.parent_dir(key)
    parent = tq.read_json(place / "SOURCE.json.gz")
    dispatch = queue.parent_dispatch(parent)
    if not queue.dispatch_runnable(dispatch):
        queue.suppress_held_parent(parent, dispatch)
        return False
    if parent.get("source_guard"):
        queue.parent_marker("root_ready", key).unlink(missing_ok=True)
        return False
    if (place / "ROOT_STATE.json").exists():
        return False
    pending = False
    for task, state in _states(queue, place):
        if state["status"] == "parked" or task.get("source_guard"):
            queue.parent_marker("root_ready", key).unlink(missing_ok=True)
            return False
        pending |= any("P" in r["tree"] for r in state["roots"])
    if pending:
        queue.make_parent_marker("root_ready", key)
    else:
        queue.parent_marker("root_ready", key).unlink(missing_ok=True)
    return pending


def claim_root(queue, owner, lease_seconds, schedule_sha256):
    if not isinstance(owner, str) or not owner or len(owner) > 200 or not 1 <= lease_seconds <= 3600:
        raise ValueError("Invalid bounded whole-root lease")
    for key in queue.iter_parent_markers("root_ready", owner):
        place = queue.parent_dir(key)
        gate = (place / "PARENT_RUN.lock").open("a")
        try:
            try:
                fcntl.flock(gate, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:
                continue
            parent = tq.read_json(place / "SOURCE.json.gz")
            dispatch = queue.parent_dispatch(parent)
            if not queue.dispatch_runnable(dispatch):
                queue.suppress_held_parent(parent, dispatch)
                continue
            commit_path = queue.area / "batches" / ("%06d.json" % parent["source"]["batch"])
            if not commit_path.exists():
                continue
            commit = tq.read_json(commit_path)
            if commit["packet_sha256"] != parent["source"]["packet_sha256"]:
                raise ValueError("Whole root source commit differs")
            state_path = place / "ROOT_STATE.json"
            state = tq.read_json(state_path) if state_path.exists() else {
                "schema": "survivor-root-attempt-v2", "parent_key": key,
                "status": "queued", "method_index": 0, "attempts": 0,
                "schedule_sha256": schedule_sha256, "source_sha256": tq.digest(parent),
                "cpu_seconds": 0.0, "physical_lean_admissions": 0}
            if state.get("source_sha256") != tq.digest(parent) or state.get("physical_lean_admissions") != 0:
                raise ValueError("Whole root source binding changed")
            if state["status"] not in ("queued", "running"):
                queue.parent_marker("root_ready", key).unlink(missing_ok=True)
                continue
            if state["schedule_sha256"] != schedule_sha256:
                raise ValueError("Whole root schedule changed without migration")
            if parent.get("source_guard") or any(s["status"] == "parked" or t.get("source_guard") for t, s in _states(queue, place)):
                state.update(status="parked", reason="inherited_guard")
                tq.durable_json(state_path, state)
                queue.parent_marker("root_ready", key).unlink(missing_ok=True)
                continue
            old_path = place / "ROOT_LEASE.json"
            old = tq.read_json(old_path) if old_path.exists() else None
            if old and old.get("expires_unix", 0) > time.time():
                continue
            lease = {"schema": 1, "token": uuid.uuid4().hex, "owner": owner,
                     "pid": os.getpid(), "claimed_unix": time.time(),
                     "expires_unix": time.time() + lease_seconds, "physical_lean_admissions": 0}
            tq.durable_json(old_path, lease)
            state["status"] = "running"
            tq.durable_json(state_path, state)
            result = RootLease(queue, parent, state, gate, lease, lease_seconds)
            gate = None
            return result
        finally:
            if gate is not None:
                gate.close()
    return None


class RootLease:
    def __init__(self, queue, parent, state, gate, lease, seconds):
        self.queue, self.parent, self.state = queue, parent, state
        self.task = root_task(parent)
        self.lock, self.lease, self.seconds = gate, lease, seconds
        self.directory = queue.parent_dir(parent["parent_key"])

    def _check(self):
        if self.lock is None or tq.read_json(self.directory / "ROOT_LEASE.json")["token"] != self.lease["token"]:
            raise ValueError("Stale whole-root lease")

    def checkpoint(self):
        self._check()
        if self.state["source_sha256"] != tq.digest(self.parent) or self.state["physical_lean_admissions"] != 0:
            raise ValueError("Whole-root attempt altered its source scope")
        tq.durable_json(self.directory / "ROOT_STATE.json", self.state)
        self.lease["expires_unix"] = time.time() + self.seconds
        tq.durable_json(self.directory / "ROOT_LEASE.json", self.lease)

    def release(self, reason, retry=False):
        self.state.update(status="queued" if retry else "parked", reason=reason)
        self.checkpoint()
        if not retry:
            self.queue.parent_marker("root_ready", self.parent["parent_key"]).unlink(missing_ok=True)
        self.lease["expires_unix"] = 0
        tq.durable_json(self.directory / "ROOT_LEASE.json", self.lease)
        self.close()

    def candidate(self, evaluation, replay, recipe=None):
        self._check()
        cc, rr = tq.exact_box(self.parent["input"])
        proof = tq.build_proof(self.task, "", cc, rr, evaluation, replay, recipe)
        if len(tq.canonical(proof)) > 65536:
            raise tq.EvidenceLimit("root_evidence_size_guard")
        history = tq.audit_history(self.queue, self.parent["parent_key"])
        value = {"schema": "survivor-whole-root-candidate-v2", "parent_key": self.parent["parent_key"],
                 "source_sha256": tq.digest(self.parent), "input_sha256": self.parent["input_sha256"],
                 "source_tree_sha256": self.parent["source_tree_sha256"],
                 "task_states_sha256": history["task_states_sha256"],
                 "historical_tree_sha256": tq.tree_sha(history["tree"]),
                 "historical_certificate_sha256": history["certificate_sha256"],
                 "proof": proof, "proof_sha256": tq.digest(proof),
                 "schedule_sha256": self.state["schedule_sha256"], "physical_lean_admissions": 0}
        sha = tq.digest(value)
        tq.immutable_json(self.directory / "root_candidates" / (sha + ".json.gz"), value)
        tq.durable_json(self.directory / "ROOT_CANDIDATE.json.gz", value)
        self.state.update(status="candidate", reason="awaiting_fresh_whole_root_replay", candidate_sha256=sha)
        self.checkpoint()
        self.queue.make_parent_marker("replay_ready", self.parent["parent_key"])
        for task, state in _states(self.queue, self.directory):
            self.queue.marker(task["task_id"]).unlink(missing_ok=True)
        self.queue.parent_marker("root_ready", self.parent["parent_key"]).unlink(missing_ok=True)
        self.lease["expires_unix"] = 0
        tq.durable_json(self.directory / "ROOT_LEASE.json", self.lease)
        self.close()
        return sha

    def close(self):
        if self.lock is not None:
            self.lock.close()
            self.lock = None


def root_cover(queue, key, source_root=None, replay_fn=None):
    place = queue.parent_dir(key)
    state_path = place / "ROOT_STATE.json"
    if not state_path.exists():
        return None
    state = tq.read_json(state_path)
    if state["status"] not in ("candidate", "accepted"):
        return None
    candidate = tq.read_json(place / "ROOT_CANDIDATE.json.gz")
    parent = tq.read_json(place / "SOURCE.json.gz")
    if (candidate.get("schema") != "survivor-whole-root-candidate-v2"
            or state.get("candidate_sha256") != tq.digest(candidate)
            or candidate["source_sha256"] != tq.digest(parent)
            or candidate["input_sha256"] != parent["input_sha256"]
            or candidate["source_tree_sha256"] != parent["source_tree_sha256"]
            or candidate.get("physical_lean_admissions") != 0 or parent.get("source_guard")):
        raise ValueError("Whole-root candidate source binding changed")
    history = tq.audit_history(queue, key, source_root)
    if (candidate["task_states_sha256"] != history["task_states_sha256"]
            or candidate["historical_tree_sha256"] != tq.tree_sha(history["tree"])
            or candidate["historical_certificate_sha256"] != history["certificate_sha256"]):
        raise ValueError("Whole-root candidate overwrote or raced descendant history")
    if any(s["status"] == "parked" or t.get("source_guard") for t, s in _states(queue, place)):
        raise ValueError("Whole-root candidate attempted to override a parked guard")
    proof = candidate["proof"]
    cc, rr = tq.exact_box(parent["input"])
    if tq.digest(proof) != candidate["proof_sha256"]:
        raise ValueError("Whole-root candidate proof changed")
    tq.validate_proof(root_task(parent), "", cc, rr, proof)
    if proof["evaluation"]["input"] != proof["geometry"]:
        raise ValueError("Whole root requires evaluation of its exact original input")
    if replay_fn is not None:
        fresh = replay_fn(proof["evaluation"])
        if fresh.get("status") != "PASS" or fresh.get("evidence_sha256") != proof["evaluation"]["replay"]["evidence_sha256"]:
            raise ValueError("Independent whole-original-root replay failed")
    result = dict(history)
    result.pop("certificate_sha256")
    method, pins = proof["evaluation"]["method"], proof["evaluation"]["provider_hashes"]
    result.update(cover_mode="whole_original_root", root_candidate_sha256=tq.digest(candidate),
                  historical_tree_sha256=candidate["historical_tree_sha256"], historical_nodes=history["nodes"],
                  historical_pending_leaves=history["pending_leaves"], tree="C", nodes=1,
                  old_closed_leaves=0, old_replayed_leaves=0, new_closed_leaves=1, pending_leaves=0,
                  new_leaf_proofs={"": {"task_id": proof["task_id"], "sha256": tq.digest(proof),
                      "method": method, "evidence_sha256": proof["evaluation"]["replay"]["evidence_sha256"],
                      "provider_dependencies": tq.recipe_identities(proof["evaluation"]),
                      "provider_hashes": pins, "provider_identity": method + "@" + tq.digest(pins)}},
                  candidate_complete=True, closed=replay_fn is not None,
                  audit="FRESH_ALL_LEAVES_PASS" if replay_fn is not None else "TOPOLOGY_AND_RECEIPTS_PASS")
    result["certificate_sha256"] = tq.digest(result)
    return result


def finalize_root(queue, key, passed):
    """Called under the auditor's exclusive parent gate, after a durable receipt."""
    place = queue.parent_dir(key)
    state_path = place / "ROOT_STATE.json"
    if not state_path.exists():
        return
    state = tq.read_json(state_path)
    if state["status"] not in ("candidate", "accepted"):
        return
    state.update(status="accepted" if passed else "replay_parked",
                 reason="fresh_whole_root_replayed" if passed else "fresh_whole_root_replay_budget")
    tq.durable_json(state_path, state)
    for task, saved in _states(queue, place):
        if passed:
            queue.marker(task["task_id"]).unlink(missing_ok=True)
        elif saved["status"] in ("queued", "running") and not task.get("source_guard"):
            queue._make_ready(task["task_id"])
