# Survivor continuation, version 2

## Current dispatch hold

This release conservatively defers every original parent that intersects,
touches, or is not rigorously certified outside the closed circular sup ball of
radius `1/40` around either stationary seed.  The exact parent-level gate and
additive unresolved ledger are documented in `DISPATCH_HOLD_INTEGRATION.md`.
The radius `1/40` is a scheduling hold only; it adds no closure or Lean credit.
The reviewed radius-`1/100` theorem is recorded separately as numerical evidence,
with the seed point `R=0` kept as a separate component.

This continuation consumes only immutable, completed batches of the existing
Popeye campaign. It preserves their exact boxes and accepted handoff scope.
It does not establish the physical no-four-MUB theorem in Lean.

The release implements all nine additions requested after the handoff review:

1. A cheap complementary-corner exclusion runs before the other leaf tests.
2. Each original box gets a bounded whole-box attempt before descendants. A
   freshly replayed whole-box certificate can replace its subdivision cover;
   all historical trees and evidence are retained.
3. Partial sign exclusions from different methods and enclosing ancestors are
   pooled only after their original witnesses have been freshly reevaluated.
4. The advanced handoff tests use their actual whole-box mathematical guards,
   without the former arbitrary radius 0.06 admission filter.
5. An exact secant circuit cancels the Fourier-seed terms before Taylor
   truncation. Its coefficient scaling, including H/rho^25, is explicit.
6. A bounded shared cache suggests enclosing certificates and D8/conjugation
   related tests. Every target enclosure is evaluated afresh. There is no
   unproved physical transport or assumed symmetry speedup. `orbit_census.py`
   counts exact duplicates without adding any proof credit.
7. Workers keep a bounded in-memory frontier and choose split axes using
   method diagnostics. Expensive methods are scheduled selectively by depth.
8. Analytic derivative enclosures support monotonic-face tests. Exact dyadic
   complex vectors support rigorous Hermitian quadratic-form PSD obstructions.
9. A separate continuously running verifier checks completed parent boxes
   while search continues, using source-pinned providers for every recipe.

Existing Taylor orders 3/4/5, paired PSD, radial normalization and exact
192/256/384-bit PSD providers remain available. The immutable v1 evaluator is
preserved for old recipes; their meaning is never replaced by a v2 method
with the same name. Each new leaf also has a method-specific pinned recipe.

The previous 48-case benchmark found 5, 7 and 8 closures for orders 3, 4 and 5.
The new handoff plain test closed 22 of those cases, including two whole
original boxes; full shifted constraints added no acceptance on that sample.
`validate_release.py` retains the pinned sample but evaluates and freshly
replays only rows whose whole exact box is strictly outside the current
dispatch hold; it records all held rows without evaluating them. New
cancellation, face and ray tests have
correctness controls but no assumed speedup. This sample is too small for a
full-campaign runtime estimate and supplies no additional ledger credit.

The A-elimination witness explicitly intersects its known-nonnegative RHS
enclosure with nonnegative reals. Its upper endpoint and acceptance comparisons
are unchanged; the strict Python decoder remains intact. Six native exact
controls and 13 saved frontier geometries exercise this rounding correction.

The pending leaves of one original box are divided into durable32-leaf chunks.
A process-held flock prevents duplicate active claims, even after lease expiry.
Checkpoint writes are throttled; recipes are grouped in compressed checkpoints.
The original depth48,262143-node,512MiB RSS and8GiB disk guards remain in force.
Per-process address space is capped at768MiB. Guarded or exhausted work remains
explicitly unresolved.

Safety flags are checked by bounded directory membership, avoiding the
multi-minute missing-file lookup stalls observed on two Popeye genx nodes.
Negative directory snapshots expire within0.25 seconds of starting the scan;
actual stops latch, errors fail closed, and the authorized production-handover
reason is reread live. This changes filesystem access, not any stop condition.
Workers verify the direct flag-parent directories once and then scan those
parents, avoiding repeated campaign-root reads. Missing optional parents stay
discoverable through their ancestors; a removed verified parent fails closed.
The optional shared hint cache tolerates a concurrent writer's not-yet-created
schema as a cache miss; other SQLite errors still stop the worker.

On each Slurm node, workers also share bounded directory-membership snapshots
through an owned, private cache on the node's local filesystem. One scanner
holds each directory's local lock; another worker can reuse its result only
within the original 0.25-second scan-start deadline. A slow scan never receives
a newer freshness timestamp. Missing, corrupt, expired or interrupted cache
records cannot establish guard absence. Published scan errors propagate to
ordinary readers; only an explicit successful synchronous refresh can replace
an error record. Actual stop latches remain permanent, and each check still
reads production-handover contents live. There is no additional daemon.

The local cache is scoped by the release, Slurm job, user, boot and directory.
Each job namespace has at most 64 directory keys and bounded atomic files;
completed-job namespaces are temporary, reproducible artifacts. Cache hits
perform no writes. Worker receipts expose local/shared hits, actual refreshes,
slow refreshes and elapsed CPU/wall time. The real-box validation requires that
the shared cache was exercised and records these measurements. Correctness
tests cover concurrent processes, expired results and interrupted publication;
they do not by themselves establish a cluster throughput gain.

`validate.sbatch SOURCE VALIDATION_AREA` runs controls, adversarial queue and
migration tests, a separate bounded pilot of whole boxes and descendants,
actual v1 checkpoint replay, and the pinned benchmark. Existing search keeps
running during validation. Pilot evidence is retained separately and is not
automatically counted in production.
The descendant pilot allows 30 minutes of wall time for the same CPU budgets,
to accommodate measured shared-storage stalls; the whole Slurm validation
remains bounded to 45 minutes. Arithmetic failures are never treated as timeouts.

`cutover.sbatch SOURCE AREA OLD_SOURCE OLD_COORDINATOR VALIDATION_RECEIPT`
requires a passing receipt for precisely the new source hash. It verifies job
ownership, stops only obsolete v1 continuation allocations, and journals a
bounded migration of their last atomic checkpoints. Encoded forests, C recipes,
original source packets and guard-parked states are preserved. Interrupted
unsaved computation is recomputed. A migration cannot erase a safety stop.
An exclusive import checkpoint barrier prevents cancellation midway through
publishing a source batch.
Ambiguous Slurm submissions require reconciliation before any replacement.

`coordinator.sbatch SOURCE AREA` requires the admitted runtime and validation.
It reserves two genx cores: one for control and one for independent replay.
It expands toward useful capacity, up to 100 ccq nodes and 490 genx worker
cores. ccq nodes run 47 numerical processes plus supervision; genx uses
10-core allocations. Root and descendant work is not double-counted as
parallel capacity. Completed whole-box candidates stop redundant descendants.

The old workers remain responsible for unfinished original batches. They can
be cancelled only after every original batch has a DONE receipt and has been
imported. Unneeded pending allocations are cancelled when the ready queue is
empty. Submission intent is durable before sbatch; ambiguous submissions fail
closed instead of silently duplicating jobs. Recovery waves and CPU attempts
are bounded. An unresolved mathematical case is never called a failure of the
scheduler or silently retried forever.

Fresh results live in AREA/FINAL_AUDIT.json. `combine.py` preserves historical
audits and creates AREA/COMBINED_FINAL_AUDIT.json, reconstructing every remaining
original ID through the pinned exact-conjugation map. It retains the separate
1857 all-completion certificates correcting the old sheet-scope issue.
SURVIVOR_AUTHORITATIVE_STATUS.json is the current continuation status.

The formal packet contains 66 kernel-checked supporting theorems, including
the actual complex seed cancellation and Hermitian contraction identities.
`formal/PROOF_STATUS.md` and `formal/NATIVE_BINDING_MAP.md` identify the remaining
native interval, trigonometric, derivative and physical-cover bindings.
No numerical closure is counted as a Lean proof. The uniform positive seed
radius and full physical no-four-MUB theorem remain separate open obligations.

`build_release.py` produces a small source-only, hash-pinned ZIP. It includes
the selected Lean sources and receipts, but excludes compiled objects, native
caches, large numerical data and intermediate expressions. It depends on the
existing frozen campaign input and engine tree; this continuation release is
not a replacement for the complete campaign transfer archive.
