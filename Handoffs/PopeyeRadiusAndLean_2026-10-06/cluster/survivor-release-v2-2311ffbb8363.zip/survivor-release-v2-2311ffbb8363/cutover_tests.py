"""Mocked cutover safety controls; no Slurm calls or numerical builds."""
from contextlib import redirect_stdout
from io import StringIO
from pathlib import Path
import json
import subprocess
import tempfile
import unittest
from unittest.mock import patch

import cutover as c


class StopProbe(Exception):
    """End a mock cutover immediately after observing the coordinator stop."""


class CutoverSafety(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name).resolve()
        self.area = self.root / "queue"
        self.old = self.root / "old-release"
        self.area.mkdir()
        self.old.mkdir()
        self.script = self.old / "coordinator.sbatch"
        self.script.write_text("pinned old coordinator\n")
        self.pins = {self.script.name: c.tq.sha_file(self.script)}
        self.old_sha = c.tq.digest(self.pins)
        self.new_sha = "b" * 64
        self.write(self.old / "PINS.json", self.pins)
        self.write(self.area / "LAUNCH.json", {"source": str(self.old), "source_sha256": self.old_sha})
        self.validation = self.root / "VALIDATION.json"
        self.write(self.validation, {"status": "PASS", "source_sha256": self.new_sha})
        self.enterContext(patch.object(c.s, "verify_source", return_value=self.new_sha))
        self.safety = self.enterContext(patch.object(c.s, "safety_stop", return_value=None))
        self.enterContext(patch.object(c.tq, "resource_guard"))
        # Any external operation which a test has not explicitly modeled fails.
        self.run = self.enterContext(patch.object(c, "run", side_effect=AssertionError("Unmocked external command")))
        self.active = self.enterContext(patch.object(c, "active", side_effect=AssertionError("Unmocked Slurm lookup")))

    @staticmethod
    def write(path, value):
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(value) + "\n")

    @staticmethod
    def reply(code=0, stdout="", stderr=""):
        return subprocess.CompletedProcess([], code, stdout=stdout, stderr=stderr)

    def jobs(self, value):
        self.active.side_effect = None
        self.active.return_value = value

    def command(self, value):
        self.run.side_effect = None
        self.run.return_value = value

    def submission(self, name, ident=None, source=None):
        value = {"source": str(source or self.old), "source_sha256": self.old_sha, "token": name}
        if ident is not None:
            value["job_id"] = ident
        self.write(self.area / "submissions" / (name + ".json"), value)

    def launch(self, ident="10"):
        with redirect_stdout(StringIO()):
            return c.cutover(self.root, self.area, self.old, ident, self.validation)

    def journal(self, **changes):
        value = {"phase": "VALIDATED", "new_source_sha256": self.new_sha,
                 "old_source_sha256": self.old_sha, "old_coordinator_job_id": "10"}
        self.write(self.area / "V2_CUTOVER.json", dict(value, **changes))

    def test_live_coordinator_scontrol_failure_is_closed(self):
        self.jobs([["10", "RUNNING"]])
        # Even plausible stdout cannot compensate for a failed scontrol read.
        self.command(self.reply(1, f"Command={self.script} {self.old} {self.area}", "unavailable"))
        with patch.object(c, "stop_allocations") as stop:
            with self.assertRaisesRegex(ValueError, "ownership"):
                self.launch()
            stop.assert_not_called()
        self.assertEqual(self.run.call_args.args[0], ["scontrol", "show", "job", "-o", "10"])

    def test_wrong_live_source_or_queue_is_rejected(self):
        self.jobs([["10", "RUNNING"]])
        for script, area in ((self.root / "another" / "coordinator.sbatch", self.area),
                             (self.script, self.root / "another-queue")):
            with self.subTest(script=script, area=area):
                self.command(self.reply(stdout=f"Command={script} {self.old} {area}"))
                with self.assertRaisesRegex(ValueError, "ownership"):
                    c.verify_coordinator(self.root, self.area, self.old, "10")

    def test_queue_path_prefix_is_not_ownership(self):
        self.jobs([["10", "RUNNING"]])
        self.command(self.reply(stdout=f"Command={self.script} {self.old} {self.area}-other"))
        with self.assertRaisesRegex(ValueError, "ownership"):
            c.verify_coordinator(self.root, self.area, self.old, "10")

    def test_script_path_prefix_is_not_ownership(self):
        self.jobs([["10", "RUNNING"]])
        self.command(self.reply(stdout=f"Command={self.script}-other {self.old} {self.area}"))
        with self.assertRaisesRegex(ValueError, "ownership"):
            c.verify_coordinator(self.root, self.area, self.old, "10")

    def test_source_argument_must_match_the_release(self):
        self.jobs([["10", "RUNNING"]])
        self.command(self.reply(stdout=f"Command={self.script} {self.root / 'other-source'} {self.area}"))
        with self.assertRaisesRegex(ValueError, "ownership"):
            c.verify_coordinator(self.root, self.area, self.old, "10")

    def test_queue_in_other_metadata_is_not_command_ownership(self):
        self.jobs([["10", "RUNNING"]])
        self.command(self.reply(stdout=f"Command={self.script} {self.old} {self.root / 'other-queue'} WorkDir={self.area}"))
        with self.assertRaisesRegex(ValueError, "ownership"):
            c.verify_coordinator(self.root, self.area, self.old, "10")

    def test_absent_coordinator_needs_no_scontrol_or_cancel(self):
        self.jobs([])
        c.verify_coordinator(self.root, self.area, self.old, "10")
        self.run.assert_not_called()

    def test_matching_live_coordinator_is_admitted(self):
        self.jobs([["10", "RUNNING"]])
        for command in (f"{self.script} {self.old} {self.area}",
                        "old-release/coordinator.sbatch old-release queue"):
            with self.subTest(command=command):
                self.command(self.reply(stdout=f"JobId=10 Command={command} WorkDir={self.root}"))
                c.verify_coordinator(self.root, self.area, self.old, "10")
        self.assertEqual(self.run.call_count, 2)

    def test_popeye_script_only_command_uses_exact_submitline(self):
        self.jobs([["10", "RUNNING"]])
        submit = f"sbatch --parsable --comment=mub6-test old-release/coordinator.sbatch old-release {self.area}"
        self.command(self.reply(stdout=f"JobId=10 Command={self.script} WorkDir={self.root} SubmitLine={submit} StdOut={self.root / 'log'}"))
        c.verify_coordinator(self.root, self.area, self.old, "10")
        self.assertEqual(self.run.call_count, 1)

    def test_popeye_submitline_mutations_are_rejected(self):
        self.jobs([["10", "RUNNING"]])
        correct = f"sbatch --parsable old-release/coordinator.sbatch old-release {self.area}"
        cases = [
            (self.root / "other-workdir", correct),
            (self.root, f"sbatch old-release/coordinator.sbatch other-release {self.area}"),
            (self.root, f"sbatch old-release/coordinator.sbatch old-release {self.area}-other"),
            (self.root, f"sbatch old-release/coordinator.sbatch-other old-release {self.area}"),
            (self.root, f"not-sbatch old-release/coordinator.sbatch old-release {self.area}"),
            (self.root, ""),
        ]
        for workdir, submit in cases:
            with self.subTest(workdir=workdir, submit=submit):
                self.command(self.reply(stdout=f"Command={self.script} WorkDir={workdir} SubmitLine={submit}"))
                with self.assertRaisesRegex(ValueError, "ownership"):
                    c.verify_coordinator(self.root, self.area, self.old, "10")

    def test_relative_three_argument_command_requires_correct_workdir(self):
        self.jobs([["10", "RUNNING"]])
        self.command(self.reply(stdout=f"Command=old-release/coordinator.sbatch old-release queue WorkDir={self.root / 'other-workdir'}"))
        with self.assertRaisesRegex(ValueError, "ownership"):
            c.verify_coordinator(self.root, self.area, self.old, "10")

    def test_ambiguous_submission_is_rejected_before_any_cancellation(self):
        self.submission("accepted-response-lost")
        self.jobs([])
        with patch.object(c, "stop_allocations") as stop:
            with self.assertRaisesRegex(RuntimeError, "reconciliation"):
                self.launch()
            stop.assert_not_called()
        self.run.assert_not_called()
        self.assertFalse((self.area / "V2_STOP_EVIDENCE.json").exists())

    def test_foreign_submission_source_is_rejected_before_cancellation(self):
        self.submission("foreign", "11", self.root / "foreign-release")
        self.jobs([])
        with patch.object(c, "stop_allocations") as stop:
            with self.assertRaisesRegex(ValueError, "Another release"):
                self.launch()
            stop.assert_not_called()
        self.run.assert_not_called()

    def test_submission_census_is_unique_and_excludes_original_jobs(self):
        self.submission("worker-a", "12")
        self.submission("worker-b", 11)
        self.submission("worker-b-copy", "11")
        self.write(self.root / "elastic-run" / "SUBMISSION.json", {"worker_arrays": ["50", "51"]})
        self.assertEqual(c.old_submissions(self.area, self.old, self.root), ["11", "12"])
        self.run.assert_not_called()
        self.active.assert_not_called()

    def test_malformed_submission_id_is_rejected(self):
        self.submission("worker-a", "11_7")
        with self.assertRaisesRegex(ValueError, "Malformed"):
            c.old_submissions(self.area, self.old, self.root)
        self.run.assert_not_called()

    def test_changed_legacy_source_is_rejected_before_external_actions(self):
        self.script.write_text("changed legacy source\n")
        with self.assertRaisesRegex(ValueError, "Legacy source pin"):
            self.launch()
        self.run.assert_not_called()
        self.active.assert_not_called()

    def test_wrong_validation_or_launch_source_is_rejected(self):
        self.write(self.validation, {"status": "PASS", "source_sha256": "c" * 64})
        with self.assertRaisesRegex(ValueError, "validation"):
            self.launch()
        self.write(self.validation, {"status": "PASS", "source_sha256": self.new_sha})
        self.write(self.area / "LAUNCH.json", {"source": str(self.old), "source_sha256": "c" * 64})
        with self.assertRaisesRegex(ValueError, "Old launch"):
            self.launch()
        self.run.assert_not_called()
        self.active.assert_not_called()

    def test_resume_cannot_change_coordinator_identity(self):
        self.journal()
        with self.assertRaisesRegex(ValueError, "identity changed"):
            self.launch("99")
        self.run.assert_not_called()
        self.active.assert_not_called()

    def test_existing_safety_stop_is_preserved(self):
        stop_path = self.area / "STOP_REQUESTED.json"
        self.write(stop_path, {"reason": "disk_reserve_8GiB"})
        before = stop_path.read_bytes()
        self.safety.return_value = str(stop_path)
        with self.assertRaisesRegex(RuntimeError, "safety stop"):
            self.launch()
        self.assertEqual(stop_path.read_bytes(), before)
        self.run.assert_not_called()
        self.active.assert_not_called()

    def test_complete_mock_cutover_preserves_exact_obsolete_id_census(self):
        self.submission("worker-a", "11")
        self.submission("worker-b", "12")
        source_jobs = self.root / "elastic-run" / "SUBMISSION.json"
        self.write(source_jobs, {"worker_arrays": ["50", "51"], "coordinator_job_id": "49"})
        original = source_jobs.read_bytes()
        self.jobs([])
        stops = []

        def stop(ids, root):
            self.assertEqual(root, self.root)
            stops.append(list(ids))
            if ids == ["10"]:
                # An importer/sbatch child publishes its last durable receipt.
                self.submission("worker-late", "13")

        def run(args, root, **kwargs):
            self.assertEqual(root, self.root)
            if len(args) > 2 and Path(args[2]).name == "migrate.py":
                self.assertEqual(args[args.index("--queue") + 1], str(self.area))
                return self.reply(stdout="mocked migration\n")
            if args[:2] == ["sbatch", "--parsable"]:
                return self.reply(stdout="99\n")
            raise AssertionError("Unexpected external command: " + repr(args))

        self.run.side_effect = run
        with patch.object(c, "stop_allocations", side_effect=stop):
            result = self.launch()
        evidence = c.tq.read_json(self.area / "V2_STOP_EVIDENCE.json")
        ids = [row["job_id"] for row in evidence["obsolete_jobs"]]
        self.assertEqual(set(ids), {"10", "11", "12", "13"})
        self.assertEqual(len(ids), 4)
        self.assertTrue(all(row["state"] == "ABSENT" for row in evidence["obsolete_jobs"]))
        self.assertTrue(evidence["source_workers_untouched"])
        self.assertEqual(source_jobs.read_bytes(), original)
        self.assertEqual(stops, [["10"], ["11", "12", "13"], ["11", "12", "13"]])
        self.assertEqual(result["phase"], "DEPLOYED")
        self.assertEqual(result["new_coordinator_job_id"], "99")
        self.assertEqual(self.run.call_count, 2)

    def test_reappearing_old_job_forbids_migration(self):
        self.submission("worker-a", "11")
        self.active.side_effect = lambda ids, root: [["11", "RUNNING"]] if "11" in ids else []
        with patch.object(c, "stop_allocations"):
            with self.assertRaisesRegex(RuntimeError, "reappeared"):
                self.launch()
        self.run.assert_not_called()
        self.assertFalse((self.area / "V2_STOP_EVIDENCE.json").exists())

    def test_coordinator_stop_holds_import_barrier(self):
        self.jobs([])
        barrier = self.area / "IMPORT.lock"

        def stop(ids, root):
            self.assertEqual(ids, ["10"])
            with barrier.open("a") as probe:
                with self.assertRaises(BlockingIOError):
                    c.fcntl.flock(probe, c.fcntl.LOCK_EX | c.fcntl.LOCK_NB)
            raise StopProbe("observed locked import barrier")

        with patch.object(c, "stop_allocations", side_effect=stop) as cancelled:
            with self.assertRaisesRegex(StopProbe, "locked import barrier"):
                self.launch()
            cancelled.assert_called_once_with(["10"], self.root)
        # Exceptions also release the controller's barrier; no stale lock is
        # left to strand a later explicit retry.
        with barrier.open("a") as probe:
            c.fcntl.flock(probe, c.fcntl.LOCK_EX | c.fcntl.LOCK_NB)
        self.run.assert_not_called()

    def test_import_barrier_timeout_never_cancels_coordinator(self):
        self.jobs([])
        barrier = self.area / "IMPORT.lock"
        checkpoint = self.area / "import-in-progress"
        checkpoint.write_bytes(b"uncommitted importer state\n")
        with barrier.open("a") as importer:
            c.fcntl.flock(importer, c.fcntl.LOCK_EX | c.fcntl.LOCK_NB)
            clock = iter((100.0,))
            with patch.object(c.time, "monotonic", side_effect=lambda: next(clock, 1e9)), \
                    patch.object(c.time, "sleep"), patch.object(c, "stop_allocations") as cancelled:
                with self.assertRaises(TimeoutError):
                    self.launch()
                cancelled.assert_not_called()
            self.assertEqual(checkpoint.read_bytes(), b"uncommitted importer state\n")
        self.run.assert_not_called()
        self.assertFalse((self.area / "V2_STOP_EVIDENCE.json").exists())
        self.assertEqual(c.tq.read_json(self.area / "V2_CUTOVER.json")["phase"], "STOPPING_OLD_COORDINATOR")

    def test_import_barrier_waits_for_importer_before_stop(self):
        self.jobs([])
        barrier = self.area / "IMPORT.lock"
        events = []
        with barrier.open("a") as importer:
            c.fcntl.flock(importer, c.fcntl.LOCK_EX | c.fcntl.LOCK_NB)

            def release_importer(seconds):
                self.assertGreater(seconds, 0)
                events.append("importer_finished")
                c.fcntl.flock(importer, c.fcntl.LOCK_UN)

            def stop(ids, root):
                self.assertEqual(events, ["importer_finished"])
                with barrier.open("a") as probe:
                    with self.assertRaises(BlockingIOError):
                        c.fcntl.flock(probe, c.fcntl.LOCK_EX | c.fcntl.LOCK_NB)
                events.append("coordinator_stopped")
                raise StopProbe("import wave completed first")

            with patch.object(c.time, "monotonic", return_value=100.0), \
                    patch.object(c.time, "sleep", side_effect=release_importer) as sleep, \
                    patch.object(c, "stop_allocations", side_effect=stop):
                with self.assertRaisesRegex(StopProbe, "completed first"):
                    self.launch()
                self.assertEqual(sleep.call_count, 1)
        self.assertEqual(events, ["importer_finished", "coordinator_stopped"])
        self.run.assert_not_called()

    def test_kill_waits_for_absence_and_only_names_requested_jobs(self):
        self.active.side_effect = [[["11", "RUNNING"]], [["11", "COMPLETING"]], []]
        self.command(self.reply())
        with patch.object(c.time, "monotonic", side_effect=[100.0, 101.0]), patch.object(c.time, "sleep") as sleep:
            c.stop_allocations(["12", "11", "11"], self.root)
            sleep.assert_called_once_with(3)
        self.run.assert_called_once_with(["scancel", "--signal=KILL", "--full", "11", "12"], self.root, check=False)
        self.assertEqual(self.active.call_count, 3)
        self.assertTrue(all(call.args[0] == ["11", "12"] for call in self.active.call_args_list))

    def test_absent_or_empty_allocations_are_never_cancelled(self):
        c.stop_allocations([], self.root)
        self.active.assert_not_called()
        self.jobs([])
        c.stop_allocations(["11"], self.root)
        self.run.assert_not_called()

    def test_cancel_failure_is_fatal(self):
        self.jobs([["11", "RUNNING"]])
        self.command(self.reply(1, stderr="permission denied"))
        with self.assertRaisesRegex(RuntimeError, "cancellation failed"):
            c.stop_allocations(["11"], self.root)
        self.assertEqual(self.active.call_count, 1)

    def test_disappearance_race_still_requires_empty_queue(self):
        self.active.side_effect = [[["11", "RUNNING"]], []]
        self.command(self.reply(1, stderr="Invalid job id specified"))
        c.stop_allocations(["11"], self.root)
        self.assertEqual(self.active.call_count, 2)

    def test_kill_timeout_is_bounded_and_forbids_progress(self):
        self.jobs([["11", "RUNNING"]])
        self.command(self.reply())
        with patch.object(c.time, "monotonic", side_effect=[100.0, 281.0]), patch.object(c.time, "sleep") as sleep:
            with self.assertRaisesRegex(TimeoutError, "migration forbidden"):
                c.stop_allocations(["11"], self.root)
            sleep.assert_not_called()
        self.assertEqual(self.run.call_count, 1)


if __name__ == "__main__":
    unittest.main()
