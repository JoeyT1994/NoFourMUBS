"""Exact transformation checks; these do not admit physical symmetries."""
import unittest
from orbit_census import keys, permutations


class OrbitChecks(unittest.TestCase):
    def test_group_and_true_transports(self):
        self.assertEqual(len(permutations()), 8)
        b = dict(centers=['1','2','4','8'], radii=['1/10','1/20','1/30','1/40'])
        expected = keys(b)[2]
        for p in permutations():
            for s in (-1, 1):
                image = dict(centers=[str(s*int(b['centers'][i])) for i in p],
                             radii=[b['radii'][i] for i in p])
                self.assertEqual(keys(image)[2], expected)

    def test_independent_sign_flip_is_not_in_group(self):
        a = dict(centers=['1','2','4','8'], radii=['1/10']*4)
        b = dict(centers=['1','-2','4','8'], radii=['1/10']*4)
        self.assertNotEqual(keys(a)[2], keys(b)[2])

    def test_radii_are_part_of_exact_geometry(self):
        a = dict(centers=['1','2','4','8'], radii=['1/10']*4)
        b = dict(centers=['1','2','4','8'], radii=['1/10','1/10','1/10','1/20'])
        self.assertNotEqual(keys(a)[2], keys(b)[2])


if __name__ == '__main__':
    unittest.main()
