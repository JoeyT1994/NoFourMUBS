"""Bounded, separate-queue validation before migrating production checkpoints."""
from fractions import Fraction
from pathlib import Path
import argparse
import hashlib
import json
import os
import subprocess
import sys
import time

import task_queue as tq
import supervisor
import dispatch_hold
from node_safety_cache import enable_node_cache, prepare_node_cache


BASE_SOURCE_SHA256 = '2214dacc43ccd9b1db7d3b8fba3fe3ccaa8eeb5b83d74242748e5addd5dab731'
BASE_VALIDATION_SHA256 = '4b15e0f98a9b69af1bda2b5b517707b17f1c5f0c96e6a4c205739e1611fd9939'
EXPECTED_ADDED = {
    'BASE_2214_PINS.json', 'BASE_2214_VALIDATION_PASS.json', 'DISPATCH_HOLD.json',
    'DISPATCH_HOLD_INTEGRATION.md', 'DISPATCH_HOLD_SCOPE.json', 'dispatch_hold.py',
    'dispatch_hold_tests.py',
}
EXPECTED_CHANGED = {
    'README.md', 'audit_worker.py', 'benchmark.py', 'parent_roots.py', 'task_queue.py',
    'validate_release.py',
}


def inherited_base_validation(source, source_sha256):
    """Admit unchanged numerical machinery through the pinned 2214 receipt."""
    current = tq.read_json(source / 'PINS.json')
    base = tq.read_json(source / 'BASE_2214_PINS.json')
    added = set(current) - set(base)
    removed = set(base) - set(current)
    changed = {name for name in set(base) & set(current) if base[name] != current[name]}
    if added != EXPECTED_ADDED or changed != EXPECTED_CHANGED or removed:
        raise ValueError('Dispatch-hold release differs from its declared 2214 source delta')
    if tq.digest(current) != source_sha256 or tq.digest(base) != BASE_SOURCE_SHA256:
        raise ValueError('Current or inherited source pin digest changed')
    receipt_path = source / 'BASE_2214_VALIDATION_PASS.json'
    if tq.sha_file(receipt_path) != BASE_VALIDATION_SHA256:
        raise ValueError('Inherited 2214 validation receipt changed')
    receipt = tq.read_json(receipt_path)
    required_tests = {'queue_tests.py', 'v2_queue_tests.py', 'hint_cache_tests.py',
                      'migration_tests.py', 'supervisor_tests.py', 'cutover_tests.py',
                      'orbit_tests.py', 'normalized_audit_tests.py', 'combine_tests.py',
                      'safety_tests.py', 'advanced_protocol_tests.py'}
    if (receipt.get('status') != 'PASS' or receipt.get('source_sha256') != BASE_SOURCE_SHA256
            or receipt.get('physical_lean_admissions') != 0
            or set(receipt.get('tests', {})) != required_tests
            or any(value.get('status') != 'PASS' for value in receipt['tests'].values())
            or set(receipt.get('control_hashes', {})) != {
                'engine_tests.py', 'advanced_controls.py', 'cancellation_tests.py'}):
        raise ValueError('Inherited 2214 validation receipt lacks its complete admitted scope')
    return {'schema': 'inherited-release-validation-v1', 'status': 'PASS',
            'base_source_sha256': BASE_SOURCE_SHA256,
            'base_validation_sha256': BASE_VALIDATION_SHA256,
            'base_validation_slurm_job_id': receipt.get('slurm_job_id'),
            'unchanged_base_files': len(set(base) - changed),
            'added_files': sorted(added), 'changed_files': sorted(changed),
            'inherited_control_hashes': receipt['control_hashes'],
            'inherited_benchmark_sha256': receipt.get('benchmark_sha256'),
            'physical_lean_admissions': 0}


def parent_runnable(queue, key):
    parent = tq.read_json(queue.parent_dir(key) / 'SOURCE.json.gz')
    record = queue.parent_dispatch(parent)
    return parent, queue.dispatch_runnable(record)


def pilot(source, root, area, capacity, mode):
    children = []
    owners = []
    started = time.monotonic()
    try:
        for rank in range(capacity):
            owner = 'validation_' + os.environ['SLURM_JOB_ID'] + '_' + mode + '_' + str(rank)
            owners.append(owner)
            command = [sys.executable, '-B', str(source / 'worker.py'), '--root', str(root),
                       '--queue', str(area), '--cache', str(area / 'cache'),
                       '--schedule', str(source / 'SCHEDULE.json'), '--owner',
                       owner,
                       '--max-tasks', '1', '--' + mode + '-only']
            children.append(subprocess.Popen(command, cwd=root))
        # The CPU budgets remain unchanged. Shared-storage waits are not CPU
        # work: allow one bounded wall window for the complete descendant
        # pilot, rather than killing correct workers before their CPU slice.
        deadline = time.monotonic() + (1800 if mode == 'descendants' else 600)
        codes = [process.wait(timeout=max(0.001, deadline-time.monotonic()))
                 for process in children]
        if any(code != 0 for code in codes):
            raise RuntimeError('Bounded real-frontier ' + mode + ' validation failed')
        observations = []
        for owner in owners:
            status = tq.read_json(area / 'workers' / tq.digest(owner)[:24] / 'STATUS.json')
            if (status.get('owner') != owner or status.get('status') != 'WORKER_FINISHED'
                    or status.get('safety_paths', {}).get('shared_enabled') is not True):
                raise ValueError('Pilot did not exercise the node-local safety cache')
            observations.append(status)
        return dict(wall_seconds=time.monotonic()-started, workers=observations)
    finally:
        for process in children:
            if process.poll() is None:
                process.terminate()
                try:
                    process.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait(timeout=10)


def audit_ready(source, root, area, capacity):
    subprocess.run([sys.executable, '-B', str(source / 'audit_worker.py'), '--root', str(root),
                    '--queue', str(area), '--cache', str(area / 'cache'), '--jobs', str(capacity),
                    '--ready-only', '--max-parents', str(capacity), '--wall-seconds', '300',
                    '--parent-cpu-seconds', '120'], cwd=root, check=True, timeout=600)


def main(root, area, capacity):
    root, area = root.resolve(), area.resolve()
    area.mkdir(parents=True, exist_ok=True)
    source = Path(__file__).resolve().parent
    pinned = supervisor.verify_source()
    inherited = inherited_base_validation(source, pinned)
    tq.resource_guard(area)
    if not os.environ.get('SLURM_JOB_ID') or capacity > int(os.environ.get('SLURM_CPUS_PER_TASK', '0')):
        raise ValueError('Validation needs its allocated Slurm CPUs')
    # Check the actual node's local filesystem before spending CPU on controls.
    # Do not enable the cache in the environment until isolated tests finish.
    prepare_node_cache(pinned)
    results = {}
    for name in ('queue_tests.py', 'v2_queue_tests.py', 'dispatch_hold_tests.py', 'hint_cache_tests.py', 'migration_tests.py', 'supervisor_tests.py',
                 'cutover_tests.py', 'orbit_tests.py', 'normalized_audit_tests.py', 'combine_tests.py',
                 'safety_tests.py', 'advanced_protocol_tests.py'):
        result = subprocess.run([sys.executable, '-B', str(source / name)], cwd=root,
                                text=True, capture_output=True, timeout=120, check=True)
        results[name] = dict(status='PASS', output=result.stdout + result.stderr)
    # Engines, providers, cache implementation, worker, schedule, runtime and
    # formal sources are byte-identical to the fully validated 2214 release.
    # Do not rerun its inner synthetic cells under the stricter dispatch hold.
    control_hashes = inherited['inherited_control_hashes']
    queue = tq.TaskQueue(area)
    imported = []
    for _ in range(32):
        value = queue.import_finalized(root, chunk_leaves=32, batch_limit=8)
        imported.append(value)
        if queue.readiness_count() >= capacity or value['imported_batches'] == 0:
            break
    from bootstrap import bootstrap
    bootstrap(queue, source, source / 'SCHEDULE.json')
    local_safety_cache = enable_node_cache(pinned)
    pilot_stats = {'roots': pilot(source, root, area, capacity, 'roots')}
    audit_ready(source, root, area, capacity)
    pilot_stats['descendants'] = pilot(source, root, area, capacity, 'descendants')
    audit_ready(source, root, area, capacity)
    # This process did not produce any pilot leaves. Reinitialize both the
    # original frozen verifier and new providers before checking evidence.
    from audit_worker import ReplayRuntime
    runtime = ReplayRuntime(root, area / 'cache', 30, area=area)
    old_checked = new_checked = held_current_skipped = 0
    for key in queue.iter_parent_keys():
        parent, runnable = parent_runnable(queue, key)
        if not runnable:
            held_current_skipped += 1
            continue
        cc, rr = tq.exact_box(parent['input'])
        if not old_checked:
            for _, token, centers, radii in tq.walk_tree(parent['source_record']['tree'], cc, rr):
                if token in 'LS':
                    runtime.reset(time.process_time() + 120)
                    runtime.old_leaf(token, centers, radii)
                    old_checked += 1
                    break
        for line in (queue.parent_dir(key) / 'TASKS.jsonl').open('rb'):
            task_id = json.loads(line)['task_id']
            state = tq.read_json(queue.task_dir(task_id) / 'STATE.json.gz')
            for proof in state['proof_records'].values():
                runtime.reset(time.process_time() + 120)
                runtime.new_leaf(proof['evaluation'])
                new_checked += 1
                if new_checked >= 8:
                    break
            if new_checked >= 8:
                break
        if old_checked and new_checked >= 8:
            break
    # Read actual durable v1 C recipes while its workers continue. Atomic
    # checkpoints permit this read-only sample without acquiring search locks.
    legacy_checked = held_legacy_skipped = 0
    legacy_queue = tq.TaskQueue(root / 'survivor-run-a8f6c0e5659b')
    for index, directory in enumerate(legacy_queue.iter_task_dirs()):
        if index >= 4096 or legacy_checked >= 8:
            break
        task = tq.read_json(directory / 'TASK.json')
        parent = tq.read_json(legacy_queue.parent_dir(task['parent_key']) / 'SOURCE.json.gz')
        if (task.get('parent_key') != parent.get('parent_key')
                or task.get('input_sha256') != parent.get('input_sha256')
                or parent.get('input_sha256') != tq.digest(parent.get('input'))):
            raise ValueError('Legacy replay source binding changed')
        decision = dispatch_hold.classify(parent['input'])
        if decision['dispatch'] != 'RUN_WHOLE_PARENT_STRICTLY_OUTSIDE_HOLD':
            held_legacy_skipped += 1
            continue
        state = tq.read_json(directory / 'STATE.json.gz')
        for proof in state['proof_records'].values():
            runtime.reset(time.process_time() + 120)
            runtime.new_leaf(proof['evaluation'])
            legacy_checked += 1
            if legacy_checked >= 8:
                break
    if not old_checked or not legacy_checked:
        raise ValueError('No outside-hold frozen/v1 checkpoint was available for fresh replay')
    # The benchmark itself applies the same exact whole-box hold before starting
    # any provider. Inner and crossing saved geometries are recorded, not run.
    sample = root / 'survivor-benchmarks/2481673/INPUTS.json'
    if tq.sha_file(sample) != '83f3b0ba0110c76321e2b736664405b639bfe832df1f879bd8eb5b994e450877':
        raise ValueError('Pinned benchmark geometries changed')
    subprocess.run([sys.executable, '-B', str(source / 'benchmark.py'), '--root', str(root),
                    '--input', str(sample), '--cache', str(area / 'cache'),
                    '--output', str(area / 'benchmark'), '--jobs', str(capacity), '--cpu', '3',
                    '--methods', 'order3', 'order5', 'complement4', 'handoff_plain4',
                    'complement_face4', 'cancellation_order4', 'psd_ray'],
                   cwd=root, check=True, timeout=1200)
    # No manufactured success threshold: a hard pilot may close no leaf.
    # Exact accepted/rejected controls separately test evaluator acceptance.
    receipt = dict(status='PASS', source_sha256=pinned, tests=results, imports=imported,
                   pilot_statistics=pilot_stats, node_local_safety_cache=str(local_safety_cache),
                   validation_scope='OUTSIDE_DISPATCH_HOLD_ONLY', inherited_base_validation=inherited,
                   control_hashes=control_hashes, independently_checked_old_leaves=old_checked,
                   independently_checked_v1_recipes=legacy_checked, independently_checked_new_leaves=new_checked,
                   held_current_parents_skipped_without_evaluation=held_current_skipped,
                   held_legacy_tasks_skipped_without_evaluation=held_legacy_skipped,
                   benchmark_sha256=tq.sha_file(area / 'benchmark/RESULTS.json'),
                   benchmark_dispatch=tq.read_json(area / 'benchmark/DISPATCH_HOLD.json'),
                   dispatch=queue.dispatch_status(),
                   slurm_job_id=os.environ['SLURM_JOB_ID'], updated_unix=time.time(), physical_lean_admissions=0)
    tq.durable_json(area / 'VALIDATION_PASS.json', receipt)
    print(json.dumps(receipt, sort_keys=True))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--queue', type=Path, required=True)
    parser.add_argument('--capacity', type=int, default=8)
    args = parser.parse_args()
    if not __debug__ or not 1 <= args.capacity <= 8:
        raise ValueError('Validation bound exceeded')
    main(args.root, args.queue, args.capacity)
