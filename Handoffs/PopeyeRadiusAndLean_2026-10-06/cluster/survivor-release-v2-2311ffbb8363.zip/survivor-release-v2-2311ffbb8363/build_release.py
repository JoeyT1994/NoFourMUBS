"""Freeze a small source-only release; never package caches or numerical data."""
from pathlib import Path
import argparse
import hashlib
import json
import zipfile


def sha(data):
    return hashlib.sha256(data).hexdigest()


def build(source, output):
    source, output = Path(source).resolve(), Path(output).resolve()
    files = {}
    for path in sorted(source.rglob('*')):
        rel = path.relative_to(source)
        if path.is_symlink():
            raise ValueError('No symlinks in a frozen release: ' + str(rel))
        if not path.is_file() or any(part.startswith('.') or part in ('__pycache__', 'build', 'cache', 'formal')
                                     for part in rel.parts):
            continue
        if path.suffix not in ('.py', '.cpp', '.hpp', '.h', '.sbatch', '.json', '.md'):
            continue
        if (path.name == 'PINS.json'
                or (path.name.startswith('DEPLOYMENT') and path.suffix == '.json')):
            continue
        if path.stat().st_size > 4 * 2**20:
            raise ValueError('Unexpected large source: ' + str(rel))
        files[str(rel)] = path.read_bytes()
    # Ship the bounded formal sources and receipts explicitly, without copying
    # compiled objects, native caches or intermediate symbolic expressions.
    formal_manifest = source / 'formal/RELEASE_FILES.json'
    formal = json.loads(formal_manifest.read_text())
    for item in formal['files']:
        rel = Path(item['path'])
        if rel.is_absolute() or '..' in rel.parts:
            raise ValueError('Unsafe formal release path')
        path = source / rel
        if path.is_symlink() or path.stat().st_size > 4 * 2**20:
            raise ValueError('Unbounded formal artifact')
        data = path.read_bytes()
        if sha(data) != item['sha256']:
            raise ValueError('Formal source or receipt changed: ' + str(rel))
        files[str(rel)] = data
    files['formal/RELEASE_FILES.json'] = formal_manifest.read_bytes()
    required = {'engines.py', 'worker.py', 'task_queue.py', 'supervisor.py', 'audit_worker.py',
                'SCHEDULE.json', 'legacy/engines.py', 'coordinator.sbatch', 'validate_release.py',
                'safety_paths.py', 'node_safety_cache.py'}
    if not required <= files.keys():
        raise ValueError('Release is missing required code')
    if sum(map(len, files.values())) > 32 * 2**20:
        raise ValueError('Source release exceeds its 32 MiB bound')
    pins = {name: sha(data) for name, data in files.items()}
    canonical = json.dumps(pins, sort_keys=True, separators=(',', ':')).encode()
    release = 'survivor-release-v2-' + sha(canonical)[:12]
    files['PINS.json'] = json.dumps(pins, indent=2, sort_keys=True).encode() + b'\n'
    output.mkdir(parents=True, exist_ok=True)
    target = output / (release + '.zip')
    if target.exists():
        raise FileExistsError(target)
    with zipfile.ZipFile(target, 'x', compression=zipfile.ZIP_DEFLATED) as z:
        for name, data in files.items():
            info = zipfile.ZipInfo(release + '/' + name, date_time=(2026, 10, 5, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            z.writestr(info, data)
    result = dict(release=release, archive=str(target), archive_sha256=sha(target.read_bytes()),
                  source_sha256=sha(canonical), files=len(pins), uncompressed_bytes=sum(map(len, files.values())),
                  archive_bytes=target.stat().st_size, physical_lean_admissions=0)
    target.with_suffix('.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, sort_keys=True))
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    build(args.source, args.output)
