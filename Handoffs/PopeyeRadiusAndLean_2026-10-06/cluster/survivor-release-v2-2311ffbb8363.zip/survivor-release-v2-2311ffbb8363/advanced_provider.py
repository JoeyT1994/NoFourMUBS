"""Pinned complement, monotonic-face, plain handoff and rational PSD witnesses.

All predicates use whole-box bounds. The old 3/50 admission radius is absent:
strict-D0 maximality is the explicit physical interface, not a radius theorem.
"""
from fractions import Fraction as Q
from pathlib import Path
import ctypes
import fcntl
import hashlib
import json
import math
import os
import subprocess
import time

HERE = Path(__file__).resolve().parent
METHODS = ("complement4", "complement_face4", "handoff_plain4", "psd_ray")


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def diagnostic(scores, radii, kind):
    values = [max(0.0,float(x)) for x in scores]
    if not all(math.isfinite(x) for x in values):
        raise ArithmeticError("Nonfinite split influence")
    total = sum(values)
    axis = max(range(4),key=lambda k:(values[k],radii[k]))
    return {"axis":axis,"score":values[axis]/total if total else 0.0,
            "kind":kind,"influences":values,"acceptance_role":"none"}


def decode_plain(status, out):
    def require(test,reason):
        if not test:
            raise ArithmeticError(reason)
    def pair(k):
        require(out[k]<=out[k+1],"Reversed plain interval")
        return out[k:k+2]
    def integer(k,values):
        require(out[k] in values,"Invalid plain discrete witness")
        return int(out[k])
    require(all(math.isfinite(x) for x in out),"Nonfinite plain witness")
    pair(0)
    if status==1:
        require(out[1]<=0,"Invalid R witness")
        return "R_nonpositive"
    if status in (2,4):
        require(out[1]<243,"Missing matching guard")
        integer(2,range(3));integer(3,range(3))
    if status==2:
        integer(4,(-1,1));integer(5,(-1,1))
        for k in (6,8,10):
            pair(k);require(out[k]>0,"Invalid product margin")
        return "coherent_product"
    if status in (0,3):
        hm,vm=integer(2,range(4)),integer(3,range(4))
        if status==3:
            require(hm==3 or vm==3 or (out[1]<243 and ((hm&1) or (vm&2)) and ((hm&2) or (vm&1))),"Incomplete sign cover")
        for mask,offset in ((hm,16),(vm,34)):
            for sg in range(2):
                if not mask&(1<<sg):
                    continue
                k=offset+sg*9
                integer(k,range(3));integer(k+1,(-1,1));kind=integer(k+2,(1,2,3))
                a,b,m=pair(k+3),pair(k+5),pair(k+7)
                require((kind==1 and a[0]>=0 and b[0]>=0 and (a[0]>0 or b[0]>0)) or
                        (kind==2 and a[0]>0 and m[0]>0) or (kind==3 and b[0]>0 and m[0]>0),"Invalid signed margin")
        return "linear_sign_cover" if status==3 else "unresolved_plain"
    if status==4:
        branch=integer(4,(0,1))
        if branch==0:
            h,rhs=pair(5),pair(7)
            require(rhs[0]>=0 and (h[0]>rhs[1] or -h[1]>rhs[1]),"Invalid A elimination")
        else:
            for k in (5,6,7):integer(k,(-1,1))
            pair(8);require(out[8]>0,"Invalid A gap")
        return "A_elimination"
    if status==5:
        pair(2);require(out[3]<0,"Invalid complementary comparison")
        return "complementary_corner"
    raise ArithmeticError("Unknown plain status")


class Provider:
    def __init__(self, root, cache, frozen):
        self.root,self.c=Path(root),frozen
        source=HERE/"advanced_engine.cpp"
        common={"advanced_provider_sha256":sha(__file__),"advanced_native_sha256":sha(source),
                "plain_source_sha256":sha(HERE/"advanced_src/plain_constraint.cpp"),
                "frozen_driver_sha256":sha(frozen.__file__),
                "interval_source_sha256":sha(frozen.MODULE.parent/"SignedCornerPSDPrune/engine.cpp"),
                "determinant_terms_sha256":sha(frozen.MODULE.parent/"SignedCornerPSDPrune/determinant_terms.hpp"),
                "taylor_source_sha256":sha(frozen.MODULE/"taylor.hpp")}
        key=hashlib.sha256(json.dumps(common,sort_keys=True).encode()).hexdigest()[:24]
        directory=Path(cache)/("advanced-"+key);directory.mkdir(parents=True,exist_ok=True)
        binary=directory/"advanced_order4.so";receipt=binary.with_suffix(".build.json")
        with (directory/"BUILD.lock").open("a") as lock:
            fcntl.flock(lock,fcntl.LOCK_EX)
            if not binary.exists():
                tmp=binary.with_name(binary.name+"."+str(os.getpid())+".tmp.so")
                cmd=["c++","-std=c++17","-O3","-fno-fast-math","-ffp-contract=off","-fPIC","-shared","-DTM_ORDER=4",str(source),"-o",str(tmp)]
                try:
                    subprocess.run(cmd,check=True,capture_output=True,text=True,timeout=90)
                    info=dict(common,binary_sha256=sha(tmp),command=cmd,
                              compiler_sha256=hashlib.sha256(subprocess.check_output(["c++","--version"])).hexdigest())
                    os.replace(tmp,binary)
                    temp=receipt.with_suffix(".tmp");temp.write_text(json.dumps(info,sort_keys=True));os.replace(temp,receipt)
                finally:
                    tmp.unlink(missing_ok=True)
            info=json.loads(receipt.read_text())
            if any(info.get(k)!=v for k,v in common.items()) or info.get("binary_sha256")!=sha(binary):
                raise ValueError("Advanced provider pins differ")
        self.lib=ctypes.CDLL(str(binary));dp=ctypes.POINTER(ctypes.c_double)
        for name in ("local_region","local_coefficients","advanced_rays","advanced_ray_control","advanced_elimination_control"):
            fn=getattr(self.lib,name);fn.argtypes=[dp,dp];fn.restype=ctypes.c_int
        self.lib.advanced_cheap.argtypes=[dp,dp,ctypes.c_int];self.lib.advanced_cheap.restype=ctypes.c_int
        self.lib.set_budget.argtypes=[ctypes.c_double];self.lib.set_budget.restype=None
        self.pins={method:{k:v for k,v in info.items() if k.endswith("sha256")} for method in METHODS}

    def _data(self, cc, rr):
        return sum((self.c.phase(x) for x in cc),[])+[self.c.up(x) for x in rr]

    def _call(self, name, cc, rr, count, deadline, Budget, *extra):
        data=self._data(cc,rr);remaining=deadline-time.process_time()
        if remaining<=0:raise Budget("cpu_budget")
        self.lib.set_budget(remaining)
        output=(ctypes.c_double*count)()
        status=getattr(self.lib,name)((ctypes.c_double*20)(*data),output,*extra)
        if status==-2:raise Budget("native_cpu_budget")
        if status<0:raise ArithmeticError(name+" arithmetic status "+str(status))
        values=list(output)
        if not all(math.isfinite(x) for x in values):raise ArithmeticError("Nonfinite advanced output")
        return status,values

    def evaluate(self, cc, rr, method, deadline, Budget):
        if method=="handoff_plain4":
            status,out=self._call("local_region",cc,rr,64,deadline,Budget)
            reason=decode_plain(status,out)
            exclusions=[]
            if status in (0,3):
                for orientation,k in ((False,2),(True,3)):
                    if out[k] not in (0,1,2,3):raise ArithmeticError("Invalid partial mask")
                    for bit,sigma in ((1,1),(2,-1)):
                        if int(out[k])&bit:exclusions.append({"orientation":orientation,"sigma":sigma})
            split=diagnostic(out[12:16],rr,"plain_polynomial_influence")
            return dict(ok=status>0,reason=reason,native_status=status,output_hex=[x.hex() for x in out],
                        exclusions=exclusions,non_tao=out[1]<243,R_upper=str(Q(out[1])),
                        axis=split["axis"],split_diagnostic=split)
        if method=="psd_ray":
            return self._rays(cc,rr,deadline,Budget)
        status,out=self._call("advanced_cheap",cc,rr,20,deadline,Budget,int(method=="complement_face4"))
        if status!=20 or any(out[k]>out[k+1] for k in (*range(0,8,2),*range(12,20,2))):
            raise ArithmeticError("Malformed complement bounds")
        reason="R_nonpositive" if out[5]<=0 else "complementary_corner" if out[7]<0 else "negative_J_maximality" if out[1]<1 and out[3]<0 else "unresolved_complement"
        split=diagnostic(out[8:12],rr,"complement_polynomial_influence")
        result=dict(ok=reason!="unresolved_complement",reason=reason,output_hex=[x.hex() for x in out],
                    axis=split["axis"],split_diagnostic=split,non_tao=out[5]<243,R_upper=str(Q(out[5])))
        if result["ok"] or method!="complement_face4":return result
        face_c,face_r=list(cc),list(rr);faces=[]
        for i in range(4):
            lo,hi=out[12+2*i:14+2*i]
            direction=1 if lo>=0 else -1 if hi<=0 else 0
            if direction and abs(cc[i]+direction*rr[i])<4:
                face_c[i]+=direction*rr[i];face_r[i]=Q(0);faces.append([i,direction])
        if not faces:return result
        status,face=self._call("advanced_cheap",face_c,face_r,20,deadline,Budget,0)
        if status!=20 or face[6]>face[7]:raise ArithmeticError("Malformed monotonic face")
        result.update(face={"centers":list(map(str,face_c)),"radii":list(map(str,face_r)),"directions":faces,
                            "output_hex":[x.hex() for x in face]})
        if face[7]<0:result.update(ok=True,reason="monotonic_complement_face")
        return result

    @staticmethod
    def _sqrt_bounds(q):
        scale=1<<128
        n=math.isqrt((q.numerator*scale*scale)//q.denominator)
        return Q(n,scale),Q(n+1,scale)

    def _rays(self,cc,rr,deadline,Budget):
        providers=[];exclusions=[];all_R=[]
        for orientation in (False,True):
            perm=(0,2,1,3) if orientation else (0,1,2,3)
            status,out=self._call("advanced_rays",[cc[k] for k in perm],[rr[k] for k in perm],470,deadline,Budget)
            if status not in (2,470) or out[0]>out[1]:raise ArithmeticError("Malformed ray provider")
            record={"orientation":orientation,"output_hex":[x.hex() for x in out[:status]],"covers":[]}
            providers.append(record);all_R.append(Q(out[1]))
            if out[1]<=0:return dict(ok=True,reason="R_nonpositive",providers=providers)
            qlo=self._sqrt_bounds(max(Q(0),Q(out[0])))[0];qhi=self._sqrt_bounds(Q(out[1]))[1]
            candidates=[]
            for k in range(2,470,13):
                row=out[k:k+13]
                if row[0] not in (0,1,2) or row[1] not in (-1,1) or row[2] not in (-1,1) or row[9]>row[10] or row[11]>row[12]:
                    raise ArithmeticError("Malformed rational ray witness")
                candidates.append(row)
            for sigma in (-1,1):
                stack=[(qlo,qhi,0)];cover=[]
                while stack:
                    if time.process_time()>=deadline:raise Budget("cpu_budget")
                    lo,hi,depth=stack.pop();found=None
                    for index,row in enumerate(candidates):
                        if row[1]!=sigma:continue
                        upper=max(Q(row[10])+lo*Q(row[12]),Q(row[10])+hi*Q(row[12]))
                        if upper<0:found={"interval":[str(lo),str(hi)],"candidate":index,"upper":str(upper)};break
                    if found is not None:cover.append(found);continue
                    if depth>=4:break
                    mid=(lo+hi)/2;stack.extend(((mid,hi,depth+1),(lo,mid,depth+1)))
                else:
                    exclusions.append({"orientation":orientation,"sigma":sigma})
                    record["covers"].append({"sigma":sigma,"leaves":cover})
        non_tao=min(all_R)<243
        masks={False:set(),True:set()}
        for item in exclusions:masks[item["orientation"]].add(item["sigma"])
        matched={-s if o else s for o,signs in masks.items() for s in signs}
        ok=any(len(signs)==2 for signs in masks.values()) or (non_tao and matched=={-1,1})
        return dict(ok=ok,reason="rational_quadratic_PSD" if ok else "unresolved_rational_PSD",providers=providers,
                    exclusions=exclusions,non_tao=non_tao,R_upper=str(min(all_R)),axis=max(range(4),key=lambda k:rr[k]))
