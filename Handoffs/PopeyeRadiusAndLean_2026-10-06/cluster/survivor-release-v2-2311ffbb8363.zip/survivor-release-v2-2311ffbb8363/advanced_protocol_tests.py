"""No-build decoder regressions; native RHS containment is in advanced_controls."""
import math
import unittest

from advanced_provider import decode_plain


class EliminationProtocolTests(unittest.TestCase):
    def witness(self, sign=1):
        out=[0.]*64
        out[1]=1.  # independently required whole-box R<243 guard
        out[5:7]=[2.,3.] if sign==1 else [-3.,-2.]
        out[7:9]=[0.,1.]
        return out

    def test_positive_and_negative_strict_comparisons(self):
        for sign in (-1,1):
            self.assertEqual(decode_plain(4,self.witness(sign)),"A_elimination")

    def test_outward_zero_lower_endpoint_remains_fatal(self):
        out=self.witness();out[7]=-3*math.ulp(0.)
        with self.assertRaisesRegex(ArithmeticError,"Invalid A elimination"):
            decode_plain(4,out)
        # The native fix proves nonnegativity and retains this same upper bound.
        upper=out[8].hex();out[7]=0.
        self.assertEqual(decode_plain(4,out),"A_elimination")
        self.assertEqual(out[8].hex(),upper)

    def test_strict_boundary_is_not_accepted(self):
        for sign in (-1,1):
            out=self.witness(sign);out[5:7]=[float(sign)]*2
            with self.assertRaisesRegex(ArithmeticError,"Invalid A elimination"):
                decode_plain(4,out)

    def test_crossing_zero_does_not_prove_absolute_lower(self):
        out=self.witness();out[5:7]=[-3.,3.]
        with self.assertRaisesRegex(ArithmeticError,"Invalid A elimination"):
            decode_plain(4,out)

    def test_zero_rhs_requires_strictly_nonzero_h(self):
        out=self.witness();out[7:9]=[0.,0.];out[5:7]=[math.ulp(0.)]*2
        self.assertEqual(decode_plain(4,out),"A_elimination")
        out[5:7]=[0.,0.]
        with self.assertRaises(ArithmeticError):decode_plain(4,out)

    def test_reversed_rhs_is_fatal(self):
        out=self.witness();out[7:9]=[1.,0.]
        with self.assertRaisesRegex(ArithmeticError,"Reversed plain interval"):
            decode_plain(4,out)

    def test_nonfinite_witness_is_fatal(self):
        for value in (math.inf,-math.inf,math.nan):
            out=self.witness();out[8]=value
            with self.assertRaisesRegex(ArithmeticError,"Nonfinite plain witness"):
                decode_plain(4,out)

    def test_matching_guard_remains_strict(self):
        for high in (243.,244.):
            out=self.witness();out[1]=high
            with self.assertRaisesRegex(ArithmeticError,"Missing matching guard"):
                decode_plain(4,out)

    def test_pair_and_branch_identifiers_are_checked(self):
        for index,value in ((2,3.),(3,-1.),(4,2.)):
            out=self.witness();out[index]=value
            with self.assertRaisesRegex(ArithmeticError,"Invalid plain discrete witness"):
                decode_plain(4,out)

    def test_gap_branch_keeps_its_positive_margin_guard(self):
        out=self.witness();out[4]=1.;out[5:8]=[1.,-1.,1.];out[8:10]=[1.,2.]
        self.assertEqual(decode_plain(4,out),"A_elimination")
        out[8]=0.
        with self.assertRaisesRegex(ArithmeticError,"Invalid A gap"):
            decode_plain(4,out)


if __name__=="__main__":unittest.main()
