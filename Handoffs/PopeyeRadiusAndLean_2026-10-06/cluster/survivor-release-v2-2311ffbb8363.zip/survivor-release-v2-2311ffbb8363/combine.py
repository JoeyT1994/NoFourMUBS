"""Extend the frozen conditional export ledger with freshly replayed roots.

Historical audits and certificates are never modified. This does not discharge
the accepted external mathematical inputs or create a physical Lean theorem.
"""
from array import array
from pathlib import Path
import argparse
import gzip
import json
import os
import sys
import time

import task_queue as tq


def lines(path):
    with gzip.open(path, 'rb') as stream:
        while True:
            line = stream.readline(65537)
            if not line:
                break
            if len(line) > 65536:
                raise ValueError('Ledger row exceeds its memory bound')
            yield json.loads(line)


def combine(root, area):
    root, area = Path(root).resolve(), Path(area).resolve()
    tq.resource_guard(area)
    old_path = root / 'COMBINED_FINAL_AUDIT.json'
    main_path = root / 'production/FINAL_AUDIT.json'
    if not old_path.exists() or not main_path.exists():
        raise FileNotFoundError('The original campaign has not yet published its final audit')
    old, main = tq.read_json(old_path), tq.read_json(main_path)
    if old.get('main_audit_sha256') != tq.sha_file(main_path):
        raise ValueError('Original combined audit is not bound to the main audit')
    config = tq.read_json(root / 'production/CONFIG.json')
    if main['campaign_sha256'] != config['campaign_sha256']:
        raise ValueError('Original final audit belongs to a different campaign')
    supplement_path = root / 'scope-correction/FINAL_AUDIT.json'
    supplement = tq.read_json(supplement_path)
    if old['supplemental_audit_sha256'] != tq.sha_file(supplement_path):
        raise ValueError('Supplemental final audit changed')
    if supplement['accepted'] != 1857 or supplement['unresolved_ids'] or old['unresolved'] != main['unresolved']:
        raise ValueError('The full sheet-scope supplement must remain closed')
    fresh_path = area / 'FINAL_AUDIT.json'
    fresh = tq.read_json(fresh_path)
    ids_path = area / 'CLOSED_NATIVE_IDS.jsonl.gz'
    if fresh['closed_native_ids']['sha256'] != tq.sha_file(ids_path):
        raise ValueError('Freshly replayed native ID ledger changed')
    if fresh['production_config_sha256'] != tq.sha_file(root / 'production/CONFIG.json'):
        raise ValueError('Fresh audit belongs to another campaign')
    queue = tq.TaskQueue(area)
    original_roots = {}
    plan = tq.read_json(root / 'elastic-run/PLAN.json')
    plan_sha = tq.sha_file(root / 'elastic-run/PLAN.json')
    if 'elastic_plan_sha256' in old and old['elastic_plan_sha256'] != plan_sha:
        raise ValueError('Original final audit uses a different batch plan')
    batch_ids = set()
    source_counts = dict(records=0, parents=0, skipped=0, already_closed=0)
    for entry in plan['batches']:
        bid = entry['batch']
        if bid in batch_ids:
            raise ValueError('Duplicate planned source batch')
        batch_ids.add(bid)
        commit = tq.read_json(area / 'batches' / f'{bid:06d}.json')
        done = root / 'elastic-run/batches' / f'{bid // 1000:03d}/{bid:06d}/DONE.json'
        if commit['done_sha256'] != tq.sha_file(done):
            raise ValueError('Original final batch coverage changed')
        done_value = tq.read_json(done)
        if commit['records'] != done_value['n']:
            raise ValueError('Committed source record census differs')
        source_counts['records'] += commit['records']
        source_counts['parents'] += commit['parents']
        source_counts['skipped'] += commit['skipped_non_native']
        source_counts['already_closed'] += commit['records'] - commit['parents'] - commit['skipped_non_native']
    if (fresh['missing_source_batches'] != 0 or fresh['committed_source_batches'] != len(batch_ids)
            or fresh['source_records_in_committed_batches'] != source_counts['records']
            or fresh['source_already_closed_records'] != source_counts['already_closed']
            or fresh['skipped_non_native_records'] != source_counts['skipped']):
        raise ValueError('Fresh source batch/record census differs from the committed cover')
    for key in queue.iter_parent_keys():
        parent = tq.read_json(queue.parent_dir(key) / 'SOURCE.json.gz')
        ident = parent['input']['id']
        if ident in original_roots:
            raise ValueError('Duplicate imported native parent')
        original_roots[ident] = key
    if len(original_roots) != fresh['original_roots'] or len(original_roots) != source_counts['parents']:
        raise ValueError('Final audit omitted an imported root')
    accepted = set()
    for item in lines(ids_path):
        ident = item['id']
        if ident in accepted or original_roots.get(ident) != item['parent_key']:
            raise ValueError('New closure does not name a unique imported root')
        receipt = tq.read_json(queue.parent_dir(item['parent_key']) / 'FINAL_REPLAY.json')
        body = {k: v for k, v in receipt.items() if k != 'receipt_sha256'}
        if (item['receipt_sha256'] != receipt.get('receipt_sha256') or tq.digest(body) != item['receipt_sha256']
                or receipt.get('status') != 'PASS' or receipt.get('closed') is not True
                or receipt.get('id') != ident or receipt.get('parent_key') != item['parent_key']
                or receipt.get('audit') != 'FRESH_ALL_LEAVES_PASS'):
            raise ValueError('New native closure lacks its final replay receipt')
        accepted.add(ident)
    if len(accepted) != fresh['original_roots_closed']:
        raise ValueError('Fresh native closure count differs')
    if len(accepted) != fresh['closed_native_ids']['count']:
        raise ValueError('Fresh native ID stream count differs')
    run_pins = root / 'campaign/RUN_PINS.json'
    if tq.sha_file(run_pins) != config['run_pins_sha256']:
        raise ValueError('Frozen run manifest changed')
    selection_path = root / 'campaign/selection.u32le'
    selection_sha = tq.sha_file(selection_path)
    expected_sha = next(x['sha256'] for x in tq.read_json(run_pins)['files'] if x['path'] == 'campaign/selection.u32le')
    if selection_sha != expected_sha:
        raise ValueError('Exact conjugation selection changed')
    selection = array('I')
    if selection.itemsize != 4:
        raise ValueError('Unsupported unsigned integer representation')
    with selection_path.open('rb') as stream:
        selection.frombytes(stream.read())
    if sys.byteorder != 'little':
        selection.byteswap()
    if len(selection) != main['original_inputs'] or old['original_inputs'] != len(selection):
        raise ValueError('Input census differs from frozen exact selection')
    if any(v['conditionally_accounted_for'] + v['unresolved'] != len(selection) for v in (old, main)):
        raise ValueError('Original final accounting is inconsistent')
    # Reconstruct every old unresolved original ID from the complete imported
    # native-root census and the exact selection map. Counts alone are not
    # sufficient to establish this coverage.
    old_unresolved_path = root / 'production/UNRESOLVED.jsonl.gz'
    old_unresolved_sha = tq.sha_file(old_unresolved_path)
    old_rows = iter(lines(old_unresolved_path))
    remaining_path = area / 'UNRESOLVED_ORIGINALS.jsonl.gz'
    temporary = remaining_path.with_suffix('.tmp')
    seen = newly_closed = remaining = native_representatives = 0
    with gzip.open(temporary, 'wb', compresslevel=3) as output:
        for ident, encoded in enumerate(selection):
            rep = encoded & 0x7fffffff
            if not 0 <= rep < len(selection) or selection[rep] != rep or bool(encoded & 0x80000000) != (ident != rep):
                raise ValueError('Invalid exact conjugate selection')
            native_representatives += ident == rep
            if rep not in original_roots:
                continue
            row = next(old_rows, None)
            if row is None or row['id'] != ident or row['representative'] != rep:
                raise ValueError('Old unresolved ledger differs from the imported exact cover')
            seen += 1
            if rep in accepted:
                newly_closed += 1
            else:
                remaining += 1
                output.write(tq.canonical(row) + b'\n')
    if next(old_rows, None) is not None or seen != main['unresolved']:
        raise ValueError('Old unresolved census was not covered exactly')
    if native_representatives - main['native_replayed_representatives'] - main['accepted_handoff_representatives'] != len(original_roots):
        raise ValueError('Native-root coverage is incomplete')
    if tq.sha_file(old_unresolved_path) != old_unresolved_sha:
        raise ValueError('Original unresolved input changed during accounting')
    with temporary.open('rb') as handle:
        os.fsync(handle.fileno())
    os.replace(temporary, remaining_path)
    tq._fsync_dir(area)
    report = dict(status='CONDITIONAL_EXPORT_CLOSED' if remaining == 0 else 'CONDITIONAL_EXPORT_STILL_OPEN',
                  original_inputs=len(selection), conditionally_accounted_for=len(selection) - remaining,
                  unresolved=remaining, newly_replayed_native_roots=len(accepted),
                  newly_accounted_original_inputs=newly_closed, unresolved_native_roots=len(original_roots) - len(accepted),
                  preserved_supplemental_all_completion_certificates=1857,
                  original_combined_audit_sha256=tq.sha_file(old_path), survivor_audit_sha256=tq.sha_file(fresh_path),
                  original_unresolved_ids_sha256=old_unresolved_sha, original_elastic_plan_sha256=plan_sha,
                  remaining_original_ids_sha256=tq.sha_file(remaining_path), selection_sha256=selection_sha,
                  scope='Exact supplied export under the same accepted external mathematical inputs. Global physical Lean theorem remains separate.',
                  updated_unix=time.time(), physical_lean_admissions=0)
    tq.durable_json(area / 'COMBINED_FINAL_AUDIT.json', report)
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--queue', type=Path, required=True)
    args = parser.parse_args()
    if not __debug__:
        raise ValueError('Optimized Python is forbidden')
    print(json.dumps(combine(args.root, args.queue), sort_keys=True))
