"""One bounded numerical survivor worker; scheduling/deployment live elsewhere.

Every accepted new leaf is freshly replayed with its exact original method and
provider pins before its C token and compact recipe enter one atomic compressed
checkpoint.  Inherited phase, disk, memory, depth and forest guards are stops.
Arithmetic failures are fatal and cannot be converted to retry budgets.
"""
from __future__ import annotations

from fractions import Fraction as Q
from pathlib import Path
import argparse
import json
import math
import os
import resource
import signal
import sys
import time
import traceback

if __package__:
    from . import task_queue as tq
    from . import engines
    from . import safety_paths
    from .frontier import Frontier, select_axis
    from .reuse_store import PartialStore, CertificateHints, pool_may_close
else:
    import task_queue as tq
    import engines
    import safety_paths
    from frontier import Frontier, select_axis
    from reuse_store import PartialStore, CertificateHints, pool_may_close

STOP = False
CPU_REASONS = {"cpu_budget", "native_cpu_budget"}
HINT_CACHE = None
SAFETY_PATHS = safety_paths.SafetyPaths()


def stop(signum, frame):
    global STOP
    STOP = True


def _seconds(value, name, maximum=600):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or not 0 < value <= maximum:
        raise ValueError(name + " must be finite and in (0," + str(maximum) + "]")
    return float(value)


def load_schedule(path=None, cpu_seconds=None, replay_cpu_seconds=None):
    """Accept benchmark-selected methods with explicit bounded per-call budgets."""
    raw = tq.read_json(path) if path else {"methods": ["order3", "order4", "order5"]}
    if isinstance(raw, list):
        raw = {"methods": raw}
    values = raw.get("methods", raw.get("schedule"))
    if not isinstance(values, list) or not 1 <= len(values) <= 16:
        raise ValueError("Schedule needs 1 through 16 method steps")
    methods = []
    for item in values:
        item = {"method": item, "cpu_seconds": 2} if isinstance(item, str) else dict(item)
        if item.get("method") not in engines.METHODS:
            raise ValueError("Unknown scheduled method")
        step = {"method": item["method"], "cpu_seconds": _seconds(item.get("cpu_seconds", 2), "method budget")}
        for field, default in (("min_depth", 0), ("max_depth", tq.MAX_DEPTH), ("every_depth", 1)):
            value = item.get(field, default)
            minimum = 1 if field == "every_depth" else 0
            if type(value) is not int or not minimum <= value <= tq.MAX_DEPTH:
                raise ValueError("Invalid absolute depth schedule gate: " + field)
            step[field] = value
        if step["min_depth"] > step["max_depth"]:
            raise ValueError("Schedule gate has an empty depth interval")
        initial = item.get("initial_frontier_only", False)
        if type(initial) is not bool:
            raise ValueError("Initial frontier schedule gate must be boolean")
        step["initial_frontier_only"] = initial
        methods.append(step)
    attempts = raw.get("max_task_attempts", 5)
    if type(attempts) is not int or not 1 <= attempts <= 100:
        raise ValueError("Task attempts need a finite bound")
    protected = raw.get("protected_points", [])
    if not isinstance(protected, list) or len(protected) > 64:
        raise ValueError("Protected seed list exceeds its bound")
    points = []
    for point in protected:
        if not isinstance(point, list) or len(point) != 4:
            raise ValueError("A protected seed needs four exact radians coordinates")
        point = list(map(Q, point))
        if any(abs(q) >= 4 for q in point):
            raise ValueError("Protected seed lies outside the phase guard")
        points.append(list(map(str, point)))
    root_methods = raw.get("root_methods")
    if root_methods is None:
        seen = set()
        root_methods = []
        for step in methods:
            if step["method"] not in seen and (step["min_depth"] == 0 or step["initial_frontier_only"]):
                root_methods.append({"method": step["method"], "cpu_seconds": step["cpu_seconds"]})
                seen.add(step["method"])
    if not isinstance(root_methods, list) or len(root_methods) > 16:
        raise ValueError("Unbounded whole-root method schedule")
    root_methods = [{"method": s["method"], "cpu_seconds": _seconds(s.get("cpu_seconds", 2), "root method budget")}
                    for s in root_methods]
    if any(s["method"] not in engines.METHODS for s in root_methods):
        raise ValueError("Unknown whole-root method")
    reuse_candidates = raw.get("reuse_candidates", 2)
    if type(reuse_candidates) is not int or not 0 <= reuse_candidates <= 16:
        raise ValueError("Unbounded certificate reuse")
    for flag in ("whole_root", "certificate_reuse", "partial_composition"):
        if type(raw.get(flag, True)) is not bool:
            raise ValueError("Invalid schedule switch: " + flag)
    return {"schema": 2, "methods": methods, "root_methods": root_methods,
            "whole_root": raw.get("whole_root", True),
            "certificate_reuse": raw.get("certificate_reuse", True), "reuse_candidates": reuse_candidates,
            "partial_composition": raw.get("partial_composition", True),
            "composition_cpu_seconds": _seconds(raw.get("composition_cpu_seconds", 2), "composition budget"),
            "root_cpu_seconds": _seconds(raw.get("root_cpu_seconds", 30), "whole root budget"),
            "root_max_attempts": min(attempts, 2),
            "task_cpu_seconds": _seconds(cpu_seconds if cpu_seconds is not None else raw.get("task_cpu_seconds", 30), "task budget"),
            "replay_cpu_seconds": _seconds(replay_cpu_seconds if replay_cpu_seconds is not None else raw.get("replay_cpu_seconds", 30), "replay budget"),
            "max_task_attempts": attempts, "protected_points": points,
            "physical_lean_admissions": 0}


def stop_requested(root, queue):
    if STOP:
        return True
    root, area = safety_paths.absolute(root), safety_paths.absolute(queue.area)
    key = (root, area)
    if SAFETY_PATHS.latched(key) is not None:
        return True
    paths = (area / "STOP_REQUESTED.json", area / "FAILURE.json",
                 root / "production/FAILURE.json", root / "elastic-run/FAILURE.json",
                 root / "elastic-run/STOP_REQUESTED.json", root / "elastic-run/output/STOP_REQUESTED.json")
    legacy = root / "production/STOP_REQUESTED.json"
    present = SAFETY_PATHS.present((*paths, legacy), anchors=SAFETY_PATHS.verified_anchors(root, area))
    for path in paths:
        if path in present:
            SAFETY_PATHS.latch(key, str(path))
            return True
    # The frozen production stop is a permanent, explicitly authorized handover
    # barrier.  Any other production stop still stops this continuation.
    if legacy in present and tq.read_json(legacy).get("reason") != "authorized_elastic_handover":
        SAFETY_PATHS.latch(key, str(legacy))
        return True
    return False


def _replace_pending(tree, prefix, path, replacement):
    stack = [prefix]
    for index, token in enumerate(tree):
        if not stack:
            raise ValueError("Malformed subtree while replacing a pending leaf")
        current = stack.pop()
        if current == path:
            if token != "P":
                raise ValueError("Attempt to replace an accepted leaf or a split")
            return tree[:index] + replacement + tree[index + 1:]
        if token in "0123":
            stack.extend((current + "1", current + "0"))
    raise ValueError("Method cursor lost its pending leaf")


def _pending(lease):
    wanted = lease.state["cursor"]["path"] if lease.state.get("cursor") else None
    first = None
    for initial, root in zip(lease.task["roots"], lease.state["roots"]):
        for path, token, centers, radii in tq.walk_tree(root["tree"], list(map(Q, initial["centers"])),
                                                      list(map(Q, initial["radii"])), initial["prefix"],
                                                      new=True, max_nodes=tq.MAX_TASK_NODES):
            if token != "P":
                continue
            item = (root, path, centers, radii)
            if first is None:
                first = item
            if wanted == path:
                return item
    if wanted is not None:
        raise ValueError("Saved method cursor does not name a pending leaf")
    return first


def _resource_reason(reason):
    return tq._parked_reason(reason) or reason in ("worker_peak_rss_512MiB", "disk_reserve_8GiB")


def _eligible(step, path, initial_prefix):
    depth = len(path)
    return (step.get("min_depth", 0) <= depth <= step.get("max_depth", tq.MAX_DEPTH)
            and depth % step.get("every_depth", 1) == 0
            and (not step.get("initial_frontier_only", False) or path == initial_prefix))


def process_lease(lease, schedule, root, stop_fn=None, provider=None):
    """Run one resumable chunk attempt, returning a compact task result.

    provider/stop_fn are injected by tests.  Native evaluators own ITIMER_PROF;
    this caller uses their bounded budgets plus a process-time task deadline.
    """
    provider = engines if provider is None else provider
    queue, state = lease.queue, lease.state
    frontier = Frontier(lease.task, state)
    partials = PartialStore(state)
    global HINT_CACHE
    if schedule.get("certificate_reuse", False) and (HINT_CACHE is None or HINT_CACHE.place != queue.area / "reuse_hints"):
        HINT_CACHE = CertificateHints(queue.area)
    hints = HINT_CACHE if schedule.get("certificate_reuse", False) else None
    root_state_path = queue.parent_dir(lease.task["parent_key"]) / "ROOT_STATE.json"
    if root_state_path.exists():
        root_state = tq.read_json(root_state_path)
        source = tq.read_json(queue.parent_dir(lease.task["parent_key"]) / "SOURCE.json.gz")
        if root_state.get("source_sha256") != tq.digest(source):
            raise ValueError("Ancestor root partial source binding changed")
        inherited = PartialStore(root_state)
        for record in inherited.records.values():
            partials.add("", record)
    should_stop = stop_fn if stop_fn is not None else lambda: stop_requested(root, queue)
    if state["attempts"] >= schedule["max_task_attempts"]:
        lease.release(reason="attempt_budget_exhausted", parked=True)
        return {"task_id": lease.task["task_id"], "status": "parked", "reason": state["reason"]}
    state["attempts"] += 1
    started = time.process_time()
    old_cpu = state["cpu_seconds"]
    deadline = started + schedule["task_cpu_seconds"]
    last_checkpoint_cpu = started
    last_checkpoint_wall = time.monotonic()

    def checkpoint(force=False):
        nonlocal last_checkpoint_cpu, last_checkpoint_wall
        now_cpu, now_wall = time.process_time(), time.monotonic()
        state["cpu_seconds"] = old_cpu + now_cpu - started
        if force or now_cpu - last_checkpoint_cpu >= 2 or now_wall - last_checkpoint_wall >= 5:
            frontier.sync()
            partials.prune(frontier.pending)
            lease.checkpoint(state)
            last_checkpoint_cpu, last_checkpoint_wall = now_cpu, now_wall

    def release(reason, parked):
        state["cpu_seconds"] = old_cpu + time.process_time() - started
        frontier.sync()
        partials.prune(frontier.pending)
        lease.release(state, reason, parked)
        return {"task_id": lease.task["task_id"], "original_id": lease.task["original_id"],
                "status": state["status"], "reason": reason, "new_closed_leaves": len(state["proofs"]),
                "attempts": state["attempts"], "cpu_seconds": state["cpu_seconds"],
                "physical_lean_admissions": 0}

    checkpoint(force=True)
    while True:
        if should_stop():
            return release("stop_requested", True)
        pending = frontier.next(state.get("cursor"))
        if pending is None:
            state["cursor"] = None
            state["cpu_seconds"] = old_cpu + time.process_time() - started
            frontier.sync()
            partials.prune(frontier.pending)
            lease.finish(state)
            return {"task_id": lease.task["task_id"], "original_id": lease.task["original_id"],
                    "status": "done", "new_closed_leaves": len(state["proofs"]),
                    "cpu_seconds": state["cpu_seconds"], "physical_lean_admissions": 0}
        subtree, path, centers, radii = pending
        if any(all(abs(centers[i] - Q(point[i])) <= radii[i] for i in range(4)) for point in schedule["protected_points"]):
            return release("protected_seed_guard", True)
        if state["cursor"] is None:
            state["cursor"] = {"prefix": subtree["prefix"], "path": path, "method_index": 0,
                               "axis": max(range(4), key=lambda axis: radii[axis]), "available_seen": False}
        cursor = state["cursor"]
        geometry = {"centers": list(map(str, centers)), "radii": list(map(str, radii)), "units": "radians"}

        def accepted(verdict):
            remaining = deadline - time.process_time()
            if remaining <= 0:
                return release("cpu_budget_before_replay", state["attempts"] >= schedule["max_task_attempts"])
            receipt = provider.replay(verdict, min(schedule["replay_cpu_seconds"], remaining))
            if receipt.get("status") not in ("PASS", "UNRESOLVED"):
                raise ArithmeticError("Malformed survivor replay receipt")
            state["replay_cpu_seconds"] += receipt.get("cpu_seconds", 0.0)
            if receipt["status"] == "PASS":
                recipe = provider.make_recipe(verdict) if hasattr(provider, "make_recipe") else None
                try:
                    proof = lease.install_proof(path, centers, radii, verdict, receipt, recipe)
                except tq.EvidenceLimit as error:
                    return release(str(error), True)
                frontier.close(path)
                state["proofs"][path] = proof
                state["cursor"] = None
                if hints is not None and (path == subtree["prefix"] or len(path) % 16 == 0):
                    value = state["proof_records"][proof["sha256"]]
                    hints.add(value["evaluation"])
                checkpoint()
                return {"accepted": True}
            reason = receipt.get("reason", "")
            if _resource_reason(reason):
                return release(reason, True)
            if reason not in CPU_REASONS:
                raise ValueError("Fresh survivor replay failed: " + reason)
            return {"accepted": False}

        if schedule.get("partial_composition", False) and hasattr(provider, "compose_partials"):
            contributors = partials.candidates(path, geometry)
            pool_sha = tq.digest([tq.digest(r) for r in contributors])
            if pool_may_close(contributors) and cursor.get("partial_set_sha256") != pool_sha:
                remaining = deadline - time.process_time()
                if remaining <= 0:
                    return release("cpu_budget", state["attempts"] >= schedule["max_task_attempts"])
                try:
                    pooled = provider.compose_partials(contributors, min(schedule.get("composition_cpu_seconds", 2), remaining),
                                                      centers=centers, radii=radii)
                except engines.CpuBudget:
                    return release("cpu_budget", state["attempts"] >= schedule["max_task_attempts"])
                if type(pooled.get("ok")) is not bool:
                    raise ArithmeticError("Malformed partial composition result")
                if _resource_reason(pooled.get("reason", "")):
                    return release(pooled["reason"], True)
                cursor["partial_set_sha256"] = pool_sha
                if pooled["ok"]:
                    result = accepted(pooled)
                    if "status" in result:
                        return result
                    if result["accepted"]:
                        continue

        if hints is not None and not cursor.get("reuse_done", False) and (path == subtree["prefix"] or len(path) % 16 == 0):
            allowed = {s["method"]: s["cpu_seconds"] for s in schedule["methods"] if _eligible(s, path, subtree["prefix"])}
            candidates = hints.candidates(geometry, allowed, schedule.get("reuse_candidates", 2))
            index = cursor.get("reuse_index", 0)
            if index < len(candidates):
                remaining = deadline - time.process_time()
                if remaining <= 0:
                    return release("cpu_budget", state["attempts"] >= schedule["max_task_attempts"])
                hint = candidates[index]
                hcc, hrr = list(map(Q, hint["input"]["centers"])), list(map(Q, hint["input"]["radii"]))
                cursor["reuse_index"] = index + 1
                if any(all(abs(hcc[i]-Q(p[i])) <= hrr[i] for i in range(4)) for p in schedule["protected_points"]):
                    continue
                verdict = provider.evaluate(hcc, hrr, hint["method"], min(allowed[hint["method"]], remaining))
                if type(verdict.get("ok")) is not bool:
                    raise ArithmeticError("Malformed certificate reuse evaluation")
                if _resource_reason(verdict.get("reason", "")):
                    return release(verdict["reason"], True)
                if verdict["ok"]:
                    result = accepted(verdict)
                    if "status" in result:
                        return result
                    if result["accepted"]:
                        continue
                checkpoint()
                continue
            cursor["reuse_done"] = True
        if cursor["method_index"] < len(schedule["methods"]):
            step = schedule["methods"][cursor["method_index"]]
            if not _eligible(step, path, subtree["prefix"]):
                cursor["gated_seen"] = True
                cursor["method_index"] += 1
                continue
            remaining = deadline - time.process_time()
            if remaining <= 0:
                return release("cpu_budget", state["attempts"] >= schedule["max_task_attempts"])
            verdict = provider.evaluate(centers, radii, step["method"], min(step["cpu_seconds"], remaining))
            if not isinstance(verdict, dict) or type(verdict.get("ok")) is not bool:
                raise ArithmeticError("Malformed survivor evaluator result")
            reason = verdict.get("reason", "")
            if reason != "method_unavailable":
                cursor["available_seen"] = True
            if _resource_reason(reason):
                return release(reason, True)
            select_axis(cursor, verdict)
            partials.add(path, verdict)
            if verdict["ok"]:
                result = accepted(verdict)
                if "status" in result:
                    return result
                if result["accepted"]:
                    continue
            cursor["method_index"] += 1
            checkpoint()
            continue
        if time.process_time() >= deadline:
            return release("cpu_budget", state["attempts"] >= schedule["max_task_attempts"])
        if not cursor.get("available_seen") and not cursor.get("gated_seen"):
            return release("method_schedule_unavailable", True)
        if len(path) >= tq.MAX_DEPTH:
            return release("depth_guard", True)
        if len(frontier.nodes) + 2 > lease.task["limits"]["max_task_nodes"]:
            return release("task_forest_size_guard", True)
        if not lease.reserve_split():
            return release("forest_size_guard", True)
        frontier.split(path, cursor["axis"])
        state["cursor"] = None
        checkpoint()


def process_root_lease(lease, schedule, root, stop_fn=None, provider=None):
    """Try the exact original root once per explicit bounded continuation stage."""
    provider = engines if provider is None else provider
    state = lease.state
    should_stop = stop_fn if stop_fn is not None else lambda: stop_requested(root, lease.queue)
    began, previous = time.process_time(), state["cpu_seconds"]
    deadline = began + schedule.get("root_cpu_seconds", 30)
    state["attempts"] += 1
    partials = PartialStore(state)
    cc, rr = tq.exact_box(lease.parent["input"])

    def release(reason, retry=False):
        state["cpu_seconds"] = previous + time.process_time() - began
        lease.release(reason, retry)
        return {"parent_key": lease.parent["parent_key"], "task_id": lease.task["task_id"],
                "original_id": lease.parent["id"], "status": "root_queued" if retry else "root_parked",
                "reason": reason, "physical_lean_admissions": 0}

    if state["attempts"] > schedule.get("root_max_attempts", 2):
        return release("root_attempt_budget_exhausted")
    if any(all(abs(cc[i]-Q(p[i])) <= rr[i] for i in range(4)) for p in schedule["protected_points"]):
        return release("protected_seed_guard")
    lease.checkpoint()
    methods = schedule.get("root_methods", [])
    while state["method_index"] < len(methods):
        if should_stop():
            return release("stop_requested")
        remaining = deadline - time.process_time()
        if remaining <= 0:
            return release("cpu_budget", state["attempts"] < schedule.get("root_max_attempts", 2))
        step = methods[state["method_index"]]
        verdict = provider.evaluate(cc, rr, step["method"], min(step["cpu_seconds"], remaining))
        if type(verdict.get("ok")) is not bool:
            raise ArithmeticError("Malformed whole-root evaluation")
        if _resource_reason(verdict.get("reason", "")):
            return release(verdict["reason"])
        partials.add("", verdict)
        if verdict["ok"]:
            remaining = deadline - time.process_time()
            if remaining <= 0:
                return release("cpu_budget_before_replay", state["attempts"] < schedule.get("root_max_attempts", 2))
            fresh = provider.replay(verdict, min(schedule["replay_cpu_seconds"], remaining))
            if fresh.get("status") == "PASS":
                recipe = provider.make_recipe(verdict) if hasattr(provider, "make_recipe") else None
                state["cpu_seconds"] = previous + time.process_time() - began
                try:
                    sha = lease.candidate(verdict, fresh, recipe)
                except tq.EvidenceLimit as error:
                    return release(str(error))
                return {"parent_key": lease.parent["parent_key"], "task_id": lease.task["task_id"],
                        "original_id": lease.parent["id"], "status": "root_candidate", "candidate_sha256": sha,
                        "physical_lean_admissions": 0}
            if fresh.get("reason") not in CPU_REASONS:
                raise ValueError("Fresh whole-root replay disagreement: " + str(fresh.get("reason")))
        state["method_index"] += 1
        state["cpu_seconds"] = previous + time.process_time() - began
        lease.checkpoint()
    geometry = {"centers": list(map(str, cc)), "radii": list(map(str, rr)), "units": "radians"}
    contributors = partials.candidates("", geometry)
    if (schedule.get("partial_composition", False) and hasattr(provider, "compose_partials")
            and pool_may_close(contributors)):
        remaining = deadline - time.process_time()
        if remaining <= 0:
            return release("cpu_budget", state["attempts"] < schedule.get("root_max_attempts", 2))
        try:
            verdict = provider.compose_partials(contributors, min(schedule.get("composition_cpu_seconds", 2), remaining),
                                                centers=cc, radii=rr)
        except engines.CpuBudget:
            return release("cpu_budget", state["attempts"] < schedule.get("root_max_attempts", 2))
        if type(verdict.get("ok")) is not bool:
            raise ArithmeticError("Malformed root partial composition")
        if _resource_reason(verdict.get("reason", "")):
            return release(verdict["reason"])
        if verdict["ok"]:
            remaining = deadline - time.process_time()
            if remaining <= 0:
                return release("cpu_budget_before_replay", state["attempts"] < schedule.get("root_max_attempts", 2))
            fresh = provider.replay(verdict, min(schedule["replay_cpu_seconds"], remaining))
            if fresh.get("status") == "PASS":
                recipe = provider.make_recipe(verdict) if hasattr(provider, "make_recipe") else None
                state["cpu_seconds"] = previous + time.process_time() - began
                try:
                    sha = lease.candidate(verdict, fresh, recipe)
                except tq.EvidenceLimit as error:
                    return release(str(error))
                return {"parent_key": lease.parent["parent_key"], "task_id": lease.task["task_id"],
                        "original_id": lease.parent["id"], "status": "root_candidate", "candidate_sha256": sha,
                        "physical_lean_admissions": 0}
            if fresh.get("reason") not in CPU_REASONS:
                raise ValueError("Fresh composed root replay disagreement")
    return release("root_schedule_exhausted")


def _memory_limit():
    if sys.platform == "linux":
        soft, hard = resource.getrlimit(resource.RLIMIT_AS)
        bound = 768 * 2**20
        if hard != resource.RLIM_INFINITY:
            bound = min(bound, hard)
        if soft != resource.RLIM_INFINITY:
            bound = min(bound, soft)
        resource.setrlimit(resource.RLIMIT_AS, (bound, bound))


def main():
    cpu_started = time.process_time()
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", required=True)
    parser.add_argument("--queue", required=True)
    parser.add_argument("--cache", required=True)
    parser.add_argument("--schedule")
    parser.add_argument("--cpu-seconds", type=float)
    parser.add_argument("--replay-cpu-seconds", type=float)
    parser.add_argument("--max-tasks", type=int, default=0)
    modes = parser.add_mutually_exclusive_group()
    modes.add_argument("--descendants-only", action="store_true", help="Validation/dispatch priority; preserves parent gates and candidate barriers")
    modes.add_argument("--roots-only", action="store_true", help="Bounded original-root pilot without descendant work")
    parser.add_argument("--wall-seconds", type=float, default=20 * 3600)
    parser.add_argument("--lease-seconds", type=float, default=180)
    parser.add_argument("--owner", default="_".join(os.environ.get(k, "local") for k in ("SLURM_JOB_ID", "SLURM_ARRAY_TASK_ID", "SLURM_PROCID")) + "_" + str(os.getpid()))
    args = parser.parse_args()
    if not __debug__:
        raise ValueError("Optimized Python is forbidden")
    if args.max_tasks < 0 or not math.isfinite(args.wall_seconds) or args.wall_seconds <= 0:
        raise ValueError("Invalid worker bounds")
    _memory_limit()
    signal.signal(signal.SIGUSR1, stop)
    signal.signal(signal.SIGTERM, stop)
    queue = tq.TaskQueue(args.queue)
    root = Path(args.root).resolve()
    binding = tq.read_json(queue.area / "CONFIG.json")
    if binding["config_sha256"] != tq.sha_file(root / "production/CONFIG.json"):
        raise ValueError("Worker campaign configuration differs from queue source")
    schedule = load_schedule(args.schedule, args.cpu_seconds, args.replay_cpu_seconds)
    schedule_sha = tq.digest(schedule)
    if __package__:
        from .runtime import RuntimeLease
    else:
        from runtime import RuntimeLease
    runtime = RuntimeLease(queue, Path(__file__).resolve().parent, schedule_sha)
    directory = queue.area / "workers" / tq.digest(args.owner)[:24]
    directory.mkdir(parents=True, exist_ok=True)
    lease = None
    started = time.monotonic()
    completed = done = parked = 0
    try:
        if stop_requested(root, queue):
            return 75
        availability = engines.initialize(root, Path(args.cache), **runtime.engine_kwargs())
        tq.durable_json(directory / "CONFIG.json", {"owner": args.owner, "schedule": schedule,
                        "schedule_sha256": schedule_sha, "providers": availability,
                        "memory_limit_bytes": 768 * 2**20, "physical_lean_admissions": 0})
        while not stop_requested(root, queue) and time.monotonic() - started < args.wall_seconds:
            tq.resource_guard(queue.area)
            if args.max_tasks and completed >= args.max_tasks:
                break
            lease = queue.claim_root(args.owner, args.lease_seconds, schedule_sha) if schedule["whole_root"] and not args.descendants_only else None
            whole_root = lease is not None
            if lease is None and not args.roots_only:
                lease = queue.claim(args.owner, args.lease_seconds, schedule_sha)
            if lease is None:
                break
            result = process_root_lease(lease, schedule, root) if whole_root else process_lease(lease, schedule, root)
            completed += 1
            done += result["status"] == "done"
            parked += result["status"] == "parked"
            tq.durable_json(directory / "STATUS.json", {"status": "RUNNING", "owner": args.owner,
                            "completed_attempts": completed, "done_tasks": done, "parked_tasks": parked,
                            "last_task": result, "updated_unix": time.time(), "physical_lean_admissions": 0})
            lease = None
        state = "CHECKPOINTED" if stop_requested(root, queue) else "WORKER_FINISHED"
        result = {"status": state, "owner": args.owner, "completed_attempts": completed,
                  "done_tasks": done, "parked_tasks": parked, "updated_unix": time.time(),
                  "worker_cpu_seconds": time.process_time() - cpu_started,
                  "elapsed_wall_seconds": time.monotonic() - started,
                  "safety_paths": SAFETY_PATHS.statistics(),
                  "physical_lean_admissions": 0}
        tq.durable_json(directory / "STATUS.json", result)
        print(json.dumps(result, sort_keys=True), flush=True)
        return 75 if state == "CHECKPOINTED" else 0
    except BaseException as error:
        # No general exception is swallowed or converted to a numerical budget.
        detail = {"owner": args.owner, "type": type(error).__name__, "error": str(error),
                  "task_id": lease.task["task_id"] if lease else None,
                  "traceback": traceback.format_exc(), "physical_lean_admissions": 0}
        tq.durable_json(directory / "FAILURE.json", detail)
        with tq.locked(queue.area / "FAILURE.lock"):
            failure = safety_paths.absolute(queue.area) / "FAILURE.json"
            if failure not in SAFETY_PATHS.present((failure,), anchors=(queue.area,), fresh=True):
                tq.durable_json(queue.area / "FAILURE.json", detail)
        raise
    finally:
        if lease is not None:
            lease.close()
        runtime.close()


if __name__ == "__main__":
    sys.exit(main())
