"""Independent exact coefficients and known-physical negative controls."""
from fractions import Fraction as Q
from pathlib import Path
import argparse,ctypes,json,sys,time

def main():
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--cache',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True);p.add_argument('--methods',nargs='+',default=['order3','order4','order5','paired_psd'])
    a=p.parse_args();sys.path.insert(0,str(Path(__file__).parent));import engines
    sys.path.insert(0,str(a.root/'engine'))
    import importlib.util
    spec=importlib.util.spec_from_file_location('frozen_exact_controls',a.root/'engine/controls.py')
    ref=importlib.util.module_from_spec(spec);sys.modules[spec.name]=ref;spec.loader.exec_module(ref)
    manifest=engines.initialize(a.root,a.cache);start=time.process_time();ncoeff=0
    for method in a.methods:
        if not manifest['methods'].get(method,{}).get('available'):raise ValueError('Control method unavailable '+method)
        if method in ['order3','order4','order5']:
            lib=engines._STATE['native'][int(method[-1])]
            for ints in [(-3,2,1,5,2,1,-2,3),(2,1,3,1,4,3,5,2),(1,2,2,3,3,4,4,5)]:
                ph=[];raw=[]
                for m,n in zip(ints[::2],ints[1::2]):
                    z=ref.Z(Q(m*m-n*n,m*m+n*n),Q(2*m*n,m*m+n*n));ph.append(z)
                    raw += [ref.c.down(z.re),ref.c.up(z.re),ref.c.down(z.im),ref.c.up(z.im)]
                out=(ctypes.c_double*38)();lib.set_budget(30)
                if lib.linear_region((ctypes.c_double*20)(*raw,*([0.]*4)),out)!=38:raise ValueError('Native control error')
                for k,v in enumerate(ref.reference(ph)):
                    if not Q(out[2*k])<=v<=Q(out[2*k+1]):raise ValueError('Exact coefficient outside enclosure')
                    ncoeff+=1
    l,u=ref.atan_bounds(Q(1,5));ll,uu=ref.atan_bounds(Q(1,239));pi=(16*l-4*uu,16*u-4*ll);pim=sum(pi)/2
    cases=[]
    for delta in [Q(1,100),Q(1,5),Q(1,2)]:
        exact=[-2*pim/3,-pim/3+delta,Q(0),-pim+delta]
        for tr in [False,True]:
            perm=[0,2,1,3] if tr else [0,1,2,3];cc=[Q(float(exact[i])) for i in perm];rr=[Q(1,2**35)]*4
            if not all(abs(cc[k]-exact[i])+pi[1]-pi[0]<rr[k] for k,i in enumerate(perm)):raise ValueError('Control point not enclosed')
            for method in a.methods:
                z=engines.evaluate(cc,rr,method,20)
                if z['ok']:raise ValueError('KNOWN PHYSICAL CORNER FALSELY EXCLUDED '+method)
                if 'budget' in z['reason'] or z['reason']=='method_unavailable':raise ValueError('Control inconclusive '+method)
                cases.append({'method':method,'delta':str(delta),'transpose':tr,'reason':z['reason']})
    result={'status':'PASS_EXACT_COEFFICIENTS_AND_PHYSICAL_CONTROLS','exact_coefficients':ncoeff,'physical_controls':cases,
            'providers':manifest,'cpu_seconds':time.process_time()-start,'physical_lean_admissions':0}
    a.output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':result['status'],'exact_coefficients':ncoeff,'physical_controls':len(cases)}))

if __name__=='__main__':main()
