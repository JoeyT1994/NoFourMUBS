# Final clean-extraction verification

The module manifest has SHA-256 `2b3bd07da77a2508699bc9dbb9153efb64a0858f7b025fa7647f68eb98ac7d6c`.
It has **43 entries**. Every module file was compared byte-for-byte
with the copy extracted for the final Clang run. The same accepting engine source
was used in the successful GCC and Clang replays.

`CLEAN_CLANG_REPLAY.json` records a fresh complete replay followed by acceptance
of all eight positive boxes. It reports PASS_UNIFORM_BALL, 140,104 verified
terminals, zero unresolved terminals, and 104 successful local inequalities.
Its recorded module-manifest hash matches the module shipped here.

The original full GCC receipt is inside the module at
`results/FULL_VERIFICATION.json`. The module was then frozen with that receipt
and the final documentation in its manifest. This outer verification directory
is separate to avoid a circular hash dependency in the clean replay receipt.

| Verification | Full proof wall seconds | Global replay wall seconds | Summed native global worker CPU seconds |
|---|---:|---:|---:|
| Fresh GCC | 597.720102126 | 571.3273927549999 | 2258.2224 |
| Fresh Clang, clean extraction | 544.104219198 | 521.0473217969998 | 2066.3289999999997 |

Timings are actual observations, not future runtime guarantees. Four workers were
used. Clang omits only GCC's `-fno-tree-vrp` option; the strict floating-point
flags and runtime arithmetic guards are retained. These are two compiler builds
of the same verifier, not two independently designed mathematical proofs.

`SOURCE_COMPARISON.json` checks unchanged arithmetic/model files against the
audited baseline. `SOURCE_CHANGES.diff` exposes the changed accepting code and
new independent cover controls. Neither is a substitute for the full proof.
`INSIDE_BOX_RESULTS.jsonl` contains the eight accepted whole-box records, each
strictly outside both former radius-1/100 balls. These examples test the interface;
the complete analytic and finite-cover argument proves the uniform ball.
