# Uniform stationary-F3 exclusion radius 1/20

The proof module is `ProvenResults/Patch2442Local/Radius050Complete/`.
Read its `PROOF.md`, `README.md`, and `VERIFICATION.md`. Fresh GCC and clean-
extraction Clang replays passed all 38,421 global terminals and 104 local
contraction inequalities, with zero unresolved cells. Both complete box runs
accepted all 2,354 original pilot boxes and all eight positive examples.

The final proof module's own manifest is checked by the clean Clang receipt.
That receipt is placed under `Verification/` rather than inserted into its own
module manifest. The final delivery adds external verification materials without
changing any module byte. `ARCHIVE_MANIFEST.sha256` hashes every delivery member
except itself. This is an additive package; earlier proof modules are not replaced.

```bash
cd ProvenResults/Patch2442Local/Radius050Complete
sha256sum -c MANIFEST.sha256
python -B verify.py --boxes examples/acceptance_boxes.jsonl.gz \
  --output work/pilot_replay.jsonl.gz --workers 4
```

Every box invocation first replays the complete proof. The optional independent
directional audit under `Verification/IndependentAudit/` is supplementary; it
does not replace the full verifier or justify larger radii from sampled tails.
The primary verifier uses only the Python standard library and a C++17 compiler.
The additional audit uses mpmath 1.3.0.

The exact radius is 1/20 = 0.05 **in circular seed-angle radians**, at both
conjugate stationary seeds. Maximality ties and the closed outer boundary are
included. No statement about radius 0.06 or a replay of the remainder of the
global no-four-MUBs campaign is made. This is computer-assisted mathematics
under the stated execution model, not a proof-assistant formalization or
independent peer review.
