#!/usr/bin/env python3
"""Exact Laurent/Taylor and tensor-Bernstein bound; not a standalone exclusion.
The accepting arithmetic in this module uses integers and Fraction only.
"""
from __future__ import annotations
from fractions import Fraction as Q
from functools import lru_cache
from math import factorial, comb, lcm, prod
from pathlib import Path
import importlib.util,json
HERE=Path(__file__).resolve().parent
RADIUS=Q(1,20)
RHO=Q(float.fromhex('0x1.999999999999bp-5'))
QCOEFF=44
if not __debug__:raise RuntimeError('Optimization mode is prohibited')

@lru_cache(None)
def taylor_data():
 spec=importlib.util.spec_from_file_location('source_physical_algebra',HERE/'inputs/physical_algebra.py')
 pa=importlib.util.module_from_spec(spec);spec.loader.exec_module(pa)
 _,R=pa.corner_algebra();assert R==R.star()
 terms=list(R.d.items());assert len(terms)==2083 and all(Q(c).denominator==1 for e,c in terms)
 roots=[sum(x*y for x,y in zip(e,(1,2,2,1)))%3 for e,c in terms]
 A=[int(c)*(1 if r==0 else -1 if r==2 else 0) for (e,c),r in zip(terms,roots)]
 B=[int(c)*(1 if r==1 else -1 if r==2 else 0) for (e,c),r in zip(terms,roots)]
 pows=[[[e[j]**d for e,c in terms] for d in range(11)] for j in range(4)]
 coefficients=[];norms=[];checks=0
 for d in range(11):
  norm=Q(0)
  for a in range(d+1):
   for b in range(d-a+1):
    for c in range(d-a-b+1):
     f=d-a-b-c;alpha=(a,b,c,f);fac=prod(factorial(t) for t in alpha);ac=bc=0
     for aa,bb,x,y,z,w in zip(A,B,pows[0][a],pows[1][b],pows[2][c],pows[3][f]):
      v=x*y*z*w;ac+=aa*v;bc+=bb*v
     if d%2==0:
      assert bc==0;v=Q((-1)**(d//2)*ac,fac);factor='1';norm+=abs(v)
     else:
      assert 2*ac==bc;v=Q((-1)**((d+1)//2)*bc,2*fac);factor='sqrt3';norm+=Q(26,15)*abs(v)
     if v:coefficients.append({'alpha':list(alpha),'coefficient':str(v),'factor':factor})
     checks+=1
  norms.append(norm)
 assert checks==1001 and norms[:4]==[0]*4
 quartic={tuple(r['alpha']):Q(r['coefficient']) for r in coefficients if sum(r['alpha'])==4}
 assert quartic=={(2,0,0,2):Q(243),(0,2,2,0):Q(243),(1,1,1,1):Q(-486)}
 assert norms==list(map(Q,('0','0','0','0','972','202176/5','27936','303264','393192','4297644/5','9216504/5')))
 rem=sum(Q(abs(c))*sum(abs(v) for v in e)**11 for e,c in terms)/factorial(11)
 assert rem==Q(31405613662277,51975)
 # Conjugation inverts the seed phases; reality of R supplies R_minus(u)=R_plus(-u).
 assert all(sum(x*y for x,y in zip(e,(2,1,1,2)))%3==(-rr)%3 for (e,c),rr in zip(terms,roots))
 return {'R_terms':len(terms),'coefficient_checks':checks,'coefficients':coefficients,'norms':list(map(str,norms)),'remainder':str(rem),'conjugation_checked':True}

@lru_cache(None)
def transformation(n,unit):
 vals=[];D=1
 for i in range(n+1):
  row=[]
  for a in range(n+1):
   if unit:v=sum((Q(comb(a,k)*2**k*(-1)**(a-k)*comb(i,k),comb(n,k)) for k in range(min(i,a)+1)),Q(0))
   else:v=Q(comb(i,a),comb(n,a)) if a<=i else Q(0)
   row.append(v);D=lcm(D,v.denominator)
  vals.append(row)
 # Independently reconstruct each power polynomial from its Bernstein expansion.
 for a in range(n+1):
  recovered=[Q(0)]*(n+1)
  for i in range(n+1):
   for j in range(n-i+1):recovered[i+j]+=vals[i][a]*comb(n,i)*comb(n-i,j)*(-1)**j
  expected=[Q(comb(a,k)*2**k*(-1)**(a-k)) if k<=a else Q(0) for k in range(n+1)] if unit else [Q(k==a) for k in range(n+1)]
  assert recovered==expected
 return tuple(tuple(int(v*D) for v in row) for row in vals),D

def tensor_bound(rho,data):
 assert Q(0)<rho<=RHO
 shape=(9,9,9,9,5);size=prod(shape);strides=[prod(shape[j+1:]) for j in range(5)]
 upper=Q(1732051,10**6);error=Q(1,10**6)
 assert (upper-error)**2<3<upper**2 and Q(26,15)**2>3
 coefficients=[];den=1;root_error=Q(0)
 for rec in data['coefficients']:
  alpha=tuple(rec['alpha']);degree=sum(alpha)
  if not 4<=degree<=8:continue
  v=Q(rec['coefficient'])*rho**(degree-4)
  if rec['factor']=='sqrt3':root_error+=abs(v)*error;v*=upper
  coefficients.append((alpha+(degree-4,),v));den=lcm(den,v.denominator)
 values=[0]*size
 for alpha,v in coefficients:values[sum(a*s for a,s in zip(alpha,strides))]=int(v*den)
 for axis in range(5):
  T,d=transformation(shape[axis]-1,axis<4);n=shape[axis];step=strides[axis];block=n*step;out=[0]*size
  for start in range(0,size,block):
   for offset in range(step):
    vector=[values[start+i*step+offset] for i in range(n)]
    for i,row in enumerate(T):out[start+i*step+offset]=sum(c*v for c,v in zip(row,vector))
  values=out;den*=d
 maximum=Q(max(values),den)
 higher=sum(Q(data['norms'][d])*rho**(d-4) for d in (9,10))+Q(data['remainder'])*rho**7
 bound=maximum+root_error+higher
 assert size==32805 and bound<1928<44**2
 return {'tensor_shape':list(shape),'tensor_coefficients':size,'max_Bernstein_coefficient':str(maximum),'root_approximation_error':str(root_error),'higher_order_bound':str(higher),'R_normalized_upper_exact':str(bound),'q_squared_margin':str(Q(44**2)-bound),'simple_upper':'1928'}

def domain_guards(rho):
 r=rho
 tests={
  'seed_radius_positive':0<r<=RHO,
  'side_sum':2*r<Q(1,8),
  'side_a_lower':1-2*r>Q(89,100),
  'side_k_lower':1/(1+2*r)**2-Q(1,4)>Q(9,16),
  'side_order_positive_imaginary':Q(3,4)*(1-2*r)-r>0,
  'sqrt3_lower':Q(173,100)**2<3,
  'sqrt200_upper':Q(283,20)**2>200,
  'side_inverse':Q(173,100)-Q(283,20)*r>1,
  'opposite_orientations':3-32*r>4*r,
  'positive_anchor':Q(1,2)-8*r>0,
  'side_factor_discrepancy':12+24*Q(7,4)+112*r<64,
 }
 assert all(tests.values()),tests
 return tests

def check(rho=None):
 rho=RADIUS if rho is None else Q(rho)
 data=taylor_data();saved=HERE/'data/seed_taylor_coefficients.json'
 assert saved.is_file() and json.loads(saved.read_text())==data,'Taylor data mismatch'
 result=tensor_bound(rho,data)
 return {'status':'PASS','scope':'INVARIANT_AND_MODEL_BOUNDS_ONLY_NOT_EXCLUSION','invariant_bound_domain_radius':str(rho),'q_coefficient':44,'native_width':str(RHO),**result,'finite_guards':domain_guards(rho),'symbolic_identities':{'exact_Laurent_generator':True,'quartic_kappa_identity':True,'univariate_Bernstein_identities':True,'conjugation_checked':True},'coefficient_checks':data['coefficient_checks'],'R_terms':data['R_terms']}
