# Radius-1/20 stationary-F3 seed exclusion

This module proves exclusion on the entire punctured circular seed balls of radius **1/20 =
0.05 radians** at `(2,4,4,2) pi/3` and `(4,2,2,4) pi/3`. The conclusion excludes
physical order-six Hadamards whose selected corner has positive R and is maximal
among all 400 positional corners, including maximality ties.

The complete fresh GCC replay passed all 38,421 global terminals and 104 local
rows, then all 2,362 pilot/example boxes. Read `PROOF.md` for the argument, normalization,
and trust boundary. The default verifier must finish successfully; local-only
checks or a successful construction log are not full-ball certificates.

## Reproduce

Requirements: Python 3.11 or later, its standard library, and a C++17 compiler
supporting the stated IEEE-754 binary64 model. No optimization solver, NumPy,
SciPy, or mpmath is required by the proof verifier. Do not use Python `-O`,
fast-math compiler flags, or altered arithmetic settings.

```bash
sha256sum -c MANIFEST.sha256
python -B verify.py --output work/full_replay.json --workers 4
```

The invocation checks hashes; regenerates the exact invariant, degree-ten Taylor
coefficients, and tensor-Bernstein source bound; checks exact reference matrices,
symmetries, and controls; rebuilds all native engines; replays all 104 local
contraction inequalities; validates complete closed cover geometry; and freshly
recomputes every global terminal. Any failure produces `NOT_CERTIFIED` and a
nonzero exit status. A `PASS_UNIFORM_BALL` receipt must be interpreted together
with the mathematical argument and accepting implementation, not by itself.

A second compiler can be selected explicitly:

```bash
CXX=clang++ python -B verify.py --output work/clang_replay.json --workers 4
```

The wrapper removes only GCC's unsupported `-fno-tree-vrp` option for Clang.
Strict floating-point flags and runtime guards remain enabled.

## Whole boxes and the original pilot ring

```bash
python -B verify.py --boxes LIST.jsonl.gz --output work/box_results.jsonl.gz --workers 4
```

Each input has an `id`, four `centers`, and four nonnegative `radii`, all coordinates
as **exact rational strings in absolute radians**. Plain JSONL and gzip JSONL are
supported. Every invocation first performs the full proof, then checks complete
closed-box membership with exact circular lifts and Machin bounds for pi.
Floating JSON coordinates, outside boxes, unresolved membership, or seed-touching
boxes are nonaccepting. The closed outer boundary is included. Any nonaccepted
record gives a nonzero exit status. Input files and pinned package files cannot
be overwritten by the output.

For exact boundary examples the optional explicit format
`coordinate_system: "seed_radius_units"` represents

`theta_j = seed_j + 2*pi*lifts_j + (1/20)*(centers_j + [-radii_j,radii_j])`.

The seed label is `2442` or `4224`. These coordinates are not silently treated as
absolute radians. `examples/inside.jsonl` has eight positive examples, all wholly
outside the old radius-1/40 balls.

The original 2,354 pilot-ring boxes are retained byte-for-byte in
`inputs/pilot_ring_all_2354.jsonl.gz`. The combined 2,362-record test is:

```bash
python -B verify.py --boxes examples/acceptance_boxes.jsonl.gz \
  --output work/pilot_and_examples.jsonl.gz --workers 4
```

This is an explicit test of the supplied pilot list, not an assertion about an
unprovided full-run list or a larger radius.

## Contents and arithmetic distinction

`seed_bound.py` and `data/seed_taylor_coefficients.json` implement the exact bound
`sqrt(R) <= 44 rho^2`. `engine.cpp`, `interval_model.hpp`, and the Taylor kernels
implement the guarded completion model and necessary residual inequalities.

The **ordinary degree-six** kernel in `taylor_model.hpp` retains a radial remainder
`tau*h^7` for local contractions (3,003 monomials). The **weighted global** kernel
in `weighted_model.hpp` assigns weight two to seed variables and weight three to
completion variables, retaining weight at most twelve (975 monomials). Its tail
is absolute on the cube. It is not a twelfth-order radial bound and is prohibited
in the local contraction operation.

The cover's `degree` label means `6` for ordinary degree six or `12` for the
weighted backend. It selects a checked enclosure algorithm, never a stored
acceptance assertion. Exact coefficient/preconditioner bindings, all cover
branches, all native terminal predicates, and both arithmetic backends are checked
on each complete invocation.

`PREVIOUS_PROOF.md` and `BASELINE_AUDIT.md` preserve provenance. Neither an earlier
radius theorem nor an old audit replaces any new accepting check. The obsolete
`geometry.py` helper is absent. The proof does not use MC1--MC4, classification,
effective-minimum or inherited confinement assumptions, or a matrix/projector
tube. It is computer-assisted mathematics under the stated numerical execution
model, not a Lean proof or a replay of the rest of the no-four-MUBs campaign.
