# Construction and verification boundary

The starting point is the supplied radius-1/40 module. Its invariant convention,
nonsingular physical completion model, exact reference set, and symmetry action
are retained. The previous uniform exclusion is not assumed as an inner region.

## New source bound

The old Gram majorant was too pessimistic at radius 1/20. The new exact calculation
regenerates all 1,001 Taylor multi-indices through degree ten from the 2,083-term
integer Laurent polynomial. Degrees four through eight are bounded jointly by an
exact five-variable tensor-Bernstein calculation. Degrees nine, ten, and the
integral order-eleven remainder are bounded absolutely. Radical coefficient
replacement has a separate rational error bound. The resulting normalized bound
is less than 1928, hence sqrt(R) <= 44 rho^2.

This calculation is not a numerical maximization. Its transform matrices are
independently checked as polynomial identities, and every coefficient is recomputed.
The side-model domain proof is also updated: the old 16rho inverse estimate and
old derivative constant are not carried into the larger domain. The new direct
Frobenius estimate sqrt(200)*rho supplies a nonsingular side matrix at radius 0.05.

## New local combinations

Ordinary degree-six radially factored models replace the old degree-four models.
Linear optimization proposed combinations of all 94 necessary residuals at each
of 13 symmetry representatives. The proposals were quantized to exact integers
divided by 2^38. Every native coefficient is compared with those integers, and the
full linear defect, nonlinear coefficients, tails, and signed source are checked
outward. Optimizer status and approximate inverse equalities are never accepted
as mathematical evidence. The final verifier has no optimization dependency.

## New global arithmetic and partition

Full ordinary degree six was unnecessarily expensive on the completion-phase
cover. A weighted downward-closed basis retains sixth-order seed terms and
fourth-order completion terms with 975 monomials. Its remainder is absolute on
the whole cube, not radial; the radial local argument uses a different backend.
Both are explicitly controlled and documented.

The global construction restarts from all 102 symmetry-representative initial
cells, not a list presumed successful at the smaller radius. Complete closed
binary subtrees are generated with the new target constants. Any construction
limit would leave an explicitly nonaccepting leaf. Only a completed zero-unresolved
cover followed by a fresh public replay establishes the theorem.

Construction summaries are preserved separately from proof replay receipts. The
final source/data hashes bind the actual accepting package. GCC and Clang runs,
when retained as completed, are two compiler executions of one verifier, not two
independently designed full verifiers or independent peer review.

## Scope

The target is the exact rational seed radius 1/20 at both conjugate seeds. It is
not claimed optimal. Coverage of the original pilot list is established by
exact membership after the full proof, not from rounded distances or sampled
centers. No unprovided full-run list or radius 0.06 is certified here.
