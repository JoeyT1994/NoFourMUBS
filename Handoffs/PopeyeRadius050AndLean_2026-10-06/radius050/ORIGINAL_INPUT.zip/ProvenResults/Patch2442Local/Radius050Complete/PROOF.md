# Uniform stationary-F3 seed exclusion at radius 1/20

## Verification status and theorem

**The complete public GCC replay has passed.** It freshly verified all 38,421
terminal boxes and all 104 local contraction inequalities, with zero unresolved
records, then accepted all 2,354 original pilot boxes and all eight positive
examples. The retained receipt is `results/FULL_VERIFICATION.json`. The receipt
must be read together with this analytic argument and the accepting implementation;
it is not a standalone proof. A construction log or a local-only receipt does
not replace that replay.

The exact target radius is **r = 1/20 radian = 0.05 radian**. For either

$$
\theta_*=(2,4,4,2)\pi/3\quad\text{or}\quad(4,2,2,4)\pi/3,
$$

**Theorem.** No physical order-six complex Hadamard has a selected
corner E(theta) satisfying

$$
0<R(E(\theta))=\max_{400\text{ positional corners }Q}R(H_Q)=M(H)
$$

when

$$
0<\|\theta-\theta_*\|_{\infty,\mathrm{circ}}\le\frac1{20}.
$$

Physical means raw unit-modulus entries and HH*=6I. Ties for maximality are
allowed. The closed outer boundary, all angular directions, and every coupled
radial approach to a degenerate direction are included. At the center, R=0
separately excludes strictness. The assertion concerns **maximal** physical
corners; it does not exclude arbitrary nonmaximal corners near F3.

This argument neither assumes the earlier radius-1/40 theorem as an inner region
nor extrapolates from the old residual-ring boxes. It does not use MC1--MC4,
all-critical classification, the effective-minimum theorem, an inherited
confinement cutoff, or a matrix/projector exclusion tube.

## 1. Inputs, conventions, and the dependency boundary

`INPUTS.json` pins every adopted source and exact data file. The package manifest
additionally pins the code, mathematical exposition, and retained receipts.

| Input | Role |
|---|---|
| `inputs/CornerBounds_PROOF.md`, Section 2 | Complementary-corner square convention. Its finite Laurent identity and normalization are regenerated here. No classification-dependent section of that file is invoked. |
| `inputs/physical_algebra.py::corner_algebra` | Exact integer Laurent generators for D and R and an exact physical control family. Their outputs are recomputed. |
| `data/determinant_words.txt` | The 48 signed determinant words, independently bound to the generator. |
| `data/preconditioners.json`, `.txt` | The 63 exact reference labels, and arbitrary legacy residual selections used in cheap global tests. Native coefficients are checked against the exact data. |
| `data/dense_preconditioners.json`, `.txt` | New fixed 8-by-94 local combinations, with integer numerators and denominator 2^38. No inverse or optimizer property is assumed. |
| `data/seed_taylor_coefficients.json` | All nonzero Taylor coefficients through degree ten and frequency moments; regenerated, not merely hash-trusted. |
| `data/phase_cover.jsonl.gz` | A complete closed phase subdivision. Every accepting predicate is freshly recomputed. |
| `inputs/pilot_ring_all_2354.jsonl.gz` | Unchanged original pilot boxes. Used only to verify that the requested pilot ring is inside the proved ball, not as an input to the ball proof. |

`PREVIOUS_PROOF.md` preserves the preceding radius-1/40 exposition. The earlier
audit is historical provenance, not an audit of the new weighted arithmetic or
a replacement for this package's checks. The interval kernel and ordinary
Taylor kernel are retained unchanged; the new weighted global kernel is
explicitly described and tested below.

### 1.1 Exact invariant normalization

For

$$
E=\begin{pmatrix}1&1&1\\1&a&b\\1&c&d\end{pmatrix},
\quad s=-1-a-b,\quad t=-1-c-d,\quad v=-1-c/a-d/b,
$$

put

$$
X=|s|^2,\quad Y=|t|^2,\quad Z=|v|^2,\quad p=X+Y+Z,
\quad J=2\operatorname{Re}(sv\bar t),\quad W=XY+XZ+YZ-XYZ,
$$

$$
g=27-3p+J,\quad\eta=9-p+J,\quad
\chi=W-(p-9)(p-18)+(p-15)J,\quad R=4g^2\eta-\chi^2.
$$

The signed six-by-six determinant D has 48 integer Laurent words. Its exact
conjugation identity is bar(D)=-D. The regenerated identity is

$$R(p,-J,W)=-D(E)^2=f(E)^2,\qquad f=-iD.$$

For a physical matrix and complementary column triples in fixed rows, row
orthogonality reverses all three off-diagonal Gram parameters. It leaves X,Y,Z
unchanged and replaces J by -J. Thus, for a corner Q and its same-row complement
Q^c,

$$R(Q^c)=f(Q)^2,\qquad M(H)=\max_Q|f(Q)|^2. \tag{1}$$

In particular, at a hypothetical strict maximal selected corner,

$$|f(Q)|\le q:=\sqrt{R(E)}\quad\text{for every positional corner }Q. \tag{2}$$

It is important that (1) relates **complementary** corners, not a corner to its
own signed square. No reconstruction or classification assumption is used.

For auxiliary matrices that are not flat, replace negative raw-entry powers in
D by powers of the conjugate entry. This gives a polynomial extension without
inverting any possibly zero lower-block entry. It agrees with f on a physical
matrix. The native fast six-term expression for each mixed corner is checked
against this literal polynomial extension.

## 2. A uniform source bound q <= 44 rho^2 on the full target ball

Let theta=theta_*+u in local seed-angle lifts and rho=||u||infinity. Define the
outward native seed width and completion width by their exact dyadic values:

```
RHO   = 0x1.999999999999bp-5  > 1/20
DELTA = 0x1.999999999999bp-4  > 1/10
```

These widths are exact binary64 rationals. They enlarge, never narrow, the
asserted rational seed cube. DELTA is an auxiliary completion-angle width, not
a seed or matrix radius.

### 2.1 Exact Laurent and Taylor coefficients

The generator produces

$$R(\theta)=\sum_{\nu\in\mathbb Z^4}c_\nu e^{i\nu\cdot\theta},
\qquad c_\nu\in\mathbb Z,$$

with 2,083 nonzero terms. At theta_+=(2,4,4,2)pi/3, each phase is
omega^(nu1+2nu2+2nu3+nu4), where omega^2+omega+1=0.
For every multi-index alpha of degree at most ten, the derivative sum is
computed exactly in Z[omega]. Multiplication by i^|alpha| and division by
alpha! gives its Taylor coefficient. Even-degree coefficients are rational;
odd-degree coefficients are rational multiples of sqrt(3).

There are 1,001 multi-indices. Every coefficient below degree four vanishes,
and the degree-four term is exactly

$$R_4(u)=243(u_1u_4-u_2u_3)^2.$$

The complete nonzero table is regenerated and compared with the retained JSON.
Using sqrt(3)<26/15, the coefficient l1 norms have the following exact upper
bounds:

| Degree n | Bound L_n |
|---:|---:|
| 4 | 972 |
| 5 | 202176/5 |
| 6 | 27936 |
| 7 | 303264 |
| 8 | 393192 |
| 9 | 4297644/5 |
| 10 | 9216504/5 |

The integral remainder for the unit exponential proves, for all real x,

$$\left|e^{ix}-\sum_{j=0}^{10}\frac{(ix)^j}{j!}\right|
\le\frac{|x|^{11}}{11!}.$$

Summing this inequality over the exact Laurent terms gives

$$|\mathcal E_{11}(u)|\le A_{11}\rho^{11},\qquad
A_{11}=\frac{1}{11!}\sum_\nu|c_\nu|\|\nu\|_1^{11}
=\frac{31405613662277}{51975}. \tag{3}$$

Reality and conjugation give R_minus(u)=R_plus(-u), which is checked directly
on the root exponents. Thus any cube bound for the first seed also holds at the
conjugate seed. No independent unverified expansion at the other seed is assumed.

### 2.2 Joint tensor-Bernstein bound

Bounding every homogeneous polynomial by its coefficient norm loses too much.
Instead, for rho>0 put u=rho*v and t=rho/RHO. Then v lies in [-1,1]^4 and t in
[0,1]. The degree-four through degree-eight contribution to R/rho^4 is

$$P(v,t)=\sum_{n=4}^{8}\mathrm{RHO}^{n-4}t^{n-4}R_n(v).$$

Replace sqrt(3) in the odd-degree coefficient table by the exact rational
s0=1732051/10^6. The verifier proves

$$\left(s_0-10^{-6}\right)^2<3<s_0^2,$$

so the error is bounded by

$$E_{\rm root}=10^{-6}\sum_{n\in\{5,7\}}
\mathrm{RHO}^{n-4}\sum_{|\alpha|=n}|b_\alpha|,$$

where the odd coefficient is b_alpha sqrt(3). This is an absolute error bound,
so no assumption about the signs of the coefficients is needed.

The rational polynomial after replacement has tensor degrees at most
(8,8,8,8,4). Map each v coordinate to 2s-1 with s in [0,1], and transform to the
Bernstein basis. All 9^4*5=32,805 coefficients are computed with integers and
exact rational denominators. Their maximum bounds P plus/minus the root error,
because the Bernstein basis is nonnegative and partitions unity on the cube.

The one-variable transformation matrices are independently checked by expanding
every power back from its Bernstein representation. The five-variable transform
then uses their exact tensor product; it is not a sample or a fitted polynomial.

Including degrees nine and ten and (3), the bound is

$$\frac{R(\theta_*+u)}{\rho^4}
\le B_{\max}+E_{\rm root}
+L_9\mathrm{RHO}^5+L_{10}\mathrm{RHO}^6+A_{11}\mathrm{RHO}^7
<1928<1936=44^2. \tag{4}$$

The exact rational quantities are recorded in the full verification receipt.
For orientation only, their sum is about 1927.24068973; the accepting comparison
is the exact rational inequality in (4), not that decimal.

We therefore have the uniform necessary condition

$$\boxed{q=\sqrt{M(H)}=\sqrt{R(E)}\le44\rho^2}
\qquad(\rho\le1/20), \tag{5}$$

and the same bound holds on the slightly enlarged native cube. The center is
handled by R=0. There is no division by the leading form, kappa, a side-fiber
clearing factor, or a possibly vanishing derivative. The degeneracy cone and
all coupled radial approaches are included.

## 3. Exhaustive nonsingular completion model at the larger radius

Fully dephase a hypothetical physical matrix while keeping the selected corner
in the upper-left block:

$$H=\begin{pmatrix}E&B\\C&T\end{pmatrix}.$$

The first row and column are one. If a row of three unit phases has prescribed
sum S and first entry z, divide by z and put

$$a_0=S\bar z-1,\qquad k=\sqrt{|a_0|^{-2}-1/4}.$$

The other two normalized entries are necessarily

$$a_0(1/2-ik),\qquad a_0(1/2+ik), \tag{6}$$

in either order. This follows by solving their sum and two modulus-one
equations. It is an exhaustive elementary two-point formula, not an assumed
side-fiber classification.

### 3.1 Domain and orientation guards

The seed estimates give |S|<=2rho. Throughout the enlarged native cube,

$$|a_0|\ge1-2\rho>89/100,\qquad
k^2\ge(1+2\rho)^{-2}-1/4>9/16.$$

Thus k>3/4, and the imaginary part of the first expression in (6) is positive:

$$\operatorname{Im}[a_0(1/2-ik)]
\ge(3/4)(1-2\rho)-\rho>0.$$

For unit p,q with |1+p+q|<=epsilon<=1/8, an elementary three-phase estimate
places p within 3epsilon of the cube root having the same imaginary sign, and
q within 4epsilon of the opposite root. For completeness,
||1+p|-1|<=epsilon implies |Re(p)+1/2|<=3epsilon/2. On Re(p) in [-3/4,-1/4],
the change in the absolute imaginary part is at most the change in Re(p), so
the first chord bound follows; the sum equation gives the second.

Taking epsilon=2rho in (6) gives entry errors at most 6rho and 8rho. The two
nontrivial B rows must have opposite orders: equal orders would give inner
product modulus at least 3-32rho, whereas physicality bounds it by 4rho.
The strict inequality 3-32rho>4rho is checked on the enlarged cube. A permutation
of the other two columns fixes the order. The same reasoning holds for C.

Let K=K(E;z,w) be the normalized side matrix with first row/column one, with
these opposite orders, and let L=K(E^T;x,y). Then every hypothetical physical
completion has unit anchors z,w,x,y and

$$B=Z_0K,\qquad C=L^TW_0,\qquad
T=-CE^*Z_0(K^*)^{-1}, \tag{7}$$

where Z0=diag(1,z,w), W0=diag(1,x,y). The last equation is exact physical row
orthogonality; the factor order is part of the formula.

The sharper side estimate is

$$\|K-F_3\|_{\rm op}\le\|K-F_3\|_F\le\sqrt{200}\rho,$$

because the four differing entries have bounds 6rho,8rho,6rho,8rho. Consequently

$$\sigma_{\min}(K)\ge\sqrt3-\sqrt{200}\rho
>\frac{173}{100}-\frac{283}{20}\rho>1.$$

The squares of 173/100 and 283/20 check the two radical comparisons exactly.
This estimate replaces the smaller-radius bound using 16rho and does not reuse
an invalid derivative constant at 0.05.

Each rotated cube-root triple has a member of real part at least 1/2. Its
actual side triple is within 8rho, and 1/2-8rho>0. Thus complementary-column or
complementary-row permutations permit anchors with

$$\arg z,\arg x\in[-\pi/2,\pi/2],\qquad
\arg w,\arg y\in\mathbb R/(2\pi\mathbb Z). \tag{8}$$

These permutations do not alter the chosen seed. The model (7) is nonsingular
throughout the seed cube and all unit anchors. It may contain nonphysical
auxiliary points; only necessary physical constraints are used to exclude them.
There is no conversion of the seed radius into a matrix or projector radius.

## 4. Necessary residuals

The model has 94 real residuals: nine lower-block flatness defects; four real
components of the remaining row/column orthogonality conditions; and 81 signed
mixed-corner invariants (two upper and one lower row, two left and one right
column). At a physical maximal completion,

$$\mathcal F_k=0\ (0\le k<13),\qquad
|\mathcal F_k|\le q\ (13\le k<94). \tag{9}$$

For the mixed corners, the first three free normalized entries are identically
unit phases in the model, while the fourth may be nonflat. The six-term native
formula is exactly equal to the literal polynomial extension from Section 1
on every real model input. This is checked in an independent Laurent ring
with separate symbols for the nonflat entry and its conjugate. It justifies
both the function values and their Taylor coefficients without asserting
flatness of independent interval endpoints.

## 5. Two Taylor backends, with distinct remainder semantics

All coefficients and elementary arithmetic operations are outward enclosed.
The original interval kernel requires IEEE-754 binary64, round-to-nearest,
ordinary binary64 evaluation, and gradual underflow. Compiler options disable
fast-math and floating-point contraction; the GCC-only value-range option is
omitted for Clang. Square-root brackets are validated by outward squaring.
Trigonometric values are enclosed by rational-coefficient Taylor expansions
with explicit analytic remainders. Invalid domains and nonfinite endpoints
are nonaccepting.

### 5.1 Ordinary degree six for local radial contractions

The ordinary backend keeps all monomials of total degree at most six in eight
common variables: 3,003 monomials and 74,613 multiplication pairs. It represents

$$f(\xi)=P_f(\xi)+e_f(\xi),\qquad
|e_f(\xi)|\le\tau_f h^7,\qquad h=\|\xi\|_\infty\le1. \tag{10}$$

Multiplication keeps degrees through six and bounds every discarded degree
and every tail product. Exponentials use the integral remainder. Inversion
and positive square roots expand about the actual constant f(0), enclosed in
its interval. For x=f/f(0)-1 the actual constant is exactly zero. If its norm
bound gives |x|<=alpha*h with alpha<1, six terms of the geometric or binomial
series leave a tail bounded by

$$\frac{\alpha^7}{(1-\alpha)\inf|f(0)|},\qquad
\sup\sqrt{f(0)}\,\left|\binom{1/2}{7}\right|
\frac{\alpha^7}{1-\alpha},$$

respectively. Errors generated while forming the finite series are retained.
The scalar coefficient in (10) is not a numerical tolerance.

### 5.2 Weighted Taylor models for the global cover

The global backend retains precisely the monomials satisfying

$$2(\alpha_1+\cdots+\alpha_4)+3(\alpha_5+\cdots+\alpha_8)\le12.$$

The first four variables are seed perturbations. The last four are completion
angles. This downward-closed set has **975 monomials and 14,313 multiplication
pairs**. Its purpose is to retain sixth-order seed terms while keeping fourth-
order completion terms without the cost of the full ordinary degree-six basis.

Its invariant is an **absolute** enclosure on the cube,

$$f(\xi)=P_f(\xi)+e_f(\xi),\qquad |e_f(\xi)|\le\tau_f.
\tag{11}$$

The retained coefficients enclose the actual weighted Taylor coefficients;
in particular the constant is f(0). No assertion of a radial error h^13 is
made. **This backend is never used for the local contraction.** The native
local operation rejects a weighted build.

Products group coefficient norms by weighted degree. All products with weight
above 12, and all products involving either tail, contribute to a new absolute
tail. For a phase in a seed variable, the exponential keeps six terms beyond
the constant; for a completion variable it keeps four. Its corresponding
integral remainder is added in full.

For inversion and square root, set x=f/f(0)-1, whose constant vanishes exactly,
and prove |x|<=alpha<1. The finite series through power six suffice: every
nonconstant variable has weight at least two, so x^7 has no retained Taylor
coefficient. The unretained analytic series is bounded absolutely by the same
alpha^7/(1-alpha) geometric bound (or the corresponding binomial bound), with
no radial factor. The intermediate products' discarded weighted terms and
absolute tails are also retained.

This reasoning proves both the exact-coefficient invariant and (11). In
particular, setting x's constant to zero uses the actual f(0), not an unrelated
chosen point from its interval. All real model functions in use are analytic
on the guarded domains. The verification implementation and controls explicitly
distinguish the two remainder semantics.

A polynomial's global range is obtained by coefficientwise ranges: an even
monomial lies in [0,1], any other nonconstant monomial in [-1,1], followed by
plus/minus its absolute tail. This is conservative regardless of cancellation.
Common-variable combinations are formed before ranging, preserving useful
cancellation without assuming independent endpoints represent the same point.

## 6. Local exclusion on all radial scales

In units of pi/3, let

$$C_3=\{(0,0),(2,4),(4,2)\},$$

$$B_6=\{(a,b)\in(\mathbb Z/6)^2:
b=2a\text{ or }a=2b\text{ or }a+b=0\}.$$

The reference set is (C3 x B6) union (B6 x C3), with 63 distinct elements.
At u=0 the model gives exact sixth-root physical matrices. The verifier checks
all 36 Gram entries and all 400 signed zeros at each reference, in two integer
Eisenstein implementations. This proves exact vanishing of every residual's
constant term used below.

The physical maps transpose, S times conjugation, and conjugation times S,
where S swaps indices 1 and 2 in each three-block, act on the anchors as

$$(a,b,c,d)\mapsto(c,d,a,b),\quad(-b,-a,-c,-d),\quad
(-a,-b,-d,-c)\pmod6.$$

Their seed actions and anchor perturbation actions are signed permutations.
They preserve each width group and physical maximality. The exact orbit
partition has 13 representatives, and their union is all 63 references.

For each representative choose the fixed exact dyadic 8-by-94 matrix P in
the retained data. Each entry is an integer divided by 2^38, and its native
encoding is checked independently: **9,776 bindings**. The proposal used linear
optimization, but neither the solver status nor an approximate inverse identity
is a premise. The verifier recomputes the entire linear defect.

Let the eight model-angle displacements be W*xi, with four seed widths RHO
and four completion widths DELTA. Put

$$G_i(\xi)=\xi_i-\frac{(P\mathcal F(W\xi))_i}{W_{ii}}.$$

Ordinary degree-six models give

$$|G_i(\xi)|\le e_i h,\qquad h=\|\xi\|_\infty,$$

where e_i is the outward sum of the linear defect, all higher coefficients,
and the radial tail divided by Wii. The actual constant is zero by the exact
reference checks, not by a near-zero tolerance.

Define C_i=sum_{k=13}^{93}|P_ik|. From (5) and (9), at a hypothetical physical
maximal point,

$$\frac{|(P\mathcal F(W\xi))_i|}{W_{ii}}
\le\frac{44\,\mathrm{RHO}^2 C_i}{W_{ii}}h^2=:b_i h^2.$$

The accepting inequalities, one for each of eight rows at each of 13
representatives, are

$$\boxed{e_i+b_i<1.} \tag{12}$$

They imply

$$h\le\max_i(e_i h+b_i h^2)\le\max_i(e_i+b_i)h,$$

so h=0. There is no positive minimum h or missing radial shell. At h=0 the seed
is stationary and R=0, contradicting strictness.

The complete fresh public GCC local replay has all **104 inequalities**
below one, with worst outward score

$$\frac{6989400537360665}{9007199254740992}
\approx0.77597934049<\frac{39}{50}<1.$$

Every public invocation recomputes these inequalities. The complete global replay
also passed; the local success alone would not have established it.

## 7. Complete global coverage of all completion phases

Cover (8) by 324 closed initial cells of halfwidth pi/6. The z,x centers are
-pi/3,0,pi/3, and the w,y centers are all six roots. The same physical symmetry
group partitions these cells into 102 represented orbits. The initial domain
need not be invariant under each generator: intersections of the full orbits
with the initial set give the valid exact partition, checked explicitly.

A binary path bisects coordinate depth modulo four. Children are closed halves,
so shared faces are retained. Midpoints and radii are exact rational multiples
of pi/6. The native pi interval is checked against exact Machin-series bounds;
all native radii are outward enlargements. For each representative root the
verifier requires unique, prefix-free terminal paths and exact equality

$$\sum_{p\text{ terminal}}2^{-|p|}=1.$$

It separately requires the complete source root set. An independent validator
builds each binary tree and requires both children at every nonterminal, then
checks the symmetry union against all 324 initial cells. A successful subset
cannot be counted as a full cover.

Each terminal must pass one of these necessary-condition tests on the entire
seed cube and its completion-phase cell:

* Whole-cell containment in a reference box certified by (12).
* A side-factor inequality. The exact F3 two-column determinant is
  3(z^2-w)(z-w^2)(zw-1)/(z^2w^2). The actual signed value differs by at most
  (12+24sqrt(3))rho+112rho^2<64rho. A factor lower bound exceeding
  QMAX+64 RHO excludes the cell. The transpose supplies the second side.
* A physical residual range missing zero, or a signed residual range disjoint
  from [-QMAX,QMAX], where QMAX outward encloses 44 RHO^2.
* A common-variable preconditioned residual range. Any finite dyadic matrix
  P and eight chosen residuals are permitted. After forming the combination
  in a Taylor model, a row range disjoint from [-C_i QMAX,C_i QMAX] contradicts
  (9). Selection and inversion proposals are noncertifying; only the final
  outward separation accepts.

The new global construction starts from all 102 initial representative roots,
not from a presumed successful smaller-radius cover. Source records use backend
label `degree: 12` for the weighted model; the interface also explicitly supports
ordinary degree six. This label specifies an enclosure algorithm, not proof
of a predicate. The complete verifier recompiles the corresponding engine and
recomputes every terminal. Stored successful labels and construction logs are
not trusted as acceptance evidence.

Any unresolved cell, invalid model domain, malformed path, failed root orbit,
missing terminal, or nonpositive predicate prevents the whole-ball result.
The final finite counts and the fresh replay receipts are recorded separately.

## 8. Logical conclusion and conjugate seed

Suppose a physical strict maximal completion exists in the punctured target
ball. The side ordering and anchor selection put it in (7)--(8), without
changing its selected corner. Some closed initial cell contains its anchors.
A physical symmetry maps it into a representative cell while preserving the
seed cube and maximality. Its complete binary cover contains the point in
some terminal.

A residual-excluded terminal contradicts (9). A locally contained terminal
invokes (12), which forces h=0 and hence R=0. Both alternatives contradict the
hypothesis. Successful replay of all finite obligations therefore proves the
entire uniform ball.

Conjugation preserves physicality, every corner R, maximality, and circular
sup distance. It interchanges the two stationary seeds and reverses their
perturbations. This transports the result to the conjugate seed; the invariant
coefficient transformation and both box-membership labels are also checked.

The 63 references have never been assumed to exhaust all physical completions.
Their complement is handled by the separate complete phase cover. Nor has a
finite annulus been substituted for the radially uniform local argument.

## 9. Controls and verification scope

The verifier regenerates the source bound, exact invariant identities, model
identities, all references, physical controls, and exact data encodings. It
compiles ordinary degree-six and weighted-degree-twelve engines afresh, then
runs arithmetic controls, all local rows, exact cover validation, and every
global terminal.

The new arithmetic controls test all basis exponents and multiplication pairs
against independent exact enumeration. They reconstruct formal coefficients
for 22 polynomial/inverse/square-root/exponential models in seed-only,
completion-only, and mixed variable pairs. Both backends check 1,300 exact
interval-operation cases and seven trigonometric cases. Their coefficient
checks total 87,516, and their remainder regression points total 1,100.
These are controls; the analytic remainder justification is Section 5, not
sampling. No radial h^13 interpretation is tested or used for the weighted tail.

The six supplied known physical strict-D0 points are independently reconstructed
with their all-400 corner census. Each has a zero seed coordinate at circular
distance 2pi/3>1 from either corresponding stationary coordinate, so all are
outside both new balls. Their exact enclosing boxes are nonaccepting. Additional
controls check outer-boundary inclusion, conjugation, integer circular wraps,
malformed floating input, invalid backend labels, outside boxes, and seed-touching
boxes. The obsolete legacy geometry helper is absent.

Actual compilation, local, global, and full-replay times appear in the retained
receipts. A second compiler build is a useful execution cross-check, not an
independently designed full verifier. The trust boundary includes the stated
IEEE-754 execution model, interval/Taylor implementation, and the elementary
analytic arguments here. No Lean formalization or independent peer review is
claimed.

## 10. Reproduction, pilot boxes, and exact whole-box interface

From this directory:

```
sha256sum -c MANIFEST.sha256
python -B verify.py --output work/full_replay.json --workers 4
```

For a list of boxes:

```
python -B verify.py --boxes LIST.jsonl.gz --output work/results.jsonl.gz --workers 4
```

A box invocation first replays the complete proof. It then checks whole-box
membership in a punctured radius-1/20 circular seed ball. Inputs use four exact
rational strings each for absolute-radian centers and radii. The additional
explicit `seed_radius_units` format has scale exactly 1/20; integer lifts are
handled exactly. A containing/touching-seed box is nonaccepting under the
requested puncture interface, even though R=0 handles the center in the theorem.
Unresolved membership is nonacceptance. Any nonaccepted record gives a nonzero
exit status. Pinned package files and input files are protected against overwrite.

The eight positive examples lie wholly outside both old radius-1/40 balls.
The 2,354 supplied original pilot boxes are also checked for exact inclusion in
the new ball. `examples/acceptance_boxes.jsonl.gz` combines these 2,362 records.
Their membership success becomes an exclusion certificate only after the full
proof replay. Merely lying within a target radius does not create an accepting
proof when the full obligations have not passed.

Component-only mode explicitly reports a nonuniform status and is incompatible
with `--boxes`. A successful receipt must be interpreted together with the
mathematical arguments, not as a standalone proof. The radius 0.05 is not
claimed optimal. No uniform radius 0.06 or replay of the rest of the global
no-four-MUBs campaign is asserted.

## 11. Completed finite census and additional independent checks

The complete fresh GCC replay checks **38,421 global terminals**, all using the
weighted backend, covering all 102 representative roots and hence all 324
initial phase cells. The maximum binary depth is **20**. The independent
complete-tree validator checks **38,319 internal nodes** and no missing child.
There are zero unresolved terminals. The local replay checks all **104** rows
for **13** representatives, whose exact symmetry orbits cover all **63**
reference completions. All **9,776** dense coefficient encodings are checked.

The eight positive boxes lie wholly outside both old radius-1/40 balls. The
exact original pilot list has **2,354 unique records**, all accepted after the
full proof. Its independently enclosed maximum seed distance is less than
19/400, hence strictly below the new radius 1/20. The original pilot bytes and
the complete 2,362-record acceptance output are retained. No conclusion about
an unprovided full-run list is inferred.

An additional implementation over Q(i,sqrt(3)) checks ordinary sixth-order
directional coefficients using direct inversion of the full B block and the
literal 48-word determinant, rather than the native factored inverse and fast
signed formula. It checks **2,912 exact coefficients** at all 13 reference
representatives, in four directions, on eight selected residuals per reference.
An independent 100-decimal-digit outward evaluation checks **2,080 radial
remainders**, subtracting those exact Taylor polynomials and testing the h^7
bound. All pass. These finite audits are not a separate full-ball proof and
do not justify lowering a uniform remainder constant from the observed samples.
The primary proof verifier has no mpmath dependency; that library is used only
by this supplementary audit.

The GCC receipt preceded the final documentation and manifest freeze; all
accepting source, numerical data, and arithmetic kernels are unchanged by that
freeze. A separate clean-extraction replay checks the final module with Clang.
Its completed receipt is distributed alongside the unchanged proof module to
avoid a circular manifest dependency. See `VERIFICATION.md` for chronology.
