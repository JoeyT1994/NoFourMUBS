# Verification chronology and measured costs

The target and proved radius is exactly **1/20** in circular seed-angle radians.
The complete public GCC invocation returned `PASS_UNIFORM_BALL`, freshly checking
**38,421** terminal predicates, **104** local inequalities, the exact complete
cover geometry, all source/data bindings, and the arithmetic controls. It then
accepted every one of the **2,354** original pilot records and **8** positive
examples. The complete receipt and output are retained under `results/`.

| Measured GCC quantity | Value |
|---|---:|
| Proof replay wall seconds (before box-output processing) | 997.941529648 |
| Global replay wall seconds | 898.801110507 |
| Summed native global-worker CPU seconds | 3557.621000000 |
| Native local CPU seconds | 77.349300000 |
| Global terminals | 38,421 |
| Local rows | 104 |
| Accepted input boxes | 2,362 |

These are observed verification costs with four global workers, not estimates,
performance guarantees, or the cost of all exploratory work. The complete
construction has its own separately labeled receipt.

The initial GCC replay used a manifest written before this final documentation
and receipt freeze. No accepting code, kernel, preconditioner, Taylor table,
cover leaf, or mathematical constant changes in that documentation step. The
final manifest additionally pins the completed receipts and documentation.
The final proof module is then archived, extracted into a clean directory, and
replayed with Clang. That external receipt checks this final module manifest
and is placed beside the module, rather than inserted into its own manifest.
The final delivery adds those external receipts without changing module bytes.

Both builds use C++17, `-O3`, `-fno-fast-math`, and `-ffp-contract=off`. GCC also
uses `-fno-tree-vrp`; Clang omits that unsupported GCC-specific option. Runtime
IEEE-754 and underflow guards remain active. Two compiler runs are not two
independently designed full verifiers, a Lean proof, or independent peer review.

The ordinary interval and Taylor kernels match the baseline byte-for-byte.
The new weighted kernel and accepting-code changes are explicitly documented,
pinned, and checked by the new controls. `SOURCE_COMPARISON.json` and
`SOURCE_CHANGES.diff` give the source comparison.

The optional independent derivative/remainder audit passed 2,912 exact
coefficient checks and 2,080 outward remainder tests. Its receipt records the
backend, precision, directions, and scope. These tests supplement the analytic
remainder arguments and do not replace them or certify a larger radius.
