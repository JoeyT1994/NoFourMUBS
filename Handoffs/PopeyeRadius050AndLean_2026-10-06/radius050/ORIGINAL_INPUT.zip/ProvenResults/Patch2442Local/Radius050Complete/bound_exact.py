"""Exact source-majorant and physical-model domain checks."""
import seed_bound
def check(rho=None):
    return seed_bound.check(rho)
