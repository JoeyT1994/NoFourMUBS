# Supplemental independent checks at radius 1/20

These scripts test the ordinary degree-six completion model using a separate
implementation over Q(i,sqrt(3)), with coefficient recurrences, direct inversion
of the full B block, and the literal 48-word signed determinant. They compare
2,912 exact directional coefficients at all 13 local reference representatives
and test 2,080 radial remainders with 100-decimal-digit outward arithmetic.
The exact polynomial, not the native interval polynomial, is subtracted in
the remainder tests. All retained tests passed.

These are supplementary finite regression/audit tests. They are not an
independently designed full-ball verifier, do not individually check every
multivariate coefficient, and do not justify decreasing a uniform tail bound
from sampled ratios. The weighted global backend is covered by the main
proof verifier's separate exact basis/coefficient and absolute-tail controls;
this additional directional audit is of the ordinary local backend.

Run the main proof verifier first. To reproduce the supplementary checks:

```bash
python -m pip install -r requirements.txt
python scripts/run.py --package /path/to/Radius050Complete --work audit_run
```

The audit-only mpmath dependency is not required by the main proof verifier.
The runner checks package hashes and recompiles the coefficient exporter.
The output can be substantially larger than the small retained receipts.
Compiler selection is available with `--compiler`. Python optimization mode
is prohibited. The old environment variable names in the two inherited audit
modules are set explicitly by the runner; they do not change the target radius.

## Independent global geometry and weighted-model point controls

`scripts/structural_cover.py` reconstructs the initial symmetry orbits and every
closed binary tree independently, requiring both children at each internal node.
It also compares iterative rational bisection with the integer coordinate formula
on every leaf: 153,684 exact coordinate comparisons, with no missing branches.
This is a geometry audit, not a residual replay. See `receipts/STRUCTURAL_COVER.json`.

The weighted global model additionally passed 1,440 independent outward point
enclosure tests: 12 distinct nonreference completion-phase cells, 15 residuals,
and eight exact rational cube points per cell. Values use a direct full B inverse
and the literal 48-word signed determinant at 100-decimal-digit interval precision.
The native weighted polynomial intervals plus their absolute tails enclosed all
independent values. These are finite controls of actual model expressions, not
an independent proof of every weighted coefficient or remainder. Their sampled
ratios cannot reduce any uniform tail bound. The fixed cells, exporter, checker,
and receipt are included.

```bash
python scripts/weighted_points.py --package /path/to/Radius050Complete \
  --work weighted_audit_run --cells data/weighted_cells.txt
```

This supplementary run recompiles its exporter without modifying the proof
module. `--reuse-export` is an audit convenience for a retained native export;
the documented command regenerates it. The script checks the proof-module hashes
before either mode. It does not issue full-ball acceptance certificates.

`receipts/FAIL_CLOSED.json` records additional negative-interface tests. Python
optimization mode, component-only box acceptance, an output path overwriting
pinned proof text, and use of the weighted backend for a local radial contraction
were all rejected with nonzero exit statuses. No accepting output was created,
and the proof text hash was unchanged. These tests do not alter the proof module.
