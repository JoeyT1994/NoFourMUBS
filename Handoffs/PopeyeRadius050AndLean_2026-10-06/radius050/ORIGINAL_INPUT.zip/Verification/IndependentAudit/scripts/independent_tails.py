#!/usr/bin/env python3
"""Independent high-precision outward checks of radial Taylor remainders.
The Taylor polynomials are the independently computed EXACT Q(i,sqrt(3)) jets,
not the native polynomial intervals. Function values use mpmath interval
arithmetic and literal signed words, with direct inversion of the full B block.
These are finite audit tests, not a substitute for the analytic remainder proof.
"""
from pathlib import Path
if not __debug__:raise RuntimeError("Python optimization is prohibited for the audit.")
from fractions import Fraction as F
import json,time,sys
import mpmath
from mpmath import iv
import independent_jets as jets
iv.dps=100
ROOT=jets.ROOT;BASE=jets.BASE
ZERO=iv.mpf(0);ONE=iv.mpf(1)
def real(q):
    q=F(q);return iv.mpf(q.numerator)/iv.mpf(q.denominator)
class C:
    __slots__=('r','i')
    def __init__(self,r=0,i=0):self.r=r if hasattr(r,'_mpi_') else real(r);self.i=i if hasattr(i,'_mpi_') else real(i)
    @staticmethod
    def cv(x):return x if isinstance(x,C) else C(x)
    def __add__(self,o):o=C.cv(o);return C(self.r+o.r,self.i+o.i)
    __radd__=__add__
    def __neg__(self):return C(-self.r,-self.i)
    def __sub__(self,o):return self+-C.cv(o)
    def __rsub__(self,o):return C.cv(o)+-self
    def __mul__(self,o):o=C.cv(o);return C(self.r*o.r-self.i*o.i,self.r*o.i+self.i*o.r)
    __rmul__=__mul__
    def conj(self):return C(self.r,-self.i)
    def norm(self):return self.r**2+self.i**2
    def inv(self):n=self.norm();return C(self.r/n,-self.i/n)
    def __truediv__(self,o):return self*C.cv(o).inv()
    def pow(self,n):
        if n<0:return self.conj().pow(-n)
        if n==0:return C(1)
        if n==1:return self
        return self*self.pow(n-1)
SQ3=iv.sqrt(iv.mpf(3));ROOTS=[C(1),C(F(1,2),SQ3/2),C(F(-1,2),SQ3/2),C(-1),C(F(-1,2),-SQ3/2),C(F(1,2),-SQ3/2)]
def phase(root,t):t=real(t);return ROOTS[root%6]*C(iv.cos(t),iv.sin(t))
def matmul(A,B):return [[sum((A[i][k]*B[k][j] for k in range(len(B))),C()) for j in range(len(B[0]))] for i in range(len(A))]
def adj(A):return [[A[j][i].conj() for j in range(len(A))] for i in range(len(A[0]))]
def determinant(A):
    from itertools import permutations
    total=C()
    for p in permutations(range(len(A))):
        par=sum(p[i]>p[j] for i in range(len(A)) for j in range(i+1,len(A)));t=C((-1)**par)
        for i,j in enumerate(p):t=t*A[i][j]
        total=total+t
    return total
def inverse(A):
    den=determinant(A).inv()
    return [[((-1)**(i+j))*determinant([[A[r][c] for c in range(len(A)) if c!=i] for r in range(len(A)) if r!=j])*den for j in range(len(A))] for i in range(len(A))]
def side(E,z):
    B=[[C(1)]*3]
    for j in range(2):
        s=-sum(E[j+1],C());a=s*z[j].conj()-1;k=iv.sqrt(ONE/a.norm()-real(F(1,4)))
        p=a*C(F(1,2),(-k if j==0 else k));q=a-p
        B.append([z[j],z[j]*p,z[j]*q])
    return B
def model(roots,direction,t):
    widths=[F(float.fromhex('0x1.999999999999bp-5'))]*4+[F(float.fromhex('0x1.999999999999bp-4'))]*4
    v=[w*d*t for w,d in zip(widths,direction)]
    E=[[C(1) for _ in range(3)] for _ in range(3)]
    for i in range(1,3):
        for j in range(1,3):E[i][j]=phase(2*i*j,v[(i-1)*2+j-1])
    z=[phase(roots[j],v[j+4]) for j in range(4)];B=side(E,z[:2]);Ct=side(list(map(list,zip(*E))),z[2:]);C0=list(map(list,zip(*Ct)))
    D=matmul(matmul(C0,adj(E)),inverse(adj(B)))
    return [E[i]+B[i] for i in range(3)]+[C0[i]+[-v for v in D[i]] for i in range(3)]
def residual(H,index):
    if index<9:return H[3+index//3][3+index%3].norm()-1
    if index<13:
        z=sum(([H[k][2]*H[k][1].conj() for k in range(6)] if index>=11 else [H[2][k]*H[1][k].conj() for k in range(6)]),C())
        return z.r if index%2 else z.i
    rr,cc=jets.CORNERS[index-13];v=[H[i][j] for i in rr for j in cc];powers=[[z.pow(k) for k in (-2,-1,0,1,2)] for z in v];out=C()
    for co,e in jets.WORDS:
        p=C(co)
        for j,n in enumerate(e):
            if n:p=p*powers[j][n+2]
        out=out+p
    return out.i
def frac_mpf(t):
    sign,m,e,b=t;assert b>=0
    return F((-1)**sign*m*(2**e)) if e>=0 else F((-1)**sign*m,2**(-e))
def abs_upper(x):return max(abs(frac_mpf(t)) for t in x._mpi_)
def main():
    start=time.monotonic();_,_,tails=jets.load_native();data=json.loads((BASE/'data/preconditioners.json').read_text());selected=json.loads((BASE/'data/local_representatives.json').read_text());coeff=json.loads((ROOT/'exact_directional_coefficients.json').read_text())
    directions=[tuple(map(F,[1,1,1,1,0,0,0,0])),tuple(map(F,[1,-1,-1,1,1,-1,1,-1])),tuple(F(x,4) for x in (1,-2,3,-4,-3,1,4,-2))]
    directions.append(tuple(map(F,[0,0,0,0,1,-1,1,-1])))
    radii=[F(1),F(1,2),F(1,16),F(-1,8),F(1,256)]
    checks=0;max_ratio=F(0)
    for idx in selected:
        for di,direction in enumerate(directions):
            for t in radii:
                H=model(data[idx]['root'],direction,t)
                for res in data[idx]['rows']:
                    value=residual(H,res);poly=ZERO
                    for deg,co in enumerate(coeff[f'{idx}/{di}/{res}']):
                        a,b,c,d=map(F,co);assert c==d==0
                        poly+=(real(a)+real(b)*SQ3)*real(t**deg)
                    remainder=abs_upper(value-poly);bound=tails[idx,res]*abs(t)**7
                    assert remainder<=bound,(idx,di,res,str(t),str(remainder),str(bound))
                    if bound:max_ratio=max(max_ratio,remainder/bound)
                    checks+=1
        print('PASS reference',idx,'checks',checks,flush=True)
    r={'status':'PASS_INDEPENDENT_OUTWARD_RADIAL_REMAINDER_TESTS','backend':'mpmath.iv','version':mpmath.__version__,'precision_decimal_digits':100,'references':len(selected),'directions':len(directions),'radial_parameters':[str(t) for t in radii],'checks':checks,'max_fraction_of_native_tail_ceiling_1e6':str(F(-(-max_ratio.numerator*1000000//max_ratio.denominator),1000000)),'wall_seconds':time.monotonic()-start,'scope':'Finite regression tests, not an independent proof of every remainder inequality.'}
    (ROOT/'independent_tails.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
if __name__=='__main__':main()
