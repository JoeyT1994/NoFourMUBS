#!/usr/bin/env python3
"""Independent exact directional derivative audit over Q(i,sqrt(3)).
Uses coefficient recurrences, literal 48-word signed invariants, and no native
Taylor-model operations. Native interval coefficients are compared exactly.
These tests are regression/audit checks, not a substitute for the ball proof.
"""
from fractions import Fraction as F
from itertools import combinations,product
from pathlib import Path
if not __debug__:raise RuntimeError("Python optimization is prohibited for the audit.")
import math,json,sys,time
import os
ROOT=Path(os.environ.get('CENTIRADIAN_AUDIT_ROOT', str(Path(__file__).resolve().parent.parent/'work')))
BASE=Path(os.environ.get('CENTIRADIAN_PACKAGE', str(ROOT/'extracted/ProvenResults/Patch2442Local/CentiradianComplete')))
ORDER=6
class K:
    __slots__=('v',)
    def __init__(self,a=0,b=0,c=0,d=0):
        self.v=tuple(map(F,(a,b,c,d)))
    @classmethod
    def raw(cls,v):
        z=object.__new__(cls);z.v=tuple(v);return z
    @staticmethod
    def cv(x):return x if isinstance(x,K) else K(x)
    def __add__(self,o):
        o=K.cv(o);return K.raw(a+b for a,b in zip(self.v,o.v))
    __radd__=__add__
    def __neg__(self):return K.raw(-a for a in self.v)
    def __sub__(self,o):return self+-K.cv(o)
    def __rsub__(self,o):return K.cv(o)+-self
    def __mul__(self,o):
        o=K.cv(o)
        if not self or not o:return ZERO
        a,b,c,d=self.v;e,f,g,h=o.v
        return K.raw((a*e+3*b*f-c*g-3*d*h,a*f+b*e-c*h-d*g,a*g+3*b*h+c*e+3*d*f,a*h+b*g+c*f+d*e))
    __rmul__=__mul__
    def inv(self):
        a,b,c,d=self.v;A=a*a+3*b*b+c*c+3*d*d;B=2*(a*b+c*d);D=A*A-3*B*B
        if not D:raise ZeroDivisionError
        return self.conj()*K.raw((A/D,-B/D,F(0),F(0)))
    def __truediv__(self,o):return self*K.cv(o).inv()
    def conj(self):
        a,b,c,d=self.v;return K.raw((a,b,-c,-d))
    def re(self):return K.raw((*self.v[:2],F(0),F(0)))
    def im(self):return K.raw((*self.v[2:],F(0),F(0)))
    def __bool__(self):return any(self.v)
    def __eq__(self,o):return self.v==K.cv(o).v
    def sqrt_center(self):
        a,b,c,d=self.v
        assert b==c==d==0 and a>=0,(self.v,'root center')
        for factor in (1,3):
            v=a/factor;n=math.isqrt(v.numerator);d=math.isqrt(v.denominator)
            if n*n==v.numerator and d*d==v.denominator:
                return K(F(n,d)) if factor==1 else K(0,F(n,d))
        raise ValueError('unexpected square root center')
ZERO=K(0);ONE=K(1);II=K(0,0,1);ROOTS=[K(1),K(F(1,2),0,0,F(1,2)),K(F(-1,2),0,0,F(1,2)),K(-1),K(F(-1,2),0,0,F(-1,2)),K(F(1,2),0,0,F(-1,2))]
class J:
    __slots__=('c',)
    def __init__(self,x=0):self.c=[K.cv(x)]+[ZERO]*ORDER
    @classmethod
    def raw(cls,c):j=object.__new__(cls);j.c=c;return j
    @staticmethod
    def cv(x):return x if isinstance(x,J) else J(x)
    def __add__(self,o):
        o=J.cv(o);return J.raw([a+b for a,b in zip(self.c,o.c)])
    __radd__=__add__
    def __neg__(self):return J.raw([-a for a in self.c])
    def __sub__(self,o):return self+-J.cv(o)
    def __rsub__(self,o):return J.cv(o)+-self
    def __mul__(self,o):
        o=J.cv(o)
        return J.raw([sum((self.c[k]*o.c[n-k] for k in range(n+1) if self.c[k] and o.c[n-k]),ZERO) for n in range(ORDER+1)])
    __rmul__=__mul__
    def inv(self):
        out=[self.c[0].inv()]
        for n in range(1,ORDER+1):out.append(-out[0]*sum((self.c[k]*out[n-k] for k in range(1,n+1)),ZERO))
        return J.raw(out)
    def __truediv__(self,o):return self*J.cv(o).inv()
    def root(self):
        out=[self.c[0].sqrt_center()];den=(2*out[0]).inv()
        for n in range(1,ORDER+1):out.append((self.c[n]-sum((out[k]*out[n-k] for k in range(1,n)),ZERO))*den)
        return J.raw(out)
    def conj(self):return J.raw([a.conj() for a in self.c])
    def re(self):return J.raw([a.re() for a in self.c])
    def im(self):return J.raw([a.im() for a in self.c])
    def pow(self,n):
        if n<0:return self.conj().pow(-n)
        if n==0:return J(1)
        if n==1:return self
        if n==2:return self*self
        return self*self.pow(n-1)
def norm2(x):return x*x.conj()
def phase(root,speed):
    out=[ROOTS[root%6]]
    for n in range(1,ORDER+1):out.append(out[-1]*II*K(speed/n))
    return J.raw(out)
def matmul(A,B):return [[sum((A[i][k]*B[k][j] for k in range(len(B))),J()) for j in range(len(B[0]))] for i in range(len(A))]
def adj(A):return [[A[j][i].conj() for j in range(len(A))] for i in range(len(A[0]))]
def determinant(A):
    from itertools import permutations
    total=J()
    for perm in permutations(range(len(A))):
        parity=sum(perm[i]>perm[j] for i in range(len(A)) for j in range(i+1,len(A)))
        v=J((-1)**parity)
        for i,j in enumerate(perm):v=v*A[i][j]
        total=total+v
    return total
def inverse(A):
    det=determinant(A);invdet=det.inv();out=[]
    for i in range(len(A)):
        row=[]
        for j in range(len(A)):
            minor=[[A[r][c] for c in range(len(A)) if c!=i] for r in range(len(A)) if r!=j]
            row.append(((-1)**(i+j))*determinant(minor)*invdet)
        out.append(row)
    return out
def side(E,z):
    B=[[J(1) for _ in range(3)]]
    for i in range(2):
        s=-sum(E[i+1],J());a=s*z[i].conj()-1
        k=(norm2(a).inv()-F(1,4)).root()
        p=a*(J(F(1,2))+k*((-1 if i==0 else 1)*II))
        q=a-p
        B.append([z[i],z[i]*p,z[i]*q])
    return B
def make_model(roots,direction):
    widths=[F(float.fromhex('0x1.999999999999bp-5'))]*4+[F(float.fromhex('0x1.999999999999bp-4'))]*4
    speeds=[w*d for w,d in zip(widths,direction)]
    E=[[J(1) for j in range(3)] for i in range(3)]
    for i in range(1,3):
        for j in range(1,3):E[i][j]=phase(2*i*j,speeds[(i-1)*2+j-1])
    z=[phase(roots[i],speeds[i+4]) for i in range(4)]
    B=side(E,z[:2]);Ct=side([list(r) for r in zip(*E)],z[2:]);C=[list(r) for r in zip(*Ct)]
    # Direct full B inverse, rather than the factored native E* Z (K*)^-1.
    D=matmul(matmul(C,adj(E)),inverse(adj(B)))
    return [E[i]+B[i] for i in range(3)]+[C[i]+[-v for v in D[i]] for i in range(3)]
TOK=list(map(int,(BASE/'data/determinant_words.txt').read_text().split()))
assert TOK[0]==48 and len(TOK)==481
WORDS=[(TOK[1+10*i],TOK[2+10*i:11+10*i]) for i in range(48)]
CORNERS=[((i,j,k),(a,b,l)) for i,j in combinations(range(3),2) for a,b in combinations(range(3),2) for k in range(3,6) for l in range(3,6)]
def residual(H,index):
    if index<9:return (norm2(H[3+index//3][3+index%3])-1).re()
    if index<13:
        terms=[H[k][2]*H[k][1].conj() for k in range(6)] if index>=11 else [H[2][k]*H[1][k].conj() for k in range(6)]
        z=sum(terms,J());return z.re() if index%2 else z.im()
    rr,cc=CORNERS[index-13];values=[H[i][j] for i in rr for j in cc]
    powers=[[v.pow(k) for k in (-2,-1,0,1,2)] for v in values]
    out=J()
    for co,e in WORDS:
        p=J(co)
        for k,n in enumerate(e):
            if n:p=p*powers[k][n+2]
        out=out+p
    return out.im()
def load_native():
    ex={};coeff={};tails={}
    for line in (ROOT/'native_models.txt').read_text().splitlines():
        p=line.split()
        if p[0]=='E':ex[int(p[1])]=tuple(map(int,p[2:]))
        elif p[0]=='P':tails[int(p[1]),int(p[2])]=F(float.fromhex(p[3]))
        elif p[0]=='C':coeff[int(p[1]),int(p[2]),int(p[3])]=tuple(F(float.fromhex(v)) for v in p[4:])
    assert len(ex)==3003 and len(tails)==104 and len(coeff)==104*3003
    return ex,coeff,tails
def root3bounds():
    s=1<<400;n=math.isqrt(3*s*s);return F(n,s),F(n+1,s)
def enclosure(v):
    a,b,c,d=v.v;assert c==d==0
    lo,hi=root3bounds();return (a+b*lo,a+b*hi) if b>=0 else (a+b*hi,a+b*lo)
def main():
    start=time.monotonic();ex,coeff,tails=load_native();data=json.loads((BASE/'data/preconditioners.json').read_text());selected=json.loads((BASE/'data/local_representatives.json').read_text())
    # Includes purely radial seed directions and seed/anchor mixed directions.
    directions=[tuple(map(F,[1,1,1,1,0,0,0,0])),tuple(map(F,[1,-1,-1,1,1,-1,1,-1])),tuple(F(x,4) for x in (1,-2,3,-4,-3,1,4,-2))]
    directions.append(tuple(map(F,[0,0,0,0,1,-1,1,-1])))
    count=zero=0;records=[];exact_coefficients={}
    for idx in selected:
        rec=data[idx]
        for di,direction in enumerate(directions):
            H=make_model(rec['root'],direction)
            for res in rec['rows']:
                truth=residual(H,res);zero+=truth.c[0]==ZERO
                exact_coefficients[f'{idx}/{di}/{res}']=[[str(x) for x in co.v] for co in truth.c]
                assert truth.c[0]==ZERO,('reference value',idx,res,truth.c[0].v)
                native=[[F(0),F(0)] for _ in range(ORDER+1)]
                for k,e in ex.items():
                    fac=math.prod(d**n for d,n in zip(direction,e));l,h=coeff[idx,res,k]
                    lo,hi=(fac*l,fac*h) if fac>=0 else (fac*h,fac*l)
                    degree=sum(e);native[degree][0]+=lo;native[degree][1]+=hi
                for degree,(v,(l,h)) in enumerate(zip(truth.c,native)):
                    lo,hi=enclosure(v)
                    assert l<=lo<=hi<=h,('directional coefficient outside',idx,di,res,degree,[str(x) for x in (l,lo,hi,h)])
                    count+=1
            records.append({'reference':idx,'direction':di,'selected_residuals':len(rec['rows']),'status':'PASS'})
            print('PASS',idx,di,'elapsed',round(time.monotonic()-start,2),flush=True)
    result={'status':'PASS_INDEPENDENT_EXACT_DIRECTIONAL_JETS','field':'Q(i,sqrt(3))','derivative_order':ORDER,'references':len(selected),'directions':len(directions),'residual_direction_pairs':len(records)*8,'coefficient_checks':count,'zero_reference_values':zero,'wall_seconds':time.monotonic()-start,'records':records,'scope':'Exact regression/audit tests, not a separate full-ball verifier.'}
    (ROOT/'independent_jets.json').write_text(json.dumps(result,indent=2)+'\n')
    (ROOT/'exact_directional_coefficients.json').write_text(json.dumps(exact_coefficients,sort_keys=True)+'\n')
if __name__=='__main__':main()
