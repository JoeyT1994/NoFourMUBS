#!/usr/bin/env python3
"""Supplementary independent point controls of weighted global model enclosures.
This is not a full-cover replay or a proof of all absolute remainder bounds.
"""
from pathlib import Path
from fractions import Fraction as F
import argparse,json,os,sys,time,subprocess,hashlib,math
if not __debug__:raise RuntimeError('Python optimization is prohibited')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--package',type=Path,required=True);ap.add_argument('--work',type=Path,required=True);ap.add_argument('--cells',type=Path,required=True);ap.add_argument('--compiler',default='clang++');ap.add_argument('--reuse-export',action='store_true');a=ap.parse_args();P=a.package.resolve();W=a.work.resolve();W.mkdir(parents=True,exist_ok=True);start=time.monotonic()
 for line in (P/'MANIFEST.sha256').read_text().splitlines():
  h,n=line.split(None,1);assert sha(P/n.strip())==h
 os.environ['CENTIRADIAN_PACKAGE']=str(P);os.environ['CENTIRADIAN_AUDIT_ROOT']=str(W)
 import independent_tails as it
 from mpmath import iv
 native=W/'native_weighted.txt'
 if not a.reuse_export:
  subprocess.run([a.compiler,'-O3','-std=c++17','-fno-fast-math','-ffp-contract=off','-DPOLY_DEG=12','-DGLOBAL_WEIGHTED','-I',str(P),str(Path(__file__).with_name('export_weighted.cpp')),'-o',str(W/'export_weighted')],check=True)
  subprocess.run([str(W/'export_weighted'),str(P/'data/determinant_words.txt'),str(P/'data/preconditioners.txt'),str(a.cells),str(native)],check=True)
 ex={};params={};coeff={};tails={}
 with native.open() as f:
  for line in f:
   s=line.split();tag=s[0]
   if tag=='B':assert int(s[1])==975
   elif tag=='E':ex[int(s[1])]=tuple(map(int,s[2:]))
   elif tag=='X':
    i,g=int(s[1]),int(s[2]);path=s[3];roots=tuple(map(int,s[4:8]));radii=tuple(F(float.fromhex(x)) for x in s[8:12]);params[i]=(g,'' if path=='-' else path,roots,radii)
   elif tag=='P':key=(int(s[1]),int(s[2]));tails[key]=F(float.fromhex(s[3]));coeff[key]=[]
   elif tag=='C':
    key=(int(s[1]),int(s[2]));k=int(s[3]);assert k==len(coeff[key]);coeff[key].append(tuple(F(float.fromhex(x)) for x in s[4:6]))
   else:raise ValueError(tag)
 assert len(ex)==975 and all(len(v)==975 for v in coeff.values())
 directions=[tuple(map(F,v)) for v in [(0,)*8,(1,)*8,(-1,)*8,(1,-1,-1,1,1,-1,1,-1),(1,1,1,1,0,0,0,0),(0,0,0,0,1,-1,1,-1),(1,-1,1,-1,0,0,0,0)]]
 directions.append(tuple(F(v,4) for v in [1,-2,3,-4,-3,1,4,-2]))
 factors=[[math.prod(x**n for x,n in zip(v,ex[k])) for k in range(975)] for v in directions]
 RHO=F(float.fromhex('0x1.999999999999bp-5'));checks=0;worst=F(0)
 def phase(ri,t):return it.ROOTS[ri%6]*it.C(iv.cos(t),iv.sin(t))
 def model(par,xi):
  grid,path,roots,radii=par;idx=[0]*4;lev=[0]*4
  for depth,bit in enumerate(path):j=depth%4;idx[j]=2*idx[j]+int(bit);lev[j]+=1
  E=[[it.C(1) for j in range(3)] for i in range(3)]
  for i in range(1,3):
   for j in range(1,3):E[i][j]=phase(2*i*j,it.real(RHO*xi[(i-1)*2+j-1]))
  z=[]
  for j in range(4):
   den=1<<lev[j];num=2*idx[j]+1-den
   angle=iv.pi*it.real(F(num,6*den))+it.real(radii[j]*xi[j+4]);z.append(phase(roots[j],angle))
  B=it.side(E,z[:2]);Ct=it.side(list(map(list,zip(*E))),z[2:]);C=list(map(list,zip(*Ct)))
  D=it.matmul(it.matmul(C,it.adj(E)),it.inverse(it.adj(B)))
  return [E[i]+B[i] for i in range(3)]+[C[i]+[-v for v in D[i]] for i in range(3)]
 for i,par in sorted(params.items()):
  for di,xi in enumerate(directions):
   H=model(par,xi)
   for key,c in coeff.items():
    if key[0]!=i:continue
    lo=hi=F(0)
    for fac,(l,h) in zip(factors[di],c):
     if fac>=0:lo+=fac*l;hi+=fac*h
     else:lo+=fac*h;hi+=fac*l
    val=it.residual(H,key[1]);vl,vh=(it.frac_mpf(x) for x in val._mpi_);tau=tails[key]
    assert lo-tau<=vl<=vh<=hi+tau,('weighted enclosure failed',key,di,str(lo-tau),str(vl),str(vh),str(hi+tau))
    distance=max(F(0),lo-vl,vh-hi)
    if tau:worst=max(worst,distance/tau)
    checks+=1
  print('PASS weighted point case',i,'checks',checks,flush=True)
 report={'status':'PASS_WEIGHTED_MODEL_POINT_ENCLOSURES_NOT_A_UNIFORM_PROOF','cells':len(params),'residuals_per_cell':len(coeff)//len(params),'points_per_cell':len(directions),'checks':checks,'native_backend':'weights (2,2,2,2,3,3,3,3), cutoff 12, absolute tail','independent_value_backend':'mpmath.iv 100 decimal digits; direct full B inverse and literal 48-word signed determinant','max_tested_fraction_of_absolute_tail_ceiling_1e6':str(F(-(-worst.numerator*1000000//worst.denominator),1000000)),'wall_seconds':time.monotonic()-start,'package_manifest_sha256':sha(P/'MANIFEST.sha256'),'cells_sha256':sha(a.cells),'export_sha256':sha(native),'scope':'Finite point controls of actual global model enclosures. Not an independent proof of every coefficient, remainder, or terminal. Sample ratios do not justify reducing any uniform tail.'}
 (W/'WEIGHTED_POINT_AUDIT.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n');print(json.dumps(report,indent=2))
if __name__=='__main__':main()
