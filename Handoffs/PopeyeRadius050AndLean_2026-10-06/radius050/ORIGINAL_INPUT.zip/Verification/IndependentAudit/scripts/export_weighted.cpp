#define main original_engine_main
#include "engine.cpp"
#undef main
int main(int argc,char**argv){try{
 guards();if(argc!=5)throw std::runtime_error("words matrices cells output");readwords(argv[1]);readmat(argv[2]);
 std::ifstream in(argv[3]);std::ofstream out(argv[4]);out<<std::hexfloat;
 out<<"B "<<pb.n<<"\n";for(int k=0;k<pb.n;k++){out<<"E "<<k;for(int e:pb.ex[k])out<<" "<<e;out<<"\n";}
 int grid,id=0;std::string path;
 while(in>>grid>>path){if(path=="-")path="";Cell cell{grid,path};array<I,4>mid;array<double,4>rad,ext;geometry(cell,mid,rad,ext);auto g=GRID.at(grid);
  out<<"X "<<id<<" "<<grid<<" "<<(path.empty()?"-":path);for(int x:g)out<<" "<<x;for(double x:rad)out<<" "<<x;out<<"\n";
  array<C<PM>,4>u,z;for(int j=0;j<4;j++){u[j]=phasePM(0,I(0),RHO,j);z[j]=phasePM(g[j],mid[j],rad[j],j+4);}auto H=model(u,z);
  for(int r:{0,4,8,9,10,11,12,13,23,35,47,59,71,83,93}){auto f=getres(H,r);out<<"P "<<id<<" "<<r<<" "<<f.tail<<"\n";for(int k=0;k<pb.n;k++)out<<"C "<<id<<" "<<r<<" "<<k<<" "<<f.a[k].lo<<" "<<f.a[k].hi<<"\n";}
  id++;
 }
 if(!in.eof()||!out)throw std::runtime_error("I/O error");std::cout<<id<<" cells exported\n";
}catch(const std::exception&e){std::cerr<<e.what()<<"\n";return 2;}return 0;}
