#define main original_engine_main
#include "engine.cpp"
#undef main
int main(int argc,char**argv){try{
 guards(); if(argc!=5)throw std::runtime_error("words matrices selected output");readwords(argv[1]);readmat(argv[2]);
 std::ifstream pick(argv[3]);std::ofstream out(argv[4]);out<<std::hexfloat;
 out<<"B "<<pb.n<<"\n";for(int k=0;k<pb.n;k++){out<<"E "<<k;for(int v:pb.ex[k])out<<" "<<v;out<<"\n";}
 int n;while(pick>>n){auto m=MAT.at(n);array<C<PM>,4>u,z;for(int k=0;k<4;k++){u[k]=phasePM(0,I(0),RHO,k);z[k]=phasePM(m.roots[k],I(0),DELTA,k+4);}auto H=model(u,z);
 for(int j=0;j<8;j++){auto f=getres(H,m.rows[j]);out<<"P "<<n<<" "<<m.rows[j]<<" "<<f.tail<<"\n";for(int k=0;k<pb.n;k++)out<<"C "<<n<<" "<<m.rows[j]<<" "<<k<<" "<<f.a[k].lo<<" "<<f.a[k].hi<<"\n";}}
 if(!pick.eof()||!out)throw std::runtime_error("I/O");
}catch(const std::exception&e){std::cerr<<e.what()<<"\n";return 2;}return 0;}
