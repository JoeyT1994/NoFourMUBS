#!/usr/bin/env python3
"""Independent exact binary-tree and coordinate check (not residual acceptance)."""
import argparse,gzip,json,time,hashlib
from pathlib import Path
from fractions import Fraction as F
from itertools import product
if not __debug__:raise RuntimeError('Python optimization is prohibited.')

def audit(path):
 start=time.monotonic();by={};n=0
 with gzip.open(path,'rt') as file:
  for line in file:
   a=json.loads(line);root=tuple(x%6 for x in a['root']);word=a['path']
   assert len(root)==4 and isinstance(word,str) and set(word)<={'0','1'}
   assert type(a['degree']) is int and a['degree'] in (6,12)
   assert type(a['kind']) is int and a['kind']>0
   by.setdefault(root,[]).append(word);n+=1
 allcells=set(product((5,0,1),range(6),(5,0,1),range(6)))
 def orbit(x):
  seen={x};todo=[x]
  while todo:
   a,b,c,d=todo.pop()
   for y in [(c,d,a,b),(-b,-a,-c,-d),(-a,-b,-d,-c)]:
    y=tuple(v%6 for v in y)
    if y not in seen:seen.add(y);todo.append(y)
  return seen
 covered=set()
 for root in by:
  assert root in allcells
  group=orbit(root)&allcells;assert covered.isdisjoint(group);covered|=group
 assert covered==allcells and len(by)==102
 leaves=internal=comparisons=0
 for root,words in by.items():
  trie={}
  for word in words:
   node=trie
   for bit in word:
    assert 'leaf' not in node;node=node.setdefault(bit,{})
   assert not node;node['leaf']=True
   center=[F(0) for _ in range(4)];radius=[F(1) for _ in range(4)];index=[0]*4;level=[0]*4
   for depth,bit in enumerate(word):
    j=depth%4;radius[j]/=2;center[j]+=(1 if bit=='1' else -1)*radius[j];index[j]=2*index[j]+int(bit);level[j]+=1
   for j in range(4):
    assert center[j]==F(2*index[j]+1-(1<<level[j]),1<<level[j])
    assert radius[j]==F(1,1<<level[j]);comparisons+=1
  todo=[trie]
  while todo:
   node=todo.pop()
   if 'leaf' in node:assert set(node)=={'leaf'};leaves+=1
   else:assert set(node)=={'0','1'};internal+=1;todo.extend((node['0'],node['1']))
 assert leaves==n and internal==n-len(by)
 return {'status':'PASS_INDEPENDENT_COVER_GEOMETRY_NOT_RESIDUAL_REPLAY','representative_roots':len(by),'initial_cells':len(allcells),'terminal_boxes':n,'internal_nodes':internal,'coordinate_comparisons':comparisons,'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'wall_seconds':time.monotonic()-start}

def main():
 p=argparse.ArgumentParser();p.add_argument('--cover',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();r=audit(a.cover);a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
if __name__=='__main__':main()
