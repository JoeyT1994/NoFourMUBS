#!/usr/bin/env python3
"""Reproduce supplemental exact directional and outward remainder audits."""
from pathlib import Path
import argparse,subprocess,hashlib,json,os,sys,shutil,time
if not __debug__:raise RuntimeError('Python optimization is prohibited.')
HERE=Path(__file__).resolve().parent

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--package',required=True,type=Path);ap.add_argument('--work',required=True,type=Path);ap.add_argument('--compiler',default=os.environ.get('CXX','c++'));a=ap.parse_args()
 p=a.package.resolve();w=a.work.resolve();w.mkdir(parents=True,exist_ok=True)
 checked=0
 for line in (p/'MANIFEST.sha256').read_text().splitlines():
  h,name=line.split(None,1);f=(p/name.strip()).resolve()
  if not f.is_relative_to(p) or hashlib.sha256(f.read_bytes()).hexdigest()!=h:raise ValueError('package hash mismatch')
  checked+=1
 compiler=shutil.which(a.compiler)
 if not compiler:raise RuntimeError('C++ compiler unavailable')
 flags=['-O3','-std=c++17','-fno-fast-math','-ffp-contract=off','-DPOLY_DEG=6']
 version=subprocess.run([compiler,'--version'],capture_output=True,text=True,check=True).stdout
 if 'clang' not in version.lower():flags.insert(1,'-fno-tree-vrp')
 start=time.monotonic();binary=w/'export_models'
 subprocess.run([compiler,*flags,'-I'+str(p),str(HERE/'export_models.cpp'),'-o',str(binary)],check=True)
 selected=json.loads((p/'data/local_representatives.json').read_text());assert len(selected)==13
 (w/'selected.txt').write_text(''.join(str(i)+'\n' for i in selected))
 subprocess.run([str(binary),str(p/'data/determinant_words.txt'),str(p/'data/preconditioners.txt'),str(w/'selected.txt'),str(w/'native_models.txt')],check=True)
 env=dict(os.environ,CENTIRADIAN_AUDIT_ROOT=str(w),CENTIRADIAN_PACKAGE=str(p))
 for name in ['independent_jets.py','independent_tails.py']:
  subprocess.run([sys.executable,'-B',str(HERE/name)],env=env,check=True)
 report={'status':'PASS_SUPPLEMENTARY_CHECKS_NOT_A_FULL_PROOF','package_manifest_entries':checked,'package_manifest_sha256':hashlib.sha256((p/'MANIFEST.sha256').read_bytes()).hexdigest(),'compiler':version,'wall_seconds':time.monotonic()-start,'jets':json.loads((w/'independent_jets.json').read_text()),'tails':json.loads((w/'independent_tails.json').read_text())}
 (w/'SUMMARY.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'status':report['status'],'summary':str(w/'SUMMARY.json')}))
if __name__=='__main__':main()
